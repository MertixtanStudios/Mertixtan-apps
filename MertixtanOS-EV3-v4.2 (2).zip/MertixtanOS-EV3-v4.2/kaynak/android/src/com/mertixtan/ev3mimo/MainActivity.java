package com.mertixtan.ev3mimo;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.text.InputFilter;
import android.text.InputType;
import android.view.View;
import android.view.WindowInsets;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public final class MainActivity extends Activity {
    private static final int SPEECH = 17;
    private static final int PORT = 9765;
    private static final int BACKGROUND = Color.rgb(15, 22, 26);
    private static final int PANEL = Color.rgb(28, 40, 45);
    private static final int TEXT = Color.rgb(235, 244, 243);
    private static final int MUTED = Color.rgb(177, 198, 197);
    private static final int ACCENT = Color.rgb(143, 237, 203);

    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private EditText ip, pin, question;
    private TextView answer;
    private Button send;
    private Button mode;
    private boolean ai = true;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(BACKGROUND);
        getWindow().setNavigationBarColor(BACKGROUND);

        ScrollView screen = new ScrollView(this);
        screen.setBackgroundColor(BACKGROUND);
        screen.setFillViewport(true);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(22), dp(24), dp(22), dp(28));
        screen.addView(root);
        if (Build.VERSION.SDK_INT >= 30) {
            root.setOnApplyWindowInsetsListener((v, insets) -> {
                android.graphics.Insets sides = insets.getInsets(WindowInsets.Type.systemBars() | WindowInsets.Type.displayCutout());
                v.setPadding(dp(22) + sides.left, dp(22) + sides.top, dp(22) + sides.right, dp(28) + sides.bottom);
                return insets;
            });
        }
        setContentView(screen);

        TextView title = text("MIMO EV3", 32, TEXT);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        root.addView(title);
        row(root, text("EV3’de Telefon menüsünü aç ve ekrandaki IP ile kodu gir.", 16, MUTED), 8);

        ip = input("EV3 IP adresi", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI, 15, true);
        ip.setText(getPreferences(MODE_PRIVATE).getString("robot-ip", ""));
        row(root, ip, 22);
        pin = input("10 haneli bağlantı kodu", InputType.TYPE_CLASS_NUMBER, 10, true);
        row(root, pin, 9);

        mode = button("EV3 TinyTurk", false);
        mode.setOnClickListener(v -> {
            ai = !ai;
            mode.setText(ai ? "EV3 TinyTurk" : "MIMO Mini ve hafıza");
        });
        row(root, mode, 9);

        Button speak = button("Konuş", true);
        speak.setOnClickListener(v -> listen());
        row(root, speak, 20);
        question = input("Komutu yaz veya konuş", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES, 180, false);
        row(root, question, 10);

        send = button("EV3’e gönder", false);
        send.setOnClickListener(v -> sendQuestion());
        row(root, send, 10);
        answer = text("EV3 yanıtı burada görünecek.", 16, MUTED);
        answer.setPadding(dp(16), dp(14), dp(16), dp(14));
        answer.setBackground(background(PANEL));
        answer.setTextIsSelectable(true);
        row(root, answer, 18);

        if (state != null) {
            ip.setText(state.getString("ip", ""));
            pin.setText(state.getString("pin", ""));
            question.setText(state.getString("question", ""));
            answer.setText(state.getString("answer", ""));
            ai = state.getBoolean("ai", true);
            mode.setText(ai ? "EV3 TinyTurk" : "MIMO Mini ve hafıza");
        }
    }

    @Override protected void onSaveInstanceState(Bundle state) {
        state.putBoolean("ai", ai);
        state.putString("ip", ip.getText().toString());
        state.putString("pin", pin.getText().toString());
        state.putString("question", question.getText().toString());
        state.putString("answer", answer.getText().toString());
        super.onSaveInstanceState(state);
    }

    private void listen() {
        Intent request = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        request.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        request.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "tr-TR");
        request.putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true);
        request.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1);
        request.putExtra(RecognizerIntent.EXTRA_PROMPT, "MIMO’ya ne sormak istiyorsun?");
        try { startActivityForResult(request, SPEECH); }
        catch (ActivityNotFoundException e) { answer.setText("Telefonunda konuşma tanıma bulunamadı. Komutu yazabilirsin."); }
    }

    @Override protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request, result, data);
        if (request != SPEECH || result != RESULT_OK || data == null) return;
        ArrayList<String> words = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
        if (words == null || words.isEmpty()) return;
        question.setText(words.get(0));
        answer.setText("Komutu kontrol et ve EV3’e gönder.");
    }

    private void sendQuestion() {
        String host = ip.getText().toString().trim();
        String code = pin.getText().toString().trim();
        String message = question.getText().toString().replaceAll("\\p{Cntrl}+", " ").trim();
        byte[] address = localAddress(host);
        if (address == null) { answer.setText("EV3 ekranındaki yerel IPv4 adresini gir."); return; }
        if (!code.matches("[0-9]{10}")) { answer.setText("Bağlantı kodu 10 haneli olmalı."); return; }
        byte[] packet = ((ai ? "MIMO/AI " : "MIMO/1 ") + code + "\n" + message + "\n").getBytes(StandardCharsets.UTF_8);
        if (message.isEmpty() || packet.length > 4096) { answer.setText("Daha kısa bir komut gir."); return; }
        getPreferences(MODE_PRIVATE).edit().putString("robot-ip", host).apply();
        send.setEnabled(false);
        answer.setText("EV3’e bağlanıyor…");
        executor.execute(() -> {
            String messageBack;
            try (Socket socket = new Socket()) {
                socket.connect(new InetSocketAddress(InetAddress.getByAddress(address), PORT), 3500);
                socket.setSoTimeout(75000);
                socket.getOutputStream().write(packet);
                socket.getOutputStream().flush();
                messageBack = readAnswer(socket.getInputStream());
            } catch (IOException e) {
                messageBack = "EV3’e ulaşılamadı. Telefon menüsünü ve ağ bağlantısını kontrol et.";
            }
            final String result = messageBack;
            runOnUiThread(() -> {
                if (!isDestroyed()) { answer.setText(result); send.setEnabled(true); }
            });
        });
    }

    private static String readAnswer(InputStream stream) throws IOException {
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        while (bytes.size() < 4096) {
            int b = stream.read();
            if (b == '\n' && bytes.size() > 0) return new String(bytes.toByteArray(), StandardCharsets.UTF_8);
            if (b < 0) break;
            bytes.write(b);
        }
        throw new IOException("Sınır dışında EV3 yanıtı");
    }

    private static byte[] localAddress(String address) {
        if (!address.matches("[0-9]{1,3}(\\.[0-9]{1,3}){3}")) return null;
        String[] fields = address.split("\\.");
        int a = Integer.parseInt(fields[0]);
        int b = Integer.parseInt(fields[1]);
        if (!(a == 10 || a == 172 && b >= 16 && b <= 31 || a == 192 && b == 168 || a == 169 && b == 254)) return null;
        byte[] raw = new byte[4];
        for (int i = 0; i < fields.length; i++) {
            int part = Integer.parseInt(fields[i]);
            if (part > 255) return null;
            raw[i] = (byte) part;
        }
        return raw;
    }

    private TextView text(String label, int size, int color) {
        TextView t = new TextView(this);
        t.setText(label); t.setTextSize(size); t.setTextColor(color);
        return t;
    }

    private EditText input(String hint, int type, int limit, boolean singleLine) {
        EditText e = new EditText(this);
        e.setHint(hint); e.setTextColor(TEXT); e.setHintTextColor(MUTED);
        e.setTextSize(16); e.setInputType(type); e.setSingleLine(singleLine);
        e.setFilters(new InputFilter[]{new InputFilter.LengthFilter(limit)});
        e.setPadding(dp(15), dp(12), dp(15), dp(12)); e.setMinHeight(dp(50));
        e.setBackground(background(PANEL));
        return e;
    }

    private Button button(String label, boolean primary) {
        Button b = new Button(this);
        b.setText(label); b.setAllCaps(false); b.setTextSize(17); b.setMinHeight(dp(48));
        b.setTextColor(primary ? BACKGROUND : TEXT);
        b.setBackground(background(primary ? ACCENT : PANEL));
        return b;
    }

    private GradientDrawable background(int color) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color); d.setCornerRadius(dp(14));
        return d;
    }

    private void row(LinearLayout box, View view, int margin) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.topMargin = dp(margin);
        box.addView(view, p);
    }

    private int dp(int n) { return Math.round(n * getResources().getDisplayMetrics().density); }

    @Override protected void onDestroy() {
        executor.shutdownNow();
        super.onDestroy();
    }
}
