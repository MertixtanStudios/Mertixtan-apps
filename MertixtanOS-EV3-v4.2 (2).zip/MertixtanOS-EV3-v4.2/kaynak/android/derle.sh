#!/bin/sh
set -eu
: "${ANDROID_JAR:?ANDROID_JAR is required}"
: "${ANDROID_BUILD_TOOLS:?ANDROID_BUILD_TOOLS is required}"
cd "$(dirname "$0")"
mkdir -p build/classes build/dex
java -m jdk.compiler/com.sun.tools.javac.Main -source 8 -target 8 -encoding UTF-8 -classpath "$ANDROID_JAR" -d build/classes $(find src -name '*.java')
java -cp "$ANDROID_BUILD_TOOLS/lib/d8.jar" com.android.tools.r8.D8 --min-api 24 --lib "$ANDROID_JAR" --output build/dex $(find build/classes -name '*.class')
"$ANDROID_BUILD_TOOLS/aapt2" link -I "$ANDROID_JAR" --manifest AndroidManifest.xml -o build/mimo-base.apk
python3 - <<'PY'
import zipfile
with zipfile.ZipFile('build/mimo-base.apk','a',zipfile.ZIP_DEFLATED) as z:
    z.write('build/dex/classes.dex','classes.dex')
PY
"$ANDROID_BUILD_TOOLS/zipalign" -f 4 build/mimo-base.apk build/mimo-imzasiz.apk
