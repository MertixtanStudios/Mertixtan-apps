// TinyTurk v2.7d CPU inference. Weight layout: tinyturk_export.py.
#include <math.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
enum { D=128, V=512, T=128, H=32, L=4 };
typedef struct { float scale[V]; int8_t *w; float bias[V]; int rows, cols; } Matrix;
typedef struct { Matrix qkv, proj, up, down, micro_up, micro_down; float norms[3][D]; } Layer;
static Matrix emb;
static Layer layers[L];
static float final_norm[D], keys[L][T][D], values[L][T][D], cs[T][16], sn[T][16];
static char tok[V][64];
static void get(FILE *f,void *p,size_t n) { if(fread(p,1,n,f)!=n) { fputs("Invalid TinyTurk weights\n",stderr); exit(2); } }
static void load_matrix(FILE *f, Matrix *m, int r, int c, int bias) {
    m->rows=r; m->cols=c; m->w=malloc((size_t)r*c);
    if(!m->w) exit(2);
    get(f,m->scale,4*r); get(f,m->w,(size_t)r*c); if(bias)get(f,m->bias,4*r);
}
static void linear(float *y, const Matrix *m,const float *x) {
    int16_t a[V]; float peak=1e-12f;
    for(int i=0;i<m->cols;i++) if(fabsf(x[i])>peak)peak=fabsf(x[i]);
    float inv=2047.0f/peak;
    for(int i=0;i<m->cols;i++)a[i]=(int16_t)(x[i]*inv);
    for(int j=0;j<m->rows;j++){
        int accum=0; const int8_t *w=m->w+j*m->cols;
        for(int i=0;i<m->cols;i++)accum+=w[i]*a[i];
        y[j]=accum*(peak/2047.0f)*m->scale[j]+m->bias[j];
    }
}
static void norm(float *y,const float *x,const float *w){
    float s=0;for(int i=0;i<D;i++)s+=x[i]*x[i];
    s=1.0f/sqrtf(s/D+1e-6f);
    for(int i=0;i<D;i++)y[i]=x[i]*s*w[i];
}
static void feed(float *x,float *a,const Matrix *up,const Matrix *down,float gate){
    float z[V], out[D];
    linear(z,up,a);
    for(int i=0;i<up->rows;i++)z[i]=0.5f*z[i]*(1.0f+erff(z[i]*0.70710678f));
    linear(out,down,z);
    for(int i=0;i<D;i++)x[i]+=out[i]*gate;
}
static void forward(int token,int p,float *logits){
    float x[D], a[D], qkv[3*D], context[D], probs[T], out[D];
    for(int i=0;i<D;i++)x[i]=emb.w[token*D+i]*emb.scale[token];
    for(int l=0;l<L;l++){
        Layer *b=layers+l;
        norm(a,x,b->norms[0]);linear(qkv,&b->qkv,a);
        float *q=qkv,*k=qkv+D,*v=qkv+2*D;
        for(int i=0;i<D;i+=2){
            float c=cs[p][(i%H)/2],s=sn[p][(i%H)/2],u=q[i], vq=q[i+1],u2=k[i],v2=k[i+1];
            q[i]=u*c-vq*s;q[i+1]=u*s+vq*c;
            k[i]=u2*c-v2*s;k[i+1]=u2*s+v2*c;
        }
        memcpy(keys[l][p],k,sizeof(a));memcpy(values[l][p],v,sizeof(a)); memset(context,0,sizeof(context));
        for(int h=0;h<D;h+=H){
            float peak=-INFINITY,sum=0;
            for(int j=0;j<=p;j++){
                float score=0;for(int i=h;i<h+H;i++)score+=q[i]*keys[l][j][i];
                probs[j]=score*0.176776695f;if(probs[j]>peak)peak=probs[j];
            }
            for(int j=0;j<=p;j++){probs[j]=expf(probs[j]-peak);sum+=probs[j];}
            for(int j=0;j<=p;j++){
                float weight=probs[j]/sum;
                for(int i=h;i<h+H;i++)context[i]+=weight*values[l][j][i];
            }
        }
        linear(out,&b->proj,context);for(int i=0;i<D;i++)x[i]+=out[i];
        norm(a,x,b->norms[1]);feed(x,a,&b->up,&b->down,1);
        norm(a,x,b->norms[2]);feed(x,a,&b->micro_up,&b->micro_down,0.75f);
    }
    norm(a,x,final_norm);linear(logits,&emb,a);
}
static int lookup(const char *s,size_t n){
    for(int i=3;i<V;i++)if(strlen(tok[i])==n&&!memcmp(s,tok[i],n))return i;
    return 0;
}
static int encode(const char *s,int *ids){
    char text[1024]="▁";size_t len=strlen(text);
    int tokens[1024],n=0;
    for(;*s&&len<sizeof(text)-4;s++){
        if(*s==' '||*s=='\t'||*s=='\n'){if(len==3||!memcmp(text+len-3,"▁",3))continue;memcpy(text+len,"▁",3);len+=3;}
        else text[len++]=*s;
    }
    for(size_t i=0;i<len;){
        unsigned char c=text[i]; size_t bytes=c<128?1:(c<224?2:(c<240?3:4));
        if(bytes>len-i)break;
        tokens[n++]=lookup(text+i,bytes);i+=bytes;
    }
    for(;;){
        int best=-1,rank=V;char word[130];
        for(int i=0;i+1<n;i++){
            if(tokens[i]<3||tokens[i+1]<3)continue;
            snprintf(word,sizeof(word),"%s%s",tok[tokens[i]],tok[tokens[i+1]]);
            int id=lookup(word,strlen(word));
            if(id&&id<rank){rank=id;best=i;}
        }
        if(best<0)break;
        tokens[best]=rank;memmove(tokens+best+1,tokens+best+2,(size_t)(n-best-2)*sizeof(int));n--;
    }
    if(n>88){memmove(tokens,tokens+n-88,88*sizeof(int));n=88;}
    ids[0]=1;memcpy(ids+1,tokens,(size_t)n*sizeof(int));return n+1;
}
static void print_token(int i){
    const char *s=tok[i];
    for(;*s;){
        if(!strncmp(s,"▁",3)){putchar(' ');s+=3;}
        else putchar((unsigned char)*s++);
    }
}
int main(int argc,char **argv){
    if(argc!=4)return 2;
    FILE *f=fopen(argv[1],"rb");if(!f){perror("TinyTurk");return 2;}
    char magic[8];get(f,magic,8);if(memcmp(magic,"MXTRQ8\1\0",8))return 2;
    load_matrix(f,&emb,V,D,0);
    for(int i=0;i<L;i++){
        Layer *b=layers+i;
        get(f,b->norms[0],4*D);load_matrix(f,&b->qkv,3*D,D,1);load_matrix(f,&b->proj,D,D,1);
        get(f,b->norms[1],4*D);load_matrix(f,&b->up,V,D,1);load_matrix(f,&b->down,D,V,1);
        get(f,b->norms[2],4*D);load_matrix(f,&b->micro_up,256,D,1);load_matrix(f,&b->micro_down,D,256,1);
    }
    get(f,final_norm,4*D);fclose(f);
    f=fopen(argv[2],"r");if(!f){perror("Tokenizer");return 2;}
    for(int i=0;i<V;i++){
        if(!fgets(tok[i],sizeof(tok[i]),f))return 2;
        tok[i][strcspn(tok[i],"\t\r\n")]=0;
    }
    fclose(f);
    for(int p=0;p<T;p++)for(int i=0;i<16;i++){float a=p*powf(10000.0f,-i/16.0f);sn[p][i]=sinf(a);cs[p][i]=cosf(a);}
    int ids[T],n=encode(argv[3],ids);float logits[V];int token=0;
    for(int p=0;p<n+28 && p<T;p++){
        if(p<n) token=ids[p];
        else{
            for(int i=3;i<V;i++)if(logits[i]>logits[token])token=i;
            if(token<3)break;
            ids[p]=token;print_token(token);
        }
        forward(token,p,logits);
        token=2;
        for(int j=p;j>=0&&j>p-16;j--) if(ids[j]>=3) logits[ids[j]]-=1.5f;
        if(p>=n && strchr(".!?",tok[ids[p]][0]) && p-n>=5)break;
    }
    putchar('\n');return 0;
}
