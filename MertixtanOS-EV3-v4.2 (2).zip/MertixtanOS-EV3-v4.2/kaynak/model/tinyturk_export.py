"""Convert the pinned TinyTurk FloatStorage checkpoint to row-wise signed int8.

Run: python3 tinyturk_export.py pytorch_model.bin tinyturk.q8
Requires NumPy. Only checkpoint metadata constructors needed by this model
are accepted. Tensor storage bytes are read directly from the ZIP.
"""
import collections
import io
import math
import pickle
import struct
import sys
import zipfile
from pathlib import Path

import numpy as np


class Reader(pickle.Unpickler):
    def find_class(self, module, name):
        entries = {
            ("collections", "OrderedDict"): collections.OrderedDict,
            ("torch", "FloatStorage"): "FloatStorage",
            ("torch._utils", "_rebuild_tensor_v2"): self.tensor,
        }
        if (module, name) not in entries:
            raise pickle.UnpicklingError(f"Unexpected constructor: {module}.{name}")
        return entries[module, name]

    def persistent_load(self, value):
        kind, dtype, key, _device, count = value
        if kind != "storage" or dtype != "FloatStorage" or not key.isdigit():
            raise ValueError("Unsupported tensor storage")
        return np.frombuffer(self.archive.read(f"pytorch_model/data/{key}"), dtype="<f4", count=count)

    @staticmethod
    def tensor(data, offset, shape, stride, *_):
        expected_stride = tuple(math.prod(shape[i + 1:]) for i in range(len(shape)))
        if tuple(stride) != expected_stride:
            raise ValueError("Non-contiguous tensor")
        return data[offset:offset + math.prod(shape)].reshape(shape)


def pack(checkpoint, output):
    with zipfile.ZipFile(checkpoint) as archive:
        rd = Reader(io.BytesIO(archive.read("pytorch_model/data.pkl")))
        rd.archive = archive
        model = rd.load()
    cfg = model["config"]
    for k, value in dict(d_model=128, n_layers=4, n_heads=4, vocab_size=512, d_ff=512,
                         context_length=128, micro_gate=0.75, rms_norm_eps=1e-6).items():
        if cfg[k] != value:
            raise ValueError(f"Unexpected {k}: {cfg[k]}")
    w = model["model_state_dict"]
    with Path(output).open("wb") as out:
        out.write(b"MXTRQ8\x01\x00")

        def vector(key, n):
            a = w[key]
            if a.shape != (n,):
                raise ValueError(key)
            out.write(a.astype("<f4").tobytes())

        def matrix(key, rows, cols, bias=True):
            a = w[key + ".weight"]
            if a.shape != (rows, cols):
                raise ValueError(key)
            scales = np.maximum(np.abs(a).max(axis=1), np.float32(1e-12)) / np.float32(127)
            out.write(scales.astype("<f4").tobytes())
            out.write(np.rint(a / scales[:, None]).clip(-127, 127).astype("i1").tobytes())
            if bias:
                vector(key + ".bias", rows)

        matrix("embedding.token_embedding", 512, 128, False)
        for i in range(4):
            p = f"blocks.{i}."
            vector(p + "ln_attn.weight", 128)
            matrix(p + "attention.qkv", 384, 128)
            matrix(p + "attention.out_proj", 128, 128)
            vector(p + "ln_mlp.weight", 128)
            matrix(p + "mlp.fc_in", 512, 128)
            matrix(p + "mlp.fc_out", 128, 512)
            vector(p + "ln_micro.weight", 128)
            matrix(p + "micro_mlp.fc_in", 256, 128)
            matrix(p + "micro_mlp.fc_out", 128, 256)
        vector("final_norm.weight", 128)


if __name__ == "__main__":
    pack(*sys.argv[1:])
