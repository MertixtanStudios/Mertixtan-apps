use crate::ev3::Brick;

pub const QUESTIONS: [&str; 10] = ["Merhaba", "Önüm açık mı?", "Motorlar", "Sensörler", "Pil", "Dur", "Rust döngüsü", "Günlük plan", "Adım ne?", "Ne hatırlıyorsun?"];

const EXAMPLES: &[(usize, &str)] = &[
    (0, "merhaba selam günaydın nasılsın kimsin mimo"),
    (1, "önüm açık mı engel mesafe uzaklık yakın kaç santim"),
    (2, "motorlar port kol bacak ayak motor sayısı"),
    (3, "sensörler hangi sensör bağlı dokunma renk"),
    (4, "pil batarya şarj volt pilim güç seviye"),
    (5, "dur durdur stop"),
    (6, "rust kod örnek döngü for while tekrar yazdır programlama"),
    (7, "günlük plan ders ödev çalışma zaman mola bugün"),
    (8, "rust değişken fonksiyon fn let mut parametre örneği"),
    (9, "su içmek uyku dinlenme mola yorgun"),
    (10, "dosya kaydet not aç nerede masaüstü nasıl"),
];

pub(crate) fn fold(c: char) -> char {
    match c.to_ascii_lowercase() {
        'ç' | 'Ç' => 'c', 'ğ' | 'Ğ' => 'g', 'ı' | 'İ' => 'i', 'ö' | 'Ö' => 'o',
        'ş' | 'Ş' => 's', 'ü' | 'Ü' => 'u', c => c,
    }
}

pub(crate) fn normalize(s: &str) -> String {
    s.chars().take(240).map(fold)
        .map(|c| if c.is_ascii_alphanumeric() { c } else { ' ' }).collect()
}

fn classify(text: &str) -> Option<usize> {
    let words: Vec<_> = text.split_whitespace().filter(|w| w.len() >= 3 && !["var", "bir", "icin"].contains(w)).collect();
    let mut ranked = None;
    for &(intent, example) in EXAMPLES {
        let example = normalize(example);
        let score: usize = words.iter().map(|w| example.split_whitespace().filter_map(|t| {
            if *w == t { Some(4) }
            else if t.len() >= 3 && w.starts_with(t) { Some(2) }
            else { None }
        }).max().unwrap_or(0)).sum();
        if score >= 2 && ranked.is_none_or(|(best, _)| score > best) { ranked = Some((score, intent)); }
    }
    ranked.map(|(_, intent)| intent)
}

pub fn answer(question: &str, brick: &mut Brick) -> String {
    let text = normalize(question);
    let hafiza = crate::memory::directory();
    if let Some(cevap) = crate::memory::reply(&hafiza, question, &text) { return cevap; }
    let ad = crate::memory::name(&hafiza);
    match text.split_whitespace().collect::<Vec<_>>().join(" ").as_str() {
        "nasilsin" | "iyi misin" => return "İyiyim, sohbet etmeye hazırım. Sen nasılsın?".into(),
        "iyiyim" | "ben de iyiyim" => return "Buna sevindim! Bugün ne yaptın?".into(),
        "tesekkurler" | "sag ol" | "tesekkur ederim" => return "Rica ederim!".into(),
        "gorusuruz" | "hosca kal" => return "Görüşürüz!".into(),
        _ => {}
    }
    let intent = if ["dur", "durdur", "stop", "hemen dur"].contains(&text.trim()) { Some(5) }
        else { classify(&text).filter(|group| *group != 5) };
    match intent {
        Some(0) => if ad.is_empty() { "Merhaba! Ben MIMO Mini. Adın ne?".into() } else { format!("Merhaba {ad}! Bugün nasılsın?") },
        Some(1) => brick.sensors().iter().flatten().find_map(|s| s.distance())
            .map_or("Geçerli ultrasonik ölçüm yok.".into(), |cm| format!("Öndeki ölçüm: {cm:.0} cm.")),
        Some(2) => format!("{} EV3 motoru görüyorum.", brick.motor_count()),
        Some(3) => format!("{} sensör bağlı.", brick.sensors().iter().flatten().count()),
        Some(4) => brick.battery().map_or("Pil ölçümü yok.".into(), |v| format!("Pil: {:.1} volt.", v as f64 / 1_000_000.0)),
        Some(5) => format!("Durdurma yollandı. {} motor yanıt verdi.", brick.stop_all()),
        Some(6) => "Rust: for i in 1..=5 { println!(\"{}\", i); }".into(),
        Some(7) => "Önce bir hedef belirle. 25 dakika çalış, 5 dakika mola ver, sonra kontrol et.".into(),
        Some(8) => "Rust: fn iki_kati(x: i32) -> i32 { x * 2 }".into(),
        Some(9) => "Kısa bir mola ver ve hazır olduğunda kaldığın yerden devam et.".into(),
        Some(10) => "Notlar uygulamasında metni yaz, Geri menüsünden Kaydet'i seç.".into(),
        _ => "Bu soruyu eşleştiremedim. Örnekler: pil, motor, döngü, günlük plan.".into(),
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn matches_turkish_inflections_and_code_topics() {
        assert_eq!(classify(&normalize("Pilim kaç volt?")), Some(4));
        assert_eq!(classify(&normalize("Rust koduyla döngü yaz")), Some(6));
        assert_eq!(classify(&normalize("futbol")), None);
    }
}
