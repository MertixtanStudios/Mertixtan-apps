//! Sadece açıkça hatırlanması istenen bilgileri cihazda saklar.
use std::{env, fs, io, path::{Path, PathBuf}, sync::Mutex};

static LOCK: Mutex<()> = Mutex::new(());

pub fn directory() -> PathBuf {
    env::var_os("HOME").map(PathBuf::from).unwrap_or_else(|| "/home/robot".into())
        .join("MertixtanOS").join("mimo-hafiza")
}

fn read(root: &Path, key: &str) -> String {
    fs::read_to_string(root.join(key)).unwrap_or_default()
}

fn write(root: &Path, key: &str, value: &str) -> io::Result<()> {
    fs::create_dir_all(root)?;
    let temp = root.join(format!(".{key}-{}.tmp", std::process::id()));
    fs::write(&temp, value)?;
    fs::rename(temp, root.join(key))
}

fn prefix<'a>(mut text: &'a str, words: &str) -> Option<&'a str> {
    for expected in words.split_whitespace() {
        let (word, rest) = text.trim_start().split_once(char::is_whitespace)?;
        if !word.trim_end_matches([':', ',']).chars().map(super::mimo::fold).eq(expected.chars()) { return None; }
        text = rest;
    }
    let rest = text.trim().trim_matches(|c: char| matches!(c, ':' | ',' | '.')).trim();
    (!rest.is_empty()).then_some(rest)
}

pub fn name(root: &Path) -> String { read(root, "ad") }

pub fn reply(root: &Path, original: &str, normalized: &str) -> Option<String> {
    let _lock = LOCK.lock().ok()?;
    let words = normalized.split_whitespace().collect::<Vec<_>>().join(" ");
    match words.as_str() {
        "adim ne" | "benim adim ne" | "ismim ne" | "beni hatirliyor musun" | "beni tanidin mi" => {
            let ad = name(root);
            return Some(if ad.is_empty() { "Henüz adını bilmiyorum. “Adım Mert” gibi söyleyebilirsin.".into() }
                else { format!("Adın {ad}. Seni hatırlıyorum!") });
        }
        "ne hatirliyorsun" | "neleri hatirliyorsun" | "hafizani goster" | "beni ne kadar taniyorsun" => {
            let ad = read(root, "ad");
            let favori = read(root, "favori");
            let notlar = read(root, "notlar");
            let mut info = Vec::new();
            if !ad.is_empty() { info.push(format!("Adın: {ad}.")); }
            if !favori.is_empty() { info.push(format!("Sevdiğin şey: {favori}.")); }
            info.extend(notlar.lines().map(str::to_owned));
            return Some(if info.is_empty() { "Hafızam boş. “Bunu hatırla, robot yapmayı seviyorum” diyebilirsin.".into() }
                else { info.join(" ") });
        }
        "hafizayi sil" | "hafizani sil" | "beni unut" => {
            let sonuc = ["ad", "favori", "notlar"].into_iter().try_for_each(|key| {
                fs::remove_file(root.join(key)).or_else(|e| if e.kind() == io::ErrorKind::NotFound { Ok(()) } else { Err(e) })
            });
            return Some(if sonuc.is_ok() { "Kaydedilen bilgileri sildim." } else { "Hafızayı silemedim." }.into());
        }
        "en sevdigim sey ne" | "ben neyi severim" | "ne severim" => {
            let favori = read(root, "favori");
            return Some(if favori.is_empty() { "Henüz neyi sevdiğini bilmiyorum.".into() }
                else { format!("En sevdiğin şey {favori}.") });
        }
        _ => {}
    }
    let (key, content) = [
        ("ad", "benim adim"), ("ad", "adim"), ("ad", "ismim"),
        ("favori", "en sevdigim sey"), ("notlar", "bunu hatirla"), ("notlar", "aklinda tut"),
    ].into_iter().find_map(|(key, words)| prefix(original, words).map(|rest| (key, rest)))?;

    let value: String = content.chars()
        .filter(|c| !c.is_control()).take(if key == "ad" { 40 } else { 110 }).collect();
    if value.is_empty() { return Some("Hatırlamamı istediğin şeyi yaz.".into()); }
    let stored = if key == "notlar" {
        let eski = read(root, key);
        let satirlar: Vec<_> = eski.lines().filter(|s| *s != value).collect();
        satirlar.into_iter().rev().take(7).collect::<Vec<_>>().into_iter().rev()
            .chain(std::iter::once(value.as_str())).collect::<Vec<_>>().join("\n")
    } else { value.clone() };
    Some(if write(root, key, &stored).is_err() { "Bilgiyi EV3 hafızasına yazamadım.".into() }
        else if key == "ad" { format!("Tanıştığıma memnun oldum, {value}. Adını hatırlayacağım.") }
        else { format!("Hatırlayacağım: {value}.") })
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn remembers_turkish_text_across_reads_and_can_forget() {
        let path = env::temp_dir().join(format!("mx-v4-test-memory-{}", std::process::id()));
        let ask = |s| reply(&path, s, &crate::mimo::normalize(s)).unwrap();
        assert!(ask("Benim adım Çağrı.").contains("Çağrı"));
        assert_eq!(ask("Adım ne?"), "Adın Çağrı. Seni hatırlıyorum!");
        assert!(ask("Bunu hatırla, Robot yapmayı seviyorum").contains("Robot yapmayı seviyorum"));
        assert!(ask("Ne hatırlıyorsun?").contains("Robot yapmayı seviyorum"));
        assert_eq!(ask("Hafızayı sil"), "Kaydedilen bilgileri sildim.");
        assert!(ask("Adım ne?").contains("Henüz"));
        fs::remove_dir_all(path).unwrap();
    }
}
