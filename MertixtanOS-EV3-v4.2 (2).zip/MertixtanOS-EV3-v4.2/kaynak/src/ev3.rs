use std::{fs, io::{self, Read}, path::{Path, PathBuf}, sync::mpsc, thread, time::{Duration, Instant}};

fn read(path: &Path) -> Option<String> {
    fs::read_to_string(path).ok().map(|s| s.trim().to_owned())
}

fn devices(root: &Path, class: &str) -> impl Iterator<Item = PathBuf> {
    fs::read_dir(root.join(class)).into_iter().flatten().filter_map(Result::ok).map(|e| e.path())
}

fn port(address: &str) -> &str { address.rsplit(':').next().unwrap_or(address) }

pub struct Brick {
    root: PathBuf,
    active: Option<(PathBuf, Instant)>,
}

impl Brick {
    pub fn new(root: PathBuf) -> Self { Self { root, active: None } }

    fn motors(&self) -> impl Iterator<Item = (PathBuf, String)> + '_ {
        devices(&self.root, "tacho-motor").filter_map(|p| {
            let driver = read(&p.join("driver_name"))?;
            if !matches!(driver.as_str(), "lego-ev3-l-motor" | "lego-ev3-m-motor") { return None; }
            let address = read(&p.join("address"))?;
            Some((p, port(&address).into()))
        })
    }

    pub fn motor_count(&self) -> usize { self.motors().count() }

    pub fn motor_name(&self, output: char) -> Option<String> {
        let name = format!("out{output}");
        let (path, _) = self.motors().find(|(_, a)| a == &name)?;
        read(&path.join("driver_name")).map(|n| if n.contains("-l-") { "Büyük motor".into() } else { "Orta motor".into() })
    }

    pub fn pulse(&mut self, output: char, reverse: bool) -> io::Result<()> {
        self.stop_active();
        let name = format!("out{output}");
        let (p, _) = self.motors().find(|(_, a)| a == &name)
            .ok_or_else(|| io::Error::new(io::ErrorKind::NotFound, "EV3 motoru yok"))?;
        if !read(&p.join("commands")).is_some_and(|s| s.split_whitespace().any(|c| c == "run-timed")) {
            return Err(io::Error::new(io::ErrorKind::Unsupported, "run-timed"));
        }
        if read(&p.join("state")).is_some_and(|s| s.split_whitespace().any(|c| matches!(c, "running" | "ramping"))) {
            return Err(io::Error::new(io::ErrorKind::WouldBlock, "Motor zaten çalışıyor"));
        }
        fs::write(p.join("stop_action"), "brake")?;
        fs::write(p.join("speed_sp"), if reverse { "-120" } else { "120" })?;
        fs::write(p.join("time_sp"), "350")?;
        fs::write(p.join("command"), "run-timed")?;
        self.active = Some((p, Instant::now() + Duration::from_millis(350)));
        Ok(())
    }

    pub fn stop_active(&mut self) {
        if let Some((p, _)) = self.active.take() {
            let _ = fs::write(p.join("command"), "stop");
        }
    }

    pub fn tick(&mut self) {
        if self.active.as_ref().is_some_and(|(_, t)| Instant::now() >= *t) { self.stop_active(); }
    }

    pub fn stop_all(&mut self) -> usize {
        self.stop_active();
        self.motors().filter(|(p, _)| fs::write(p.join("command"), "stop").is_ok()).count()
    }

    pub fn sensors(&self) -> [Option<Sensor>; 4] {
        let mut result = [None, None, None, None];
        for p in devices(&self.root, "lego-sensor") {
            let Some(address) = read(&p.join("address")) else { continue };
            let index = match port(&address) { "in1" => 0, "in2" => 1, "in3" => 2, "in4" => 3, _ => continue };
            let Some(driver) = read(&p.join("driver_name")) else { continue };
            let mode = read(&p.join("mode")).unwrap_or_default();
            let raw = read(&p.join("value0")).and_then(|s| s.parse().ok());
            let units = read(&p.join("units")).unwrap_or_default();
            let decimals = read(&p.join("decimals")).and_then(|s| s.parse::<u32>().ok()).unwrap_or(0).min(4);
            result[index] = Some(Sensor { driver, mode, raw, units, decimals });
        }
        result
    }

    pub fn battery(&self) -> Option<i64> {
        devices(&self.root, "power_supply").filter(|p| p.file_name().is_some_and(|s| s.to_string_lossy().contains("battery")))
            .find_map(|p| read(&p.join("voltage_now"))?.parse().ok())
    }
}

impl Drop for Brick { fn drop(&mut self) { self.stop_active(); } }

pub struct Sensor {
    driver: String,
    mode: String,
    raw: Option<i32>,
    units: String,
    decimals: u32,
}

impl Sensor {
    pub fn label(&self) -> &str {
        match self.driver.as_str() {
            "lego-ev3-touch" => "Dokunma", "lego-ev3-us" => "Ultrasonik", "lego-ev3-color" => "Renk",
            "lego-ev3-ir" => "Kızılötesi", "lego-ev3-gyro" => "Jiroskop", _ => "Sensör",
        }
    }

    fn number(&self) -> Option<f64> { Some(f64::from(self.raw?) / f64::from(10u32.pow(self.decimals))) }

    pub fn value(&self) -> String {
        match (self.number(), self.driver.as_str(), self.mode.as_str()) {
            (Some(n), "lego-ev3-touch", _) => if n != 0.0 { "BASILI".into() } else { "SERBEST".into() },
            (Some(n), _, _) => format!("{:.*} {}", self.decimals as usize, n, self.units),
            _ => "Okunamadı".into(),
        }
    }

    pub fn distance(&self) -> Option<f64> {
        if self.driver != "lego-ev3-us" || self.mode != "US-DIST-CM" { return None; }
        self.number().filter(|&n| (0.0..255.0).contains(&n))
    }
}

#[derive(Clone, Copy)]
pub enum Key { Up, Down, Left, Right, Enter, Back }

pub fn buttons() -> io::Result<mpsc::Receiver<Key>> {
    let device = button_device(Path::new("/dev/input"), Path::new("/sys/class/input"))?;
    let mut f = fs::File::open(&device)
        .map_err(|e| io::Error::new(e.kind(), format!("EV3 tuşları ({}): {e}", device.display())))?;
    let (tx, rx) = mpsc::channel();
    thread::spawn(move || {
        // EV3 uses 32-bit Linux input_event: 8-byte timeval and 8-byte event.
        let mut event = [0u8; 16];
        while f.read_exact(&mut event).is_ok() {
            if u16::from_le_bytes([event[8], event[9]]) != 1 || event[12..16] != [1, 0, 0, 0] { continue; }
            let key = match u16::from_le_bytes([event[10], event[11]]) {
                103 => Key::Up, 108 => Key::Down, 105 => Key::Left, 106 => Key::Right,
                28 => Key::Enter, 14 => Key::Back, _ => continue,
            };
            if tx.send(key).is_err() { break; }
        }
    });
    Ok(rx)
}

fn button_device(dev: &Path, sys: &Path) -> io::Result<PathBuf> {
    for name in ["platform-gpio_keys-event", "platform-gpio-keys.0-event"] {
        let path = dev.join("by-path").join(name);
        if path.exists() { return Ok(path); }
    }
    for entry in fs::read_dir(sys)?.flatten() {
        let name = entry.file_name();
        if !name.to_string_lossy().starts_with("event") { continue; }
        let label = read(&entry.path().join("device/name"));
        if matches!(label.as_deref(), Some("gpio_keys" | "gpio-keys")) {
            return Ok(dev.join(name));
        }
    }
    Err(io::Error::new(io::ErrorKind::NotFound, "EV3 tuş aygıtı bulunamadı"))
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn discovers_ev3_buttons_by_device_label() {
        let root = std::env::temp_dir().join(format!("mertixtan-ev3-keys-{}", std::process::id()));
        let sys = root.join("sys");
        let dev = root.join("dev");
        for (event, label) in [("event0", "keyboard"), ("event2", "gpio_keys")] {
            let path = sys.join(event).join("device");
            fs::create_dir_all(&path).unwrap();
            fs::write(path.join("name"), label).unwrap();
        }
        assert_eq!(button_device(&dev, &sys).unwrap(), dev.join("event2"));
        fs::remove_dir_all(root).unwrap();
    }

    #[test]
    fn ev3_motor_and_sensor() {
        let root = std::env::temp_dir().join(format!("mertixtan-ev3-test-{}", std::process::id()));
        let _ = fs::remove_dir_all(&root);
        let motor = root.join("tacho-motor/motor0");
        let sensor = root.join("lego-sensor/sensor0");
        fs::create_dir_all(&motor).unwrap();
        fs::create_dir_all(&sensor).unwrap();
        for (k, v) in [("driver_name", "lego-ev3-l-motor"), ("address", "ev3-ports:outB"),
            ("commands", "run-timed stop"), ("state", "")] { fs::write(motor.join(k), v).unwrap(); }
        for (k, v) in [("driver_name", "lego-ev3-us"), ("address", "ev3-ports:in3"),
            ("mode", "US-DIST-CM"), ("value0", "145"), ("decimals", "1")] { fs::write(sensor.join(k), v).unwrap(); }
        let mut b = Brick::new(root.clone());
        assert_eq!(b.motor_count(), 1);
        assert_eq!(b.sensors()[2].as_ref().unwrap().distance(), Some(14.5));
        assert!(b.pulse('A', false).is_err());
        b.pulse('B', true).unwrap();
        assert_eq!(read(&motor.join("command")).unwrap(), "run-timed");
        assert_eq!(read(&motor.join("time_sp")).unwrap(), "350");
        assert_eq!(read(&motor.join("speed_sp")).unwrap(), "-120");
        b.stop_active();
        assert_eq!(read(&motor.join("command")).unwrap(), "stop");
        fs::remove_dir_all(root).unwrap();
    }
}
