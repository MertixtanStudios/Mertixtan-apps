use std::{io, process::Command};

const HELP: &[(&str, &str)] = &[
    ("mimo sohbet model", "Dil modeli: sağ okla yaz, = ile bitir, OK ile üret. Yukarı ve aşağı cevapta gezinir."),
    ("telefon android bluetooth", "Telefon menüsünde IP ve kod görünür. Android'de Cihaz Bağlantısı'na bunları gir."),
    ("motor kol bacak", "Hareket menüsünde sol ve sağ ok port seçer. İki OK basışı kısa motor testi yapar."),
    ("mikrofon ses", "USB Mikrofon menüsü öğretilmiş komutları tanır. Serbest dikte Android MIMO EV3 uygulamasındadır."),
    ("not dosya kaydet", "Notlar menüsünde yaz, ardından Kaydet'i seç. Dosyalar menüsünde notu açabilirsin."),
    ("pil şarj volt", "Bilgi ekranı veya MIMO Mini'nin Pil komutu robot pilini gösterir."),
];

pub fn search(q: &str) -> String {
    if let Some(query) = q.strip_prefix("google ") {
        return google(query).unwrap_or_else(|e| format!("Google: {e}"));
    }
    let query = crate::mimo::normalize(q);
    let results: Vec<_> = HELP.iter().filter(|(keys, _)| {
        let keys = crate::mimo::normalize(keys);
        query.split_whitespace().any(|word| keys.split_whitespace().any(|key| word == key))
    }).map(|(_, text)| *text).collect();
    if results.is_empty() { "Yerel sonuç yok. MIMO, pil, motor, mikrofon veya dosya yaz.".into() }
    else { results.join("\n") }
}

fn google(q: &str) -> io::Result<String> {
    use std::fmt::Write;
    if q.trim().is_empty() { return Err(io::Error::other("Arama metni boş")); }
    let mut url = "https://www.google.com/search?q=".to_owned();
    for b in q.bytes() {
        if b.is_ascii_alphanumeric() { url.push(char::from(b)); }
        else { let _ = write!(url, "%{b:02X}"); }
    }
    let result = Command::new("lynx").args(["-dump", "-nolist", "-width=40", "-connect_timeout=6", "-read_timeout=6", &url])
        .env("LC_ALL", "C.UTF-8").output().map_err(|e| {
            if e.kind() == io::ErrorKind::NotFound { io::Error::other("Çevrimiçi arama için EV3'te lynx gerekli") } else { e }
        })?;
    if !result.status.success() { return Err(io::Error::other("Arama açılamadı. Ağ bağlantısını kontrol et")); }
    let text: String = String::from_utf8_lossy(&result.stdout).trim().chars().take(1100).collect();
    if text.is_empty() { return Err(io::Error::other("Sonuç alınamadı")); }
    Ok(text)
}

#[cfg(test)]
mod tests {
    #[test]
    fn local_search_works_without_network() {
        assert!(super::search("mikrofon").contains("USB Mikrofon"));
        assert!(super::search("gezegen").contains("Yerel sonuç yok"));
    }
}
