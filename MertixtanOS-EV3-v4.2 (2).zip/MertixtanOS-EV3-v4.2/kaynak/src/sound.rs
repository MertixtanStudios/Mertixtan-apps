use std::{io::Write, process::{Command, Stdio}, sync::atomic::{AtomicBool, Ordering}, thread};

static BUSY: AtomicBool = AtomicBool::new(false);

pub fn say(text: &str) {
    if BUSY.swap(true, Ordering::AcqRel) { return; }
    let text = text.to_owned();
    thread::spawn(move || {
        let ok = speech(&text).unwrap_or(false);
        if !ok {
            let beep = Command::new("/usr/bin/beep").args(["-f", "700", "-l", "120"])
                .stdin(Stdio::null()).stdout(Stdio::null()).stderr(Stdio::null()).status();
            if !beep.is_ok_and(|s| s.success()) { let _ = pcm_tone(); }
        }
        BUSY.store(false, Ordering::Release);
    });
}

fn speech(text: &str) -> std::io::Result<bool> {
    let mut speaker = Command::new("espeak").args(["--stdout", "-v", "tr", "--", text])
        .stdout(Stdio::piped()).stderr(Stdio::null()).spawn()?;
    let pcm = speaker.stdout.take().expect("pipe configured");
    let played = Command::new("aplay").arg("-q").stdin(pcm).stdout(Stdio::null()).stderr(Stdio::null()).status();
    let made = speaker.wait()?;
    Ok(made.success() && played?.success())
}


fn pcm_tone() -> std::io::Result<()> {
    let mut player = Command::new("aplay").args(["-q", "-t", "raw", "-f", "S16_LE", "-r", "8000", "-c", "1"])
        .stdin(Stdio::piped()).stdout(Stdio::null()).stderr(Stdio::null()).spawn()?;
    let mut samples = [0u8; 1920];
    for (i, sample) in samples.chunks_exact_mut(2).enumerate() {
        let level = (i.min(959 - i).min(64) as i16) * 24;
        let wave = if (i * 1400 / 8000) % 2 == 0 { level } else { -level };
        sample.copy_from_slice(&wave.to_le_bytes());
    }
    let result = player.stdin.take().expect("pipe configured").write_all(&samples);
    let _ = player.wait();
    result
}
