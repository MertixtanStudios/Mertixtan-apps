use std::{fs::{self, File, OpenOptions}, io::{self, Seek, SeekFrom, Write}, path::Path};

pub const WIDTH: usize = 178;
pub const HEIGHT: usize = 128;
const STRIDE: usize = 24;

const FONT: &[(char, [u8; 7])] = &[
    ('A',[14,17,17,31,17,17,17]),('B',[30,17,17,30,17,17,30]),('C',[14,17,16,16,16,17,14]),
    ('D',[30,17,17,17,17,17,30]),('E',[31,16,16,30,16,16,31]),('F',[31,16,16,30,16,16,16]),
    ('G',[14,17,16,23,17,17,14]),('H',[17,17,17,31,17,17,17]),('I',[14,4,4,4,4,4,14]),
    ('J',[7,2,2,2,18,18,12]),('K',[17,18,20,24,20,18,17]),('L',[16,16,16,16,16,16,31]),
    ('M',[17,27,21,21,17,17,17]),('N',[17,25,21,19,17,17,17]),('O',[14,17,17,17,17,17,14]),
    ('P',[30,17,17,30,16,16,16]),('Q',[14,17,17,17,21,18,13]),('R',[30,17,17,30,20,18,17]),
    ('S',[15,16,16,14,1,1,30]),('T',[31,4,4,4,4,4,4]),('U',[17,17,17,17,17,17,14]),
    ('V',[17,17,17,17,17,10,4]),('W',[17,17,17,21,21,27,17]),('X',[17,17,10,4,10,17,17]),
    ('Y',[17,17,10,4,4,4,4]),('Z',[31,1,2,4,8,16,31]),
    ('0',[14,17,19,21,25,17,14]),('1',[4,12,4,4,4,4,14]),('2',[14,17,1,2,4,8,31]),
    ('3',[30,1,1,14,1,1,30]),('4',[2,6,10,18,31,2,2]),('5',[31,16,16,30,1,1,30]),
    ('6',[14,16,16,30,17,17,14]),('7',[31,1,2,4,8,8,8]),('8',[14,17,17,14,17,17,14]),
    ('9',[14,17,17,15,1,1,14]),('-',[0,0,0,31,0,0,0]),('.',[0,0,0,0,0,0,4]),
    (':',[0,0,4,0,4,0,0]),('?', [14,17,1,2,4,0,4]),('!',[4,4,4,4,4,0,4]),('>',[16,8,4,2,4,8,16]),
    ('<',[1,2,4,8,4,2,1]),('/',[1,1,2,4,8,16,16]),('+',[0,4,4,31,4,4,0]),('=',[0,0,31,0,31,0,0]),
];

fn latin(ch: char) -> char {
    match ch {
        'ç' | 'Ç' => 'C', 'ğ' | 'Ğ' => 'G', 'ı' | 'İ' => 'I', 'ö' | 'Ö' => 'O',
        'ş' | 'Ş' => 'S', 'ü' | 'Ü' => 'U', c => c.to_ascii_uppercase(),
    }
}

pub struct Frame(pub [u8; STRIDE * HEIGHT]);

impl Frame {
    pub fn new() -> Self { Self([0; STRIDE * HEIGHT]) }

    fn pixel(&mut self, x: usize, y: usize, black: bool) {
        if x >= WIDTH || y >= HEIGHT { return; }
        let b = &mut self.0[y * STRIDE + x / 8];
        let mask = 1 << (x % 8);
        if black { *b |= mask; } else { *b &= !mask; }
    }

    fn xrgb8888(&self, output: &mut [u8], stride: usize) {
        for (source, target) in self.0.chunks_exact(STRIDE).zip(output.chunks_exact_mut(stride)) {
            for (x, pixel) in target[..WIDTH * 4].chunks_exact_mut(4).enumerate() {
                let level = if source[x / 8] & (1 << (x % 8)) == 0 { 255 } else { 0 };
                pixel.copy_from_slice(&[level, level, level, 0]);
            }
        }
    }

    pub fn box_fill(&mut self, x: usize, y: usize, w: usize, h: usize, black: bool) {
        for yy in y..(y + h).min(HEIGHT) { for xx in x..(x + w).min(WIDTH) { self.pixel(xx, yy, black); } }
    }

    pub fn text(&mut self, x: usize, y: usize, s: &str, size: usize, black: bool) {
        for (i, ch) in s.chars().take(WIDTH.saturating_sub(x) / (6 * size)).enumerate() {
            let Some((_, glyph)) = FONT.iter().find(|(c, _)| *c == latin(ch)) else { continue };
            for (row, bits) in glyph.iter().enumerate() {
                for col in 0..5 {
                    if bits & (16 >> col) != 0 {
                        self.box_fill(x + (i * 6 + col) * size, y + row * size, size, size, black);
                    }
                }
            }
        }
    }

    pub fn pbm(&self, path: &Path) -> io::Result<()> {
        let mut f = File::create(path)?;
        write!(f, "P4\n{WIDTH} {HEIGHT}\n")?;
        let mut line = [0u8; WIDTH.div_ceil(8)];
        for row in self.0.chunks_exact(STRIDE) {
            for (i, v) in line.iter_mut().enumerate() { *v = row[i].reverse_bits(); }
            f.write_all(&line)?;
        }
        Ok(())
    }
}

pub enum Lcd {
    Mono(File),
    Xrgb { map: *mut u8, stride: usize, pixels: Vec<u8> },
}

unsafe extern "C" {
    fn mmap(addr: *mut u8, len: usize, prot: i32, flags: i32, fd: i32, offset: std::ffi::c_long) -> *mut u8;
    fn munmap(addr: *mut u8, len: usize) -> i32;
}

impl Lcd {
    pub fn open() -> io::Result<Self> {
        use std::os::fd::AsRawFd;
        const PROT_READ_WRITE: i32 = 3;
        const MAP_SHARED: i32 = 1;
        let size = fs::read_to_string("/sys/class/graphics/fb0/virtual_size")?;
        let bpp = fs::read_to_string("/sys/class/graphics/fb0/bits_per_pixel")?;
        let stride = fs::read_to_string("/sys/class/graphics/fb0/stride")?;
        let stride = stride.trim().parse::<usize>().unwrap_or(0);
        if size.trim() != "178,128" {
            return Err(io::Error::new(io::ErrorKind::Unsupported, format!("EV3 LCD boyutu desteklenmiyor: {}", size.trim())));
        }
        match bpp.trim() {
            "1" if stride == STRIDE => Ok(Self::Mono(OpenOptions::new().write(true).open("/dev/fb0")?)),
            "32" if (WIDTH * 4..=4096).contains(&stride) => {
                let file = OpenOptions::new().read(true).write(true).open("/dev/fb0")?;
                let len = stride * HEIGHT;
                // The mapping keeps the framebuffer alive after the descriptor is closed.
                let map = unsafe { mmap(std::ptr::null_mut(), len, PROT_READ_WRITE, MAP_SHARED, file.as_raw_fd(), 0) };
                if map as usize == usize::MAX { return Err(io::Error::last_os_error()); }
                Ok(Self::Xrgb { map, stride, pixels: vec![0; len] })
            }
            _ => Err(io::Error::new(io::ErrorKind::Unsupported, format!("EV3 LCD biçimi desteklenmiyor: {} bit, satır {} bayt", bpp.trim(), stride))),
        }
    }

    pub fn draw(&mut self, img: &Frame) -> io::Result<()> {
        match self {
            Self::Mono(file) => {
                file.seek(SeekFrom::Start(0))?;
                file.write_all(&img.0)
            }
            Self::Xrgb { map, stride, pixels } => {
                img.xrgb8888(pixels, *stride);
                // The mapping is writable and has exactly pixels.len() bytes.
                unsafe { std::ptr::copy_nonoverlapping(pixels.as_ptr(), *map, pixels.len()); }
                Ok(())
            }
        }
    }
}

impl Drop for Lcd {
    fn drop(&mut self) {
        if let Self::Xrgb { map, pixels, .. } = self {
            unsafe { munmap(*map, pixels.len()); }
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn xrgb_preserves_pixel_positions_and_row_padding() {
        let mut frame = Frame::new();
        frame.pixel(WIDTH - 1, 0, true);
        frame.pixel(0, 1, true);
        let stride = WIDTH * 4 + 8;
        let mut output = vec![0x55; stride * HEIGHT];
        frame.xrgb8888(&mut output, stride);
        assert_eq!(&output[..4], &[255, 255, 255, 0]);
        assert_eq!(&output[WIDTH * 4 - 4..WIDTH * 4], &[0; 4]);
        assert_eq!(&output[WIDTH * 4..stride], &[0x55; 8]);
        assert_eq!(&output[stride..stride + 8], &[0, 0, 0, 0, 255, 255, 255, 0]);
    }
}
