use crate::{ev3::Brick, mimo};
use std::{
    fs::File,
    io::{self, Read, Write},
    net::{Ipv4Addr, SocketAddr, TcpListener, TcpStream},
    path::PathBuf,
    process::Command,
    sync::{Arc, atomic::{AtomicBool, Ordering}},
    thread,
    time::{Duration, Instant},
};

const PORT: u16 = 9765;
const LIMIT: usize = 4096;

fn local(ip: Ipv4Addr) -> bool { ip.is_private() || ip.is_link_local() || ip.is_loopback() }

pub struct Phone {
    pub pin: String,
    pub addresses: Vec<Ipv4Addr>,
    stop: Arc<AtomicBool>,
    pub response: std::sync::mpsc::Receiver<String>,
}

impl Phone {
    pub fn start(audio: bool) -> io::Result<Self> {
        let mut random = [0u8; 8];
        File::open("/dev/urandom")?.read_exact(&mut random)?;
        let pin = format!("{:010}", u64::from_ne_bytes(random) % 10_000_000_000);
        let addresses = Command::new("hostname").arg("-I").output().ok().into_iter()
            .flat_map(|o| String::from_utf8_lossy(&o.stdout).split_whitespace().filter_map(|s| s.parse().ok()).collect::<Vec<_>>())
            .filter(|ip: &Ipv4Addr| local(*ip) && !ip.is_loopback()).collect();
        let listener = TcpListener::bind((Ipv4Addr::UNSPECIFIED, PORT))?;
        listener.set_nonblocking(true)?;
        let stop = Arc::new(AtomicBool::new(false));
        let worker_stop = stop.clone();
        let worker_pin = pin.clone();
        let (tx, response) = std::sync::mpsc::sync_channel(4);
        thread::Builder::new().name("mimo-phone".into()).spawn(move || {
            let mut brick = Brick::new(PathBuf::from("/sys/class"));
            while !worker_stop.load(Ordering::Acquire) {
                match listener.accept() {
                    Ok((mut stream, SocketAddr::V4(peer))) if local(*peer.ip()) => {
                        let result = read_question(&mut stream, &worker_pin);
                        if worker_stop.load(Ordering::Acquire) { break; }
                        let answer = match result {
                            Ok(("MIMO/1", q)) => {
                                let answer = mimo::answer(&q, &mut brick);
                                let _ = tx.try_send(answer.clone());
                                if audio { crate::sound::say(&answer); }
                                answer
                            }
                            Ok(("MIMO/AI", q)) => {
                                let answer = crate::language::generate(&q).unwrap_or_else(|e| e.to_string());
                                let _ = tx.try_send(answer.clone());
                                if audio { crate::sound::say(&answer); }
                                answer
                            }
                            Ok(("MIMO/GOSTER", q)) => {
                                let _ = tx.try_send(q.clone());
                                if audio { crate::sound::say(&q); }
                                "EV3 ekranına gönderildi.".into()
                            }
                            Ok(_) => "İstek desteklenmiyor.".into(),
                            Err(_) => "Kod veya istek geçersiz.".to_owned(),
                        };
                        let _ = stream.set_write_timeout(Some(Duration::from_secs(1)));
                        let _ = writeln!(stream, "{answer}");
                    }
                    Ok(_) => {}
                    Err(e) if e.kind() == io::ErrorKind::WouldBlock => thread::sleep(Duration::from_millis(60)),
                    Err(_) => break,
                }
            }
        })?;
        Ok(Self { pin, addresses, stop, response })
    }
}

impl Drop for Phone {
    fn drop(&mut self) { self.stop.store(true, Ordering::Release); }
}

fn read_question(stream: &mut TcpStream, pin: &str) -> io::Result<(&'static str,String)> {
    let end = Instant::now() + Duration::from_secs(2);
    let mut request = Vec::new();
    let mut chunk = [0u8; 128];
    while request.len() < LIMIT {
        let remaining = end.saturating_duration_since(Instant::now());
        if remaining.is_zero() { break; }
        stream.set_read_timeout(Some(remaining))?;
        let n = stream.read(&mut chunk)?;
        if n == 0 { break; }
        request.extend_from_slice(&chunk[..n]);
        if request.iter().filter(|&&b| b == b'\n').count() >= 2 { break; }
    }
    parse(&request, pin).map(|(mode, q)| (mode, q.to_owned())).ok_or_else(|| io::Error::new(io::ErrorKind::InvalidData, "MIMO request"))
}

fn parse<'a>(packet: &'a [u8], pin: &str) -> Option<(&'static str, &'a str)> {
    if packet.len() > LIMIT { return None; }
    let s = std::str::from_utf8(packet).ok()?.strip_suffix('\n')?;
    let (head, question) = s.split_once('\n')?;
    let (mode, code) = head.split_once(' ')?;
    let mode = match mode { "MIMO/1" => "MIMO/1", "MIMO/AI" => "MIMO/AI", "MIMO/GOSTER" => "MIMO/GOSTER", _ => return None };
    if code.len() != pin.len() || code.bytes().zip(pin.bytes()).fold(0u8, |v, (a, b)| v | a ^ b) != 0 {
        return None;
    }
    if question.trim().is_empty() || question.chars().any(char::is_control) { return None; }
    Some((mode, question))
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn rejects_bad_code_and_extra_commands() {
        assert_eq!(parse(b"MIMO/1 0123456789\nPil?\n", "0123456789"), Some(("MIMO/1", "Pil?")));
        assert!(parse(b"MIMO/1 0123456789\nPil?\n", "0123456780").is_none());
        assert!(parse(b"MIMO/1 0123456789\nPil?\nDur\n", "0123456789").is_none());
        assert!(parse(b"MIMO/1 0123456789\nPil?", "0123456789").is_none());
    }
}
