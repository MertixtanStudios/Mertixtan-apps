use std::{fs, io, path::PathBuf, process::{Command, Stdio}};

const BLOCKS: usize = 20;
type Profile = [[f32; 2]; BLOCKS];
pub const COMMANDS: [&str; 4] = ["Pil", "Sensörler", "Önüm açık mı?", "Dur"];

fn profile_path(index: usize) -> PathBuf {
    let home = std::env::var_os("HOME").map(PathBuf::from).unwrap_or_else(|| "/home/robot".into());
    home.join("MertixtanOS").join(format!("ses-{index}.csv"))
}

fn device() -> io::Result<String> {
    let cards = fs::read_to_string("/proc/asound/pcm")?;
    for line in cards.lines() {
        if !line.contains("capture") { continue; }
        let Some((ids, _)) = line.split_once(':') else { continue };
        let Some((card, pcm)) = ids.trim().split_once('-') else { continue };
        if fs::read_to_string(format!("/proc/asound/card{}/usbid", card.parse::<u32>().unwrap_or(u32::MAX))).is_err() { continue; }
        return Ok(format!("plughw:{},{}", card.parse::<u32>().unwrap_or(0), pcm.parse::<u32>().unwrap_or(0)));
    }
    Err(io::Error::new(io::ErrorKind::NotFound, "USB ses kartı/mikrofon bulunamadı"))
}

pub fn connected() -> bool { device().is_ok() }

fn capture() -> io::Result<Profile> {
    let dev = device()?;
    let output = Command::new("arecord")
        .args(["-q", "-D", &dev, "-t", "raw", "-f", "S16_LE", "-c", "1", "-r", "8000", "-d", "2"])
        .stdin(Stdio::null()).output()?;
    if !output.status.success() {
        return Err(io::Error::other("Mikrofon kaydı açılamadı"));
    }
    let pcm: Vec<i16> = output.stdout.chunks_exact(2).map(|b| i16::from_le_bytes([b[0], b[1]])).collect();
    let peak = pcm.iter().map(|s| (*s as i32).unsigned_abs()).max().unwrap_or(0);
    if peak < 300 { return Err(io::Error::other("Ses çok düşük")); }
    let present = |s: &i16| (*s as i32).unsigned_abs() >= peak / 10;
    let start = pcm.iter().position(present).ok_or_else(|| io::Error::other("Ses bulunamadı"))?;
    let end = pcm.iter().rposition(present).unwrap() + 1;
    if end - start < BLOCKS * 8 { return Err(io::Error::other("Komut çok kısa")); }
    let mut out = [[0.0; 2]; BLOCKS];
    for (i, o) in out.iter_mut().enumerate() {
        let samples = &pcm[start + (end-start)*i/BLOCKS..start + (end-start)*(i+1)/BLOCKS];
        o[0] = samples.iter().map(|s| (*s as i32).unsigned_abs() as f32).sum::<f32>() / (samples.len() as f32 * peak as f32);
        o[1] = samples.windows(2).filter(|p| (p[0] < 0) != (p[1] < 0)).count() as f32 / samples.len() as f32;
    }
    Ok(out)
}

pub fn enroll(index: usize) -> io::Result<String> {
    let p = capture()?;
    let path = profile_path(index);
    if let Some(dir) = path.parent() { fs::create_dir_all(dir)?; }
    let lines: String = p.iter().map(|[a,b]| format!("{a:.4},{b:.4}\n")).collect();
    fs::write(path, lines)?;
    Ok(format!("Kaydedildi: {}", COMMANDS[index]))
}

pub fn recognize() -> io::Result<&'static str> {
    let p = capture()?;
    let mut scores = Vec::new();
    for (i, &label) in COMMANDS.iter().enumerate() {
        let Ok(raw) = fs::read_to_string(profile_path(i)) else { continue };
        let values: Vec<(f32,f32)> = raw.lines().filter_map(|line| {
            let (a, b) = line.split_once(',')?;
            Some((a.parse().ok()?, b.parse().ok()?))
        }).collect();
        if values.len() != BLOCKS { continue; }
        let score = p.iter().zip(values).map(|([a,b], (c,d))| (*a-c).abs() + 2.0*(*b-d).abs()).sum::<f32>() / BLOCKS as f32;
        if score.is_finite() { scores.push((score, label)); }
    }
    scores.sort_by(|a,b| a.0.total_cmp(&b.0));
    let Some(&(best, label)) = scores.first() else { return Err(io::Error::other("Önce ses örneği kaydet")); };
    if best > 0.16 || scores.get(1).is_some_and(|second| second.0 - best < 0.025) {
        return Err(io::Error::other("Komut net anlaşılmadı"));
    }
    Ok(label)
}
