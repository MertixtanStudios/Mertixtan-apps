use std::{env, io, process::Command, sync::Mutex};

static RUNNING: Mutex<()> = Mutex::new(());

pub fn generate(prompt: &str) -> io::Result<String> {
    let _running = RUNNING.try_lock().map_err(|_| io::Error::other("Model başka bir yanıt üretiyor"))?;
    let bin = env::current_exe()?;
    let dir = bin.parent().ok_or_else(|| io::Error::other("Model klasörü yok"))?;
    let prompt: String = prompt.trim().chars().filter(|c| !c.is_control()).take(180).collect();
    if prompt.is_empty() { return Err(io::Error::other("Önce bir metin yaz")); }
    let output = Command::new(dir.join("tinyturk-ev3"))
        .current_dir(dir).args(["tinyturk.q8", "tinyturk.vocab", &prompt]).output()
        .map_err(|e| io::Error::new(e.kind(), format!("TinyTurk: {e}")))?;
    if !output.status.success() { return Err(io::Error::other("TinyTurk ağırlıkları açılamadı")); }
    let text = String::from_utf8_lossy(&output.stdout).trim().to_owned();
    if text.is_empty() { return Err(io::Error::other("Model boş yanıt verdi. Başka bir başlangıç yaz.")); }
    Ok(text)
}
