mod ev3;
mod lcd;
mod mic;
mod mimo;
mod phone;
mod sound;

use ev3::{Brick, Key};
use lcd::{Frame, Lcd};
use std::{env, io, path::{Path, PathBuf}, sync::mpsc::RecvTimeoutError, time::{Duration, Instant}};

const MENU: [&str; 12] = ["MIMO Mini", "Hareket", "Sensörler", "Bilgi", "Ses", "Telefon", "Mikrofon", "Notlar", "Hesap", "Dil modeli", "Dosyalar", "Çıkış"];
const ROLES: [&str; 4] = ["SOL KOL", "SOL BACAK", "SAG BACAK", "SAG KOL"];
const ALPHABET: [&str; 6] = ["abcdefg", "ğhıijklm", "noöpqrs", "ştuüvwyz", "01234567", "89 +-*/."];
const PORTS: [char; 4] = ['A', 'B', 'C', 'D'];

#[derive(Clone, Copy)]
enum Page { Home, Mimo, Motor, Sensors, Info, Sound, Phone, Mic, Notes, Calc, Model, Files }

struct App {
    page: Page,
    index: usize,
    port: usize,
    reverse: bool,
    armed: Option<Instant>,
    audio: bool,
    status: String,
    phone: Option<phone::Phone>,
    draft: String,
    note: String,
    row: usize,
    col: usize,
    edit: bool,
    story: Option<std::sync::mpsc::Receiver<io::Result<String>>>,
    mic_job: Option<std::sync::mpsc::Receiver<io::Result<(String, bool)>>>,
}

impl App {
    fn new() -> Self {
        Self { page: Page::Home, index: 0, port: 0, reverse: false, armed: None,
            audio: true, status: String::new(), phone: None,
            draft: String::new(), note: std::fs::read_to_string(note_path()).unwrap_or_default(),
            row: 0, col: 0, edit: false, story: None, mic_job: None }
    }

    fn key(&mut self, key: Key, brick: &mut Brick) -> bool {
        if self.edit {
            let rows: &[&str] = if matches!(self.page, Page::Calc) { &["0123456789", "+-*/"] } else { &ALPHABET };
            match key {
                Key::Back => { self.edit = false; self.index = 0; }
                Key::Up => self.row = (self.row + rows.len() - 1) % rows.len(),
                Key::Down => self.row = (self.row + 1) % rows.len(),
                Key::Left => self.col = self.col.saturating_sub(1),
                Key::Right => self.col = (self.col + 1).min(rows[self.row].chars().count() - 1),
                Key::Enter if self.draft.chars().count() < 240 => {
                    if let Some(c) = rows[self.row].chars().nth(self.col) { self.draft.push(c); }
                }
                _ => {}
            }
            self.col = self.col.min(rows[self.row].chars().count() - 1);
            return true;
        }
        if let Key::Back = key {
            brick.stop_active();
            self.phone = None;
            if matches!(self.page, Page::Home) { return false; }
            self.page = Page::Home;
            self.index = 0;
            self.armed = None;
            self.status.clear();
            return true;
        }
        match self.page {
            Page::Home => match key {
                Key::Up => self.index = self.index.saturating_sub(2),
                Key::Down => self.index = (self.index + 2).min(MENU.len() - 1),
                Key::Left => self.index = self.index.saturating_sub(1),
                Key::Right => self.index = (self.index + 1).min(MENU.len() - 1),
                Key::Enter => {
                    self.page = match self.index {
                        0 => Page::Mimo, 1 => Page::Motor, 2 => Page::Sensors, 3 => Page::Info, 4 => Page::Sound, 5 => Page::Phone, 6 => Page::Mic, 7 => Page::Notes, 8 => Page::Calc, 9 => Page::Model, 10 => Page::Files, _ => return false,
                    };
                    self.index = 0;
                    self.status.clear();
                    if matches!(self.page, Page::Phone) { self.start_phone(); }
                    self.draft = if matches!(self.page, Page::Notes) { self.note.clone() } else { String::new() };
                    self.row = 0;
                    self.col = 0;
                }
                _ => {}
            },
            Page::Mimo => match key {
                Key::Right => { self.edit = true; self.draft.clear(); }
                Key::Up => { self.index = self.index.saturating_sub(1); self.status.clear(); }
                Key::Down => { self.index = (self.index + 1).min(mimo::QUESTIONS.len() - 1); self.status.clear(); }
                Key::Enter if !self.draft.is_empty() => {
                    self.status = mimo::answer(&std::mem::take(&mut self.draft), brick);
                    if self.audio { sound::say(&self.status); }
                }
                Key::Enter => {
                    self.status = mimo::answer(mimo::QUESTIONS[self.index], brick);
                    if self.audio { sound::say(&self.status); }
                }
                _ => {}
            },
            Page::Motor => match key {
                Key::Left | Key::Right | Key::Up | Key::Down => {
                    brick.stop_active();
                    match key {
                        Key::Left => self.port = (self.port + PORTS.len() - 1) % PORTS.len(),
                        Key::Right => self.port = (self.port + 1) % PORTS.len(),
                        Key::Up => self.reverse = false, Key::Down => self.reverse = true, _ => {}
                    }
                    self.status.clear();
                    self.armed = None;
                }
                Key::Enter => {
                    let output = PORTS[self.port];
                    if brick.motor_name(output).is_none() {
                        self.status = "Bu porta EV3 motoru bağlı değil.".into();
                    } else if self.armed.is_some_and(|deadline| Instant::now() < deadline) {
                        self.armed = None;
                        self.status = match brick.pulse(output, self.reverse) {
                            Ok(()) => "350 ms test gönderildi.".into(),
                            Err(e) => format!("Motor: {}", match e.kind() {
                                io::ErrorKind::WouldBlock => "zaten çalışıyor",
                                io::ErrorKind::PermissionDenied => "izin yok", _ => "komut başarısız",
                            }),
                        };
                    } else {
                        self.armed = Some(Instant::now() + Duration::from_secs(4));
                        self.status = "Tekrar OK: 350 ms hareket.".into();
                    }
                }
                _ => {}
            },
            Page::Phone => match key {
                Key::Enter if self.phone.is_none() => self.start_phone(),
                Key::Left => self.index = self.index.saturating_sub(1),
                Key::Right => {
                    if let Some(phone) = &self.phone {
                        self.index = (self.index + 1).min(phone.addresses.len().saturating_sub(1));
                    }
                }
                _ => {}
            }
            Page::Model => match key {
                Key::Up => self.index = self.index.saturating_sub(1),
                Key::Down => self.index = (self.index + 1).min(self.status.chars().count().div_ceil(28).saturating_sub(5)),
                Key::Enter if self.story.is_none() => {
                    self.status = "Hikâye üretiliyor...".into();
                    self.index = 0;
                    let (tx, rx) = std::sync::mpsc::channel();
                    self.story = Some(rx);
                    std::thread::spawn(move || { let _ = tx.send(generate_story()); });
                }
                _ => {}
            },
            Page::Files => match key {
                Key::Up => self.index = self.index.saturating_sub(1),
                Key::Down => self.index = (self.index + 1).min(file_names().len().saturating_sub(1)),
                Key::Enter => {
                    if file_names().get(self.index).is_some_and(|n| n == "not.txt") {
                        self.page = Page::Notes;
                        self.draft = self.note.clone();
                        self.index = 0;
                    }
                }
                _ => {}
            },
            Page::Notes | Page::Calc => match key {
                Key::Up => self.index = self.index.saturating_sub(1),
                Key::Down => self.index = (self.index + 1).min(2),
                Key::Enter => match self.index {
                    0 => self.edit = true,
                    1 => { self.draft.pop(); }
                    _ if matches!(self.page, Page::Calc) => {
                        self.status = calculate(&self.draft).map_or("Örnek: 12+5".into(), |n| n.to_string());
                    }
                    _ => {
                        self.status = std::fs::write(note_path(), &self.draft)
                            .map_or_else(|e| format!("Kaydetme: {e}"), |()| "Kaydedildi".into());
                        self.note = self.draft.clone();
                    }
                },
                _ => {}
            },
            Page::Mic if self.mic_job.is_none() => match key {
                Key::Up => self.index = self.index.saturating_sub(1),
                Key::Down => self.index = (self.index + 1).min(mic::COMMANDS.len()),
                Key::Enter => {
                    let index = self.index;
                    self.status = if index == 0 { "Şimdi konuş (2 sn)" } else { "Komutu söyle (2 sn)" }.into();
                    let (tx, rx) = std::sync::mpsc::channel();
                    self.mic_job = Some(rx);
                    std::thread::spawn(move || {
                        let result = if index == 0 { mic::recognize().map(|s| (s.to_owned(), true)) }
                            else { mic::enroll(index - 1).map(|s| (s, false)) };
                        let _ = tx.send(result);
                    });
                }
                _ => {}
            },
            Page::Sound if matches!(key, Key::Enter) => {
                self.audio = !self.audio;
                if self.audio { sound::say("Merhaba. MIMO Mini hazır."); }
            }
            _ => {}
        }
        true
    }

    fn tick(&mut self, brick: &mut Brick) {
        if let Some(Ok(result)) = self.story.as_ref().map(|rx| rx.try_recv()) {
            self.story = None;
            if matches!(self.page, Page::Model) {
                self.status = result.unwrap_or_else(|e| e.to_string());
                self.index = 0;
            }
        }
        if let Some(Ok(result)) = self.mic_job.as_ref().map(|rx| rx.try_recv()) {
            self.mic_job = None;
            if !matches!(self.page, Page::Mic) { return; }
            self.status = match result {
                Ok((text, true)) => mimo::answer(&text, brick),
                Ok((text, false)) => text,
                Err(e) => e.to_string(),
            };
            if self.audio { sound::say(&self.status); }
        }
    }

    fn start_phone(&mut self) {
        match phone::Phone::start(self.audio) {
            Ok(p) => { self.status.clear(); self.phone = Some(p); }
            Err(_) => self.status = "Bağlantı açılamadı. Tekrar OK.".into(),
        }
    }

    fn display(&self, brick: &Brick) -> Frame {
        let mut f = Frame::new();
        f.box_fill(0, 0, 178, 19, true);
        f.text(5, 5, "MERTIXTANOS", 1, false);
        f.text(146, 5, "EV3", 1, false);
        f.box_fill(0, 113, 178, 1, true);
        f.text(5, 118, if matches!(self.page, Page::Home) { "OK: SEC   GERI: CIK" }
            else { "OK: SEC   GERI: DON" }, 1, true);
        match self.page {
            Page::Home => {
                for (i, &label) in MENU.iter().enumerate() {
                    let x = 4 + (i % 2) * 87;
                    let y = 22 + (i / 2) * 15;
                    let active = self.index == i;
                    f.box_fill(x, y, 83, 13, active);
                    f.box_fill(x + 3, y + 4, 4, 5, !active);
                    f.text(x + 11, y + 3, label, 1, !active);
                }
            }
            Page::Mimo => {
                f.text(5, 25, "MIMO MINI / CEVRIMDISI", 1, true);
                f.text(5, 42, &format!("{}/{} {}", self.index + 1, mimo::QUESTIONS.len(), mimo::QUESTIONS[self.index]), 1, true);
                if self.status.is_empty() { f.text(5, 63, "OK: SOR   SAG: YAZ", 1, true); }
                label(&mut f, 63, &self.status);
            }
            Page::Motor => {
                f.text(5, 24, "MOTOR TESTI", 1, true);
                f.text(5, 40, &format!("{} {} / {}", ROLES[self.port], PORTS[self.port], if self.reverse { "GERI" } else { "ILERI" }), 1, true);
                f.text(5, 56, brick.motor_name(PORTS[self.port]).as_deref().unwrap_or("Motor algılanmadı."), 1, true);
                f.text(5, 70, "SOL/SAG: PORT  YUK/AS: YON", 1, true);
                label(&mut f, 85, &self.status);
            }
            Page::Sensors => {
                f.text(5, 24, "SENSORLER 1-4", 1, true);
                for (i, sensor) in brick.sensors().iter().enumerate() {
                    let line = sensor.as_ref().map_or_else(|| "-".into(), |s| format!("{} {}", s.label(), s.value()));
                    f.text(5, 42 + i * 16, &format!("{}: {line}", i + 1), 1, true);
                }
            }
            Page::Info => {
                f.text(5, 25, concat!("MERTIXTANOS EV3 ", env!("CARGO_PKG_VERSION")), 1, true);
                f.text(5, 43, "EV3DEV / ARMV5TE", 1, true);
                f.text(5, 60, &format!("{} MOTOR", brick.motor_count()), 1, true);
                f.text(5, 77, &brick.battery().map_or("PIL OKUNAMADI".into(), |v| format!("PIL {:.2} V", v as f64 / 1_000_000.0)), 1, true);
            }
            Page::Phone => {
                f.text(5, 25, "TELEFON MIKROFONU", 1, true);
                if let Some(phone) = &self.phone {
                    let ip = phone.addresses.get(self.index).map(ToString::to_string).unwrap_or_else(|| "AG BAGLA".into());
                    f.text(5, 42, &format!("IP: {ip}"), 1, true);
                    f.text(5, 55, &format!("KOD: {}", phone.pin), 1, true);
                    f.text(5, 73, if phone.addresses.len() > 1 { "SOL/SAG: IP SEC" } else { "TELEFONDA MIMO EV3 AC" }, 1, true);
                    f.text(5, 89, "GERI: BAGLANTIYI KAPAT", 1, true);
                } else { label(&mut f, 45, &self.status); }
            }
            Page::Model => {
                f.text(5, 24, "TINYSTORIES 260K / EN", 1, true);
                f.text(5, 38, "OK: URET   OKLAR: KAYDIR", 1, true);
                let letters: Vec<char> = self.status.chars().collect();
                for (i, line) in letters.chunks(28).skip(self.index).take(5).enumerate() {
                    f.text(5, 51 + i * 11, &line.iter().collect::<String>(), 1, true);
                }
            }
            Page::Files => {
                f.text(5, 24, "DOSYALAR / MERTIXTANOS", 1, true);
                let bas = self.index.saturating_sub(4);
                for (i, path) in file_names().into_iter().enumerate().skip(bas).take(5) {
                    f.text(5, 42 + (i-bas)*13, &format!("{} {path}", if i == self.index { ">" } else { " " }), 1, true);
                }
            }
            Page::Mic => {
                f.text(5, 24, if mic::connected() { "USB MIKROFON HAZIR" } else { "USB MIKROFON YOK" }, 1, true);
                for (i, item) in std::iter::once("Dinle").chain(mic::COMMANDS).enumerate() {
                    f.text(5, 38 + i * 11, &format!("{} {}", if self.index == i { ">" } else { " " },
                        if i == 0 { item.to_owned() } else { format!("Öğret: {item}") }), 1, true);
                }
                label(&mut f, 94, &self.status);
            }
            Page::Notes | Page::Calc => {
                f.text(5, 24, if matches!(self.page, Page::Notes) { "NOTLAR" } else { "HESAP MAKINESI" }, 1, true);
                label(&mut f, 38, &self.draft.chars().rev().take(56).collect::<Vec<_>>().into_iter().rev().collect::<String>());
                let last = if matches!(self.page, Page::Notes) { "Kaydet" } else { "Hesapla" };
                for (i, name) in ["Yaz", "Son harfi sil", last].into_iter().enumerate() {
                    f.text(5, 60 + i * 11, &format!("{} {name}", if i == self.index { ">" } else { " " }), 1, true);
                }
                label(&mut f, 94, &self.status);
            }
            Page::Sound => {
                f.text(5, 28, if self.audio { "MIMO SESI: ACIK" } else { "MIMO SESI: KAPALI" }, 1, true);
                f.text(5, 49, "OK: SESI DEGISTIR", 1, true);
                f.text(5, 70, "HOPARLORUNU KULLANIR", 1, true);
            }
        }
        if self.edit {
            let rows: &[&str] = if matches!(self.page, Page::Calc) { &["0123456789", "+-*/"] } else { &ALPHABET };
            f.box_fill(0, 20, 178, 108, false);
            f.text(5, 23, "KLAVYE", 1, true);
            let tail: String = self.draft.chars().rev().take(28).collect::<Vec<_>>().into_iter().rev().collect();
            f.text(5, 34, &tail, 1, true);
            for (i, row) in rows.iter().enumerate() {
                for (j, c) in row.chars().enumerate() {
                    let (x, y) = (7 + 15*j, 45 + 10*i);
                    let active = self.row == i && self.col == j;
                    if active { f.box_fill(x - 2, y - 1, 11, 9, true); }
                    f.text(x, y, &c.to_string(), 1, !active);
                }
            }
            f.text(5, 115, "OK: YAZ   GERI: BITIR", 1, true);
        }
        f
    }
}

fn note_path() -> PathBuf {
    let home = env::var_os("HOME").map(PathBuf::from).unwrap_or_else(|| "/home/robot".into());
    home.join("MertixtanOS").join("not.txt")
}

fn file_names() -> Vec<String> {
    let mut names: Vec<String> = note_path().parent().into_iter().flat_map(|path| std::fs::read_dir(path).into_iter().flatten())
        .filter_map(Result::ok).map(|p| p.file_name().to_string_lossy().into_owned()).collect();
    names.sort();
    names
}

fn generate_story() -> io::Result<String> {
    let executable = env::current_exe()?;
    let directory = executable.parent().ok_or_else(|| io::Error::other("Model klasörü yok"))?;
    let output = std::process::Command::new(directory.join("tiny-stories-ev3"))
        .current_dir(directory).args(["stories260K.bin", "-z", "tok512.bin", "-n", "36", "-i", "Once upon a time"]).output()
        .map_err(|e| io::Error::new(e.kind(), format!("Dil modeli: {e}")))?;
    if !output.status.success() { return Err(io::Error::other("TinyStories açılamadı")); }
    Ok(String::from_utf8_lossy(&output.stdout).split_whitespace().collect::<Vec<_>>().join(" "))
}

fn calculate(s: &str) -> Option<i64> {
    let (i, op) = s.char_indices().skip(1).find(|(_, c)| "+-*/".contains(*c))?;
    let a: i64 = s[..i].trim().parse().ok()?;
    let b: i64 = s[i+1..].trim().parse().ok()?;
    match op { '+' => a.checked_add(b), '-' => a.checked_sub(b), '*' => a.checked_mul(b), '/' => a.checked_div(b), _ => None }
}

fn label(f: &mut Frame, y: usize, s: &str) {
    for (i, line) in s.chars().collect::<Vec<_>>().chunks(28).take(3).enumerate() {
        f.text(5, y + i * 10, &line.iter().collect::<String>(), 1, true);
    }
}

fn run() -> io::Result<()> {
    let mut brick = Brick::new(PathBuf::from("/sys/class"));
    let mut app = App::new();
    let mut args = env::args().skip(1);
    match args.next().as_deref() {
        Some("--mimo") => {
            let question = args.collect::<Vec<_>>().join(" ");
            println!("{}", mimo::answer(&question, &mut brick));
            return Ok(());
        }
        Some("--preview") => {
            let file = args.next().unwrap_or_else(|| "ev3.pbm".into());
            return app.display(&brick).pbm(Path::new(&file));
        }
        Some("--phone") => {
            let phone = phone::Phone::start(false)?;
            println!("EV3 IP: {:?} | Kod: {} | Port: 9765", phone.addresses, phone.pin);
            println!("Bağlantıyı kapatmak için Enter'a bas.");
            let mut line = String::new();
            io::stdin().read_line(&mut line)?;
            return Ok(());
        }
        Some("--story") => { println!("{}", generate_story()?); return Ok(()); }
        Some("--version") => { println!("MertixtanOS EV3 {}", env!("CARGO_PKG_VERSION")); return Ok(()); }
        Some(_) => return Err(io::Error::new(io::ErrorKind::InvalidInput, "Seçenekler: --mimo, --phone, --preview, --story, --version")),
        None => {}
    }
    let mut lcd = Lcd::open()
        .map_err(|e| io::Error::new(e.kind(), format!("EV3 ekranı: {e}")))?;
    let keys = ev3::buttons()?;
    lcd.draw(&app.display(&brick))?;
    loop {
        match keys.recv_timeout(Duration::from_millis(150)) {
            Ok(key) if !app.key(key, &mut brick) => break,
            Ok(_) | Err(RecvTimeoutError::Timeout) => {}
            Err(RecvTimeoutError::Disconnected) => break,
        }
        brick.tick();
        app.tick(&mut brick);
        lcd.draw(&app.display(&brick))?;
    }
    lcd.draw(&Frame::new())?;
    Ok(())
}

fn main() {
    if let Err(e) = run() {
        eprintln!("MertixtanOS EV3: {e}");
        std::process::exit(1);
    }
}
