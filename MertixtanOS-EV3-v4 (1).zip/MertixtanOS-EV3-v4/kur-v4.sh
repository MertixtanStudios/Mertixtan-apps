#!/bin/sh
set -eu

case "$(uname -m)" in
    armv5*) ;;
    *) printf '%s\n' 'Bu komutu ev3dev çalışan EV3 üzerinde çalıştır.' >&2; exit 1 ;;
esac

kaynak=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
hedef="$HOME/MertixtanOS-v4"
if [ "${1:-}" = "--acilista" ] && [ "$HOME" != "/home/robot" ]; then
    printf '%s\n' 'Açılış kurulumu için robot kullanıcısıyla bağlan.' >&2
    exit 1
fi
mkdir -p -- "$hedef"
install -m 0755 -- "$kaynak/mertixtanos-ev3" "$kaynak/tiny-stories-ev3" "$hedef/"
install -m 0644 -- "$kaynak/stories260K.bin" "$kaynak/tok512.bin" "$hedef/"
mkdir -p -- "$HOME/MertixtanOS"
if [ "${1:-}" = "--acilista" ]; then
    sudo install -m 0644 -- "$kaynak/mertixtanos-v4.service" /etc/systemd/system/mertixtanos-v4.service
    sudo systemctl daemon-reload
    sudo systemctl enable mertixtanos-v4.service
fi
printf '%s\n' 'File Browser → MertixtanOS-v4 → mertixtanos-ev3'
