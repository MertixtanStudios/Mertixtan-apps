# Mertixtan Studios · Canlı Paket

İçinde:
- `site/index.html`: web sitesi (Haberler bölümü, MIMO kartı ve MIMO sohbet ekranı eklendi)
- `model/mimo.gguf`: şimdilik **deneme modeli** (minicik; sadece ders cümlelerini bilir)
- `mimo-sifir/`: MIMO-Sıfır'ın eğitim kodu ve Kaggle defteri (gerçek modeli buradan eğit)
- `kur.sh`: sunucuya kurar (nginx + MIMO), yükleyici kendisi çalıştırır
- `yukleyici.py`: tek seferlik yükleme sayfası (KOMUT.txt'deki tek satır, bunun sıkıştırılmış hâli)

## Canlıya alma
1. Sunucuna bağlan (Termius). `KOMUT.txt` içindeki **tek satırı** yapıştır, Enter.
2. Ekrana bir bağlantı çıkar: `http://SUNUCU_IP:8099/....` Bunu tabletinin tarayıcısında aç.
3. **Dosya seç** → depolama açılır → `Mertixtan-Canli.zip` → **Kabul et ve yayınla**.
4. Kurulum sayfada canlı akar (ilk seferde llama.cpp derlendiği için 5-15 dakika). Sonunda:
   `YAYINDA: http://SUNUCU_IP/`
5. Gerçek MIMO modeli Kaggle'dan çıkınca: komutu yine çalıştır, bu sefer **mimo.gguf** dosyasını seç. Sadece model değişir.

## Bağlantı açılmazsa
Sunucu firmanın panelinde (Hetzner, DigitalOcean vb.) bir güvenlik duvarı varsa **80** ve **8099** portlarını aç.
8099 sadece yükleme sırasında kullanılır; yükleme bitince yükleyici kapanır.

## Güvenlik
- Yükleme bağlantısında tek seferlik, tahmin edilemez bir kod var. Başkasıyla paylaşma.
- MIMO dışarıya kapalı; sadece sitenin sohbet adresi açık. Gizli anahtar sunucudan çıkmıyor.
- Kişi başına dakikada 12 mesaj sınırı var; kimse sunucunu kilitleyemez.
- Yükleme şifresiz HTTP ile gider; pakette gizli bilgi yok. İleride bir alan adı alınca HTTPS eklenmeli.

## Giriş / Kayıt ve Yönetici Paneli

- Sitenin sağ üstünde **Giriş Yap** butonu var. Üyeler kullanıcı adı + e-posta ve/veya telefon + şifre ile kayıt olur; kullanıcı adı, e-posta ya da telefonla giriş yapar.
- Şifreler sunucuda düz metin değil, **scrypt özeti** olarak saklanır (`/var/lib/mertixtan/hesap.db`, sadece servis okuyabilir).
- **Yönetici hesabı** önceden kurulu ve doğrulanmış: kullanıcı adı `MertixtanStudios`. Üye listesinde ve sayılarda görünmez.
  Giriş yaptıktan sonra menüden **Şifre Değiştir**'i kullanarak şifreyi hemen değiştir (şifre sohbette yazıldı).
- Panel: `http://SUNUCU_IP/#yonetici` ya da kullanıcı menüsü → Yönetici Paneli. Üye sayıları, arama, engelle / engeli kaldır / yönetici yap / doğrula / sil, site duyurusu, MIMO durumu.
- **Google ile giriş**: Google Cloud Console'da Web için OAuth istemci kimliği oluştur, sitenin adresini "Yetkili JavaScript kaynakları"na ekle, kimliği panele yapıştır. Buton kendiliğinden çıkar.
  Not: Google bu butonu yalnızca **https** adreslerde (ya da localhost) çalıştırır; önce bir alan adı + SSL gerekir.
- Telefon ve e-posta şu an **SMS/e-posta koduyla doğrulanmıyor** (bunun için ücretli SMS / e-posta servisi gerekir). Panelden elle "Doğrula" diyebilirsin.
- Güvenlik: aynı IP'den dakikada 20'den fazla giriş/kayıt isteği ve 15 dakikada 10 yanlış şifre engellenir.

## mertixtanstudios.com

Alan adı Natro'da. DNS'te iki kayıt sunucuyu gösterir: `A @ 45.74.243.124` ve `A www 45.74.243.124`.
Kayıt yayıldıktan sonra paketi bir kez daha yükle: https (Let's Encrypt) kendiliğinden kurulur ve 90 günde bir kendiliğinden yenilenir.

## Site içeriği (hepsi Yönetici Paneli → sekmelerden yönetilir)

Haberler + yorumlar · Yol haritası · SSS · Anketler (hesap başına bir oy) · İndirme Merkezi (sayaçlı, Pro'ya özel dosya) ·
Fikir Panosu (öneri + oy + stüdyo yanıtı) · Lisans anahtarları (Shopier için üret, üye profilinden etkinleştirir;
uygulamalar `GET /api/site/lisans/dogrula?anahtar=...` ile doğrular) · İletişim mesajları · Bülten aboneleri (CSV) ·
MIMO dersleri (👍/👎 + "doğrusu", onaylananlar JSONL iner → Kaggle'da mimo_dersler.jsonl'a ekle) · Skor tablosu ·
Profil + üye kartı (PNG) + rozetler · Site araması (Ctrl+K) · Karanlık mod · Ziyaret grafiği · Geri sayım / YouTube / Shopier / kayan şerit ayarları.

## Mertixtan Lives (canlı yayın)

Site menüsünde **Lives**. Kurulum bunları kendisi yapar: LiveKit medya sunucusu (pakette, sürüm 1.13.11), anahtarlar
(/etc/mertixtan/livekit.env, sadece root okur), nginx yolları (/livekit, /api/lives, /kapak) ve ufw kuralları.

**Sağlayıcının güvenlik duvarında açılması gereken portlar** (canlı görüntü/ses için):
`7881/tcp`, `50000-50200/udp`, `3478/udp` (443 ve 80 zaten açık olmalı).

- Resmî kanal "Mertixtan Studios Live": Lives → Yönetim → Program / Film & Dizi / Resmî kanal. O an programda bir şey yoksa NO SIGNAL.
  Video kaynağı: https ile başlayan .mp4 / .webm / .m3u8 ya da YouTube bağlantısı. Sadece yayın hakkına sahip olduğun içerikleri ekle.
- Yayın açma: Pro üyeler ve yöneticinin "yayıncı" yetkisi verdiği kullanıcılar (kamera, ekran, sesli). Ekran paylaşımı telefon tarayıcılarının çoğunda yok.
- Sohbet: gerçek zamanlı; @etiket, yanıt, sabitleme (yönetici/oda sahibi), silme, susturma, uzaklaştırma, yasak, spam koruması.
- Destekliyoruz şu an ücretsiz bir göstergedir; para transferi yoktur (veritabanında ileride kullanılmak üzere 'tutar' alanı ayrıldı).

### Lives V2
- **Videolar** (Yönetim → 🎞 Videolar): telefondan/bilgisayardan MP4, MOV, WEBM yükle (en çok 4 GB, 8 MB'lık parçalar, kopan bağlantıda kaldığı yerden sürer).
  Dosyalar `/var/lib/mertixtan-video/` altında; ffmpeg hızlı başlatma, süre ve otomatik kapak üretir. Sunucuda en az 3 GB boş yer kalmalı.
- **YouTube programı** (Yönetim → Program): bağlantı + ad + saat → o saatte kanalda kendiliğinden oynar. Haftalık takvim: Yönetim → 🗓 Takvim.
- **Yaş sınırı**: Genel, 7+, 10+, 13+, 16+, 18+. 16+/18+ içerikte izleyiciden onay istenir.
- **Kanal görünümü** (Yönetim → Resmî kanal): logo, kapak, açıklama, tema rengi, tasarım. Logo NO SIGNAL ekranında da görünür.
- **Yayın öncesi kontrol + efektler**: kamera yayınında önizleme, ön/arka kamera, kamera/mikrofon testi; 2D/3D yüz efektleri,
  renk filtreleri, arka plan bulanıklaştırma/değiştirme (MediaPipe, tamamen sunucumuzdan, cihazda çalışır). Yayın sırasında da değiştirilebilir.
- **Canlı anket**, **program hatırlatmaları** (başlamadan 5 dk önce site içi + tarayıcı bildirimi; site açık olmalı), **sinema modu**,
  **yayın sonu istatistikleri** (izleyici grafiği, izlenme süresi, anket sonuçları, özet).

## Gece yedeği

Her gece 03:17'de veritabanının tutarlı bir yedeği `/var/lib/mertixtan/yedek/` altına alınır (son 14 gün).
Sunucu tamamen kaybolursa bu yedekler de gider; ara sıra bir yedeği bilgisayarına indir:
`sudo cp /var/lib/mertixtan/yedek/$(sudo ls /var/lib/mertixtan/yedek | head -1) ~/` (sonra Termius'tan indir).
