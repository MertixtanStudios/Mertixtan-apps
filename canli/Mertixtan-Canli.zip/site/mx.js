// MertixtanStudios site motoru: haberler, yorumlar, anketler, yol haritası, SSS, geri sayım, destekçi sayacı,
// skor tablosu, İndirme Merkezi, Fikir Panosu, profil + üye kartı, lisans, iletişim, bülten, site araması,
// karanlık mod, MIMO sohbet geçmişi + MIMO'ya öğret ve yönetici panelinin içerik yönetimi.
// Bütün veriler sunucudaki /api/site servisinden gelir; kullanıcı yazıları her zaman textContent ile basılır.

const $ = (id) => document.getElementById(id);
let SITE = null;

// ------------------------------------------------------------ yardımcılar
async function api(yol, veri) {
    const r = await fetch('/api/site/' + yol, veri === undefined ? { cache: 'no-store', credentials: 'same-origin' }
        : { method: 'POST', credentials: 'same-origin', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(veri) });
    let j = {}; try { j = await r.json(); } catch (e) {}
    if (!r.ok) throw new Error(j.hata || 'Sunucuya ulaşılamadı');
    return j;
}
function el(etiket, sinif, yazi) {
    const e = document.createElement(etiket);
    if (sinif) e.className = sinif;
    if (yazi !== undefined && yazi !== null) e.textContent = yazi;
    return e;
}
function ikon(sinif) { const i = document.createElement('i'); i.className = sinif; return i; }
function tarih(t) { return t ? new Date(t * 1000).toLocaleDateString('tr-TR', { day: 'numeric', month: 'long', year: 'numeric' }) : ''; }
function sayi(n) { return Number(n || 0).toLocaleString('tr-TR'); }
function bildir(mesaj, iyi = true) {
    let t = $('mx-toast');
    if (!t) { t = el('div', 'fixed bottom-5 left-1/2 -translate-x-1/2 z-[200] px-5 py-3 rounded-2xl shadow-2xl text-sm font-bold max-w-[90vw] text-center transition-opacity'); t.id = 'mx-toast'; document.body.appendChild(t); }
    t.textContent = mesaj; t.style.opacity = 1;
    t.className = t.className.replace(/bg-\S+ text-\S+/g, '') + (iyi ? ' bg-slate-900 text-white' : ' bg-red-600 text-white');
    clearTimeout(t._z); t._z = setTimeout(() => t.style.opacity = 0, 3500);
}
function girisGerek(ne) { if (hesapBen) return false; bildir(ne + ' için giriş yapmalısın', false); hesapPencere('giris'); return true; }
const GIRDI = 'w-full rounded-2xl border border-slate-200 focus:border-primary-500 focus:ring-2 focus:ring-primary-100 outline-none px-4 py-3 text-sm bg-white';
const BUTON = 'px-5 py-3 rounded-2xl bg-gradient-to-r from-primary-500 to-accent-600 text-white font-bold text-sm shadow-md disabled:opacity-50';
const KUCUK = 'px-3 py-1.5 rounded-lg text-[11px] font-bold bg-slate-100 text-slate-700 hover:bg-slate-200';

// ------------------------------------------------------------ görünümler
const YENI_GORUNUMLER = ['indirme-view', 'fikir-view', 'haber-view', 'profil-view', 'iletisim-view', 'uyelik-view'];
const TUM_GORUNUMLER = ['main-home-view', 'detail-page-view', 'game-view', 'mimo-view', 'yonetici-view', ...YENI_GORUNUMLER];

function sayfaKabugu(id, ikonSinif, baslik, alt) {
    const m = el('main', 'hidden min-h-[85vh] py-10 bg-white/95 backdrop-blur-sm'); m.id = id;
    const ic = el('div', 'max-w-5xl mx-auto px-4 sm:px-6 lg:px-8');
    const ust = el('div', 'flex items-center gap-3 border-b border-slate-100 pb-5 mb-6');
    const kut = el('div', 'w-12 h-12 rounded-2xl bg-gradient-to-br from-primary-500 to-accent-600 flex items-center justify-center text-white text-xl shadow-lg'); kut.appendChild(ikon(ikonSinif));
    const yz = el('div'); yz.append(el('h1', 'font-display font-black text-2xl text-slate-900', baslik), el('p', 'text-xs text-slate-500', alt));
    ust.append(kut, yz);
    const govde = el('div'); govde.id = id + '-govde';
    ic.append(ust, govde); m.appendChild(ic);
    $('detail-page-view').before(m);
    return govde;
}

function gorunum(id) {
    if (!$('main-home-view').classList.contains('hidden')) lastScrollPosition = window.scrollY;
    isGameOpen = false;
    for (const v of TUM_GORUNUMLER) $(v)?.classList.add('hidden');
    $(id).classList.remove('hidden');
    $('top-back-btn').classList.remove('hidden'); ustDuzen();
    $('hesap-menu')?.classList.add('hidden');
    window.scrollTo({ top: 0, behavior: 'smooth' });
}
// "Açılışı Gör" düğmesi: telefonda hep gizli (hidden sm:flex), büyük ekranda sadece ana sayfada görünür.
// Eski kod 'hidden' sınıfını ekleyip çıkararak bu ayarı bozuyordu (telefonda çıkıp taşıyor, alt sayfalarda kalıyordu).
function ustDuzen() {
    const d = $('top-launch-btn'); if (!d) return;
    d.classList.add('hidden');
    d.style.display = $('main-home-view').classList.contains('hidden') ? 'none' : '';
}
// eski görünüm fonksiyonları yeni sayfaları da gizlesin
for (const ad of ['closeAllViews', 'openMimoView', 'openGameView', 'openCategoryModal', 'openYoneticiView']) {
    const eski = window[ad];
    window[ad] = function (...a) { for (const v of YENI_GORUNUMLER) $(v)?.classList.add('hidden'); const r = eski.apply(this, a); ustDuzen(); return r; };
}

// ------------------------------------------------------------ ana sayfa içeriği
async function siteYukle() {
    try { SITE = await api('icerik'); } catch (e) { return; }
    const s = SITE.istatistik;
    $('ist-uye').textContent = sayi(s.uye); $('ist-ucus').textContent = sayi(s.ucus);
    $('ist-ders').textContent = sayi(s.ders); $('ist-indirme').textContent = sayi(s.indirme);
    seritCiz(); haberleriCiz(); anketleriCiz(); yolCiz(); sssCiz(); destekCiz(); sayacBaslat();
    const yt = $('youtube-link');
    if (SITE.ayar.youtube) { yt.href = SITE.ayar.youtube; yt.classList.remove('hidden'); } else yt.classList.add('hidden');
    if (!$('indirme-view').classList.contains('hidden')) indirmeCiz();
}

function seritCiz() {
    const s = (SITE.ayar.serit || '').split('\n').map(x => x.trim()).filter(Boolean);
    if (!s.length) return;
    const k = $('serit'); k.replaceChildren();
    const ik = ['fa-solid fa-fire text-amber-300', 'fa-solid fa-bolt text-white', 'fa-solid fa-star text-amber-300', 'fa-solid fa-wand-magic-sparkles text-white'];
    s.forEach((m, i) => { const sp = el('span', 'flex items-center gap-2'); sp.append(ikon(ik[i % ik.length]), document.createTextNode(' ' + m)); k.appendChild(sp); });
}

function haberleriCiz() {
    const g = $('haber-grid'); g.replaceChildren();
    if (!SITE.haberler.length) { g.appendChild(el('p', 'text-sm text-slate-400', 'Henüz haber yok.')); return; }
    for (const h of SITE.haberler.slice(0, 8)) {
        const a = el('article', 'cursor-pointer group bg-slate-50/80 hover:bg-white rounded-3xl p-6 border border-slate-200/80 hover:border-primary-300 shadow-sm hover:shadow-xl transition-all flex flex-col');
        a.onclick = () => openHaber(h.id);
        const ust = el('div', 'flex items-center justify-between text-[11px] font-bold mb-4');
        ust.append(el('span', 'px-2.5 py-1 rounded-lg bg-primary-100 text-primary-700', h.etiket || 'HABER'), el('time', 'text-slate-400', tarih(h.tarih)));
        const alt = el('span', 'mt-4 text-sm font-bold text-primary-600', 'Devamını oku ');
        alt.appendChild(ikon('fa-solid fa-arrow-right ml-1'));
        if (h.yorum) alt.appendChild(el('span', 'ml-2 text-xs text-slate-400 font-semibold', `· ${h.yorum} yorum`));
        a.append(ust, el('h3', 'font-display font-bold text-lg text-slate-900 group-hover:text-primary-600 transition-colors mb-2', h.baslik),
            el('p', 'text-sm text-slate-500 leading-relaxed flex-1', h.ozet), alt);
        g.appendChild(a);
    }
}

function anketleriCiz() {
    const k = $('anket-kap'); k.replaceChildren();
    if (!SITE.anketler.length) { k.appendChild(el('p', 'text-sm text-slate-400', 'Şu an açık anket yok.')); return; }
    for (const a of SITE.anketler) k.appendChild(anketKarti(a));
}
function anketKarti(a) {
    const kap = el('div');
    const toplam = a.oylar.reduce((x, y) => x + y, 0);
    const ust = el('div', 'flex items-center justify-between mb-3');
    ust.append(el('span', 'px-3 py-1 rounded-full bg-primary-100 text-primary-700 text-xs font-extrabold uppercase tracking-wider', 'Topluluk Anketi'),
        el('span', 'text-xs font-bold text-slate-500', `Toplam ${sayi(toplam)} oy`));
    kap.append(ust, el('h3', 'font-display font-black text-2xl text-slate-900 mb-2', a.soru),
        el('p', 'text-xs text-slate-500 mb-5', hesapBen ? (a.benim !== null ? 'Oyun kaydedildi. İstersen değiştirebilirsin.' : 'Bir seçeneğe dokunarak oy ver.') : 'Oy vermek için giriş yap. Her hesap bir oy.'));
    const l = el('div', 'space-y-3');
    a.secenekler.forEach((s, i) => {
        const yuzde = toplam ? Math.round(a.oylar[i] * 100 / toplam) : 0;
        const b = el('button', 'w-full text-left p-4 rounded-2xl bg-white border-2 transition-all relative overflow-hidden ' + (a.benim === i ? 'border-primary-500' : 'border-slate-200 hover:border-primary-400'));
        const bar = el('div', 'absolute inset-y-0 left-0 bg-primary-500/15 transition-all duration-500 pointer-events-none'); bar.style.width = yuzde + '%';
        const sat = el('div', 'relative z-10 flex justify-between items-center font-bold text-sm text-slate-800 pointer-events-none gap-3');
        const ad = el('span', 'flex items-center gap-2'); if (a.benim === i) ad.appendChild(ikon('fa-solid fa-circle-check text-primary-600')); ad.appendChild(document.createTextNode(s));
        sat.append(ad, el('span', 'text-primary-600 font-extrabold whitespace-nowrap', `%${yuzde} · ${a.oylar[i]}`));
        b.append(bar, sat);
        b.onclick = async () => {
            if (girisGerek('Oy vermek')) return;
            try { const yeni = await api('oy', { anket_id: a.id, secim: i }); kap.replaceWith(anketKarti(yeni)); bildir('Oyun kaydedildi ✓'); }
            catch (e) { bildir(e.message, false); }
        };
        l.appendChild(b);
    });
    kap.appendChild(l);
    return kap;
}

function yolCiz() {
    const k = $('yol-kap'); k.replaceChildren();
    const sutun = { bitti: ['Tamamlandı', 'fa-circle-check', 'primary'], yapiliyor: ['Yapılıyor', 'fa-gears', 'accent'], plan: ['Sırada', 'fa-flag', 'slate'] };
    for (const [d, [ad, ik, renk]] of Object.entries(sutun)) {
        const s = el('div', 'bg-white rounded-3xl border border-slate-200 p-5 shadow-sm');
        const b = el('h3', `font-display font-black text-lg mb-4 flex items-center gap-2 text-${renk}-600`); b.append(ikon('fa-solid ' + ik), document.createTextNode(' ' + ad));
        s.appendChild(b);
        const ogeler = SITE.yol.filter(x => x.durum === d);
        if (!ogeler.length) s.appendChild(el('p', 'text-xs text-slate-400', '—'));
        for (const o of ogeler) {
            const k2 = el('div', `border-l-4 border-${renk === 'slate' ? 'slate-300' : renk + '-500'} pl-3 py-1.5 mb-3`);
            k2.append(el('div', 'font-bold text-sm text-slate-800', o.baslik), el('div', 'text-xs text-slate-500', o.aciklama || ''));
            s.appendChild(k2);
        }
        k.appendChild(s);
    }
}

function sssCiz(acilacak) {
    const k = $('sss-kap'); k.replaceChildren();
    const ara = ($('sss-ara').value || '').toLocaleLowerCase('tr');
    const l = SITE.sss.filter(s => !ara || (s.soru + ' ' + s.cevap).toLocaleLowerCase('tr').includes(ara));
    if (!l.length) k.appendChild(el('p', 'text-sm text-slate-400 text-center', 'Eşleşen soru yok.'));
    for (const s of l) {
        const d = el('details', 'group bg-slate-50 rounded-2xl border border-slate-200 px-5 py-4'); d.id = 'sss-' + s.id;
        if (acilacak === s.id) d.open = true;
        const o = el('summary', 'font-bold text-slate-800 cursor-pointer list-none flex justify-between items-center gap-3');
        o.append(document.createTextNode(s.soru), ikon('fa-solid fa-chevron-down text-xs text-slate-400 group-open:rotate-180 transition-transform'));
        d.append(o, el('p', 'text-sm text-slate-600 mt-3 whitespace-pre-line', s.cevap));
        k.appendChild(d);
    }
}

let sayacZamanlayici = null;
function sayacBaslat() {
    clearInterval(sayacZamanlayici);
    const hedef = SITE.ayar.acilis ? new Date(SITE.ayar.acilis + ':00+03:00').getTime() : 0;
    const ciz = () => {
        const kalan = hedef - Date.now();
        if (!hedef || kalan <= 0) {
            $('sayac-kutular').classList.add('hidden');
            $('sayac-etiket').textContent = 'Büyük Açılış';
            $('sayac-baslik').replaceChildren(document.createTextNode('MertixtanStudios '), el('span', 'text-primary-600', 'Yayında 🎉'));
            clearInterval(sayacZamanlayici); return;
        }
        $('sayac-kutular').classList.remove('hidden');
        const p = (n) => String(Math.floor(n)).padStart(2, '0');
        $('days').textContent = p(kalan / 864e5); $('hours').textContent = p(kalan % 864e5 / 36e5);
        $('minutes').textContent = p(kalan % 36e5 / 6e4); $('seconds').textContent = p(kalan % 6e4 / 1e3);
    };
    ciz(); sayacZamanlayici = setInterval(ciz, 1000);
}

function destekCiz() {
    $('hype-count').textContent = sayi(SITE.destek.sayi);
    $('destek-yazi').textContent = SITE.destek.ben ? 'Destekçisin, teşekkürler!' : 'Ateşi Harla!';
    $('destek-btn').disabled = SITE.destek.ben;
    $('destek-yazi').textContent = SITE.destek.ben ? 'Destekçisin, teşekkürler!' : (hesapBen ? 'Ateşi Harla!' : 'Giriş yap, ateşi harla!');
}
async function destekVer() {
    if (girisGerek('Destekçi olmak')) return;
    try { SITE.destek = await api('destek', {}); destekCiz(); bildir('Destekçiler arasına katıldın 🔥'); } catch (e) { bildir(e.message, false); }
}

// ------------------------------------------------------------ skor tablosu (+ oyundan otomatik kayıt)
async function skorYukle() {
    try {
        const d = await api('skorlar');
        const t = $('skor-tablo'); t.replaceChildren();
        if (!d.skorlar.length) { const tr = t.insertRow(); const td = tr.insertCell(); td.colSpan = 5; td.className = 'px-4 py-8 text-center text-slate-400'; td.textContent = 'Henüz uçuş yok. İlk rekoru sen kır!'; }
        d.skorlar.forEach((s, i) => {
            const tr = t.insertRow(); tr.className = i < 3 ? 'bg-primary-50/40' : '';
            const h = (x, c) => { const td = tr.insertCell(); td.className = 'px-4 py-3 ' + (c || ''); td.textContent = x; };
            h(['🥇', '🥈', '🥉'][i] || i + 1, 'font-bold'); h(s.ad + (s.pro ? ' ★' : ''), 'font-bold text-slate-800');
            h(sayi(s.mesafe) + ' m', 'font-bold text-primary-700'); h(s.seviye); h(s.ucus, 'text-slate-500');
        });
        $('skor-ben').textContent = d.ben ? `Senin rekorun: ${sayi(d.ben.rekor)} m · ${d.ben.ucus} uçuş` : (hesapBen ? 'Henüz uçmadın. Bir uçuş yap, skorun buraya yazılsın.' : 'Giriş yaparsan uçuşların skor tablosuna kaydedilir.');
    } catch (e) {}
}
let ucusJetonu = null;
if (typeof startFlight === 'function') {
    const eskiBaslat = startFlight;
    window.startFlight = function (...a) {
        ucusJetonu = null;
        if (hesapBen) api('skor/basla', {}).then(d => ucusJetonu = d.jeton).catch(() => {});
        return eskiBaslat.apply(this, a);
    };
}
if (typeof endFlight === 'function') {
    const eskiBitis = endFlight;
    window.endFlight = function (kazandi, neden) {
        const mesafe = Math.floor(flight.distance), altin = flight.coinsCollected, seviye = gameState.level;
        eskiBitis(kazandi, neden);
        if (!hesapBen) { bildir('Giriş yaparsan bu uçuş skor tablosuna yazılır'); return; }
        if (!ucusJetonu) return;
        const jeton = ucusJetonu; ucusJetonu = null;
        api('skor', { mesafe, altin, seviye, jeton }).then(() => { bildir(`Skor kaydedildi: ${sayi(mesafe)} m`); skorYukle(); }).catch(e => bildir(e.message, false));
    };
}

// ------------------------------------------------------------ haber detayı + yorumlar
function haberSayfasi() {
    const g = sayfaKabugu('haber-view', 'fa-solid fa-newspaper', 'Haberler', 'Stüdyodan son gelişmeler');
    g.innerHTML = '<article id="hd-kap"></article><section class="mt-10 border-t border-slate-100 pt-8"><h2 class="font-display font-black text-xl text-slate-900 mb-4">Yorumlar</h2><form id="hd-form" class="flex gap-2 mb-6 items-end"><textarea name="metin" rows="2" maxlength="1000" required placeholder="Yorumunu yaz…" class="flex-1 rounded-2xl border border-slate-200 focus:border-primary-500 outline-none px-4 py-3 text-sm resize-none"></textarea><button class="' + BUTON + '">Gönder</button></form><div id="hd-yorumlar" class="space-y-3"></div></section>';
    $('hd-form').addEventListener('submit', async (e) => {
        e.preventDefault(); if (girisGerek('Yorum yazmak')) return;
        const f = e.target;
        try { await api('yorum', { haber_id: $('haber-view').dataset.id, metin: f.metin.value }); f.reset(); openHaber($('haber-view').dataset.id, true); }
        catch (err) { bildir(err.message, false); }
    });
}
async function openHaber(id, yerinde) {
    if (!yerinde) gorunum('haber-view');
    $('haber-view').dataset.id = id;
    try {
        const d = await api('haber?id=' + encodeURIComponent(id));
        const h = d.haber, k = $('hd-kap'); k.replaceChildren();
        const ust = el('div', 'flex items-center gap-3 text-xs font-bold mb-3');
        ust.append(el('span', 'px-2.5 py-1 rounded-lg bg-primary-100 text-primary-700', h.etiket || 'HABER'), el('time', 'text-slate-400', tarih(h.tarih)));
        k.append(ust, el('h1', 'font-display font-black text-3xl sm:text-4xl text-slate-900 mb-4', h.baslik), el('p', 'text-lg text-slate-500 mb-6', h.ozet || ''));
        for (const p of (h.icerik || '').split(/\n\s*\n/)) if (p.trim()) k.appendChild(el('p', 'text-slate-700 leading-relaxed mb-4 whitespace-pre-line', p.trim()));
        const y = $('hd-yorumlar'); y.replaceChildren();
        if (!d.yorumlar.length) y.appendChild(el('p', 'text-sm text-slate-400', 'İlk yorumu sen yaz.'));
        for (const c of d.yorumlar) {
            const kut = el('div', 'bg-slate-50 rounded-2xl border border-slate-200 px-4 py-3');
            const bas = el('div', 'flex items-center gap-2 text-xs mb-1');
            const nok = el('span', 'w-2.5 h-2.5 rounded-full inline-block'); nok.style.background = c.renk || '#10b981';
            bas.append(nok, el('b', 'text-slate-800', c.ad), el('span', 'text-slate-400', tarih(c.tarih)));
            if (c.yonetici) bas.appendChild(el('span', 'px-1.5 py-0.5 rounded bg-accent-100 text-accent-700 font-bold', 'Stüdyo'));
            if (hesapBen && (hesapBen.yonetici || hesapBen.ad === c.ad)) {
                const s = el('button', 'ml-auto text-red-500 hover:text-red-700 font-bold', 'Sil');
                s.onclick = async () => { if (!confirm('Yorum silinsin mi?')) return; try { await api('yorum/sil', { id: c.id }); openHaber(id, true); } catch (e) { bildir(e.message, false); } };
                bas.appendChild(s);
            }
            kut.append(bas, el('p', 'text-sm text-slate-700 whitespace-pre-line break-words', c.metin));
            y.appendChild(kut);
        }
    } catch (e) { $('hd-kap').replaceChildren(el('p', 'text-red-600', e.message)); }
}

// ------------------------------------------------------------ İndirme Merkezi
let indirmeFiltre = 'hepsi';
function indirmeSayfasi() {
    const g = sayfaKabugu('indirme-view', 'fa-solid fa-download', 'İndirme Merkezi', 'Uygulamalarımız, oyunlarımız ve tasarım paketlerimiz');
    g.innerHTML = '<div id="ind-filtre" class="flex flex-wrap gap-2 mb-6"></div><div id="ind-pro" class="hidden mb-6 rounded-3xl bg-gradient-to-r from-primary-50 to-accent-50 border border-primary-100 p-5 flex flex-wrap items-center justify-between gap-3"></div><div id="ind-liste" class="grid sm:grid-cols-2 gap-4"></div>';
}
function openIndirme(kat) { if (kat) indirmeFiltre = kat; gorunum('indirme-view'); indirmeCiz(); }
function indirmeCiz() {
    if (!SITE) return;
    const f = $('ind-filtre'); f.replaceChildren();
    for (const [k, ad] of [['hepsi', 'Tümü'], ['yazilim', 'Yazılım'], ['oyun', 'Oyun'], ['tasarim', 'Tasarım']]) {
        const b = el('button', 'px-4 py-2 rounded-xl text-sm font-semibold border transition-all ' + (indirmeFiltre === k ? 'bg-primary-600 text-white border-primary-600' : 'bg-white text-slate-600 border-slate-200'), ad);
        b.onclick = () => { indirmeFiltre = k; indirmeCiz(); }; f.appendChild(b);
    }
    const pro = $('ind-pro');
    if (SITE.ayar.pro_link || hesapBen?.pro) {
        pro.classList.remove('hidden'); pro.replaceChildren();
        const yz = el('div'); yz.append(el('div', 'font-display font-black text-lg text-slate-900', 'MX Dev Pro'), el('div', 'text-sm text-slate-600', hesapBen?.pro ? 'Pro üyesin, Pro dosyalar açık ✓' : 'Pro dosyalara erişim ve öncelikli destek. Satın alınca gelen anahtarı profilinde etkinleştir.'));
        const a = el('a', BUTON, hesapBen?.pro ? 'Profilime git' : 'Pro\'yu incele'); a.href = '#uyelik'; a.onclick = (e) => { e.preventDefault(); hesapBen?.pro ? openProfil() : openUyelik(); };
        pro.append(yz, a);
    } else pro.classList.add('hidden');
    const l = $('ind-liste'); l.replaceChildren();
    const dosyalar = SITE.indirmeler.filter(d => indirmeFiltre === 'hepsi' || d.kategori === indirmeFiltre);
    if (!dosyalar.length) l.appendChild(el('p', 'text-sm text-slate-400', 'Bu kategoride henüz dosya yok.'));
    const pIkon = { android: 'fa-brands fa-android', windows: 'fa-brands fa-windows', linux: 'fa-brands fa-linux', web: 'fa-solid fa-globe' };
    for (const d of dosyalar) {
        const k = el('div', 'rounded-3xl border border-slate-200 bg-white p-5 shadow-sm flex flex-col');
        const ust = el('div', 'flex items-center gap-3 mb-2');
        const ik = el('div', 'w-11 h-11 rounded-2xl bg-primary-50 text-primary-600 flex items-center justify-center text-xl'); ik.appendChild(ikon(pIkon[(d.platform || '').toLowerCase()] || 'fa-solid fa-box'));
        const yz = el('div', 'flex-1'); yz.append(el('div', 'font-bold text-slate-900', `${d.ad} ${d.surum || ''}`), el('div', 'text-xs text-slate-500', `${d.platform || ''} · ${tarih(d.tarih)} · ${sayi(d.sayac)} indirme`));
        ust.append(ik, yz); if (d.pro) ust.appendChild(el('span', 'px-2 py-1 rounded-lg bg-accent-100 text-accent-700 text-[11px] font-bold', 'PRO'));
        const b = el('a', BUTON + ' mt-4 text-center', d.pro && !(hesapBen?.pro || hesapBen?.yonetici) ? 'Pro üyelere özel' : 'İndir');
        b.href = '/api/site/indir?id=' + d.id;
        b.onclick = (e) => {
            if (d.pro && !(hesapBen?.pro || hesapBen?.yonetici)) { e.preventDefault(); bildir('Bu dosya Pro üyelere özel', false); return; }
            setTimeout(siteYukle, 1500);
        };
        k.append(ust, el('p', 'text-sm text-slate-600 flex-1 whitespace-pre-line', d.notlar || ''), b);
        l.appendChild(k);
    }
}

// ------------------------------------------------------------ Fikir Panosu
function fikirSayfasi() {
    const g = sayfaKabugu('fikir-view', 'fa-solid fa-lightbulb', 'Fikir Panosu', 'Ne yapalım? Öner, oy ver; en çok oy alanlar yol haritasına girer.');
    g.innerHTML = '<form id="fk-form" class="rounded-3xl border border-slate-200 bg-slate-50 p-5 mb-8 space-y-3"><input name="baslik" required minlength="4" maxlength="120" placeholder="Fikrin (kısa başlık)" class="' + GIRDI + '"><textarea name="aciklama" rows="3" maxlength="1500" placeholder="Biraz anlat (isteğe bağlı)" class="' + GIRDI + ' resize-none"></textarea><button class="' + BUTON + '">Fikrimi paylaş</button></form><div id="fk-liste" class="space-y-3"></div>';
    $('fk-form').addEventListener('submit', async (e) => {
        e.preventDefault(); if (girisGerek('Fikir paylaşmak')) return;
        try { await api('fikir', Object.fromEntries(new FormData(e.target))); e.target.reset(); bildir('Fikrin panoya eklendi 💡'); fikirCiz(); }
        catch (err) { bildir(err.message, false); }
    });
}
function openFikirler() { gorunum('fikir-view'); fikirCiz(); }
async function fikirCiz() {
    const l = $('fk-liste');
    try {
        const d = await api('fikirler'); l.replaceChildren();
        if (!d.fikirler.length) l.appendChild(el('p', 'text-sm text-slate-400', 'İlk fikri sen yaz!'));
        const durum = { yeni: ['Yeni', 'bg-slate-100 text-slate-600'], planlandi: ['Planlandı', 'bg-accent-100 text-accent-700'], yapiliyor: ['Yapılıyor', 'bg-amber-100 text-amber-700'], bitti: ['Yapıldı ✓', 'bg-primary-100 text-primary-700'], red: ['Şimdilik yok', 'bg-red-50 text-red-600'] };
        for (const f of d.fikirler) {
            const k = el('div', 'rounded-3xl border border-slate-200 bg-white p-4 flex gap-4');
            const oy = el('button', 'w-16 shrink-0 rounded-2xl border-2 flex flex-col items-center justify-center py-2 font-bold ' + (f.benim ? 'border-primary-500 bg-primary-50 text-primary-700' : 'border-slate-200 text-slate-600 hover:border-primary-400'));
            oy.append(ikon('fa-solid fa-caret-up text-xl'), el('span', 'text-sm', sayi(f.oy)));
            oy.onclick = async () => { if (girisGerek('Oy vermek')) return; try { await api('fikir/oy', { id: f.id }); fikirCiz(); } catch (e) { bildir(e.message, false); } };
            const yz = el('div', 'flex-1 min-w-0');
            const ust = el('div', 'flex flex-wrap items-center gap-2 mb-1');
            ust.append(el('span', 'font-bold text-slate-900 break-words', f.baslik), el('span', 'px-2 py-0.5 rounded-lg text-[11px] font-bold ' + durum[f.durum][1], durum[f.durum][0]));
            yz.append(ust);
            if (f.aciklama) yz.appendChild(el('p', 'text-sm text-slate-600 whitespace-pre-line break-words', f.aciklama));
            if (f.yanit) { const y = el('p', 'text-sm text-accent-700 bg-accent-50 rounded-xl px-3 py-2 mt-2 whitespace-pre-line'); y.append(el('b', '', 'Stüdyo: '), document.createTextNode(f.yanit)); yz.appendChild(y); }
            yz.appendChild(el('div', 'text-[11px] text-slate-400 mt-1', `${f.ad || 'silinmiş üye'} · ${tarih(f.tarih)}`));
            k.append(oy, yz); l.appendChild(k);
        }
    } catch (e) { l.replaceChildren(el('p', 'text-red-600', e.message)); }
}

// ------------------------------------------------------------ İletişim
function iletisimSayfasi() {
    const g = sayfaKabugu('iletisim-view', 'fa-solid fa-envelope', 'İletişim', 'Soru, öneri, iş birliği ya da hata bildirimi: doğrudan stüdyoya ulaşır.');
    g.innerHTML = '<form id="il-form" class="max-w-2xl space-y-3"><div class="grid sm:grid-cols-2 gap-3"><input name="ad" required minlength="2" maxlength="80" placeholder="Adın" class="' + GIRDI + '"><input name="eposta" type="email" maxlength="200" placeholder="E-posta (cevap için)" class="' + GIRDI + '"></div><select name="konu" class="' + GIRDI + '"><option>Soru</option><option>Öneri</option><option>Hata bildirimi</option><option>İş birliği</option><option>Pro / lisans</option><option>Diğer</option></select><textarea name="metin" rows="6" required minlength="5" maxlength="3000" placeholder="Mesajın" class="' + GIRDI + ' resize-none"></textarea><button class="' + BUTON + '">Gönder</button><p id="il-mesaj" class="text-sm font-semibold text-primary-700"></p></form>';
    $('il-form').addEventListener('submit', async (e) => {
        e.preventDefault(); const b = e.target.querySelector('button'); b.disabled = true;
        try { await api('iletisim', Object.fromEntries(new FormData(e.target))); e.target.reset(); $('il-mesaj').textContent = 'Mesajın ulaştı, teşekkürler! En kısa sürede dönüş yapacağız.'; }
        catch (err) { $('il-mesaj').textContent = err.message; } finally { b.disabled = false; }
    });
}
function openIletisim() {
    gorunum('iletisim-view');
    if (hesapBen) { const f = $('il-form'); if (!f.ad.value) f.ad.value = hesapBen.ad; if (!f.eposta.value && hesapBen.eposta) f.eposta.value = hesapBen.eposta; }
}

// ------------------------------------------------------------ Profil + üye kartı + lisans
function profilSayfasi() {
    const g = sayfaKabugu('profil-view', 'fa-solid fa-id-card', 'Profilim', 'Üye kartın, rozetlerin, lisansların');
    g.innerHTML = `<div class="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div><div id="pr-kart" class="relative rounded-[2rem] p-7 text-white shadow-2xl overflow-hidden aspect-[1.6/1] flex flex-col justify-between"></div>
            <div class="flex flex-wrap gap-2 mt-4"><button id="pr-png" class="${KUCUK}"><i class="fa-solid fa-image"></i> Kartı resim olarak indir</button><button id="pr-yonetici" class="hidden ${KUCUK}"><i class="fa-solid fa-shield-halved"></i> Yönetici Paneli</button><button onclick="openMimoView()" class="${KUCUK}"><i class="fa-solid fa-robot"></i> MIMO sohbetlerim</button></div>
            <div id="pr-rozet" class="flex flex-wrap gap-2 mt-5"></div><div id="pr-sayilar" class="grid grid-cols-4 gap-2 mt-5"></div></div>
        <div class="space-y-6">
            <form id="pr-form" class="rounded-3xl border border-slate-200 p-5 space-y-3"><h2 class="font-display font-black text-lg">Kartını düzenle</h2>
                <input name="unvan" maxlength="30" placeholder="Unvan (ör. Espor Oyuncusu)" class="${GIRDI}">
                <label class="flex items-center gap-3 text-sm font-semibold text-slate-600">Kart rengi <input name="renk" type="color" value="#10b981" class="w-12 h-10 rounded-lg border border-slate-200"></label>
                <textarea name="biyografi" rows="3" maxlength="300" placeholder="Kendinden kısaca bahset" class="${GIRDI} resize-none"></textarea>
                <button class="${BUTON}">Kaydet</button></form>
            <form id="pr-lisans" class="rounded-3xl border border-slate-200 p-5 space-y-3"><h2 class="font-display font-black text-lg">Lisans etkinleştir</h2><p class="text-xs text-slate-500">Shopier'den aldığın anahtarı yapıştır (MXD-XXXX-XXXX-XXXX-XXXX).</p>
                <div class="flex gap-2"><input name="anahtar" required placeholder="MXD-…" class="${GIRDI} uppercase"><button class="${BUTON}">Etkinleştir</button></div><div id="pr-lisanslar" class="text-xs text-slate-600 space-y-1"></div></form>
            <div class="rounded-3xl border border-red-100 bg-red-50/50 p-5"><h2 class="font-display font-black text-lg text-red-700 mb-1">Hesabı sil</h2><p class="text-xs text-slate-500 mb-3">Hesabın, yorumların, oyların, sohbetlerin ve skorların kalıcı olarak silinir.</p><button id="pr-sil" class="px-4 py-2 rounded-xl bg-red-600 text-white text-xs font-bold">Hesabımı sil</button></div>
        </div></div>`;
    const f = $('pr-form');
    f.addEventListener('input', () => kartCiz({ ...hesapBen, unvan: f.unvan.value, renk: f.renk.value, biyografi: f.biyografi.value }));
    f.addEventListener('submit', async (e) => {
        e.preventDefault();
        try { await api('profil', Object.fromEntries(new FormData(f))); Object.assign(hesapBen, Object.fromEntries(new FormData(f))); bildir('Profil kaydedildi ✓'); } catch (err) { bildir(err.message, false); }
    });
    $('pr-lisans').addEventListener('submit', async (e) => {
        e.preventDefault();
        try { const r = await api('lisans', { anahtar: e.target.anahtar.value.trim() }); e.target.reset(); hesapBen.pro = true; bildir(`${r.urun} etkinleştirildi 🎉`); openProfil(); }
        catch (err) { bildir(err.message, false); }
    });
    $('pr-png').onclick = kartPng;
    $('pr-yonetici').onclick = () => openYoneticiView();
    $('pr-sil').onclick = async () => {
        if (prompt('Silmek için kullanıcı adını yaz: ' + hesapBen.ad) !== hesapBen.ad) return;
        try { await api('hesap_sil', {}); hesapBen = null; hesapGoster(); closeAllViews(); bildir('Hesabın silindi'); } catch (e) { bildir(e.message, false); }
    };
}
function kartCiz(k) {
    const kart = $('pr-kart'); const renk = k.renk || '#10b981';
    kart.style.background = `linear-gradient(135deg, ${renk}, #2563eb)`;
    kart.replaceChildren();
    const ust = el('div', 'flex justify-between items-start');
    ust.append(el('span', 'font-display font-black text-lg tracking-tight', 'MertixtanStudios.'), el('span', 'px-2.5 py-1 rounded-lg bg-white/20 text-xs font-bold', k.pro ? 'PRO' : (k.yonetici ? 'STÜDYO' : 'ÜYE')));
    const orta = el('div'); orta.append(el('div', 'text-[11px] uppercase tracking-widest opacity-80', 'Üye Adı'), el('div', 'font-display font-black text-3xl break-all', k.ad), el('div', 'text-sm opacity-90', k.unvan || 'Mertixtan Üyesi'));
    if (k.biyografi) orta.appendChild(el('div', 'text-xs opacity-80 mt-1 line-clamp-2', k.biyografi));
    const alt = el('div', 'flex justify-between text-xs font-bold opacity-90');
    alt.append(el('span', '', '#' + String(k.id).padStart(5, '0')), el('span', '', 'Katılım: ' + tarih(k.olusturma)));
    kart.append(ust, orta, alt);
}
function kartPng() {
    const k = { ...hesapBen, ...Object.fromEntries(new FormData($('pr-form'))) };
    const c = document.createElement('canvas'); c.width = 1200; c.height = 750; const x = c.getContext('2d');
    const g = x.createLinearGradient(0, 0, 1200, 750); g.addColorStop(0, k.renk || '#10b981'); g.addColorStop(1, '#2563eb');
    x.fillStyle = g; x.beginPath(); x.roundRect(0, 0, 1200, 750, 60); x.fill();
    x.fillStyle = '#fff'; x.font = '900 44px Outfit, sans-serif'; x.fillText('MertixtanStudios.', 70, 110);
    x.font = '700 30px Inter, sans-serif'; x.fillText(k.pro ? 'PRO' : (k.yonetici ? 'STÜDYO' : 'ÜYE'), 1030, 105);
    x.globalAlpha = .8; x.font = '700 24px Inter, sans-serif'; x.fillText('ÜYE ADI', 70, 330); x.globalAlpha = 1;
    x.font = '900 96px Outfit, sans-serif'; x.fillText(k.ad, 70, 430, 1060);
    x.font = '600 38px Inter, sans-serif'; x.fillText(k.unvan || 'Mertixtan Üyesi', 70, 490, 1060);
    x.font = '700 30px Inter, sans-serif'; x.fillText('#' + String(k.id).padStart(5, '0'), 70, 680); x.textAlign = 'right'; x.fillText('Katılım: ' + tarih(k.olusturma), 1130, 680);
    const a = document.createElement('a'); a.download = `mertixtan-uye-${k.ad}.png`; a.href = c.toDataURL('image/png'); a.click();
}
async function openProfil() {
    if (girisGerek('Profilini görmek')) return;
    gorunum('profil-view');
    const f = $('pr-form'); f.unvan.value = hesapBen.unvan || ''; f.renk.value = hesapBen.renk || '#10b981'; f.biyografi.value = hesapBen.biyografi || '';
    $('pr-yonetici').classList.toggle('hidden', !hesapBen.yonetici);
    kartCiz(hesapBen);
    try {
        const p = await api('profil');
        const r = $('pr-rozet'); r.replaceChildren();
        if (!p.rozetler.length) r.appendChild(el('span', 'text-xs text-slate-400', 'Rozet kazanmak için uç, fikir yaz, MIMO\'ya öğret.'));
        for (const z of p.rozetler) r.appendChild(el('span', 'px-3 py-1.5 rounded-xl bg-amber-50 border border-amber-200 text-amber-700 text-xs font-bold', '🏅 ' + z));
        const s = $('pr-sayilar'); s.replaceChildren();
        for (const [ad, n] of [['Yorum', p.sayilar.yorum], ['Fikir', p.sayilar.fikir], ['MIMO dersi', p.sayilar.ders], ['Uçuş', p.sayilar.ucus]]) {
            const k = el('div', 'rounded-2xl bg-slate-50 border border-slate-200 p-3 text-center'); k.append(el('div', 'font-display font-black text-xl text-slate-900', sayi(n)), el('div', 'text-[10px] font-bold uppercase text-slate-500', ad)); s.appendChild(k);
        }
        const l = $('pr-lisanslar'); l.replaceChildren();
        for (const x of p.lisanslar) l.appendChild(el('div', '', `✓ ${x.urun} · ${x.anahtar} · ${tarih(x.etkinlesme)}`));
        for (const x of p.siparisler || []) l.appendChild(el('div', 'text-slate-500', `Shopier sipariş ${x.orderid}${x.test ? ' (test)' : ''} · ${tarih(x.tarih)}`));
    } catch (e) {}
}

// ------------------------------------------------------------ Üyelik (Pro, Shopier ile otomatik)
const PRO_OZELLIKLER = [
    ['fa-download', 'Pro\'ya özel dosyalar', 'İndirme Merkezi\'ndeki PRO etiketli uygulama ve paketleri indirirsin.'],
    ['fa-key', 'MX Dev Pro lisansı', 'Hesabına bir lisans anahtarı tanımlanır; MX Dev uygulaması Pro özelliklerini bununla açar.'],
    ['fa-headset', 'Öncelikli destek', 'İletişim mesajların stüdyonun gelen kutusunda en üstte, PRO işaretiyle görünür.'],
    ['fa-star', 'Pro rozeti', 'Profil kartında PRO, skor tablosunda ★ işareti.'],
];
function uyelikSayfasi() {
    const g = sayfaKabugu('uyelik-view', 'fa-solid fa-crown', 'Üyelik', 'Ücretsiz üyelik ve Mertixtan Pro');
    g.innerHTML = `<div id="uy-durum" class="mb-6"></div>
        <div class="grid grid-cols-1 md:grid-cols-2 gap-5 mb-8">
            <div class="rounded-3xl border border-slate-200 bg-white p-6 flex flex-col"><div class="text-xs font-extrabold uppercase tracking-wider text-slate-500">Ücretsiz</div>
                <div class="font-display font-black text-3xl text-slate-900 mt-1 mb-4">0 ₺</div>
                <ul class="space-y-2 text-sm text-slate-600 flex-1">${['MIMO ile sohbet ve sohbet geçmişi', '3D Gökyüzü Ustası ve skor tablosu', 'Anket, fikir panosu, yorumlar', 'Ücretsiz indirmeler', 'Üye kartı ve rozetler'].map(x => `<li class="flex gap-2"><i class="fa-solid fa-check text-primary-600 mt-1"></i><span>${x}</span></li>`).join('')}</ul>
                <button id="uy-ucretsiz" class="mt-6 ${KUCUK} py-3">Ücretsiz üye ol</button></div>
            <div class="rounded-3xl border-2 border-primary-400 bg-gradient-to-br from-primary-50 to-accent-50 p-6 flex flex-col shadow-xl"><div class="flex justify-between items-center"><div class="text-xs font-extrabold uppercase tracking-wider text-primary-700">Mertixtan Pro</div><span class="px-2 py-1 rounded-lg bg-primary-600 text-white text-[10px] font-bold">TEK SEFERLİK</span></div>
                <div id="uy-fiyat" class="font-display font-black text-3xl text-slate-900 mt-1 mb-4"></div>
                <ul id="uy-pro-liste" class="space-y-3 text-sm text-slate-700 flex-1"></ul>
                <a id="uy-al" target="_blank" rel="noopener" class="mt-6 text-center ${BUTON}">Shopier'den satın al</a>
                <p class="text-xs text-slate-500 mt-3">Shopier'de <b>bu sitedeki hesabının e-postasını</b> kullan. Ödeme onaylanınca Pro hesabında kendiliğinden açılır; ayrıca bir şey yapman gerekmez.</p></div>
        </div>
        <div class="grid grid-cols-1 md:grid-cols-2 gap-5">
            <form id="uy-bagla" class="rounded-3xl border border-slate-200 p-5 space-y-3"><h2 class="font-display font-black text-lg">Shopier'de başka e-posta mı kullandın?</h2><p class="text-xs text-slate-500">Shopier'in gönderdiği e-postadaki sipariş numarasını ve ödemede kullandığın e-postayı yaz; sipariş hesabına bağlanır.</p>
                <input name="orderid" required placeholder="Sipariş numarası" class="${GIRDI}"><input name="eposta" type="email" required placeholder="Shopier'de kullandığın e-posta" class="${GIRDI}"><button class="${BUTON}">Siparişimi bağla</button></form>
            <form id="uy-lisans" class="rounded-3xl border border-slate-200 p-5 space-y-3"><h2 class="font-display font-black text-lg">Lisans anahtarın mı var?</h2><p class="text-xs text-slate-500">Elden ya da kampanyayla aldığın MXD-… anahtarını gir.</p>
                <input name="anahtar" required placeholder="MXD-XXXX-XXXX-XXXX-XXXX" class="${GIRDI} uppercase"><button class="${BUTON}">Etkinleştir</button></form>
        </div>`;
    const l = $('uy-pro-liste');
    for (const [ik, b, a] of PRO_OZELLIKLER) { const li = el('li', 'flex gap-3'); const i = ikon('fa-solid ' + ik + ' text-primary-600 mt-1 w-4'); const yz = el('div'); yz.append(el('b', 'block text-slate-900', b), el('span', 'text-slate-600', a)); li.append(i, yz); l.appendChild(li); }
    $('uy-ucretsiz').onclick = () => hesapBen ? openProfil() : hesapPencere('kayit');
    $('uy-bagla').addEventListener('submit', async (e) => {
        e.preventDefault(); if (girisGerek('Siparişini bağlamak')) return;
        try { await api('siparis_bagla', Object.fromEntries(new FormData(e.target))); e.target.reset(); await hesapYenile(); bildir('Pro açıldı 🎉'); openUyelik(); } catch (err) { bildir(err.message, false); }
    });
    $('uy-lisans').addEventListener('submit', async (e) => {
        e.preventDefault(); if (girisGerek('Lisans etkinleştirmek')) return;
        try { const r = await api('lisans', { anahtar: e.target.anahtar.value.trim() }); e.target.reset(); await hesapYenile(); bildir(`${r.urun} etkinleştirildi 🎉`); openUyelik(); } catch (err) { bildir(err.message, false); }
    });
}
async function hesapYenile() { try { hesapBen = (await hesapIstek('ben')).kullanici; hesapGoster(); } catch (e) {} }
function openUyelik() {
    gorunum('uyelik-view');
    const a = SITE?.ayar || {};
    $('uy-fiyat').textContent = a.pro_fiyat || 'Fiyat yakında';
    const al = $('uy-al');
    if (a.pro_link) { al.href = a.pro_link; al.classList.remove('pointer-events-none', 'opacity-50'); al.textContent = 'Shopier\'den satın al'; }
    else { al.removeAttribute('href'); al.classList.add('pointer-events-none', 'opacity-50'); al.textContent = 'Satış yakında açılacak'; }
    const d = $('uy-durum'); d.replaceChildren();
    const kut = el('div', 'rounded-2xl px-5 py-4 text-sm font-semibold ');
    if (!hesapBen) { kut.className += 'bg-amber-50 text-amber-800 border border-amber-200'; kut.textContent = 'Pro almadan önce ücretsiz üye ol: Pro, Shopier\'de kullandığın e-postayla eşleşen hesaba kendiliğinden tanımlanır.'; }
    else if (hesapBen.pro) { kut.className += 'bg-primary-50 text-primary-800 border border-primary-200'; kut.textContent = '✓ Pro üyesin. Teşekkürler! Lisansın profil sayfanda.'; }
    else if (!hesapBen.eposta) { kut.className += 'bg-amber-50 text-amber-800 border border-amber-200'; kut.textContent = 'Hesabında e-posta yok. Satın aldıktan sonra aşağıdan sipariş numaranla Pro\'yu bağlayabilirsin.'; }
    else { kut.className += 'bg-slate-50 text-slate-700 border border-slate-200'; kut.textContent = `Shopier'de şu e-postayı kullan: ${hesapBen.eposta}`; }
    d.appendChild(kut);
    $('uy-ucretsiz').textContent = hesapBen ? 'Ücretsiz üyesin ✓' : 'Ücretsiz üye ol';
}

// ------------------------------------------------------------ site araması
function aramaKur() {
    const o = el('div', 'hidden fixed inset-0 z-[110] bg-slate-900/60 backdrop-blur-sm p-4 pt-20'); o.id = 'arama';
    o.innerHTML = '<div class="max-w-2xl mx-auto bg-white rounded-3xl shadow-2xl p-4"><div class="flex gap-2 items-center"><i class="fa-solid fa-magnifying-glass text-slate-400 ml-2"></i><input id="arama-girdi" placeholder="Haber, soru, indirme, fikir ara…" class="flex-1 outline-none px-2 py-3 text-base"><button onclick="aramaKapat()" class="w-9 h-9 rounded-xl bg-slate-100"><i class="fa-solid fa-xmark"></i></button></div><div id="arama-sonuc" class="max-h-[60vh] overflow-y-auto mt-2 space-y-1"></div></div>';
    o.addEventListener('click', (e) => { if (e.target === o) aramaKapat(); });
    document.body.appendChild(o);
    let z;
    $('arama-girdi').addEventListener('input', (e) => { clearTimeout(z); z = setTimeout(() => aramaYap(e.target.value), 250); });
}
function aramaAc() { $('arama').classList.remove('hidden'); setTimeout(() => $('arama-girdi').focus(), 50); }
function aramaKapat() { $('arama').classList.add('hidden'); }
async function aramaYap(q) {
    const k = $('arama-sonuc'); k.replaceChildren();
    if (q.trim().length < 2) return;
    try {
        const d = await api('ara?q=' + encodeURIComponent(q));
        if (!d.sonuclar.length) k.appendChild(el('p', 'text-sm text-slate-400 p-3', 'Sonuç yok.'));
        for (const s of d.sonuclar) {
            const b = el('button', 'w-full text-left rounded-2xl hover:bg-slate-50 p-3');
            const u = el('div', 'flex items-center gap-2'); u.append(el('span', 'px-2 py-0.5 rounded-lg bg-primary-100 text-primary-700 text-[10px] font-bold', s.tur), el('b', 'text-sm text-slate-800', s.baslik));
            b.append(u, el('div', 'text-xs text-slate-500 mt-0.5 line-clamp-2', s.ozet));
            b.onclick = () => {
                aramaKapat();
                if (s.tur === 'Haber') openHaber(s.id);
                else if (s.tur === 'İndirme') openIndirme('hepsi');
                else if (s.tur === 'Fikir') openFikirler();
                else { closeAllViews(); $('sss-ara').value = ''; sssCiz(s.id); setTimeout(() => $('sss-' + s.id)?.scrollIntoView({ behavior: 'smooth', block: 'center' }), 100); }
            };
            k.appendChild(b);
        }
    } catch (e) {}
}

// ------------------------------------------------------------ karanlık mod
function karanlikUygula(acik) {
    document.documentElement.classList.toggle('koyu', acik);
    const i = $('karanlik-ikon'); if (i) i.className = acik ? 'fa-solid fa-sun' : 'fa-solid fa-moon';
}
function karanlikDegistir() {
    const acik = !document.documentElement.classList.contains('koyu');
    karanlikUygula(acik); try { localStorage.setItem('mx_koyu', acik ? '1' : '0'); } catch (e) {}
}

// ------------------------------------------------------------ MIMO: sohbet geçmişi, durdur, MIMO'ya öğret
let mimoSohbetId = null, mimoDurdurucu = null;
function mimoKur() {
    const v = $('mimo-view').firstElementChild;
    const arac = el('div', 'flex flex-wrap items-center gap-2 mb-4');
    arac.innerHTML = `<button id="mimo-yeni" class="${KUCUK}"><i class="fa-solid fa-plus"></i> Yeni sohbet</button><select id="mimo-gecmis" class="rounded-lg border border-slate-200 text-xs font-bold px-2 py-1.5 max-w-[60%]"><option value="">Geçmiş sohbetler…</option></select><button id="mimo-gsil" class="hidden ${KUCUK} text-red-600">Bu sohbeti sil</button>`;
    $('mimo-mesajlar').before(arac);
    $('mimo-yeni').onclick = mimoYeni;
    $('mimo-gecmis').onchange = (e) => e.target.value && mimoAc(e.target.value);
    $('mimo-gsil').onclick = async () => {
        if (!mimoSohbetId || !confirm('Bu sohbet silinsin mi?')) return;
        try { await api('sohbet/sil', { id: mimoSohbetId }); mimoYeni(); mimoGecmisYukle(); } catch (e) { bildir(e.message, false); }
    };
    const dur = el('button', 'hidden px-5 py-3 rounded-2xl bg-slate-800 text-white font-bold text-sm', 'Durdur'); dur.id = 'mimo-durdur'; dur.type = 'button';
    dur.onclick = () => mimoDurdurucu?.abort();
    $('mimo-gonder').after(dur);
    const not = v.querySelector('p.text-\\[11px\\]');
    if (not) not.textContent = 'MIMO yanılabilir; önemli bilgileri kontrol et. Cevapları 👍 / 👎 ile puanla, yanlışların doğrusunu yaz: bir sonraki eğitimde MIMO bunlardan öğrenir. Giriş yaptıysan sohbetlerin hesabında saklanır.';
}
function mimoYeni() {
    mimoSohbetId = null; mimoGecmis = [];
    const k = $('mimo-mesajlar'); k.replaceChildren(); mimoBalonu('assistant', 'Merhaba! Ben MIMO. Bana Türkçe bir şey sor.', -1);
    $('mimo-gecmis').value = ''; $('mimo-gsil').classList.add('hidden');
}
async function mimoGecmisYukle() {
    const s = $('mimo-gecmis'); if (!s) return;
    s.classList.toggle('hidden', !hesapBen);
    if (!hesapBen) return;
    try {
        const d = await api('sohbetler');
        s.replaceChildren(el('option', '', 'Geçmiş sohbetler…')); s.firstChild.value = '';
        for (const x of d.sohbetler) { const o = el('option', '', `${x.baslik} · ${tarih(x.guncelleme)}`); o.value = x.id; s.appendChild(o); }
        if (mimoSohbetId) s.value = mimoSohbetId;
    } catch (e) {}
}
async function mimoAc(id) {
    try {
        const d = await api('sohbetler?id=' + id);
        mimoSohbetId = d.id; mimoGecmis = d.mesajlar;
        $('mimo-mesajlar').replaceChildren();
        d.mesajlar.forEach((m, i) => { const b = mimoBalonu(m.role, m.content, m.role === 'assistant' ? i : -1); if (m.role === 'assistant') mdCiz(b, m.content); });
        $('mimo-gsil').classList.remove('hidden');
    } catch (e) { bildir(e.message, false); }
}
function mimoBalonu(rol, metin, indeks) {
    const b = mimoBalon(rol, metin);
    if (rol === 'assistant' && indeks >= 0) b.parentElement.after(ogretCubugu(indeks));
    return b;
}
function ogretCubugu(indeks) {
    const c = el('div', 'flex gap-1.5 pl-11 -mt-2 text-xs');
    const gonder = async (puan, duzeltme) => {
        try { await api('mimo/ogret', { mesajlar: mimoGecmis.slice(Math.max(0, indeks - 5), indeks + 1), puan, duzeltme }); c.replaceChildren(el('span', 'text-primary-600 font-bold', puan > 0 ? '👍 Teşekkürler, not edildi' : '✓ Ders olarak kaydedildi, MIMO bir sonraki eğitimde öğrenecek')); }
        catch (e) { bildir(e.message, false); }
    };
    const iyi = el('button', 'px-2 py-1 rounded-lg hover:bg-slate-100', '👍'); iyi.title = 'İyi cevap'; iyi.onclick = () => gonder(1);
    const kotu = el('button', 'px-2 py-1 rounded-lg hover:bg-slate-100', '👎 Doğrusunu yaz'); kotu.onclick = () => {
        c.replaceChildren();
        const t = el('textarea', 'flex-1 rounded-xl border border-slate-200 px-3 py-2 text-xs resize-none'); t.rows = 2; t.maxLength = 4000; t.placeholder = 'MIMO nasıl cevap vermeliydi?';
        const g = el('button', 'px-3 rounded-xl bg-primary-600 text-white font-bold', 'Öğret'); g.onclick = () => gonder(-1, t.value.trim());
        c.append(t, g); t.focus();
    };
    const kop = el('button', 'px-2 py-1 rounded-lg hover:bg-slate-100 text-slate-500', 'Kopyala'); kop.onclick = () => { navigator.clipboard?.writeText(mimoGecmis[indeks]?.content || ''); bildir('Kopyalandı'); };
    c.append(iyi, kotu, kop);
    return c;
}
// MIMO'nun kimliği + sitenin güncel bilgileri (her soruda modele verilir)
function mimoSistem() {
    const s = SITE || {}, a = s.ayar || {};
    const satir = [
        'Sen MIMO\'sun: Mertixtan Studios\'un Türkçe yapay zekâ asistanı. Mertixtan Studios\'u Mert kurdu; oyun, yazılım ve yapay zekâ projeleri yapan bir stüdyo.',
        'Her zaman kullanıcının dilinde, varsayılan olarak Türkçe cevap ver. Samimi ama net ol; gereksiz uzatma. Kod isterse çalışan, açıklamalı kod yaz ve ``` blokları kullan.',
        'Bilmediğin şeyi uydurma, "emin değilim" de. Güncel olaylar veya internet erişimin yok. Zararlı, yasa dışı isteklere yardım etme.',
        'Kimliğin sorulursa: MIMO\'yum, Mertixtan Studios\'un asistanıyım; açık kaynak Qwen2.5-Coder modeli üzerinde çalışıyorum; özellikle kodda iyiyim.',
        'Site bilgileri (mertixtanstudios.com):',
        '- Ürünler: MX Dev (telefon-PC köprüsü, Windows+Android), MertixtanOS (Rust ile yazılmış işletim sistemi), 3D Gökyüzü Ustası (tarayıcı oyunu, skor tablosu var).',
        `- Mertixtan Pro: ${a.pro_fiyat || 'fiyat sitede'}, tek seferlik; Shopier'den alınır, sitedeki hesabın e-postasıyla alınca otomatik açılır. Özellikler → Üyelik & Pro sayfasında.`,
        '- Sayfalar: İndirme Merkezi, Fikir Panosu (öneri yaz/oyla), Skor Tablosu, İletişim, Profil (üye kartı, rozetler).',
    ];
    if (s.haberler?.length) satir.push('- Son haberler: ' + s.haberler.slice(0, 4).map(h => h.baslik).join('; ') + '.');
    for (const q of (s.sss || []).slice(0, 6)) satir.push(`- S: ${q.soru} C: ${q.cevap}`);
    if (hesapBen) satir.push(`Konuştuğun kişi: ${hesapBen.ad}${hesapBen.pro ? ' (Pro üye)' : ''}.`);
    return satir.join('\n');
}

// Güvenli Markdown: önce bütün HTML kaçırılır, sonra sadece kod/kalın/italik/liste/başlık biçimlenir
function mdCiz(kutu, metin) {
    const kac = (x) => x.replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
    const parcalar = metin.split(/```/);
    let html = '';
    parcalar.forEach((p, i) => {
        if (i % 2) {  // kod bloğu
            const ilk = p.indexOf('\n'); const kod = ilk >= 0 && /^[\w+#.-]*$/.test(p.slice(0, ilk).trim()) ? p.slice(ilk + 1) : p;
            html += `<pre class="my-2 rounded-xl bg-slate-900 text-slate-100 text-xs p-3 overflow-x-auto whitespace-pre"><code>${kac(kod.replace(/\n$/, ''))}</code></pre>`;
        } else {
            let t = kac(p)
                .replace(/`([^`\n]+)`/g, '<code class="px-1 rounded bg-slate-200 text-[0.85em]">$1</code>')
                .replace(/\*\*([^*\n]+)\*\*/g, '<b>$1</b>')
                .replace(/^#{1,4} (.+)$/gm, '<b class="block mt-2">$1</b>')
                .replace(/^\s*[-*] (.+)$/gm, '• $1');
            html += `<span class="whitespace-pre-wrap">${t}</span>`;
        }
    });
    kutu.innerHTML = html;
}

window.mimoGonder = async function (metin) {
    if (mimoMesgul || !metin.trim()) return;
    mimoMesgul = true; $('mimo-gonder').classList.add('hidden'); $('mimo-durdur').classList.remove('hidden');
    mimoBalon('user', metin); mimoGecmis.push({ role: 'user', content: metin });
    const b = mimoBalon('assistant', '…'); let yazi = '';
    mimoDurdurucu = new AbortController();
    try {
        const istek = (mesajlar) => fetch(MIMO_ADRES, { method: 'POST', signal: mimoDurdurucu.signal, headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ messages: mesajlar, stream: true, temperature: 0.7, top_p: 0.8, max_tokens: 1024 }) });
        let r = await istek([{ role: 'system', content: mimoSistem() }, ...mimoGecmis.slice(-10)]);
        if (r.status === 400) r = await istek(mimoGecmis.slice(-1));  // model bağlamı küçükse (yedek model) sistem mesajısız dene
        if (r.status === 503 || r.status === 429) throw new Error('Çok hızlı yazıyorsun, biraz bekleyip tekrar dene.');
        if (!r.ok || !r.body) throw new Error('Şu an MIMO\'ya ulaşılamıyor. Biraz sonra tekrar dener misin?');
        const okur = r.body.getReader(), coz = new TextDecoder(); let tampon = '';
        while (true) {
            const { value, done } = await okur.read(); if (done) break;
            tampon += coz.decode(value, { stream: true });
            const satirlar = tampon.split('\n'); tampon = satirlar.pop();
            for (const s of satirlar) {
                if (!s.startsWith('data: ') || s.includes('[DONE]')) continue;
                try { const p = JSON.parse(s.slice(6)).choices[0].delta.content; if (p) { yazi += p; mdCiz(b, yazi); } } catch (e) {}
            }
            $('mimo-mesajlar').scrollTop = 1e9;
        }
    } catch (e) {
        if (e.name !== 'AbortError') { b.textContent = e.message; mimoGecmis.pop(); yazi = null; }
    } finally {
        mimoMesgul = false; mimoDurdurucu = null;
        $('mimo-gonder').classList.remove('hidden'); $('mimo-durdur').classList.add('hidden'); $('mimo-gonder').disabled = false;
    }
    if (yazi === null) return;
    if (!yazi) b.textContent = '…';
    mimoGecmis.push({ role: 'assistant', content: yazi || '…' });
    b.parentElement.after(ogretCubugu(mimoGecmis.length - 1));
    if (hesapBen) {
        try { const r = await api('sohbet', { id: mimoSohbetId, mesajlar: mimoGecmis }); if (!mimoSohbetId) { mimoSohbetId = r.id; mimoGecmisYukle(); $('mimo-gsil').classList.remove('hidden'); } } catch (e) {}
    }
};

// ------------------------------------------------------------ yönetici paneli: içerik yönetimi
const YONET = {
    haber: { ad: 'Haberler', yeni: true, alanlar: [['baslik', 'Başlık'], ['etiket', 'Etiket (ör. YAZILIM)'], ['ozet', 'Kısa özet', 'alan'], ['icerik', 'İçerik (paragrafları boş satırla ayır)', 'buyuk'], ['yayinda', 'Yayında', 'onay', 1]],
        ozet: r => [r.baslik, r.etiket, tarih(r.tarih), r.yayinda ? 'Yayında' : 'Taslak'] },
    yol: { ad: 'Yol Haritası', yeni: true, alanlar: [['baslik', 'Başlık'], ['aciklama', 'Açıklama', 'alan'], ['durum', 'Durum', 'sec', 'plan', [['plan', 'Sırada'], ['yapiliyor', 'Yapılıyor'], ['bitti', 'Tamamlandı']]], ['sira', 'Sıra', 'sayi', 0]],
        ozet: r => [r.baslik, { plan: 'Sırada', yapiliyor: 'Yapılıyor', bitti: 'Tamamlandı' }[r.durum], 'Sıra ' + r.sira] },
    sss: { ad: 'SSS', yeni: true, alanlar: [['soru', 'Soru'], ['cevap', 'Cevap', 'buyuk'], ['sira', 'Sıra', 'sayi', 0]], ozet: r => [r.soru, (r.cevap || '').slice(0, 80)] },
    anket: { ad: 'Anketler', yeni: true, alanlar: [['soru', 'Soru'], ['secenekler', 'Seçenekler (her satıra bir tane, 2-8)', 'alan'], ['aktif', 'Sitede göster', 'onay', 1]],
        ozet: r => [r.soru, r.secenekler.map((s, i) => `${s}: ${r.oylar[i]}`).join(' · '), r.aktif ? 'Aktif' : 'Kapalı'], duzenle: r => ({ ...r, secenekler: r.secenekler.join('\n') }) },
    indirme: { ad: 'İndirmeler', yeni: true, alanlar: [['ad', 'Ad'], ['surum', 'Sürüm'], ['platform', 'Platform (Android, Windows, Web…)'], ['kategori', 'Kategori', 'sec', 'yazilim', [['yazilim', 'Yazılım'], ['oyun', 'Oyun'], ['tasarim', 'Tasarım']]], ['url', 'Dosya bağlantısı (https://…)'], ['notlar', 'Notlar / değişiklikler', 'alan'], ['pro', 'Sadece Pro üyeler', 'onay', 0]],
        ozet: r => [`${r.ad} ${r.surum}`, r.platform, `${r.sayac} indirme`, r.pro ? 'PRO' : 'Herkese açık'] },
    fikir: { ad: 'Fikirler', alanlar: [['durum', 'Durum', 'sec', 'yeni', [['yeni', 'Yeni'], ['planlandi', 'Planlandı'], ['yapiliyor', 'Yapılıyor'], ['bitti', 'Yapıldı'], ['red', 'Şimdilik yok']]], ['yanit', 'Stüdyo yanıtı (herkes görür)', 'alan']],
        ozet: r => [r.baslik, `${r.oy} oy · ${r.ad || '—'}`, r.durum] },
    yorum: { ad: 'Yorumlar', ozet: r => [r.metin.slice(0, 90), `${r.ad} → ${r.baslik}`, tarih(r.tarih)] },
    mesaj: { ad: 'Mesajlar', ozet: r => [`${r.okundu ? '' : '● '}${r.pro ? '[PRO] ' : ''}${r.konu}: ${r.metin.slice(0, 80)}`, `${r.ad} ${r.eposta ? '<' + r.eposta + '>' : ''}`, tarih(r.tarih)] },
    mimo_ders: { ad: 'MIMO Dersleri', ozet: r => { const m = JSON.parse(r.mesajlar); const s = m.filter(x => x.role === 'user').pop(); return [`${r.puan > 0 ? '👍' : '👎'} ${s ? s.content.slice(0, 70) : ''}`, r.duzeltme ? 'Doğrusu: ' + r.duzeltme.slice(0, 70) : (m[m.length - 1]?.content || '').slice(0, 70), r.durum]; } },
    siparis: { ad: 'Siparişler', ozet: r => [`${r.test ? '[TEST] ' : ''}Sipariş ${r.orderid} · ${r.fiyat || ''} ₺`, `${r.ad || ''} <${r.eposta}>`, r.uye ? `✓ Pro verildi: ${r.uye}` : '⏳ Eşleşen hesap yok (üye sipariş no ile bağlayabilir)', tarih(r.tarih)] },
    lisans: { ad: 'Lisanslar', ozet: r => [r.anahtar, r.urun, r.ad ? `${r.ad} · ${tarih(r.etkinlesme)}` : 'Kullanılmadı'] },
    bulten: { ad: 'Bülten', ozet: r => [r.eposta, tarih(r.tarih)] },
};
let ypSekme = 'genel';
function yoneticiKur() {
    const ic = $('yonetici-view').firstElementChild;
    const genel = el('div'); genel.id = 'yp-genel';
    while (ic.children.length > 1) genel.appendChild(ic.children[1]);
    const istat = el('div', 'grid grid-cols-1 lg:grid-cols-3 gap-5 mb-8'); istat.id = 'yp-site';
    genel.insertBefore(istat, genel.children[1]);
    const ayar = el('div', 'rounded-3xl border border-slate-200 p-5 mb-8');
    ayar.innerHTML = `<h2 class="font-display font-black text-lg text-slate-900 mb-3">Site ayarları</h2><form id="yp-site-ayar" class="grid sm:grid-cols-2 gap-3">
        <label class="text-xs font-bold text-slate-500">Büyük açılış (Türkiye saati)<input name="acilis" type="datetime-local" class="${GIRDI} mt-1"></label>
        <label class="text-xs font-bold text-slate-500">YouTube kanalı<input name="youtube" placeholder="https://youtube.com/@…" class="${GIRDI} mt-1"></label>
        <label class="text-xs font-bold text-slate-500">Pro satın alma (Shopier) bağlantısı<input name="pro_link" placeholder="https://www.shopier.com/…" class="${GIRDI} mt-1"></label>
        <label class="text-xs font-bold text-slate-500">Pro fiyatı (sayfada görünür, ör. 149 ₺)<input name="pro_fiyat" maxlength="30" class="${GIRDI} mt-1"></label>
        <label class="text-xs font-bold text-slate-500">Kayan şerit (her satıra bir yazı)<textarea name="serit" rows="3" class="${GIRDI} mt-1 resize-none"></textarea></label>
        <div class="sm:col-span-2 rounded-2xl bg-slate-50 border border-slate-200 p-4 space-y-2"><div class="font-bold text-sm text-slate-800">Shopier otomatik Pro (OSB)</div>
            <p class="text-xs text-slate-500">Shopier paneli → Entegrasyonlar → Otomatik Sipariş Bildirimi: bildirim adresine <b id="yp-osb-url" class="select-all text-slate-800"></b> yaz; Shopier'in verdiği kullanıcı adı ve anahtarı buraya gir. Anahtar kaydedildikten sonra bir daha gösterilmez.</p>
            <div class="grid sm:grid-cols-2 gap-3"><input name="osb_kullanici" placeholder="OSB kullanıcı adı" autocomplete="off" class="${GIRDI}"><input name="osb_anahtar" type="password" placeholder="OSB anahtarı" autocomplete="new-password" class="${GIRDI}"></div>
            <p id="yp-osb-durum" class="text-xs font-bold"></p></div>
        <button class="${BUTON} sm:col-span-2">Ayarları kaydet</button></form>`;
    genel.insertBefore(ayar, genel.children[2]);
    ayar.querySelector('#yp-site-ayar').addEventListener('submit', async (e) => {
        e.preventDefault();
        try { await api('yonetici/site_ayar', Object.fromEntries(new FormData(e.target))); bildir('Ayarlar kaydedildi ✓'); siteYukle(); } catch (err) { bildir(err.message, false); }
    });
    const sekmeler = el('div', 'flex flex-wrap gap-2 mb-6'); sekmeler.id = 'yp-sekmeler';
    const yonet = el('div', 'hidden'); yonet.id = 'yp-yonet';
    ic.append(sekmeler, genel, yonet);
    yoneticiSekmeCiz();
}
function yoneticiSekmeCiz(sayilar = {}) {
    const s = $('yp-sekmeler'); s.replaceChildren();
    const rozet = { mesaj: sayilar.okunmamis, mimo_ders: sayilar.bekleyen_ders, fikir: sayilar.yeni_fikir };
    for (const [k, ad] of [['genel', 'Genel & Üyeler'], ...Object.entries(YONET).map(([k, v]) => [k, v.ad])]) {
        const b = el('button', 'px-3.5 py-2 rounded-xl text-xs font-bold border ' + (ypSekme === k ? 'bg-slate-900 text-white border-slate-900' : 'bg-white text-slate-600 border-slate-200'), ad);
        if (rozet[k]) b.appendChild(el('span', 'ml-1.5 px-1.5 rounded-full bg-red-500 text-white', rozet[k]));
        b.onclick = () => { ypSekme = k; yoneticiSekmeCiz(sayilar); $('yp-genel').classList.toggle('hidden', k !== 'genel'); $('yp-yonet').classList.toggle('hidden', k === 'genel'); if (k !== 'genel') yonetCiz(k); else yoneticiYukle(); };
        s.appendChild(b);
    }
}
// genel sekmesine site istatistikleri
const eskiYoneticiYukle = window.yoneticiYukle;
window.yoneticiYukle = async function () {
    await eskiYoneticiYukle();
    if (!yoneticiVeri?.site) return;
    const s = yoneticiVeri.site; yoneticiSekmeCiz(s);
    const k = $('yp-site'); k.replaceChildren();
    const z = el('div', 'lg:col-span-2 rounded-3xl border border-slate-200 p-5');
    const enCok = Math.max(1, ...s.ziyaret.map(x => x.toplam));
    z.appendChild(el('h2', 'font-display font-black text-lg text-slate-900 mb-1', 'Ziyaretler (son 14 gün)'));
    z.appendChild(el('p', 'text-xs text-slate-500 mb-4', `Bugün ${s.ziyaret[13].tekil} tekil ziyaretçi, ${s.ziyaret[13].toplam} sayfa açılışı`));
    const g = el('div', 'flex items-end gap-1.5 h-36');
    for (const d of s.ziyaret) {
        const sut = el('div', 'flex-1 flex flex-col items-center justify-end gap-1 h-full'); sut.title = `${d.gun}: ${d.tekil} tekil, ${d.toplam} açılış`;
        const bar = el('div', 'w-full rounded-t-md bg-gradient-to-t from-primary-500 to-accent-500'); bar.style.height = Math.max(2, d.toplam / enCok * 100) + '%';
        sut.append(el('span', 'text-[9px] text-slate-400', d.toplam || ''), bar, el('span', 'text-[9px] text-slate-400', d.gun.slice(8)));
        g.appendChild(sut);
    }
    z.appendChild(g);
    const o = el('div', 'rounded-3xl border border-slate-200 p-5 space-y-2 text-sm');
    o.appendChild(el('h2', 'font-display font-black text-lg text-slate-900 mb-2', 'Bekleyenler'));
    for (const [ad, n, sek] of [['Okunmamış mesaj', s.okunmamis, 'mesaj'], ['Onay bekleyen MIMO dersi', s.bekleyen_ders, 'mimo_ders'], ['Yeni fikir', s.yeni_fikir, 'fikir'], ['Bülten abonesi', s.bulten, 'bulten'], ['Lisans (kullanılan / toplam)', `${s.lisans_kullanilan} / ${s.lisans}`, 'lisans']]) {
        const sat = el('button', 'w-full flex justify-between items-center rounded-xl hover:bg-slate-50 px-3 py-2'); sat.append(el('span', 'text-slate-600', ad), el('b', 'text-slate-900', String(n)));
        sat.onclick = () => { ypSekme = sek; yoneticiSekmeCiz(s); $('yp-genel').classList.add('hidden'); $('yp-yonet').classList.remove('hidden'); yonetCiz(sek); };
        o.appendChild(sat);
    }
    k.append(z, o);
    const f = $('yp-site-ayar'); const a = SITE?.ayar || {};
    f.acilis.value = a.acilis || ''; f.youtube.value = a.youtube || ''; f.pro_link.value = a.pro_link || ''; f.serit.value = a.serit || ''; f.pro_fiyat.value = a.pro_fiyat || '';
    $('yp-osb-url').textContent = location.origin + '/api/site/shopier/osb';
    try { const o = await api('yonetici/shopier'); f.osb_kullanici.value = o.osb_kullanici; f.osb_anahtar.value = '';
        const d = $('yp-osb-durum'); d.textContent = o.osb_kullanici && o.osb_anahtar_var ? '✓ Bağlı: ödemeler Pro\'yu kendiliğinden açar' : '✗ Henüz ayarlanmadı: Pro sadece elle/anahtarla açılır'; d.className = 'text-xs font-bold ' + (o.osb_kullanici && o.osb_anahtar_var ? 'text-primary-700' : 'text-amber-700'); } catch (e) {}
};

async function yonetCiz(t) {
    const c = YONET[t], k = $('yp-yonet'); k.replaceChildren();
    const ust = el('div', 'flex flex-wrap items-center justify-between gap-3 mb-4');
    ust.appendChild(el('h2', 'font-display font-black text-xl text-slate-900', c.ad));
    const ar = el('div', 'flex flex-wrap gap-2');
    if (c.yeni) { const b = el('button', BUTON, '+ Yeni ekle'); b.onclick = () => yonetForm(t, null); ar.appendChild(b); }
    if (t === 'mimo_ders') { const a = el('a', KUCUK + ' py-3', 'Onaylı dersleri indir (JSONL)'); a.href = '/api/site/yonetici/disa?ne=mimo'; ar.appendChild(a); }
    if (t === 'bulten') { const a = el('a', KUCUK + ' py-3', 'Listeyi indir (CSV)'); a.href = '/api/site/yonetici/disa?ne=bulten'; ar.appendChild(a); }
    ust.appendChild(ar); k.appendChild(ust);
    const form = el('div'); form.id = 'yp-form'; k.appendChild(form);
    if (t === 'lisans') k.appendChild(lisansUretici());
    if (t === 'mimo_ders') k.appendChild(el('p', 'text-xs text-slate-500 mb-4', 'Onayladığın dersler JSONL olarak iner. Kaggle defterinde mimo_dersler.jsonl dosyasının sonuna ekleyip ince ayarı yeniden çalıştırınca MIMO bunları öğrenir. 👎 dersler sadece "doğrusu" yazılmışsa kullanılır.'));
    const liste = el('div', 'space-y-2'); k.appendChild(liste);
    try {
        const d = await api('yonetici/liste?tablo=' + t);
        if (!d.satirlar.length) liste.appendChild(el('p', 'text-sm text-slate-400', 'Kayıt yok.'));
        for (const r of d.satirlar) {
            const sat = el('div', 'rounded-2xl border border-slate-200 bg-white p-4 flex flex-wrap items-center gap-3');
            const yz = el('div', 'flex-1 min-w-[200px]'); const [a, ...digerleri] = c.ozet(r);
            yz.appendChild(el('div', 'font-bold text-sm text-slate-800 break-words', a));
            for (const x of digerleri) if (x) yz.appendChild(el('div', 'text-xs text-slate-500 break-words', String(x)));
            sat.appendChild(yz);
            const bt = el('div', 'flex flex-wrap gap-1.5');
            const dugme = (ad, f, kirmizi) => { const b = el('button', kirmizi ? 'px-3 py-1.5 rounded-lg text-[11px] font-bold bg-red-50 text-red-600 hover:bg-red-100' : KUCUK, ad); b.onclick = f; bt.appendChild(b); };
            if (c.alanlar) dugme('Düzenle', () => yonetForm(t, c.duzenle ? c.duzenle(r) : r));
            if (t === 'mesaj') {
                if (r.eposta) { const a2 = el('a', KUCUK, 'Yanıtla'); a2.href = `mailto:${encodeURIComponent(r.eposta)}?subject=${encodeURIComponent('Re: ' + r.konu)}`; bt.appendChild(a2); }
                dugme('Oku', () => { alert(`${r.konu}\n${r.ad} ${r.eposta || ''}\n\n${r.metin}`); if (!r.okundu) api('yonetici/durum', { tablo: 'mesaj', id: r.id }).then(() => yonetCiz(t)); });
            }
            if (t === 'mimo_ders') {
                dugme('Gör / düzelt', () => dersDuzenle(r));
                if (r.durum !== 'onay') dugme('Onayla', () => api('yonetici/durum', { tablo: 'mimo_ders', id: r.id, durum: 'onay' }).then(() => yonetCiz(t)));
                if (r.durum !== 'red') dugme('Reddet', () => api('yonetici/durum', { tablo: 'mimo_ders', id: r.id, durum: 'red' }).then(() => yonetCiz(t)));
            }
            dugme('Sil', async () => {
                if (!confirm('Silinsin mi? Geri alınamaz.')) return;
                try { await api('yonetici/sil', { tablo: t, id: r.id ?? r.anahtar ?? r.eposta }); yonetCiz(t); siteYukle(); } catch (e) { bildir(e.message, false); }
            }, true);
            sat.appendChild(bt); liste.appendChild(sat);
        }
    } catch (e) { liste.replaceChildren(el('p', 'text-red-600', e.message)); }
}
function yonetForm(t, r) {
    const c = YONET[t], k = $('yp-form'); k.replaceChildren();
    const f = el('form', 'rounded-3xl border-2 border-primary-200 bg-primary-50/30 p-5 mb-6 space-y-3');
    f.appendChild(el('h3', 'font-bold text-slate-900', r ? 'Düzenle' : 'Yeni kayıt'));
    for (const [ad, etiket, tur, vars, secenek] of c.alanlar) {
        const lb = el('label', 'block text-xs font-bold text-slate-500'); lb.appendChild(document.createTextNode(etiket));
        let g;
        if (tur === 'alan' || tur === 'buyuk') { g = el('textarea', GIRDI + ' mt-1'); g.rows = tur === 'buyuk' ? 10 : 3; }
        else if (tur === 'sec') { g = el('select', GIRDI + ' mt-1'); for (const [d, a] of secenek) { const o = el('option', '', a); o.value = d; g.appendChild(o); } }
        else if (tur === 'onay') { g = el('input', 'ml-2 w-5 h-5 align-middle'); g.type = 'checkbox'; }
        else { g = el('input', GIRDI + ' mt-1'); if (tur === 'sayi') g.type = 'number'; }
        g.name = ad;
        const deger = r ? r[ad] : vars;
        if (tur === 'onay') g.checked = !!(deger ?? 0); else g.value = deger ?? '';
        lb.appendChild(g); f.appendChild(lb);
    }
    const bt = el('div', 'flex gap-2'); const kaydet = el('button', BUTON, 'Kaydet'); const iptal = el('button', KUCUK, 'Vazgeç'); iptal.type = 'button'; iptal.onclick = () => k.replaceChildren();
    bt.append(kaydet, iptal); f.appendChild(bt);
    f.addEventListener('submit', async (e) => {
        e.preventDefault();
        const v = { tablo: t }; if (r) v.id = r.id;
        for (const [ad, , tur] of c.alanlar) v[ad] = tur === 'onay' ? (f[ad].checked ? 1 : 0) : (tur === 'sayi' ? Number(f[ad].value || 0) : f[ad].value);
        try { await api('yonetici/kaydet', v); bildir('Kaydedildi ✓'); k.replaceChildren(); yonetCiz(t); siteYukle(); } catch (err) { bildir(err.message, false); }
    });
    k.appendChild(f); f.scrollIntoView({ behavior: 'smooth', block: 'center' });
}
function lisansUretici() {
    const f = el('form', 'rounded-3xl border border-slate-200 bg-slate-50 p-5 mb-6 grid sm:grid-cols-4 gap-3 items-end');
    f.innerHTML = `<label class="text-xs font-bold text-slate-500 sm:col-span-2">Ürün<input name="urun" value="MX Dev Pro" class="${GIRDI} mt-1"></label><label class="text-xs font-bold text-slate-500">Adet<input name="adet" type="number" min="1" max="200" value="5" class="${GIRDI} mt-1"></label><button class="${BUTON}">Anahtar üret</button><label class="text-xs font-bold text-slate-500 sm:col-span-4">Not (ör. Shopier siparişi)<input name="notu" class="${GIRDI} mt-1"></label><textarea id="yp-anahtarlar" readonly rows="4" class="hidden sm:col-span-4 ${GIRDI} font-mono text-xs"></textarea>`;
    f.addEventListener('submit', async (e) => {
        e.preventDefault();
        try {
            const d = await api('yonetici/lisans_uret', Object.fromEntries(new FormData(f)));
            const t = f.querySelector('#yp-anahtarlar'); t.value = d.anahtarlar.join('\n'); t.classList.remove('hidden'); t.select();
            bildir(`${d.anahtarlar.length} anahtar üretildi. Shopier'de dijital ürün teslimatına yapıştırabilirsin.`);
            setTimeout(() => yonetCiz('lisans').then(() => { const y = $('yp-yonet').querySelector('#yp-anahtarlar'); if (y) { y.value = d.anahtarlar.join('\n'); y.classList.remove('hidden'); } }), 50);
        } catch (err) { bildir(err.message, false); }
    });
    return f;
}
function dersDuzenle(r) {
    const k = $('yp-form'); k.replaceChildren();
    const kap = el('div', 'rounded-3xl border-2 border-primary-200 bg-primary-50/30 p-5 mb-6 space-y-2');
    kap.appendChild(el('h3', 'font-bold text-slate-900', `Ders #${r.id} · ${r.puan > 0 ? '👍' : '👎'} · ${r.ad || 'ziyaretçi'}`));
    for (const m of JSON.parse(r.mesajlar)) kap.appendChild(el('div', 'text-sm whitespace-pre-line rounded-xl px-3 py-2 ' + (m.role === 'user' ? 'bg-white border border-slate-200' : 'bg-slate-100'), (m.role === 'user' ? 'Kullanıcı: ' : 'MIMO: ') + m.content));
    const t = el('textarea', GIRDI); t.rows = 4; t.placeholder = 'MIMO\'nun vermesi gereken doğru cevap'; t.value = r.duzeltme || '';
    const b = el('button', BUTON, 'Düzeltmeyi kaydet ve onayla');
    b.onclick = async () => { try { await api('yonetici/durum', { tablo: 'mimo_ders', id: r.id, durum: 'onay', duzeltme: t.value.trim() }); k.replaceChildren(); yonetCiz('mimo_ders'); } catch (e) { bildir(e.message, false); } };
    kap.append(el('div', 'text-xs font-bold text-slate-500 pt-2', 'Doğrusu:'), t, b);
    k.appendChild(kap);
}

function uyeKartiOnizleme() {
    const n = $('onizleme-no'), r = $('onizleme-rozet');
    if (!n) return;
    n.textContent = hesapBen ? '#' + String(hesapBen.id).padStart(5, '0') : '#ÖNİZLEME';
    r.textContent = hesapBen ? (hesapBen.pro ? 'PRO' : (hesapBen.yonetici ? 'STÜDYO' : 'ÜYE')) : 'ÖNİZLEME';
}

// ------------------------------------------------------------ başlangıç
(function baslat() {
    const st = document.createElement('style');
    st.textContent = `html.koyu{filter:invert(.92) hue-rotate(180deg);background:#fff}
        html.koyu img,html.koyu video,html.koyu canvas,html.koyu iframe,html.koyu #pr-kart{filter:invert(1) hue-rotate(180deg)}
        details>summary::-webkit-details-marker{display:none}`;
    document.head.appendChild(st);
    try { karanlikUygula(localStorage.getItem('mx_koyu') === '1'); } catch (e) {}
    ustDuzen();
    haberSayfasi(); indirmeSayfasi(); fikirSayfasi(); iletisimSayfasi(); profilSayfasi(); uyelikSayfasi(); aramaKur(); mimoKur(); yoneticiKur();
    $('sss-ara').addEventListener('input', () => sssCiz());
    // ana sayfadaki "Kurucu Üye Kartı" aracı: kartı hesaba kaydet
    const rol = $('member-role-select');
    if (rol) {
        const b = el('button', 'mt-3 w-full ' + BUTON, 'Kartımı hesabıma kaydet');
        b.onclick = () => {
            if (girisGerek('Kartını kaydetmek')) return;
            openProfil().then(() => { const f = $('pr-form'); f.unvan.value = rol.value; f.dispatchEvent(new Event('input')); bildir('Unvanını seçtim; "Kaydet"e basınca kartın hesabına yazılır'); });
        };
        rol.parentElement.after(b);
    }
    $('bulten-form').addEventListener('submit', async (e) => {
        e.preventDefault();
        try { await api('bulten', { eposta: e.target.eposta.value }); e.target.reset(); $('bulten-mesaj').textContent = 'Abone oldun, teşekkürler! 📬'; }
        catch (err) { $('bulten-mesaj').textContent = err.message; }
    });
    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape') aramaKapat();
        if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') { e.preventDefault(); aramaAc(); }
    });
    // giriş / çıkışta kişiye özel içerik yenilensin
    const eskiGoster = window.hesapGoster;
    window.hesapGoster = function () {
        eskiGoster(); siteYukle(); skorYukle(); mimoGecmisYukle(); uyeKartiOnizleme();
        if (hesapBen?.sifre_degistir) setTimeout(() => { hesapPencere('sifre'); hesapMesaj('Güvenliğin için kurulumdaki varsayılan şifreyi şimdi değiştir.'); }, 300);
    };
    siteYukle(); skorYukle();
    api('ziyaret', {}).catch(() => {});
    const h = location.hash;
    const ac = { '#uyelik': () => setTimeout(openUyelik, 600), '#indir': () => openIndirme(), '#fikirler': openFikirler, '#iletisim': openIletisim, '#profil': () => setTimeout(openProfil, 600), '#ara': aramaAc };
    if (ac[h]) ac[h]();
    else if (h.startsWith('#haber-')) openHaber(h.slice(7));
})();
