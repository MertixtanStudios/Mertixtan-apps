// Mertixtan Lives: canlı yayın, resmî kanal (program + NO SIGNAL), sohbet, sesli odalar, kamera/ekran/ses yayını.
// Görüntü/ses LiveKit üzerinden (sunucuda /livekit), sohbet Server-Sent Events ile (/api/lives/akis).
// Kullanıcı yazıları her zaman textContent ile basılır. Yetkiler sunucuda denetlenir; buradaki gizle/göster sadece arayüz.

(function () {
'use strict';
const LK = window.LivekitClient;
const LV_ISTEMCI = (() => { try { let c = sessionStorage.getItem('lv_c'); if (!c) { c = Math.random().toString(36).slice(2, 12); sessionStorage.setItem('lv_c', c); } return c; } catch (e) { return Math.random().toString(36).slice(2, 12); } })();
const WS_ADRES = (location.protocol === 'https:' ? 'wss://' : 'ws://') + location.host + '/livekit';
const EMOJILER = '😀 😂 🤣 😍 😎 🤔 😮 😢 😡 👍 👎 👏 🙌 🔥 💯 ❤️ 💙 💚 💛 🎉 🎮 🎬 🎵 ⚽ 🚀 ✨ 👀 🤝 🙏 💪 😴 🤯 🥳 😇 🤖 👑 💎 ⭐ ✅ ❌'.split(' ');
const TEMA_ADI = { klasik: 'Klasik', gece: 'Gece', neon: 'Neon', yakut: 'Yakut', altin: 'Altın', okyanus: 'Okyanus' };
const TEMA_ARKA = {
    klasik: 'linear-gradient(135deg,#0f172a,#1e293b)', gece: 'linear-gradient(135deg,#020617,#0b1023)', neon: 'linear-gradient(135deg,#0b0420,#14002e)',
    yakut: 'linear-gradient(135deg,#2a0010,#4a0418)', altin: 'linear-gradient(135deg,#1f1600,#3d2b00)', okyanus: 'linear-gradient(135deg,#001b2e,#003049)'
};
const TEMA_VURGU = { klasik: '#10b981', gece: '#64748b', neon: '#d946ef', yakut: '#e0115f', altin: '#f5c518', okyanus: '#38bdf8' };

let temizlik = [];      // sayfa değişince çalışacaklar (sohbet akışı, LiveKit odası, kamera, zamanlayıcılar)
let KESFET = null;
const lv = (yol, veri) => fetch('/api/lives/' + yol, veri === undefined ? { cache: 'no-store', credentials: 'same-origin' }
    : { method: 'POST', credentials: 'same-origin', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(veri) })
    .then(async r => { let j = {}; try { j = await r.json(); } catch (e) {} if (!r.ok) { const h = new Error(j.hata || 'Sunucuya ulaşılamadı'); h.kod = r.status; throw h; } return j; });
const sure = (s) => { s = Math.max(0, Math.floor(s)); const h = Math.floor(s / 3600), m = Math.floor(s % 3600 / 60); return h ? `${h} sa ${m} dk` : `${m} dk`; };
const saat = (t) => new Date(t * 1000).toLocaleTimeString('tr-TR', { hour: '2-digit', minute: '2-digit' });
const bugun = () => { const d = new Date(Date.now() + 3 * 3600e3); return d.toISOString().slice(0, 10); };  // Türkiye günü
const yerelZaman = (t) => { const d = new Date(t * 1000 + 3 * 3600e3); return d.toISOString().slice(0, 16); };
function temizle() { for (const f of temizlik.splice(0)) { try { f(); } catch (e) {} } }
function butonla(yazi, sinif, f) { const b = el('button', sinif, yazi); b.type = 'button'; b.onclick = f; return b; }
const KIRMIZI = 'px-3 py-1.5 rounded-lg text-[11px] font-bold bg-red-50 text-red-600 hover:bg-red-100';

// ------------------------------------------------------------ rozetler ve kullanıcı adı
function adEl(k, tik) {
    const s = el('span', 'inline-flex items-center gap-1 min-w-0');
    const r = k?.rozet || {};
    const ad = el('span', 'font-bold truncate ' + (r.admin ? 'lv-ad-admin' : r.pro ? 'lv-ad-pro' : ''), k?.ad || '?');
    s.appendChild(ad);
    if (r.admin) { const i = ikon('fa-solid fa-gem lv-rozet-admin'); i.title = 'Yönetici'; s.appendChild(i); }
    if (r.pro) { const i = ikon('fa-solid fa-crown lv-rozet-pro'); i.title = 'Pro üye'; s.appendChild(i); }
    if (r.onayli) { const i = ikon('fa-solid fa-circle-check lv-rozet-onay'); i.title = 'Onaylı hesap'; s.appendChild(i); }
    if (tik !== false && k?.ad && !k.resmi) { s.classList.add('cursor-pointer'); s.onclick = (e) => { e.stopPropagation(); profilKarti(k.ad, e.currentTarget); }; }
    return s;
}

async function profilKarti(ad, hedef) {
    document.getElementById('lv-pkart')?.remove();
    const k = el('div', 'fixed z-[120] w-72 rounded-2xl bg-white shadow-2xl border border-slate-200 p-4 text-sm'); k.id = 'lv-pkart';
    const r = hedef.getBoundingClientRect();
    k.style.left = Math.min(window.innerWidth - 300, Math.max(8, r.left)) + 'px';
    k.style.top = Math.min(window.innerHeight - 220, r.bottom + 6) + 'px';
    k.textContent = 'Yükleniyor…'; document.body.appendChild(k);
    const kapat = (e) => { if (!k.contains(e.target)) { k.remove(); document.removeEventListener('click', kapat); } };
    setTimeout(() => document.addEventListener('click', kapat), 0);
    try {
        const p = await lv('profil?ad=' + encodeURIComponent(ad));
        k.replaceChildren();
        const ust = el('div', 'flex items-center gap-3 mb-2');
        const av = el('div', 'w-10 h-10 rounded-xl flex items-center justify-center text-white font-black'); av.style.background = p.kul.renk || '#10b981'; av.textContent = p.kul.ad[0].toUpperCase();
        const yz = el('div', 'min-w-0'); yz.append(adEl(p.kul, false), el('div', 'text-xs text-slate-500', `${p.takipci} takipçi · ${p.yayin_sayisi} yayın`));
        ust.append(av, yz); k.appendChild(ust);
        if (p.kul.biyografi) k.appendChild(el('p', 'text-xs text-slate-600 mb-2', p.kul.biyografi));
        if (p.aktif) { const a = butonla('● Şu an canlı: ' + p.aktif.baslik, 'w-full text-left px-3 py-2 rounded-xl bg-red-50 text-red-600 text-xs font-bold mb-2 truncate', () => { k.remove(); git('y/' + p.aktif.id); }); k.appendChild(a); }
        k.appendChild(butonla('Profili gör', BUTON + ' w-full py-2', () => { k.remove(); git('u/' + encodeURIComponent(p.kul.ad)); }));
    } catch (e) { k.textContent = e.message; }
}

// ------------------------------------------------------------ yönlendirme
function git(rota) { location.hash = 'lives' + (rota ? '/' + rota : ''); }
function rotaCiz() {
    const h = decodeURIComponent(location.hash.slice(1));
    if (!h.startsWith('lives')) return;
    acLives();
    const p = h.split('/').slice(1);
    temizle();
    sekmeIsaretle(p[0] || 'kesfet');
    const kap = $('lv-icerik'); kap.replaceChildren(el('div', 'py-20 text-center text-slate-400', 'Yükleniyor…'));
    const sayfa = { '': kesfetSayfasi, kesfet: kesfetSayfasi, resmi: resmiSayfasi, y: () => yayinSayfasi(+p[1]), odalar: odalarSayfasi,
        oda: () => odaSayfasi(+p[1]), u: () => profilSayfasi(p.slice(1).join('/')), yayinla: () => studyoSayfasi(p[1] === 'resmi'), yonetim: () => yonetimSayfasi(p[1] || 'program') }[p[0] || ''];
    (sayfa || kesfetSayfasi)().catch(e => kap.replaceChildren(el('div', 'py-20 text-center text-red-600 font-semibold', e.message)));
}
function acLives() {
    if (!$('lives-view').classList.contains('hidden')) return;
    gorunum('lives-view');
}
function sekmeIsaretle(s) {
    for (const b of document.querySelectorAll('#lv-sekmeler [data-s]')) {
        const aktif = b.dataset.s === s || (s === 'y' && b.dataset.s === 'kesfet') || (s === 'oda' && b.dataset.s === 'odalar') || (s === 'u' && b.dataset.s === 'kesfet');
        b.className = 'px-3.5 py-2 rounded-xl text-xs sm:text-sm font-bold whitespace-nowrap transition-all ' + (aktif ? 'bg-white text-slate-900 shadow' : 'text-white/70 hover:text-white hover:bg-white/10');
    }
    $('lv-yonetim-sekme').classList.toggle('hidden', !hesapBen?.yonetici);
}

// ------------------------------------------------------------ iskelet
function kur() {
    const m = el('main', 'hidden min-h-[85vh] bg-slate-50'); m.id = 'lives-view';
    m.innerHTML = `<div class="bg-gradient-to-r from-slate-950 via-slate-900 to-slate-950 border-b border-white/5">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex flex-wrap items-center gap-3 justify-between">
            <a href="#lives" class="flex items-center gap-2.5 shrink-0"><span class="w-9 h-9 rounded-xl bg-gradient-to-br from-red-500 to-primary-600 flex items-center justify-center text-white shadow-lg shadow-red-500/30"><i class="fa-solid fa-tower-broadcast"></i></span>
                <span class="font-display font-black text-xl text-white tracking-tight">Mertixtan <span class="text-red-400">Lives</span></span></a>
            <nav id="lv-sekmeler" class="flex gap-1 overflow-x-auto max-w-full -mx-1 px-1">
                <a href="#lives/kesfet" data-s="kesfet"><i class="fa-solid fa-compass mr-1"></i>Keşfet</a>
                <a href="#lives/resmi" data-s="resmi"><i class="fa-solid fa-tv mr-1"></i>Studios Live</a>
                <a href="#lives/odalar" data-s="odalar"><i class="fa-solid fa-headset mr-1"></i>Sesli Odalar</a>
                <a href="#lives/yayinla" data-s="yayinla"><i class="fa-solid fa-video mr-1"></i>Yayın Aç</a>
                <a href="#lives/yonetim" data-s="yonetim" id="lv-yonetim-sekme" class="hidden"><i class="fa-solid fa-shield-halved mr-1"></i>Yönetim</a>
            </nav>
        </div></div>
        <div id="lv-icerik" class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6"></div>`;
    $('detail-page-view').before(m);
    YENI_GORUNUMLER.push('lives-view'); TUM_GORUNUMLER.push('lives-view');
    const st = document.createElement('style');
    st.textContent = `
    .lv-ad-pro{background:linear-gradient(90deg,#a16207,#facc15,#fff7c2,#facc15,#a16207);background-size:200% auto;-webkit-background-clip:text;background-clip:text;color:transparent;animation:lvParla 3s linear infinite}
    .lv-ad-admin{background:linear-gradient(90deg,#7f0019,#e0115f,#ff8fab,#e0115f,#7f0019);background-size:200% auto;-webkit-background-clip:text;background-clip:text;color:transparent;animation:lvParla 2.5s linear infinite;filter:drop-shadow(0 0 3px rgba(224,17,95,.45))}
    .lv-rozet-pro{color:#eab308;filter:drop-shadow(0 0 3px rgba(250,204,21,.8));animation:lvIsilti 2s ease-in-out infinite}
    .lv-rozet-admin{color:#e0115f;filter:drop-shadow(0 0 4px rgba(224,17,95,.9));animation:lvIsilti 1.6s ease-in-out infinite}
    .lv-rozet-onay{color:#3b82f6}
    @keyframes lvParla{to{background-position:200% center}}
    @keyframes lvIsilti{0%,100%{opacity:1;transform:scale(1)}50%{opacity:.75;transform:scale(1.12)}}
    .lv-canli{animation:lvNabiz 1.4s ease-in-out infinite}@keyframes lvNabiz{50%{opacity:.55}}
    .lv-oynatici video{width:100%;height:100%;object-fit:contain;background:#000}
    .lv-oynatici:fullscreen{border-radius:0}
    .lv-konusuyor{box-shadow:0 0 0 3px #10b981,0 0 18px rgba(16,185,129,.6)}
    .lv-sinema #lives-view, .lv-sinema #lv-icerik{background:#020617}
    .lv-sinema #lv-icerik .lv-acik{background:#0f172a;color:#e2e8f0;border-color:#1e293b}`;
    document.head.appendChild(st);
    sekmeIsaretle('kesfet');
    window.addEventListener('hashchange', rotaCiz);
    // ana menü bağlantıları
    const navMimo = document.querySelector('nav a[href="#mimo"]');
    if (navMimo) { const a = el('a', 'hover:text-red-600 transition-colors flex items-center gap-1.5 whitespace-nowrap'); a.href = '#lives'; a.innerHTML = '<span class="w-2 h-2 rounded-full bg-red-500 lv-canli"></span> Lives'; navMimo.after(a); }
    const mobMimo = document.querySelector('#mobile-menu a[href="#mimo"]');
    if (mobMimo) { const a = el('a', 'block px-4 py-2.5 rounded-xl bg-red-50 text-red-600 font-bold text-sm flex items-center gap-2'); a.href = '#lives'; a.onclick = () => toggleMobileMenu(); a.innerHTML = '<i class="fa-solid fa-tower-broadcast"></i> Mertixtan Lives'; mobMimo.after(a); }
    const eskiKapat = window.closeAllViews;
    window.closeAllViews = function (...a) { temizle(); if (location.hash.startsWith('#lives')) history.replaceState(null, '', location.pathname + location.search); return eskiKapat.apply(this, a); };
    // hesap bilgisi gelince (ve giriş/çıkışta) Lives'ı çiz: yetkiler buna bağlı
    const eskiGoster = window.hesapGoster; let sonKim;
    window.hesapGoster = function (...a) {
        const r = eskiGoster.apply(this, a);
        const kim = hesapBen ? hesapBen.id : 0;
        if (kim !== sonKim) { sonKim = kim; if (location.hash.startsWith('#lives')) rotaCiz(); else sekmeIsaretle('kesfet'); }
        return r;
    };
}

// ------------------------------------------------------------ yayın kartları
function yayinKarti(y, buyuk) {
    const k = el('button', 'lv-acik group text-left rounded-2xl overflow-hidden bg-white border border-slate-200 hover:border-red-300 hover:shadow-xl transition-all flex flex-col');
    k.type = 'button'; k.onclick = () => git('y/' + y.id);
    const g = el('div', 'relative aspect-video overflow-hidden'); g.style.background = TEMA_ARKA[y.tema] || TEMA_ARKA.klasik;
    if (y.kapak) { const im = el('img', 'absolute inset-0 w-full h-full object-cover group-hover:scale-105 transition-transform'); im.src = y.kapak; im.alt = ''; im.loading = 'lazy'; g.appendChild(im); }
    else { const i = ikon({ kamera: 'fa-solid fa-video', ekran: 'fa-solid fa-display', sesli: 'fa-solid fa-microphone-lines' }[y.tur] + ' absolute inset-0 m-auto w-fit h-fit text-4xl text-white/30'); g.appendChild(i); }
    if (y.durum === 'canli') g.appendChild(el('span', 'absolute top-2 left-2 px-2 py-0.5 rounded-md bg-red-600 text-white text-[10px] font-black tracking-wider lv-canli', 'CANLI'));
    else g.appendChild(el('span', 'absolute top-2 left-2 px-2 py-0.5 rounded-md bg-black/60 text-white text-[10px] font-bold', 'BİTTİ'));
    if (y.durum === 'canli') { const iz = el('span', 'absolute bottom-2 left-2 px-2 py-0.5 rounded-md bg-black/60 text-white text-[11px] font-bold'); iz.append(ikon('fa-solid fa-eye mr-1'), document.createTextNode(sayi(y.izleyici))); g.appendChild(iz); }
    if (y.one_cikan) g.appendChild(el('span', 'absolute top-2 right-2 px-2 py-0.5 rounded-md bg-amber-400 text-amber-950 text-[10px] font-black', '★ ÖNE ÇIKAN'));
    const yz = el('div', 'p-3 min-w-0');
    yz.append(el('div', 'font-bold text-slate-900 truncate ' + (buyuk ? 'text-base' : 'text-sm'), y.baslik));
    const alt = el('div', 'flex items-center justify-between gap-2 text-xs text-slate-500 mt-1');
    alt.append(adEl(y.yayinci, false), el('span', 'shrink-0 px-1.5 py-0.5 rounded bg-slate-100', y.kategori || ''));
    yz.appendChild(alt); k.append(g, yz);
    return k;
}
function odaKarti(o) {
    const k = el('button', 'lv-acik text-left rounded-2xl bg-white border border-slate-200 hover:border-primary-300 hover:shadow-xl transition-all p-4 flex gap-3 items-start');
    k.type = 'button'; k.onclick = () => git('oda/' + o.id);
    const i = el('div', 'w-11 h-11 rounded-xl flex items-center justify-center text-white shrink-0 ' + (o.resmi ? 'bg-gradient-to-br from-red-500 to-primary-600' : 'bg-gradient-to-br from-primary-500 to-accent-600')); i.appendChild(ikon('fa-solid fa-headset'));
    const yz = el('div', 'min-w-0 flex-1');
    yz.append(el('div', 'font-bold text-slate-900 truncate', o.baslik), el('div', 'text-xs text-slate-500 line-clamp-2', o.aciklama || ''));
    const alt = el('div', 'flex items-center gap-2 text-xs mt-1.5'); alt.append(adEl(o.sahip, false), el('span', 'text-primary-700 font-bold', `● ${o.katilimci} kişi`));
    yz.appendChild(alt); k.append(i, yz);
    return k;
}
function bolum(baslik, ikonS, ogeler, bosYazi, izgara) {
    const b = el('section', 'mb-10');
    const h = el('h2', 'font-display font-black text-xl text-slate-900 mb-4 flex items-center gap-2'); h.append(ikon(ikonS), document.createTextNode(' ' + baslik)); b.appendChild(h);
    if (!ogeler.length) { b.appendChild(el('p', 'text-sm text-slate-400', bosYazi)); return b; }
    const g = el('div', izgara || 'grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4'); ogeler.forEach(o => g.appendChild(o)); b.appendChild(g);
    return b;
}

// ------------------------------------------------------------ KEŞFET
async function kesfetSayfasi() {
    const d = KESFET = await lv('kesfet');
    const kap = $('lv-icerik'); kap.replaceChildren();
    // resmî kanal vitrini (gerçek durumla)
    const r = d.resmi;
    const v = el('button', 'w-full text-left rounded-3xl overflow-hidden mb-10 relative min-h-[180px] sm:min-h-[220px] flex items-end shadow-xl');
    v.type = 'button'; v.onclick = () => git('resmi'); v.style.background = TEMA_ARKA[r.tema] || TEMA_ARKA.klasik;
    if (r.mod === 'nosignal') { const c = statikTuval(); c.className = 'absolute inset-0 w-full h-full opacity-60'; v.appendChild(c); temizlik.push(c._dur); }
    const ic = el('div', 'relative p-6 sm:p-8 w-full bg-gradient-to-t from-black/80 to-transparent text-white');
    const et = el('div', 'flex items-center gap-2 mb-2 text-xs font-black tracking-widest');
    et.append(el('span', 'px-2 py-0.5 rounded ' + (r.mod === 'nosignal' ? 'bg-slate-600' : 'bg-red-600 lv-canli'), r.mod === 'nosignal' ? 'NO SIGNAL' : (r.mod === 'canli' ? 'CANLI' : 'YAYINDA')), el('span', 'opacity-80', 'MERTIXTAN STUDIOS LIVE'));
    const bas = r.mod === 'canli' ? r.canli.baslik : r.mod === 'program' ? r.simdi.baslik : (r.nosignal_mesaj || 'Şu an yayın yok');
    ic.append(et, el('div', 'font-display font-black text-2xl sm:text-4xl', bas));
    const alt = r.mod === 'program' ? `${saat(r.simdi.baslangic)} – ${saat(r.simdi.bitis)} · ${r.izleyici} izleyici` : r.mod === 'canli' ? `${r.izleyici} izleyici` : (r.sonraki ? `Sıradaki: ${r.sonraki.baslik} · ${new Date(r.sonraki.baslangic * 1000).toLocaleString('tr-TR', { weekday: 'short', hour: '2-digit', minute: '2-digit' })}` : 'Program henüz eklenmedi');
    ic.appendChild(el('div', 'text-sm opacity-80 mt-1', alt));
    v.appendChild(ic); kap.appendChild(v);
    if (d.ben.giris && d.takip.length) kap.appendChild(bolum('Takip ettiklerin canlı', 'fa-solid fa-heart text-red-500', d.takip.map(y => yayinKarti(y)), ''));
    kap.appendChild(bolum('Canlı yayınlar', 'fa-solid fa-circle text-red-500 lv-canli text-xs', d.canli.map(y => yayinKarti(y)), 'Şu an açık yayın yok. ' + (d.ben.yayin_yetkili ? 'İlk yayını sen aç!' : '')));
    kap.appendChild(bolum('Popüler', 'fa-solid fa-fire text-orange-500', d.populer.filter(y => y.izleyici > 0).slice(0, 8).map(y => yayinKarti(y)), 'Henüz izleyicisi olan yayın yok.'));
    kap.appendChild(bolum('Üyelerin yayınları', 'fa-solid fa-crown lv-rozet-pro', d.uyeler.map(y => yayinKarti(y)), 'Şu an yayında olan Pro üye yok.'));
    kap.appendChild(bolum('Sesli sohbet odaları', 'fa-solid fa-headset text-primary-600', d.odalar.map(odaKarti), 'Açık oda yok.', 'grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4'));
    kap.appendChild(bolum('Yeni yayıncılar', 'fa-solid fa-seedling text-primary-600', d.yeni.map(n => {
        const b = el('button', 'lv-acik text-left rounded-2xl bg-white border border-slate-200 p-4 hover:shadow-lg'); b.type = 'button';
        b.onclick = () => git('u/' + encodeURIComponent(n.kul.ad));
        b.append(adEl(n.kul, false), el('div', 'text-xs text-slate-500 mt-1', 'İlk yayın: ' + tarih(n.ilk)), el('div', 'text-xs text-slate-600 truncate mt-1', n.son_yayin ? (n.son_yayin.durum === 'canli' ? '● Şu an canlı: ' : 'Son: ') + n.son_yayin.baslik : ''));
        return b;
    }), 'Son 14 günde ilk yayınını yapan yok.'));
    const t = setInterval(() => { if (location.hash.replace('#', '').replace(/\/$/, '') === 'lives' || location.hash === '#lives/kesfet') lv('kesfet').then(y => { if (JSON.stringify(y.canli.map(x => [x.id, x.izleyici])) !== JSON.stringify(KESFET.canli.map(x => [x.id, x.izleyici])) || y.resmi.mod !== KESFET.resmi.mod) { temizle(); kesfetSayfasi(); } }).catch(() => {}); }, 20000);
    temizlik.push(() => clearInterval(t));
}

// ------------------------------------------------------------ NO SIGNAL (statik/sinyal efekti)
function statikTuval() {
    const c = document.createElement('canvas'); c.width = 320; c.height = 180;
    const x = c.getContext('2d'); let calis = true, kare = 0;
    const img = x.createImageData(320, 180);
    const ciz = () => {
        if (!calis) return;
        kare++;
        if (kare % 2 === 0) {
            const d = img.data;
            for (let i = 0; i < d.length; i += 4) { const v = Math.random() * 70 | 0; d[i] = d[i + 1] = d[i + 2] = v; d[i + 3] = 255; }
            x.putImageData(img, 0, 0);
            const y = (kare * 3) % 220 - 20; x.fillStyle = 'rgba(255,255,255,0.06)'; x.fillRect(0, y, 320, 14);  // tarama çizgisi
        }
        requestAnimationFrame(ciz);
    };
    requestAnimationFrame(ciz);
    c._dur = () => { calis = false; };
    return c;
}
function noSignalEkrani(r) {
    const k = el('div', 'absolute inset-0 bg-black overflow-hidden flex items-center justify-center');
    const c = statikTuval(); c.className = 'absolute inset-0 w-full h-full opacity-50'; k.appendChild(c); temizlik.push(c._dur);
    const ic = el('div', 'relative text-center px-6');
    const logo = el('div', 'inline-flex items-center gap-2 text-white/50 text-[10px] sm:text-xs font-black tracking-[0.3em] mb-3'); logo.append(ikon('fa-solid fa-tower-broadcast'), document.createTextNode(' MERTIXTAN STUDIOS LIVE'));
    const ns = el('div', 'font-mono font-black text-4xl sm:text-7xl tracking-[0.15em] text-white', 'NO SIGNAL');
    ns.style.textShadow = '2px 0 #ff0040, -2px 0 #00e5ff, 0 0 24px rgba(255,255,255,.35)';
    ic.append(logo, ns);
    ic.appendChild(el('div', 'text-white/70 text-xs sm:text-sm mt-3', r.nosignal_mesaj || 'Şu an yayın ya da geçerli program yok.'));
    if (r.sonraki) ic.appendChild(el('div', 'text-white/90 text-xs sm:text-sm mt-2 font-semibold', `Sıradaki: ${r.sonraki.baslik} · ${new Date(r.sonraki.baslangic * 1000).toLocaleString('tr-TR', { weekday: 'long', hour: '2-digit', minute: '2-digit' })}`));
    k.appendChild(ic);
    const renkler = el('div', 'absolute bottom-0 inset-x-0 h-2 flex'); ['#c0c0c0', '#c0c000', '#00c0c0', '#00c000', '#c000c0', '#c00000', '#0000c0'].forEach(r_ => { const s = el('span', 'flex-1'); s.style.background = r_; s.style.opacity = '.5'; renkler.appendChild(s); });
    k.appendChild(renkler);
    return k;
}

// ------------------------------------------------------------ oynatıcı kabuğu (tam ekran, ses, kalite, tema)
function oynaticiKabugu(tema) {
    const dis = el('div', 'lv-oynatici relative w-full aspect-video rounded-2xl overflow-hidden bg-black shadow-2xl group');
    dis.style.background = '#000';
    const sahne = el('div', 'absolute inset-0'); dis.appendChild(sahne);
    const cubuk = el('div', 'absolute bottom-0 inset-x-0 p-2 sm:p-3 flex items-center gap-2 bg-gradient-to-t from-black/80 to-transparent text-white opacity-100 sm:opacity-0 group-hover:opacity-100 focus-within:opacity-100 transition-opacity z-10');
    const ses = butonla('', 'w-9 h-9 rounded-lg hover:bg-white/15', null); ses.appendChild(ikon('fa-solid fa-volume-high')); ses.title = 'Sesi kapat/aç';
    const sev = el('input', 'w-20 sm:w-28 accent-red-500'); sev.type = 'range'; sev.min = 0; sev.max = 1; sev.step = 0.05; sev.value = 1; sev.setAttribute('aria-label', 'Ses düzeyi');
    const bosluk = el('div', 'flex-1');
    const kalite = el('select', 'hidden bg-black/60 text-white text-xs rounded-lg px-2 py-1.5 border border-white/20'); kalite.setAttribute('aria-label', 'Kalite');
    const tam = butonla('', 'w-9 h-9 rounded-lg hover:bg-white/15', () => document.fullscreenElement ? document.exitFullscreen() : (dis.requestFullscreen?.() || dis.webkitRequestFullscreen?.()));
    tam.appendChild(ikon('fa-solid fa-expand')); tam.title = 'Tam ekran';
    cubuk.append(ses, sev, bosluk, kalite, tam); dis.appendChild(cubuk);
    const sesAc = el('button', 'hidden absolute top-3 right-3 z-20 px-3 py-2 rounded-xl bg-white text-slate-900 text-xs font-bold shadow-lg'); sesAc.type = 'button'; sesAc.append(ikon('fa-solid fa-volume-xmark mr-1'), document.createTextNode('Sesi aç'));
    dis.appendChild(sesAc);
    const o = { dis, sahne, kalite, sesAc, ortamlar: () => [...dis.querySelectorAll('video,audio')], sessiz: false, duzey: 1 };
    const uygula = () => { for (const m of o.ortamlar()) { m.muted = o.sessiz; m.volume = o.duzey; } ses.firstChild.className = o.sessiz || o.duzey == 0 ? 'fa-solid fa-volume-xmark' : 'fa-solid fa-volume-high'; o.yt?.(o.sessiz, o.duzey); };
    o.uygula = uygula;
    ses.onclick = () => { o.sessiz = !o.sessiz; uygula(); };
    sev.oninput = () => { o.duzey = +sev.value; o.sessiz = o.duzey == 0; uygula(); };
    return o;
}

// LiveKit izleyici: odaya bağlanır, gelen görüntü/sesi sahneye koyar
async function lkIzle(o, oda, sesli) {
    if (!LK) throw new Error('Canlı yayın kütüphanesi yüklenemedi');
    const { token } = await lv('token', { oda, mod: 'izle', c: LV_ISTEMCI });
    const room = new LK.Room({ adaptiveStream: false, dynacast: true });
    temizlik.push(() => room.disconnect());
    const bos = el('div', 'absolute inset-0 flex flex-col items-center justify-center text-white/70 text-sm gap-2');
    bos.append(ikon(sesli ? 'fa-solid fa-microphone-lines text-4xl' : 'fa-solid fa-satellite-dish text-4xl lv-canli'), el('span', '', sesli ? 'Sesli yayın' : 'Yayıncının görüntüsü bekleniyor…'));
    o.sahne.replaceChildren(bos);
    const yayinlar = [];
    const ciz = () => {
        const v = o.sahne.querySelectorAll('video'); bos.classList.toggle('hidden', v.length > 0 || sesli);
        o.kalite.classList.toggle('hidden', !yayinlar.some(p => p.kind === 'video'));
    };
    room.on(LK.RoomEvent.TrackSubscribed, (track, pub) => {
        const m = track.attach();
        if (track.kind === 'video') { m.className = 'absolute inset-0 w-full h-full'; m.playsInline = true; o.sahne.appendChild(m); yayinlar.push(pub); }
        else { m.className = 'hidden'; o.sahne.appendChild(m); }
        o.uygula(); ciz();
    });
    room.on(LK.RoomEvent.TrackUnsubscribed, (track, pub) => { track.detach().forEach(e => e.remove()); const i = yayinlar.indexOf(pub); if (i >= 0) yayinlar.splice(i, 1); ciz(); });
    room.on(LK.RoomEvent.AudioPlaybackStatusChanged, () => o.sesAc.classList.toggle('hidden', room.canPlaybackAudio));
    o.sesAc.onclick = async () => { await room.startAudio(); o.sesAc.classList.add('hidden'); };
    room.on(LK.RoomEvent.Disconnected, (neden) => { if (neden === LK.DisconnectReason?.PARTICIPANT_REMOVED) bildir('Yayından çıkarıldın', false); });
    // kalite (yayıncı simulcast gönderiyor)
    o.kalite.innerHTML = '<option value="2">Yüksek</option><option value="1">Orta</option><option value="0">Düşük</option>';
    o.kalite.onchange = () => yayinlar.forEach(p => p.kind === 'video' && p.setVideoQuality(+o.kalite.value));
    await room.connect(WS_ADRES, token);
    o.sesAc.classList.toggle('hidden', room.canPlaybackAudio);
    ciz();
    return room;
}

// Program oynatıcı: mp4/webm, HLS (m3u8) ya da YouTube; "canlı TV" gibi programın şu anki saniyesinden başlar
function programOynat(o, durum) {
    const p = durum.simdi, kaynak = p.icerik?.kaynak;
    const alinan = Date.now() / 1000, ofset = () => durum.ofset + (Date.now() / 1000 - alinan);
    if (!kaynak) {
        const k = el('div', 'absolute inset-0 flex flex-col items-center justify-center text-center text-white p-6'); k.style.background = TEMA_ARKA[durum.tema];
        k.append(el('div', 'text-xs font-black tracking-widest text-red-400 mb-2 lv-canli', '● YAYINDA'), el('div', 'font-display font-black text-2xl sm:text-4xl', p.baslik), el('div', 'text-white/70 text-sm mt-2', `${saat(p.baslangic)} – ${saat(p.bitis)}`));
        if (p.aciklama) k.appendChild(el('p', 'text-white/60 text-sm mt-3 max-w-lg', p.aciklama));
        o.sahne.replaceChildren(k); return;
    }
    const yt = kaynak.match(/(?:youtube\.com\/(?:watch\?v=|embed\/|live\/)|youtu\.be\/)([\w-]{11})/);
    if (yt) {
        const f = el('iframe', 'absolute inset-0 w-full h-full');
        f.src = `https://www.youtube-nocookie.com/embed/${yt[1]}?autoplay=1&mute=1&start=${Math.floor(ofset())}&playsinline=1&rel=0&enablejsapi=1`;
        f.allow = 'autoplay; encrypted-media; picture-in-picture; fullscreen'; f.allowFullscreen = true; f.title = p.baslik;
        o.sahne.replaceChildren(f);
        o.sesAc.classList.remove('hidden');
        o.sesAc.onclick = () => { f.contentWindow?.postMessage(JSON.stringify({ event: 'command', func: 'unMute', args: [] }), '*'); o.sesAc.classList.add('hidden'); };
        o.yt = (sessiz, duzey) => { f.contentWindow?.postMessage(JSON.stringify({ event: 'command', func: sessiz ? 'mute' : 'unMute', args: [] }), '*'); f.contentWindow?.postMessage(JSON.stringify({ event: 'command', func: 'setVolume', args: [Math.round(duzey * 100)] }), '*'); };
        return;
    }
    const v = el('video', 'absolute inset-0 w-full h-full'); v.playsInline = true; v.autoplay = true; v.muted = true;
    o.sahne.replaceChildren(v);
    const atla = () => { const t = ofset(); if (v.duration && t >= v.duration) { o.sahne.replaceChildren(noSignalEkrani({ ...durum, nosignal_mesaj: `"${p.baslik}" bitti; program saatinin sonu bekleniyor.` })); return; } if (isFinite(t)) v.currentTime = t; };
    v.addEventListener('loadedmetadata', atla, { once: true });
    if (/\.m3u8(\?|$)/i.test(kaynak) && window.Hls?.isSupported()) { const hls = new Hls(); hls.loadSource(kaynak); hls.attachMedia(v); temizlik.push(() => hls.destroy()); }
    else v.src = kaynak;
    v.play().catch(() => {});
    o.sesAc.classList.remove('hidden');
    o.sesAc.onclick = () => { o.sessiz = false; o.uygula(); v.play(); o.sesAc.classList.add('hidden'); };
    o.sessiz = true; o.uygula();
    v.onerror = () => o.sahne.replaceChildren(noSignalEkrani({ ...durum, nosignal_mesaj: 'Program kaynağı açılamadı.' }));
    temizlik.push(() => { v.pause(); v.removeAttribute('src'); v.load(); });
}

// ------------------------------------------------------------ puanlama
function puanKutusu(icerik) {
    const k = el('div', 'lv-acik rounded-2xl bg-white border border-slate-200 p-4');
    const ciz = (p) => {
        k.replaceChildren();
        const ust = el('div', 'flex items-center justify-between mb-2');
        ust.append(el('div', 'text-xs font-bold text-slate-500 uppercase tracking-wider', `${icerik.tur === 'dizi' ? 'Dizi' : icerik.tur === 'film' ? 'Film' : 'Program'} puanı`),
            el('div', 'text-sm font-bold text-slate-800', p.ortalama ? `★ ${p.ortalama.toFixed(1)} · ${p.oy} oy` : 'Henüz oy yok'));
        k.append(ust, el('div', 'font-bold text-slate-900 mb-2', icerik.ad));
        const y = el('div', 'flex gap-1');
        for (let i = 1; i <= 5; i++) {
            const b = butonla('★', 'text-3xl leading-none transition-transform hover:scale-110 ' + (i <= (p.benim || 0) ? 'text-amber-400' : 'text-slate-300'), async () => {
                if (girisGerek('Puan vermek')) return;
                try { ciz(await lv('puan', { icerik_id: icerik.id, puan: i })); bildir(`${i} yıldız verdin`); } catch (e) { bildir(e.message, false); }
            });
            b.setAttribute('aria-label', `${i} yıldız`); y.appendChild(b);
        }
        k.appendChild(y);
        if (p.benim) k.appendChild(el('div', 'text-xs text-slate-500 mt-1', `Senin puanın: ${p.benim}. İstersen değiştirebilirsin.`));
    };
    ciz(icerik.puan);
    return k;
}

// ------------------------------------------------------------ CANLI SOHBET
function sohbet(kap, ayar) {
    // ayar: {oda, yetki, mesajlar, sabit, sahipId, onIzleyici, onDurum, onDestek, onKonusmaci, onYasak}
    kap.className = 'lv-acik flex flex-col rounded-2xl bg-white border border-slate-200 overflow-hidden h-[60vh] lg:h-[calc(100vh-220px)] min-h-[380px]';
    kap.innerHTML = `<div class="px-4 py-3 border-b border-slate-100 flex items-center justify-between"><span class="font-bold text-sm text-slate-900"><i class="fa-solid fa-comments text-primary-600 mr-1"></i> Canlı sohbet</span><span class="lv-iz text-xs font-bold text-slate-500"></span></div>
        <div class="lv-sabit hidden px-3 py-2 bg-amber-50 border-b border-amber-200 text-xs"></div>
        <div class="lv-liste flex-1 overflow-y-auto px-3 py-2 space-y-1.5 text-sm" aria-live="polite"></div>
        <div class="lv-yanit hidden px-3 py-1.5 bg-slate-50 border-t border-slate-100 text-xs text-slate-600 flex items-center justify-between"></div>
        <div class="lv-oner hidden border-t border-slate-100 px-2 py-1 flex flex-wrap gap-1"></div>
        <div class="lv-emoji hidden border-t border-slate-100 p-2 grid grid-cols-10 gap-1 text-lg"></div>
        <form class="lv-form border-t border-slate-100 p-2 flex gap-1.5 items-center"></form>`;
    const q = (s) => kap.querySelector(s);
    const liste = q('.lv-liste'), form = q('.lv-form');
    let yanitId = null, sabitId = null;
    const adlar = new Set();
    const benim = ayar.yetki;
    const asagida = () => liste.scrollHeight - liste.scrollTop - liste.clientHeight < 80;

    function metinEl(m) {
        const p = el('span', 'break-words');
        for (const parca of m.metin.split(/(@[A-Za-z0-9_.ÇĞİÖŞÜçğıöşü-]{3,24})/)) {
            if (parca.startsWith('@') && parca.length > 3) { const s = el('span', 'font-bold ' + (hesapBen && parca.slice(1).toLowerCase() === hesapBen.ad.toLowerCase() ? 'bg-amber-200 text-amber-900 rounded px-0.5' : 'text-accent-600'), parca); p.appendChild(s); }
            else if (parca) p.appendChild(document.createTextNode(parca));
        }
        return p;
    }
    function satir(m) {
        adlar.add(m.kul.ad);
        const d = el('div', 'group relative rounded-lg px-2 py-1 hover:bg-slate-50 ' + (hesapBen && m.metin.toLowerCase().includes('@' + hesapBen.ad.toLowerCase()) ? 'bg-amber-50' : '')); d.dataset.id = m.id;
        if (m.yanit) { const y = el('div', 'text-[11px] text-slate-400 truncate pl-2 border-l-2 border-slate-200 mb-0.5'); y.textContent = `↪ ${m.yanit.ad}: ${m.yanit.metin}`; d.appendChild(y); }
        const ust = el('div', 'leading-snug');
        ust.append(adEl(m.kul), el('span', 'text-slate-400 mx-1', ':'), metinEl(m));
        d.appendChild(ust);
        const men = el('button', 'absolute top-1 right-1 w-7 h-7 rounded-lg bg-white border border-slate-200 text-slate-500 opacity-0 group-hover:opacity-100 focus:opacity-100 text-xs'); men.type = 'button';
        men.appendChild(ikon('fa-solid fa-ellipsis')); men.setAttribute('aria-label', 'Mesaj seçenekleri');
        men.onclick = (e) => { e.stopPropagation(); mesajMenusu(m, men); };
        d.appendChild(men);
        return d;
    }
    function ekle(m, kaydir) { const al = asagida(); liste.appendChild(satir(m)); if (kaydir || al) liste.scrollTop = liste.scrollHeight; while (liste.children.length > 300) liste.firstChild.remove(); }
    function sistem(metin) { const d = el('div', 'text-center text-[11px] text-slate-400 italic py-1', metin); liste.appendChild(d); if (asagida()) liste.scrollTop = liste.scrollHeight; }
    function sabitCiz(m) {
        const s = q('.lv-sabit'); sabitId = m?.id || null; s.classList.toggle('hidden', !m); s.replaceChildren();
        if (!m) return;
        const sat = el('div', 'flex items-start gap-2'); const yz = el('div', 'flex-1 min-w-0');
        yz.append(el('div', 'text-[10px] font-black text-amber-700 uppercase tracking-wider', '📌 Sabitlenmiş mesaj'));
        const sa = el('div', 'text-slate-800'); sa.append(adEl(m.kul), document.createTextNode(': '), metinEl(m)); yz.appendChild(sa);
        sat.appendChild(yz);
        if (benim.moderator) sat.appendChild(butonla('Kaldır', 'text-[11px] font-bold text-amber-700 underline', () => lv('sabitle', { oda: ayar.oda, id: null }).catch(e => bildir(e.message, false))));
        s.appendChild(sat);
    }
    function mesajMenusu(m, hedef) {
        document.getElementById('lv-mmenu')?.remove();
        const k = el('div', 'fixed z-[120] w-56 rounded-2xl bg-white shadow-2xl border border-slate-200 p-1.5 text-sm'); k.id = 'lv-mmenu';
        const r = hedef.getBoundingClientRect(); k.style.left = Math.max(8, Math.min(window.innerWidth - 232, r.right - 224)) + 'px'; k.style.top = Math.min(window.innerHeight - 300, r.bottom + 4) + 'px';
        const sec = (yazi, f, kirmizi) => k.appendChild(butonla(yazi, 'w-full text-left px-3 py-2 rounded-xl font-semibold ' + (kirmizi ? 'text-red-600 hover:bg-red-50' : 'text-slate-700 hover:bg-slate-100'), () => { k.remove(); f(); }));
        const ben = hesapBen && m.kul.id === hesapBen.id;
        if (benim.giris) sec('↪ Yanıtla', () => { yanitId = m.id; const y = q('.lv-yanit'); y.classList.remove('hidden'); y.replaceChildren(el('span', 'truncate', `↪ ${m.kul.ad} kişisine yanıt`), butonla('✕', 'px-2 font-bold', () => { yanitId = null; y.classList.add('hidden'); })); form.querySelector('input').focus(); });
        if (benim.giris) sec('@ Etiketle', () => { const i = form.querySelector('input'); i.value = (i.value + ' @' + m.kul.ad + ' ').trimStart(); i.focus(); });
        if (benim.moderator) sec(sabitId === m.id ? '📌 Sabitlemeyi kaldır' : '📌 Sabitle', () => lv('sabitle', { oda: ayar.oda, id: sabitId === m.id ? null : m.id }).catch(e => bildir(e.message, false)));
        if (ben || benim.moderator) sec('🗑 Sil', () => lv('mesaj_sil', { id: m.id }).catch(e => bildir(e.message, false)), true);
        if (benim.moderator && !ben && !(m.kul.rozet?.admin && !benim.admin)) {
            const mod = (islem, dakika, oda) => lv('moderasyon', { oda: oda || ayar.oda, kid: m.kul.id, islem, dakika }).then(() => bildir('Uygulandı')).catch(e => bildir(e.message, false));
            sec('🔇 5 dk sustur', () => mod('sustur', 5), true);
            sec('⏱ 10 dk uzaklaştır', () => mod('uzaklastir', 10), true);
            sec('⛔ Bu odadan yasakla', () => confirm(m.kul.ad + ' bu odadan kalıcı yasaklansın mı?') && mod('yasak', null), true);
            if (benim.admin) sec('🚫 Tüm Lives\'tan yasakla', () => { const g = prompt('Kaç gün? (boş = kalıcı)'); if (g === null) return; mod('yasak', g ? Math.round(+g * 1440) : null, '*'); }, true);
        }
        if (benim.giris && !ben) sec('⚑ Raporla', () => { const n = prompt('Neden raporluyorsun?'); if (n) lv('rapor', { hedef_tur: 'mesaj', hedef_id: m.id, neden: n }).then(() => bildir('Rapor iletildi')).catch(e => bildir(e.message, false)); });
        if (!k.children.length) return;
        document.body.appendChild(k);
        const kapat = (e) => { if (!k.contains(e.target)) { k.remove(); document.removeEventListener('click', kapat); } };
        setTimeout(() => document.addEventListener('click', kapat), 0);
    }
    function formCiz() {
        form.replaceChildren();
        if (!benim.giris) { form.appendChild(butonla('Sohbete katılmak için giriş yap', BUTON + ' w-full py-2.5', () => hesapPencere('giris'))); return; }
        if (benim.susturuldu && (!benim.susturuldu.bitis || benim.susturuldu.bitis * 1000 > Date.now())) {
            const s = benim.susturuldu; form.appendChild(el('div', 'w-full text-center text-xs font-bold text-red-600 py-2', `Sohbette ${s.bitis ? new Date(s.bitis * 1000).toLocaleTimeString('tr-TR', { hour: '2-digit', minute: '2-digit' }) + "'e kadar" : 'kalıcı olarak'} ${s.tur === 'sustur' ? 'susturuldun' : s.tur === 'yasak' ? 'yasaklısın' : 'uzaklaştırıldın'}.`));
            if (s.bitis) setTimeout(() => { benim.susturuldu = null; formCiz(); }, s.bitis * 1000 - Date.now() + 500);
            return;
        }
        const em = butonla('😀', 'w-9 h-9 rounded-xl hover:bg-slate-100 text-lg shrink-0', () => q('.lv-emoji').classList.toggle('hidden')); em.setAttribute('aria-label', 'Emoji');
        const i = el('input', 'flex-1 min-w-0 rounded-xl border border-slate-200 focus:border-primary-500 outline-none px-3 py-2 text-sm'); i.maxLength = 300; i.placeholder = 'Mesaj yaz… (@ ile etiketle)'; i.setAttribute('aria-label', 'Mesaj');
        const g = el('button', 'w-10 h-10 rounded-xl bg-gradient-to-r from-primary-500 to-accent-600 text-white shrink-0'); g.appendChild(ikon('fa-solid fa-paper-plane')); g.setAttribute('aria-label', 'Gönder');
        form.append(em, i, g);
        i.addEventListener('input', () => {
            const m = i.value.match(/@([A-Za-z0-9_.ÇĞİÖŞÜçğıöşü-]*)$/); const o = q('.lv-oner'); o.replaceChildren();
            if (!m) { o.classList.add('hidden'); return; }
            const l = [...adlar].filter(a => a.toLowerCase().startsWith(m[1].toLowerCase()) && a !== hesapBen?.ad).slice(0, 6);
            o.classList.toggle('hidden', !l.length);
            l.forEach(a => o.appendChild(butonla('@' + a, 'px-2 py-1 rounded-lg bg-slate-100 text-xs font-bold', () => { i.value = i.value.replace(/@[^@\s]*$/, '@' + a + ' '); o.classList.add('hidden'); i.focus(); })));
        });
    }
    form.addEventListener('submit', async (e) => {
        e.preventDefault(); const i = form.querySelector('input'); if (!i || !i.value.trim()) return;
        const metin = i.value; i.value = ''; q('.lv-emoji').classList.add('hidden'); q('.lv-oner').classList.add('hidden');
        try { await lv('mesaj', { oda: ayar.oda, metin, yanit_id: yanitId }); yanitId = null; q('.lv-yanit').classList.add('hidden'); }
        catch (err) { bildir(err.message, false); if (err.kod === 403) { i.value = metin; } }
    });
    const emo = q('.lv-emoji'); EMOJILER.forEach(x => emo.appendChild(butonla(x, 'hover:bg-slate-100 rounded', () => { const i = form.querySelector('input'); if (i) { i.value += x; i.focus(); } })));
    (ayar.mesajlar || []).forEach(m => ekle(m));
    liste.scrollTop = liste.scrollHeight;
    sabitCiz(ayar.sabit); formCiz();
    // canlı akış
    let es, hata = 0, kapali = false;
    const baglan = () => {
        es = new EventSource(`/api/lives/akis?oda=${encodeURIComponent(ayar.oda)}&c=${LV_ISTEMCI}`);
        es.onopen = () => { if (hata) { lv('mesajlar?oda=' + encodeURIComponent(ayar.oda)).then(d => { liste.replaceChildren(); d.mesajlar.forEach(m => ekle(m)); sabitCiz(d.sabit); liste.scrollTop = liste.scrollHeight; }).catch(() => {}); } hata = 0; };
        es.onmessage = (e) => {
            const o = JSON.parse(e.data);
            if (o.tip === 'mesaj') ekle(o.m, hesapBen && o.m.kul.id === hesapBen.id);
            else if (o.tip === 'sil') { liste.querySelector(`[data-id="${o.id}"]`)?.remove(); if (sabitId === o.id) sabitCiz(null); }
            else if (o.tip === 'sabit') sabitCiz(o.m);
            else if (o.tip === 'izleyici') { q('.lv-iz').textContent = `👁 ${sayi(o.sayi)}`; ayar.onIzleyici?.(o.sayi); }
            else if (o.tip === 'sistem') sistem(o.metin);
            else if (o.tip === 'destek') { sistem(`💚 ${o.kul.ad} yayıncıyı destekliyor!`); ayar.onDestek?.(o.kul); }
            else if (o.tip === 'durum') ayar.onDurum?.(o);
            else if (o.tip === 'konusmaci') ayar.onKonusmaci?.(o);
            else if (o.tip === 'yasak' && hesapBen && o.kid === hesapBen.id) {
                benim.susturuldu = { tur: o.islem, bitis: o.bitis }; formCiz();
                if (o.islem !== 'sustur') { es.close(); kapali = true; sistem('Bu odadan uzaklaştırıldın.'); ayar.onYasak?.(o); }
            }
        };
        es.onerror = () => { if (kapali) return; hata++; if (es.readyState === EventSource.CLOSED) { setTimeout(() => !kapali && baglan(), Math.min(15000, 2000 * hata)); } };
    };
    baglan();
    const kapat = () => { kapali = true; es?.close(); document.getElementById('lv-mmenu')?.remove(); };
    temizlik.push(kapat);
    return { kapat, sistem };
}

// ------------------------------------------------------------ RESMÎ KANAL: Mertixtan Studios Live
async function resmiSayfasi() {
    let d = await lv('resmi');
    const kap = $('lv-icerik'); kap.replaceChildren();
    const izgara = el('div', 'grid grid-cols-1 lg:grid-cols-[minmax(0,1fr)_360px] gap-5'); kap.appendChild(izgara);
    const sol = el('div', 'min-w-0 space-y-4'), sag = el('div'); izgara.append(sol, sag);
    const o = oynaticiKabugu(); sol.appendChild(o.dis);
    const bilgi = el('div'); sol.appendChild(bilgi);
    const prog = el('div'); sol.appendChild(prog);
    let mevcut = '', izleyici = d.durum.izleyici, zaman;
    const oynat = async () => {
        const r = d.durum;
        const anahtar = r.mod + ':' + (r.canli?.id || r.simdi?.id || '') + ':' + (r.simdi?.icerik?.kaynak || '');
        o.dis.parentElement.style.setProperty('--vurgu', TEMA_VURGU[r.tema]);
        o.dis.style.boxShadow = `0 0 0 2px ${TEMA_VURGU[r.tema]}55, 0 25px 50px -12px rgba(0,0,0,.5)`;
        if (anahtar !== mevcut) {
            mevcut = anahtar; o.yt = null; o.sesAc.classList.add('hidden');
            if (o.oda) { o.oda.disconnect(); o.oda = null; }
            if (r.mod === 'nosignal') o.sahne.replaceChildren(noSignalEkrani(r));
            else if (r.mod === 'program') programOynat(o, r);
            else o.oda = await lkIzle(o, 'resmi').catch(e => { o.sahne.replaceChildren(noSignalEkrani({ ...r, nosignal_mesaj: e.message })); return null; });
        }
        bilgiCiz(); progCiz();
        clearTimeout(zaman);  // program sınırında (bitiş/başlangıç) kendini yenile
        const sinirlar = [r.simdi?.bitis, r.sonraki?.baslangic].filter(Boolean).map(t => (t - r.sunucu_zamani) * 1000 + 1500);
        if (sinirlar.length) zaman = setTimeout(yenile, Math.min(...sinirlar, 2147000000));
    };
    const yenile = async () => { try { d = await lv('resmi'); oynat(); } catch (e) {} };
    temizlik.push(() => { clearTimeout(zaman); o.oda?.disconnect(); });
    function bilgiCiz() {
        const r = d.durum; bilgi.replaceChildren();
        const k = el('div', 'lv-acik rounded-2xl bg-white border border-slate-200 p-4 sm:p-5');
        const ust = el('div', 'flex flex-wrap items-start justify-between gap-3');
        const yz = el('div', 'min-w-0');
        const et = el('div', 'flex flex-wrap items-center gap-2 mb-1');
        et.append(el('span', 'px-2 py-0.5 rounded text-[10px] font-black tracking-wider ' + (r.mod === 'nosignal' ? 'bg-slate-200 text-slate-600' : 'bg-red-600 text-white lv-canli'), r.mod === 'nosignal' ? 'NO SIGNAL' : r.mod === 'canli' ? 'CANLI' : 'YAYINDA'),
            el('span', 'text-xs font-bold text-slate-500', `👁 ${sayi(izleyici)} izleyici`));
        yz.appendChild(et);
        yz.appendChild(el('h1', 'font-display font-black text-xl sm:text-2xl text-slate-900', r.mod === 'canli' ? r.canli.baslik : r.mod === 'program' ? r.simdi.baslik : 'Mertixtan Studios Live'));
        const yay = el('div', 'flex items-center gap-2 text-sm mt-1'); yay.append(adEl({ ad: 'Mertixtan Studios Live', rozet: { admin: true, onayli: true }, resmi: true }, false));
        if (r.mod === 'program') yay.appendChild(el('span', 'text-slate-500', `· ${saat(r.simdi.baslangic)} – ${saat(r.simdi.bitis)}`));
        yz.appendChild(yay);
        const ac = r.mod === 'program' ? r.simdi.aciklama || r.simdi.icerik?.aciklama : r.mod === 'canli' ? r.canli.aciklama : '';
        if (ac) yz.appendChild(el('p', 'text-sm text-slate-600 mt-2 whitespace-pre-line', ac));
        const bt = el('div', 'flex flex-wrap gap-2');
        bt.append(paylasBtn('Mertixtan Studios Live', location.origin + '/#lives/resmi'), temaBtn());
        if (hesapBen?.yonetici) bt.appendChild(butonla('⚙ Yönet', KUCUK + ' py-2', () => git('yonetim/kanal')));
        ust.append(yz, bt); k.appendChild(ust);
        bilgi.appendChild(k);
        if (r.mod === 'program' && r.simdi.icerik) bilgi.appendChild(el('div', 'mt-4')).appendChild(puanKutusu(r.simdi.icerik));
    }
    async function progCiz(gun) {
        gun = gun || prog.dataset.gun || bugun(); prog.dataset.gun = gun;
        const veri = gun === bugun() ? d.program : (await lv('resmi?gun=' + gun)).program;
        prog.replaceChildren();
        const k = el('div', 'lv-acik rounded-2xl bg-white border border-slate-200 p-4 sm:p-5');
        const ust = el('div', 'flex flex-wrap items-center justify-between gap-2 mb-3');
        ust.appendChild(el('h2', 'font-display font-black text-lg text-slate-900', '📺 Yayın programı'));
        const t = el('input', 'rounded-xl border border-slate-200 px-3 py-1.5 text-sm'); t.type = 'date'; t.value = gun; t.onchange = () => progCiz(t.value); t.setAttribute('aria-label', 'Gün');
        ust.appendChild(t); k.appendChild(ust);
        if (!veri.length) k.appendChild(el('div', 'rounded-xl bg-slate-900 text-white/80 font-mono text-center py-6 tracking-widest', 'NO SIGNAL · bu gün için program yok'));
        for (const p of veri) {
            const s = el('div', 'flex gap-3 py-3 border-t border-slate-100 first:border-0 ' + (p.durum === 'bitti' ? 'opacity-50' : ''));
            const sa = el('div', 'w-16 shrink-0 text-sm font-black ' + (p.durum === 'yayinda' ? 'text-red-600' : 'text-slate-700')); sa.append(el('div', '', saat(p.baslangic)), el('div', 'text-[11px] font-semibold text-slate-400', saat(p.bitis)));
            const yz = el('div', 'min-w-0 flex-1');
            const b = el('div', 'flex flex-wrap items-center gap-2'); b.appendChild(el('span', 'font-bold text-slate-900', p.baslik));
            b.appendChild(el('span', 'px-1.5 py-0.5 rounded text-[10px] font-black ' + ({ yayinda: 'bg-red-600 text-white lv-canli', sirada: 'bg-slate-100 text-slate-600', bitti: 'bg-slate-100 text-slate-400' }[p.durum]), { yayinda: 'ŞİMDİ', sirada: 'SIRADA', bitti: 'BİTTİ' }[p.durum]));
            yz.appendChild(b);
            if (p.icerik) yz.appendChild(el('div', 'text-xs text-slate-500', `${{ film: '🎬 Film', dizi: '📺 Dizi', program: '🎙 Program', diger: '•' }[p.icerik.tur]}: ${p.icerik.ad}${p.icerik.puan.ortalama ? ` · ★ ${p.icerik.puan.ortalama.toFixed(1)} (${p.icerik.puan.oy})` : ''}`));
            if (p.aciklama) yz.appendChild(el('div', 'text-xs text-slate-600 mt-0.5', p.aciklama));
            s.append(sa, yz); k.appendChild(s);
        }
        prog.appendChild(k);
    }
    const sh = el('div'); sag.appendChild(sh);
    sohbet(sh, { oda: 'resmi', yetki: d.yetki, mesajlar: d.mesajlar, sabit: d.sabit,
        onIzleyici: (n) => { izleyici = n; const s = bilgi.querySelector('.text-xs.font-bold.text-slate-500'); if (s) s.textContent = `👁 ${sayi(n)} izleyici`; },
        onDurum: () => yenile() });
    await oynat();
}

function paylasBtn(baslik, url) {
    const b = butonla('', KUCUK + ' py-2', async () => {
        try { if (navigator.share) await navigator.share({ title: baslik, url }); else { await navigator.clipboard.writeText(url); bildir('Bağlantı kopyalandı'); } } catch (e) {}
    });
    b.append(ikon('fa-solid fa-share-nodes mr-1'), document.createTextNode('Paylaş')); return b;
}
function temaBtn() {
    const b = butonla('', KUCUK + ' py-2', () => { const a = !document.documentElement.classList.contains('lv-sinema'); document.documentElement.classList.toggle('lv-sinema', a); try { localStorage.setItem('lv_sinema', a ? '1' : '0'); } catch (e) {} });
    b.append(ikon('fa-solid fa-film mr-1'), document.createTextNode('Sinema modu')); b.title = 'Sayfa temasını koyu sinema moduna çevir'; return b;
}

// ------------------------------------------------------------ YAYIN İZLEME
async function yayinSayfasi(id) {
    const d = await lv('yayin?id=' + id);
    const y = d.yayin;
    if (d.yetki.sahip && y.durum === 'canli') { git('yayinla'); return; }
    const kap = $('lv-icerik'); kap.replaceChildren();
    const izgara = el('div', 'grid grid-cols-1 lg:grid-cols-[minmax(0,1fr)_360px] gap-5'); kap.appendChild(izgara);
    const sol = el('div', 'min-w-0 space-y-4'), sag = el('div', 'space-y-4'); izgara.append(sol, sag);
    const o = oynaticiKabugu(); sol.appendChild(o.dis);
    o.dis.style.boxShadow = `0 0 0 2px ${TEMA_VURGU[y.tema]}66, 0 25px 50px -12px rgba(0,0,0,.5)`;
    if (y.durum !== 'canli') {
        const k = el('div', 'absolute inset-0 flex flex-col items-center justify-center text-white text-center p-6'); k.style.background = TEMA_ARKA[y.tema];
        k.append(el('div', 'text-xs font-black tracking-widest text-white/60 mb-2', 'YAYIN SONA ERDİ'), el('div', 'font-display font-black text-2xl', y.baslik),
            el('div', 'text-sm text-white/70 mt-2', `${tarih(y.baslangic)} · ${sure((y.bitis || y.baslangic) - y.baslangic)} · en çok ${y.tepe} izleyici · ${y.tekil} tekil izleyici`));
        o.sahne.replaceChildren(k);
    } else {
        o.oda = await lkIzle(o, y.oda, y.tur === 'sesli').catch(e => { bildir(e.message, false); return null; });
        if (y.tur === 'sesli' && o.oda) sesliKatilimcilar(sol, o.oda, y.oda, d.yetki, d.konusmacilar);
    }
    // bilgi kartı
    const k = el('div', 'lv-acik rounded-2xl bg-white border border-slate-200 p-4 sm:p-5'); sol.appendChild(k);
    const et = el('div', 'flex flex-wrap items-center gap-2 mb-1');
    const izEl = el('span', 'text-xs font-bold text-slate-500', `👁 ${sayi(y.izleyici)} izleyici`);
    et.append(el('span', 'px-2 py-0.5 rounded text-[10px] font-black tracking-wider ' + (y.durum === 'canli' ? 'bg-red-600 text-white lv-canli' : 'bg-slate-200 text-slate-600'), y.durum === 'canli' ? 'CANLI' : 'BİTTİ'), izEl,
        el('span', 'px-2 py-0.5 rounded bg-slate-100 text-[11px] font-bold text-slate-600', y.kategori), el('span', 'text-xs text-slate-400', { kamera: '📷 Kamera', ekran: '🖥 Ekran', sesli: '🎙 Sesli' }[y.tur]));
    if (y.ozel) et.appendChild(el('span', 'px-2 py-0.5 rounded bg-amber-100 text-amber-800 text-[11px] font-bold', '🔒 Özel oda'));
    k.append(et, el('h1', 'font-display font-black text-xl sm:text-2xl text-slate-900', y.baslik));
    if (y.aciklama) k.appendChild(el('p', 'text-sm text-slate-600 mt-1 whitespace-pre-line', y.aciklama));
    const yay = el('div', 'flex flex-wrap items-center justify-between gap-3 mt-4 pt-4 border-t border-slate-100');
    const ys = el('div', 'flex items-center gap-3 min-w-0');
    const av = el('div', 'w-11 h-11 rounded-xl flex items-center justify-center text-white font-black shrink-0'); av.style.background = y.yayinci.renk || '#10b981'; av.textContent = (y.yayinci.ad || '?')[0].toUpperCase();
    const ysy = el('div', 'min-w-0'); const tk = el('div', 'text-xs text-slate-500', `${d.takipci} takipçi`);
    ysy.append(adEl(y.yayinci), tk); ys.append(av, ysy);
    const bt = el('div', 'flex flex-wrap gap-2');
    if (!d.yetki.sahip) {
        let takip = d.takip_ediyorum, destek = d.destekliyorum;
        const tb = butonla('', '', async () => { if (girisGerek('Takip etmek')) return; try { const r = await lv('takip', { ad: y.yayinci.ad }); takip = r.takip; tk.textContent = `${r.takipci} takipçi`; tc(); } catch (e) { bildir(e.message, false); } });
        const tc = () => { tb.className = 'px-4 py-2 rounded-xl text-xs font-bold ' + (takip ? 'bg-slate-100 text-slate-700' : 'bg-red-600 text-white'); tb.textContent = takip ? '✓ Takip ediliyor' : '+ Takip et'; }; tc();
        const db_ = butonla('', '', async () => { if (girisGerek('Desteklemek')) return; try { const r = await lv('destek', { ad: y.yayinci.ad }); destek = r.destek; dc(); destekCiz(); } catch (e) { bildir(e.message, false); } });
        const dc = () => { db_.className = 'px-4 py-2 rounded-xl text-xs font-bold ' + (destek ? 'bg-primary-100 text-primary-700' : 'bg-gradient-to-r from-primary-500 to-accent-600 text-white'); db_.textContent = destek ? '💚 Destekliyorsun' : '💚 Destekliyoruz'; }; dc();
        bt.append(tb, db_);
        const destekCiz = async () => { const r = await lv('yayin?id=' + id).catch(() => null); if (r) { d.destekciler = r.destekciler; destekKutusuCiz(); } };
    }
    bt.append(paylasBtn(y.baslik, location.origin + '/#lives/y/' + y.id), temaBtn());
    if (!d.yetki.sahip && d.yetki.giris) bt.appendChild(butonla('⚑ Raporla', KUCUK + ' py-2', () => { const n = prompt('Bu yayını neden raporluyorsun?'); if (n) lv('rapor', { hedef_tur: 'yayin', hedef_id: y.id, neden: n }).then(() => bildir('Rapor iletildi')).catch(e => bildir(e.message, false)); }));
    if (d.yetki.admin && y.durum === 'canli') bt.appendChild(butonla('⛔ Yayını bitir', KIRMIZI + ' py-2', () => confirm('Bu yayın sonlandırılsın mı?') && lv('yayin_bitir', { id: y.id }).then(() => yayinSayfasi(id)).catch(e => bildir(e.message, false))));
    yay.append(ys, bt); k.appendChild(yay);
    // destekleyenler
    const dk = el('div'); sag.appendChild(dk);
    const destekKutusuCiz = () => {
        dk.replaceChildren();
        const b = el('div', 'lv-acik rounded-2xl bg-white border border-slate-200 p-4');
        b.appendChild(el('div', 'font-bold text-sm text-slate-900 mb-2', `💚 Destekleyenler (${d.destekciler.length})`));
        if (!d.destekciler.length) b.appendChild(el('p', 'text-xs text-slate-400', 'Henüz destekleyen yok. İlk destekleyen sen ol!'));
        const l = el('div', 'flex flex-wrap gap-1.5');
        d.destekciler.slice(0, 40).forEach(x => { const c = el('span', 'px-2 py-1 rounded-lg text-xs ' + (x.rozet?.pro ? 'bg-amber-50 border border-amber-200' : 'bg-slate-50 border border-slate-200')); c.appendChild(adEl(x)); l.appendChild(c); });
        b.appendChild(l); dk.appendChild(b);
    };
    destekKutusuCiz();
    const sh = el('div'); sag.appendChild(sh);
    sohbet(sh, { oda: y.oda, yetki: d.yetki, mesajlar: d.mesajlar, sabit: d.sabit,
        onIzleyici: (n) => { izEl.textContent = `👁 ${sayi(n)} izleyici`; },
        onDestek: (kul) => { if (!d.destekciler.some(x => x.ad === kul.ad)) { d.destekciler.unshift(kul); destekKutusuCiz(); } },
        onDurum: (e) => { if (e.bitti) { bildir('Yayın sona erdi'); setTimeout(() => yayinSayfasi(id), 800); } },
        onYasak: () => { o.oda?.disconnect(); } });
}

// Sesli yayın / sesli oda: katılımcılar, konuşanlar, mikrofon
function sesliKatilimcilar(kap, room, oda, yetki, konusmacilar, odaMi) {
    const k = el('div', 'lv-acik rounded-2xl bg-white border border-slate-200 p-4'); kap.appendChild(k);
    const ust = el('div', 'flex flex-wrap items-center justify-between gap-2 mb-3'); k.appendChild(ust);
    ust.appendChild(el('div', 'font-bold text-sm text-slate-900', '🎙 Katılımcılar'));
    const mik = butonla('', 'hidden px-4 py-2 rounded-xl text-xs font-bold', async () => {
        try { await room.localParticipant.setMicrophoneEnabled(!room.localParticipant.isMicrophoneEnabled); ciz(); } catch (e) { bildir('Mikrofon açılamadı: ' + (e.message || e), false); }
    });
    ust.appendChild(mik);
    const g = el('div', 'grid grid-cols-3 sm:grid-cols-4 md:grid-cols-6 gap-3'); k.appendChild(g);
    const meta = (p) => { try { return JSON.parse(p.metadata || '{}'); } catch (e) { return {}; } };
    const ciz = () => {
        const yer = room.localParticipant;
        const yayinlayabilir = yer.permissions?.canPublish;
        mik.classList.toggle('hidden', !yayinlayabilir || !hesapBen);
        mik.className = 'px-4 py-2 rounded-xl text-xs font-bold ' + (yer.isMicrophoneEnabled ? 'bg-red-600 text-white' : 'bg-slate-100 text-slate-700') + (!yayinlayabilir || !hesapBen ? ' hidden' : '');
        mik.textContent = yer.isMicrophoneEnabled ? '🎙 Mikrofon açık (kapat)' : '🎙 Mikrofonu aç';
        g.replaceChildren();
        const hepsi = [yer, ...room.remoteParticipants.values()].filter(p => !p.identity.startsWith('m') || p === yer);
        hepsi.sort((a, b) => (meta(b).yayinci ? 1 : 0) - (meta(a).yayinci ? 1 : 0) || (b.isSpeaking ? 1 : 0) - (a.isSpeaking ? 1 : 0));
        for (const p of hepsi) {
            const mt = meta(p); const kul = { id: mt.id, ad: mt.ad || p.name || 'Misafir', rozet: mt.rozet || {} };
            const c = el('div', 'flex flex-col items-center gap-1 text-center min-w-0');
            const av = el('div', 'relative w-14 h-14 rounded-2xl flex items-center justify-center text-white font-black text-lg transition-shadow ' + (p.isSpeaking ? 'lv-konusuyor' : ''));
            av.style.background = kul.rozet.admin ? 'linear-gradient(135deg,#7f0019,#e0115f)' : kul.rozet.pro ? 'linear-gradient(135deg,#a16207,#facc15)' : '#64748b';
            av.textContent = kul.ad[0].toUpperCase();
            const acik = [...p.audioTrackPublications.values()].some(t => !t.isMuted && t.track);
            const mi = el('span', 'absolute -bottom-1 -right-1 w-6 h-6 rounded-full flex items-center justify-center text-[11px] ' + (acik ? 'bg-primary-500 text-white' : 'bg-slate-200 text-slate-500'));
            mi.appendChild(ikon(acik ? 'fa-solid fa-microphone' : 'fa-solid fa-microphone-slash')); av.appendChild(mi);
            c.append(av, adEl(kul));
            if (mt.yayinci || (odaMi && p === yer && yetki.sahip)) c.appendChild(el('span', 'text-[10px] font-bold text-red-600', mt.yayinci ? 'Yayıncı' : 'Oda sahibi'));
            if (yetki.moderator && p !== yer && kul.id && !mt.yayinci) {
                const bt = el('div', 'flex gap-1');
                const konusabilir = p.permissions?.canPublish;
                bt.appendChild(butonla(konusabilir ? '🔇' : '🎙', 'w-7 h-7 rounded-lg bg-slate-100 text-xs', () => lv('konusmaci', { oda, kid: kul.id, izin: !konusabilir }).then(() => bildir(konusabilir ? 'Susturuldu' : 'Konuşma izni verildi')).catch(e => bildir(e.message, false))));
                bt.lastChild.title = konusabilir ? 'Sustur (dinleyici yap)' : 'Konuşmacı yap';
                bt.appendChild(butonla('⨯', 'w-7 h-7 rounded-lg bg-red-50 text-red-600 text-xs font-bold', () => confirm(kul.ad + ' odadan çıkarılsın mı? (10 dk)') && lv('cikar', { oda, kid: kul.id }).catch(e => bildir(e.message, false))));
                bt.lastChild.title = 'Odadan çıkar';
                c.appendChild(bt);
            }
            g.appendChild(c);
        }
        if (!hepsi.length) g.appendChild(el('p', 'text-xs text-slate-400 col-span-full', 'Kimse yok.'));
    };
    for (const e of ['ParticipantConnected', 'ParticipantDisconnected', 'ActiveSpeakersChanged', 'TrackMuted', 'TrackUnmuted', 'TrackPublished', 'TrackUnpublished', 'LocalTrackPublished', 'LocalTrackUnpublished', 'ParticipantPermissionsChanged', 'ParticipantMetadataChanged'])
        room.on(LK.RoomEvent[e], ciz);
    ciz();
    return { ciz };
}

// ------------------------------------------------------------ YAYIN AÇ (stüdyo): kamera / ekran / sesli
async function studyoSayfasi(resmiMi) {
    const kap = $('lv-icerik'); kap.replaceChildren();
    if (!hesapBen) { kap.appendChild(bilgiKutusu('Yayın açmak için giriş yap', 'Mertixtan hesabınla giriş yapman yeterli; yeni hesap gerekmez.', 'Giriş yap', () => hesapPencere('giris'))); return; }
    if (!KESFET) KESFET = await lv('kesfet').catch(() => null);
    const yetkili = hesapBen.pro || hesapBen.yonetici || KESFET?.ben?.yayin_yetkili;
    if (resmiMi && !hesapBen.yonetici) { kap.appendChild(bilgiKutusu('Yetkin yok', 'Resmî kanala sadece yöneticiler yayın açar.')); return; }
    if (!yetkili && !resmiMi) { kap.appendChild(bilgiKutusu('Yayın açmak Pro üyelere özel', 'Pro üyeler kamera, ekran ve sesli yayın açabilir, sesli oda kurabilir ve keşfette öne çıkar. Yöneticiler de seçilen kullanıcılara yayıncı yetkisi verebilir.', 'Pro\'yu incele', () => openUyelik())); return; }
    // açık yayın var mı?
    const prof = await lv('profil?ad=' + encodeURIComponent(hesapBen.ad)).catch(() => null);
    let aktif = resmiMi ? (await lv('resmi')).durum.canli : prof?.aktif;
    if (resmiMi && aktif) aktif = { ...aktif, oda: 'resmi' };
    if (aktif) return studyo(aktif, resmiMi);
    // form
    const f = el('form', 'lv-acik max-w-3xl mx-auto rounded-3xl bg-white border border-slate-200 p-5 sm:p-8 space-y-4');
    f.innerHTML = `<h1 class="font-display font-black text-2xl text-slate-900">${resmiMi ? '📡 Resmî kanalda canlıya geç' : '🎥 Yeni yayın'}</h1>
        <p class="text-sm text-slate-500">${resmiMi ? 'Mertixtan Studios Live kanalında canlı yayın programın önüne geçer. Bitirince program kaldığı yerden devam eder.' : 'Yayın başlayınca keşfette görünür; takipçilerin "Takip ettiklerin canlı" bölümünde görür.'}</p>
        <label class="block text-xs font-bold text-slate-500">Yayın adı<input name="baslik" required minlength="3" maxlength="100" class="${GIRDI} mt-1" placeholder="Ör. Akşam sohbeti"></label>
        <label class="block text-xs font-bold text-slate-500">Açıklama<textarea name="aciklama" rows="2" maxlength="500" class="${GIRDI} mt-1 resize-none"></textarea></label>
        <div class="grid sm:grid-cols-2 gap-3"><label class="block text-xs font-bold text-slate-500">Kategori<select name="kategori" class="${GIRDI} mt-1"></select></label>
        <label class="block text-xs font-bold text-slate-500">Tema<select name="tema" class="${GIRDI} mt-1"></select></label></div>
        <fieldset><legend class="text-xs font-bold text-slate-500 mb-1">Yayın türü</legend><div class="grid grid-cols-3 gap-2 lv-tur"></div></fieldset>
        <label class="lv-konus hidden items-center gap-2 text-sm font-semibold text-slate-700"><input type="checkbox" name="konusmaya_acik" class="w-5 h-5"> Dinleyiciler de konuşabilsin (sesli sohbet)</label>
        ${resmiMi ? '' : '<label class="flex items-center gap-2 text-sm font-semibold text-slate-700"><input type="checkbox" name="ozel" class="w-5 h-5"> Özel oda: keşfette görünmesin, sadece bağlantıyı paylaştıkların girsin</label>'}
        <label class="block text-xs font-bold text-slate-500">Kapak görseli (isteğe bağlı, en çok 2 MB)<input name="kapakd" type="file" accept="image/jpeg,image/png,image/webp" class="block mt-1 text-sm"></label>
        <p class="lv-destek text-xs text-slate-500"></p>
        <button type="submit" class="lv-baslat ${BUTON} w-full py-3.5 text-base">🔴 Yayını başlat</button>`;
    kap.appendChild(f);
    for (const k_ of KESFET?.kategoriler || ['Sohbet', 'Oyun', 'Diğer']) { const o = el('option', '', k_); f.kategori.appendChild(o); }
    for (const [t, a] of Object.entries(TEMA_ADI)) { const o = el('option', '', a); o.value = t; f.tema.appendChild(o); }
    if (resmiMi) f.tema.value = 'yakut';
    const ekranVar = !!navigator.mediaDevices?.getDisplayMedia, medyaVar = !!navigator.mediaDevices?.getUserMedia;
    let tur = 'kamera';
    const turler = [['kamera', 'fa-video', 'Kamera', medyaVar], ['ekran', 'fa-display', 'Ekran', ekranVar], ['sesli', 'fa-microphone-lines', 'Sesli', medyaVar]];
    const turCiz = () => {
        const k = f.querySelector('.lv-tur'); k.replaceChildren();
        for (const [t, i, a, var_] of turler) {
            const b = butonla('', 'rounded-2xl border-2 p-3 text-center text-sm font-bold ' + (!var_ ? 'opacity-40 cursor-not-allowed border-slate-200' : tur === t ? 'border-red-500 bg-red-50 text-red-700' : 'border-slate-200 hover:border-slate-300'), () => { if (var_) { tur = t; turCiz(); } });
            b.append(ikon('fa-solid ' + i + ' block text-xl mb-1'), document.createTextNode(a)); k.appendChild(b);
        }
        f.querySelector('.lv-konus').classList.toggle('hidden', tur !== 'sesli'); f.querySelector('.lv-konus').classList.toggle('flex', tur === 'sesli');
        f.querySelector('.lv-destek').textContent = !ekranVar ? 'Not: Bu cihaz/tarayıcı ekran paylaşımını desteklemiyor (çoğu telefon tarayıcısında yok). Kamera ya da sesli yayın açabilirsin.' : (location.protocol !== 'https:' && location.hostname !== 'localhost' && location.hostname !== '127.0.0.1' ? 'Uyarı: Kamera/mikrofon/ekran için site https ile açılmalı.' : '');
    };
    turCiz();
    f.addEventListener('submit', async (e) => {
        e.preventDefault(); const b = f.querySelector('.lv-baslat'); b.disabled = true; b.textContent = 'Hazırlanıyor…';
        try {
            // önce izinleri al (kullanıcı reddederse yayın kaydı açılmasın)
            const yerel = await yerelIzerler(tur);
            let kapak = '';
            const dosya = f.kapakd.files[0];
            if (dosya) { const r = await fetch('/api/lives/kapak', { method: 'POST', credentials: 'same-origin', headers: { 'Content-Type': dosya.type }, body: dosya }); const j = await r.json(); if (!r.ok) throw new Error(j.hata); kapak = j.kapak; }
            const r = await lv('yayin_baslat', { baslik: f.baslik.value, aciklama: f.aciklama.value, kategori: f.kategori.value, tema: f.tema.value, tur, ozel: f.ozel?.checked, konusmaya_acik: f.konusmaya_acik.checked, kapak, resmi: resmiMi });
            const y = (await lv('yayin?id=' + r.id)).yayin;
            studyo({ ...y, oda: r.oda }, resmiMi, yerel);
        } catch (err) { bildir(err.name === 'NotAllowedError' ? 'İzin verilmedi: kamera/mikrofon/ekran için tarayıcıya izin vermelisin' : err.message, false); b.disabled = false; b.textContent = '🔴 Yayını başlat'; }
    });
}
function bilgiKutusu(baslik, metin, btn, f) {
    const k = el('div', 'lv-acik max-w-xl mx-auto text-center rounded-3xl bg-white border border-slate-200 p-8');
    k.append(el('h2', 'font-display font-black text-2xl text-slate-900 mb-2', baslik), el('p', 'text-sm text-slate-600 mb-5', metin));
    if (btn) k.appendChild(butonla(btn, BUTON, f));
    return k;
}
async function yerelIzerler(tur) {
    if (tur === 'kamera') return LK.createLocalTracks({ audio: true, video: { facingMode: 'user', resolution: LK.VideoPresets.h720.resolution } });
    if (tur === 'sesli') return LK.createLocalTracks({ audio: true, video: false });
    const t = await LK.createLocalScreenTracks({ audio: true, resolution: LK.VideoPresets.h1080.resolution });
    try { t.push(...await LK.createLocalTracks({ audio: true, video: false })); } catch (e) {}  // mikrofon isteğe bağlı
    return t;
}

async function studyo(y, resmiMi, yerel) {
    const kap = $('lv-icerik'); kap.replaceChildren();
    const oda = resmiMi ? 'resmi' : y.oda;
    const izgara = el('div', 'grid grid-cols-1 lg:grid-cols-[minmax(0,1fr)_360px] gap-5'); kap.appendChild(izgara);
    const sol = el('div', 'min-w-0 space-y-4'), sag = el('div'); izgara.append(sol, sag);
    const o = oynaticiKabugu(); sol.appendChild(o.dis);
    o.dis.style.boxShadow = `0 0 0 3px #dc2626, 0 25px 50px -12px rgba(0,0,0,.5)`;
    const ust = el('div', 'absolute top-3 left-3 z-10 flex gap-2');
    const canli = el('span', 'px-2 py-1 rounded-md bg-red-600 text-white text-[11px] font-black lv-canli', '● CANLI'); const izEl = el('span', 'px-2 py-1 rounded-md bg-black/60 text-white text-[11px] font-bold', '👁 0');
    const sureEl = el('span', 'px-2 py-1 rounded-md bg-black/60 text-white text-[11px] font-bold', '0 dk');
    ust.append(canli, izEl, sureEl); o.dis.appendChild(ust);
    const t0 = y.baslangic; const st = setInterval(() => { sureEl.textContent = sure(Date.now() / 1000 - t0); }, 1000); temizlik.push(() => clearInterval(st));
    // kontrol paneli
    const panel = el('div', 'lv-acik rounded-2xl bg-white border border-slate-200 p-4 space-y-3'); sol.appendChild(panel);
    panel.appendChild(el('div', 'font-display font-black text-lg text-slate-900', y.baslik));
    const kontroller = el('div', 'flex flex-wrap gap-2'); panel.appendChild(kontroller);
    const durumYazi = el('p', 'text-xs text-slate-500'); panel.appendChild(durumYazi);
    const room = new LK.Room({ dynacast: true, adaptiveStream: false, publishDefaults: { simulcast: true, videoSimulcastLayers: [LK.VideoPresets.h360, LK.VideoPresets.h540] } });
    let bitti = false;
    temizlik.push(() => { if (!bitti) { room.disconnect(); for (const t of yerel || []) t.stop(); } });
    const onizle = () => {
        const v = [...room.localParticipant.videoTrackPublications.values()].find(p => p.track)?.track;
        o.sahne.replaceChildren();
        if (v) { const m = v.attach(); m.className = 'absolute inset-0 w-full h-full'; m.muted = true; if (v.source === 'camera') m.style.transform = 'scaleX(-1)'; o.sahne.appendChild(m); }
        else { const b = el('div', 'absolute inset-0 flex flex-col items-center justify-center text-white/80 gap-2'); b.style.background = TEMA_ARKA[y.tema]; b.append(ikon(y.tur === 'sesli' ? 'fa-solid fa-microphone-lines text-5xl' : 'fa-solid fa-video-slash text-5xl'), el('span', 'text-sm', y.tur === 'sesli' ? 'Sesli yayın' : 'Görüntü kapalı')); o.sahne.appendChild(b); }
    };
    const kontrolCiz = () => {
        kontroller.replaceChildren();
        const lp = room.localParticipant;
        const b = (yazi, f, aktif, kirmizi) => kontroller.appendChild(butonla(yazi, 'px-4 py-2.5 rounded-xl text-sm font-bold ' + (kirmizi ? 'bg-red-600 text-white' : aktif ? 'bg-slate-900 text-white' : 'bg-slate-100 text-slate-700'), async () => { try { await f(); } catch (e) { bildir(e.name === 'NotAllowedError' ? 'İzin verilmedi' : (e.message || String(e)), false); } kontrolCiz(); onizle(); }));
        b(lp.isMicrophoneEnabled ? '🎙 Mikrofon açık' : '🔇 Mikrofon kapalı', () => lp.setMicrophoneEnabled(!lp.isMicrophoneEnabled), lp.isMicrophoneEnabled);
        if (y.tur === 'kamera') {
            b(lp.isCameraEnabled ? '📷 Kamera açık' : '📷 Kamera kapalı', () => lp.setCameraEnabled(!lp.isCameraEnabled), lp.isCameraEnabled);
            b('🔄 Kamera değiştir', async () => {
                const k = [...lp.videoTrackPublications.values()].find(p => p.source === 'camera')?.track; if (!k) return;
                const simdi = k.mediaStreamTrack.getSettings().facingMode === 'environment' ? 'user' : 'environment';
                await k.restartTrack({ facingMode: simdi });
            });
        }
        if (y.tur === 'ekran' || resmiMi) {
            b(lp.isScreenShareEnabled ? '🖥 Paylaşımı durdur' : '🖥 Ekranı paylaş', () => lp.setScreenShareEnabled(!lp.isScreenShareEnabled, { audio: true }), lp.isScreenShareEnabled);
            if (resmiMi) b(lp.isCameraEnabled ? '📷 Kamera açık' : '📷 Kamera', () => lp.setCameraEnabled(!lp.isCameraEnabled), lp.isCameraEnabled);
        }
        if (y.tur === 'sesli' && !resmiMi) b(y.konusmaya_acik ? '🗣 Herkes konuşabilir' : '🤫 Sadece izin verdiklerim', async () => { await lv('yayin_ayar', { id: y.id, konusmaya_acik: !y.konusmaya_acik }); y.konusmaya_acik = !y.konusmaya_acik; bildir('Yeni katılanlar için geçerli; mevcut dinleyicilere tek tek izin verebilirsin'); });
        const ts = el('select', 'rounded-xl border border-slate-200 px-3 text-sm font-bold'); ts.setAttribute('aria-label', 'Yayın teması');
        for (const [t, a] of Object.entries(TEMA_ADI)) { const op = el('option', '', '🎨 ' + a); op.value = t; ts.appendChild(op); } ts.value = y.tema;
        ts.onchange = () => (resmiMi ? lv('yonetim_kanal', { tema: ts.value }) : lv('yayin_ayar', { id: y.id, tema: ts.value })).then(() => { y.tema = ts.value; bildir('Tema değişti'); onizle(); }).catch(e => bildir(e.message, false));
        kontroller.appendChild(ts);
        kontroller.appendChild(paylasBtn(y.baslik, location.origin + '/#lives/' + (resmiMi ? 'resmi' : 'y/' + y.id)));
        b('⏹ Yayını bitir', async () => {
            if (!confirm('Yayın bitirilsin mi?')) return;
            bitti = true;
            const r = await lv('yayin_bitir', { id: y.id });
            room.disconnect(); for (const t of yerel || []) t.stop();
            for (const p of room.localParticipant.trackPublications.values()) p.track?.stop();
            istatistikGoster(r.istatistik);
        }, false, true);
    };
    try {
        const { token } = await lv('token', { oda, mod: 'yayinla', c: LV_ISTEMCI });
        await room.connect(WS_ADRES, token);
        if (!yerel) { durumYazi.textContent = 'Yayına devam etmek için kaynağı yeniden aç.'; yerel = await yerelIzerler(y.tur).catch(e => { bildir('İzin verilmedi; aşağıdaki düğmelerle yeniden açabilirsin', false); return []; }); }
        for (const t of yerel) await room.localParticipant.publishTrack(t, t.kind === 'video' ? { simulcast: true, source: t.source } : { source: t.source });
        durumYazi.textContent = 'Yayındasın. İzleyiciler: ' + location.origin + '/#lives/' + (resmiMi ? 'resmi' : 'y/' + y.id);
    } catch (e) { durumYazi.textContent = 'Bağlantı hatası: ' + e.message; bildir(e.message, false); }
    room.on(LK.RoomEvent.LocalTrackUnpublished, () => { kontrolCiz(); onizle(); });
    room.on(LK.RoomEvent.LocalTrackPublished, () => { kontrolCiz(); onizle(); });
    kontrolCiz(); onizle();
    if (y.tur === 'sesli' && !resmiMi) sesliKatilimcilar(sol, room, oda, { moderator: true, sahip: true, giris: true }, []);
    const d = resmiMi ? await lv('resmi') : await lv('yayin?id=' + y.id);
    const sh = el('div'); sag.appendChild(sh);
    sohbet(sh, { oda, yetki: { ...d.yetki, moderator: true }, mesajlar: d.mesajlar, sabit: d.sabit, onIzleyici: (n) => { izEl.textContent = '👁 ' + sayi(n); } });
}
function istatistikGoster(s) {
    const kap = $('lv-icerik'); temizle(); kap.replaceChildren();
    const k = el('div', 'lv-acik max-w-2xl mx-auto rounded-3xl bg-white border border-slate-200 p-6 sm:p-8 text-center');
    k.append(el('div', 'text-5xl mb-2', '🎬'), el('h1', 'font-display font-black text-2xl text-slate-900', 'Yayın bitti'), el('p', 'text-sm text-slate-500 mb-6', s.baslik));
    const g = el('div', 'grid grid-cols-2 sm:grid-cols-3 gap-3 mb-6');
    for (const [a, v] of [['Süre', sure((s.bitis || Date.now() / 1000) - s.baslangic)], ['En çok izleyici', sayi(s.tepe)], ['Tekil izleyici', sayi(s.tekil)], ['Sohbet mesajı', sayi(s.mesaj)], ['Yeni destekçi', sayi(s.destekci)], ['Yeni takipçi', sayi(s.takipci_yeni)]]) {
        const c = el('div', 'rounded-2xl bg-slate-50 border border-slate-200 p-4'); c.append(el('div', 'font-display font-black text-2xl text-slate-900', v), el('div', 'text-[11px] font-bold uppercase text-slate-500', a)); g.appendChild(c);
    }
    k.append(g, butonla('Keşfete dön', BUTON, () => git('kesfet')));
    kap.appendChild(k);
}

// ------------------------------------------------------------ SESLİ ODALAR
async function odalarSayfasi() {
    const d = KESFET = await lv('kesfet');
    const kap = $('lv-icerik'); kap.replaceChildren();
    const ust = el('div', 'flex flex-wrap items-end justify-between gap-3 mb-6');
    ust.append(el('div', '', '')); ust.firstChild.append(el('h1', 'font-display font-black text-2xl text-slate-900', '🎧 Sesli sohbet odaları'), el('p', 'text-sm text-slate-500', 'Odaya gir, mikrofonunu aç, konuş. Oda sahipleri ve yöneticiler odayı yönetir.'));
    kap.appendChild(ust);
    if (d.ben.yayin_yetkili) {
        const f = el('form', 'lv-acik rounded-2xl bg-white border border-slate-200 p-4 mb-6 grid sm:grid-cols-[1fr_1fr_auto] gap-2');
        f.innerHTML = `<input name="baslik" required minlength="3" maxlength="80" placeholder="Oda başlığı" class="${GIRDI}"><input name="aciklama" maxlength="300" placeholder="Açıklama (isteğe bağlı)" class="${GIRDI}"><button class="${BUTON}">+ Oda aç</button>`;
        f.addEventListener('submit', async (e) => { e.preventDefault(); try { const r = await lv('oda_ac', { baslik: f.baslik.value, aciklama: f.aciklama.value }); git('oda/' + r.id); } catch (err) { bildir(err.message, false); } });
        kap.appendChild(f);
    } else kap.appendChild(el('p', 'text-xs text-slate-500 mb-6', 'Kendi odanı açmak Pro üyelere özel. Odalara herkes katılabilir.'));
    const g = el('div', 'grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4'); d.odalar.forEach(o => g.appendChild(odaKarti(o))); kap.appendChild(g);
}

async function odaSayfasi(id) {
    const d = await lv('oda?id=' + id);
    const r = d.oda;
    const kap = $('lv-icerik'); kap.replaceChildren();
    const izgara = el('div', 'grid grid-cols-1 lg:grid-cols-[minmax(0,1fr)_360px] gap-5'); kap.appendChild(izgara);
    const sol = el('div', 'min-w-0 space-y-4'), sag = el('div'); izgara.append(sol, sag);
    const bas = el('div', 'rounded-3xl p-6 text-white relative overflow-hidden'); bas.style.background = r.resmi ? 'linear-gradient(135deg,#4a0418,#0f172a)' : 'linear-gradient(135deg,#065f46,#1e3a8a)';
    const et = el('div', 'flex flex-wrap items-center gap-2 text-xs font-bold mb-1'); et.append(el('span', 'px-2 py-0.5 rounded ' + (r.durum === 'acik' ? 'bg-red-600 lv-canli' : 'bg-white/20'), r.durum === 'acik' ? '● AÇIK' : 'KAPALI'));
    if (r.resmi) et.appendChild(el('span', 'px-2 py-0.5 rounded bg-white/15', 'RESMÎ ODA'));
    bas.append(et, el('h1', 'font-display font-black text-2xl sm:text-3xl', r.baslik));
    if (r.aciklama) bas.appendChild(el('p', 'text-sm text-white/80 mt-1', r.aciklama));
    const sh_ = el('div', 'flex items-center gap-2 mt-3 text-sm'); sh_.append(document.createTextNode('Oda sahibi: '), adEl(r.sahip)); bas.appendChild(sh_);
    sol.appendChild(bas);
    if (r.durum !== 'acik') {
        sol.appendChild(bilgiKutusu('Bu oda kapalı', 'Oda sahibi odayı kapattı.', d.yetki.moderator ? 'Odayı yeniden aç' : null, () => lv('oda_kapat', { id, ac: true }).then(() => odaSayfasi(id)).catch(e => bildir(e.message, false))));
        return;
    }
    if (!hesapBen) { sol.appendChild(bilgiKutusu('Sesli odaya katılmak için giriş yap', 'Mertixtan hesabınla giriş yap; yeni hesap gerekmez.', 'Giriş yap', () => hesapPencere('giris'))); return; }
    const kontrol = el('div', 'flex flex-wrap gap-2'); sol.appendChild(kontrol);
    const sesAc = butonla('🔊 Sesi aç', 'hidden px-4 py-2.5 rounded-xl text-sm font-bold bg-amber-400 text-amber-950', async () => { await room.startAudio(); sesAc.classList.add('hidden'); });
    kontrol.appendChild(sesAc);
    const room = new LK.Room({ adaptiveStream: true, dynacast: true });
    temizlik.push(() => room.disconnect());
    room.on(LK.RoomEvent.TrackSubscribed, (t) => { if (t.kind === 'audio') { const a = t.attach(); a.className = 'hidden'; document.body.appendChild(a); temizlik.push(() => a.remove()); } });
    room.on(LK.RoomEvent.TrackUnsubscribed, (t) => t.detach().forEach(e => e.remove()));
    room.on(LK.RoomEvent.AudioPlaybackStatusChanged, () => sesAc.classList.toggle('hidden', room.canPlaybackAudio));
    room.on(LK.RoomEvent.Disconnected, (neden) => { if (neden === LK.DisconnectReason?.PARTICIPANT_REMOVED || neden === LK.DisconnectReason?.ROOM_DELETED) { bildir(neden === LK.DisconnectReason.ROOM_DELETED ? 'Oda kapatıldı' : 'Odadan çıkarıldın', false); setTimeout(() => odaSayfasi(id), 800); } });
    try {
        const { token } = await lv('token', { oda: r.oda, mod: 'ses', c: LV_ISTEMCI });
        await room.connect(WS_ADRES, token);
        sesAc.classList.toggle('hidden', room.canPlaybackAudio);
    } catch (e) { sol.appendChild(bilgiKutusu('Odaya bağlanılamadı', e.message)); return; }
    kontrol.appendChild(butonla('🚪 Odadan çık', KUCUK + ' py-2.5', () => { room.disconnect(); git('odalar'); }));
    if (d.yetki.moderator && !r.resmi || (r.resmi && d.yetki.admin)) kontrol.appendChild(butonla('⛔ Odayı kapat', KIRMIZI + ' py-2.5', () => confirm('Oda kapatılsın mı? Herkes çıkarılır.') && lv('oda_kapat', { id }).then(() => odaSayfasi(id)).catch(e => bildir(e.message, false))));
    kontrol.appendChild(paylasBtn(r.baslik, location.origin + '/#lives/oda/' + id));
    sesliKatilimcilar(sol, room, r.oda, d.yetki, [], true);
    const sh = el('div'); sag.appendChild(sh);
    sohbet(sh, { oda: r.oda, yetki: d.yetki, mesajlar: d.mesajlar, sabit: d.sabit, onDurum: (e) => { if (e.bitti) { bildir('Oda kapatıldı'); setTimeout(() => odaSayfasi(id), 800); } }, onYasak: () => room.disconnect() });
}

// ------------------------------------------------------------ LIVES PROFİLİ
async function profilSayfasi(ad) {
    const p = await lv('profil?ad=' + encodeURIComponent(ad));
    const kap = $('lv-icerik'); kap.replaceChildren();
    const bas = el('div', 'lv-acik rounded-3xl bg-white border border-slate-200 p-6 mb-6 flex flex-wrap gap-5 items-center');
    const av = el('div', 'w-20 h-20 rounded-3xl flex items-center justify-center text-white font-black text-3xl shrink-0'); av.style.background = p.kul.renk || '#10b981'; av.textContent = p.kul.ad[0].toUpperCase();
    const yz = el('div', 'flex-1 min-w-0');
    const ad_ = adEl(p.kul, false); ad_.classList.add('text-2xl'); yz.appendChild(ad_);
    const rz = el('div', 'flex flex-wrap gap-1.5 mt-2');
    if (p.kul.rozet.admin) rz.appendChild(el('span', 'px-2 py-0.5 rounded-lg text-[11px] font-black text-white', '💎 Yönetici')).style.background = 'linear-gradient(90deg,#7f0019,#e0115f)';
    if (p.kul.rozet.pro) rz.appendChild(el('span', 'px-2 py-0.5 rounded-lg text-[11px] font-black text-amber-950', '👑 Pro üye')).style.background = 'linear-gradient(90deg,#facc15,#fde68a)';
    if (p.kul.rozet.onayli) rz.appendChild(el('span', 'px-2 py-0.5 rounded-lg text-[11px] font-black bg-blue-100 text-blue-700', '✓ Onaylı'));
    yz.appendChild(rz);
    if (p.kul.biyografi) yz.appendChild(el('p', 'text-sm text-slate-600 mt-2', p.kul.biyografi));
    yz.appendChild(el('div', 'text-xs text-slate-500 mt-2', `${p.takipci} takipçi · ${p.destekci} destekçi · ${p.yayin_sayisi} yayın · katılım ${tarih(p.kul.katilim)}`));
    const bt = el('div', 'flex flex-wrap gap-2');
    if (!p.ben_miyim) {
        let t = p.takip_ediyorum, dd = p.destekliyorum;
        const tb = butonla('', '', async () => { if (girisGerek('Takip etmek')) return; try { t = (await lv('takip', { ad: p.kul.ad })).takip; tc(); } catch (e) { bildir(e.message, false); } });
        const tc = () => { tb.className = 'px-4 py-2 rounded-xl text-xs font-bold ' + (t ? 'bg-slate-100 text-slate-700' : 'bg-red-600 text-white'); tb.textContent = t ? '✓ Takip ediliyor' : '+ Takip et'; }; tc();
        const db_ = butonla('', '', async () => { if (girisGerek('Desteklemek')) return; try { dd = (await lv('destek', { ad: p.kul.ad })).destek; dc(); } catch (e) { bildir(e.message, false); } });
        const dc = () => { db_.className = 'px-4 py-2 rounded-xl text-xs font-bold ' + (dd ? 'bg-primary-100 text-primary-700' : 'bg-gradient-to-r from-primary-500 to-accent-600 text-white'); db_.textContent = dd ? '💚 Destekliyorsun' : '💚 Destekliyoruz'; }; dc();
        bt.append(tb, db_);
        if (hesapBen) bt.appendChild(butonla('⚑', KUCUK + ' py-2', () => { const n = prompt('Bu kullanıcıyı neden raporluyorsun?'); if (n) lv('rapor', { hedef_tur: 'kullanici', hedef_id: p.kul.id, neden: n }).then(() => bildir('Rapor iletildi')).catch(e => bildir(e.message, false)); }));
    } else bt.appendChild(butonla('🎥 Yayın aç', BUTON, () => git('yayinla')));
    bas.append(av, yz, bt); kap.appendChild(bas);
    kap.appendChild(bolum('Aktif yayın', 'fa-solid fa-circle text-red-500 lv-canli text-xs', p.aktif ? [yayinKarti(p.aktif, true)] : [], 'Şu an yayında değil.'));
    const gecmis = el('section', 'mb-10'); gecmis.appendChild(el('h2', 'font-display font-black text-xl text-slate-900 mb-4', '🕘 Yayın geçmişi'));
    if (!p.gecmis.length) gecmis.appendChild(el('p', 'text-sm text-slate-400', 'Henüz bitmiş yayın yok.'));
    const tb = el('div', 'lv-acik rounded-2xl bg-white border border-slate-200 divide-y divide-slate-100');
    for (const y of p.gecmis) {
        const s = butonla('', 'w-full text-left px-4 py-3 flex flex-wrap gap-2 justify-between items-center hover:bg-slate-50', () => git('y/' + y.id));
        const a = el('div', 'min-w-0'); a.append(el('div', 'font-bold text-sm text-slate-900 truncate', y.baslik), el('div', 'text-xs text-slate-500', `${tarih(y.baslangic)} · ${y.kategori} · ${sure((y.bitis || y.baslangic) - y.baslangic)}`));
        s.append(a, el('div', 'text-xs font-bold text-slate-600', `👁 en çok ${y.tepe} · ${y.tekil} tekil · 💬 ${y.mesaj}`));
        tb.appendChild(s);
    }
    if (p.gecmis.length) gecmis.appendChild(tb);
    kap.appendChild(gecmis);
}

// ------------------------------------------------------------ YÖNETİM (sadece yönetici; sunucu ayrıca denetler)
async function yonetimSayfasi(sekme) {
    const kap = $('lv-icerik');
    if (!hesapBen?.yonetici) { kap.replaceChildren(bilgiKutusu('Yetkin yok', 'Bu alan yöneticilere özel.')); return; }
    const gun = sessionStorage.getItem('lv_ygun') || bugun();
    const d = await lv('yonetim?gun=' + gun);
    kap.replaceChildren();
    const sk = el('div', 'flex flex-wrap gap-2 mb-6');
    const ss = [['program', '📅 Program'], ['icerik', '🎬 Film & Dizi'], ['kanal', '📡 Resmî kanal'], ['yayinlar', '🎥 Yayınlar'], ['moderasyon', '🛡 Moderasyon'], ['raporlar', `⚑ Raporlar${d.istatistik.yeni_rapor ? ' (' + d.istatistik.yeni_rapor + ')' : ''}`], ['yayincilar', '🎙 Yayıncılar'], ['istatistik', '📊 İstatistik']];
    for (const [s, a] of ss) sk.appendChild(butonla(a, 'px-3.5 py-2 rounded-xl text-xs font-bold border ' + (s === sekme ? 'bg-slate-900 text-white border-slate-900' : 'bg-white text-slate-600 border-slate-200'), () => git('yonetim/' + s)));
    kap.appendChild(sk);
    const k = el('div', 'space-y-5'); kap.appendChild(k);
    const kart = (baslik) => { const c = el('div', 'lv-acik rounded-2xl bg-white border border-slate-200 p-5'); if (baslik) c.appendChild(el('h2', 'font-display font-black text-lg text-slate-900 mb-3', baslik)); k.appendChild(c); return c; };
    const yenile = () => yonetimSayfasi(sekme);
    const islem = (yol, veri, msg) => lv(yol, veri).then(() => { bildir(msg || 'Kaydedildi ✓'); yenile(); }).catch(e => bildir(e.message, false));

    if (sekme === 'program') {
        const c = kart('📅 Günlük yayın programı');
        const ust = el('div', 'flex flex-wrap gap-2 items-center mb-4');
        const g = el('input', 'rounded-xl border border-slate-200 px-3 py-2 text-sm'); g.type = 'date'; g.value = d.gun; g.onchange = () => { sessionStorage.setItem('lv_ygun', g.value); yenile(); };
        ust.append(g, butonla('Bu günü yarına kopyala', KUCUK + ' py-2', () => { const y = new Date(d.gun + 'T12:00:00'); y.setDate(y.getDate() + 1); islem('yonetim_program_kopyala', { kaynak_gun: d.gun, hedef_gun: y.toISOString().slice(0, 10) }, 'Kopyalandı'); }));
        c.appendChild(ust);
        if (!d.program.length) c.appendChild(el('p', 'text-sm text-amber-700 bg-amber-50 rounded-xl px-4 py-3 mb-3', 'Bu gün için program yok: kanal o gün NO SIGNAL gösterecek.'));
        for (const p of d.program) {
            const s = el('div', 'flex flex-wrap items-center gap-3 py-2 border-t border-slate-100');
            s.append(el('span', 'text-sm font-black w-28', `${saat(p.baslangic)}–${saat(p.bitis)}`), el('span', 'flex-1 min-w-[150px] text-sm font-bold', p.baslik + (p.icerik ? ` (${p.icerik.ad})` : '')),
                el('span', 'text-[10px] font-black px-1.5 py-0.5 rounded ' + (p.durum === 'yayinda' ? 'bg-red-600 text-white' : 'bg-slate-100'), p.durum.toUpperCase()));
            s.append(butonla('Düzenle', KUCUK, () => progForm(p)), butonla('Sil', KIRMIZI, () => confirm('Silinsin mi?') && islem('yonetim_program', { sil: p.id }, 'Silindi')));
            c.appendChild(s);
        }
        const fk = el('div', 'mt-4'); c.appendChild(fk);
        const progForm = (p) => {
            fk.replaceChildren();
            const f = el('form', 'grid sm:grid-cols-2 gap-3 rounded-2xl bg-slate-50 border border-slate-200 p-4');
            f.innerHTML = `<label class="text-xs font-bold text-slate-500">Yayın adı<input name="baslik" required class="${GIRDI} mt-1"></label>
                <label class="text-xs font-bold text-slate-500">Film / dizi / program<select name="icerik_id" class="${GIRDI} mt-1"><option value="">— içeriksiz (sadece bilgi ekranı) —</option></select></label>
                <label class="text-xs font-bold text-slate-500">Başlangıç (TR saati)<input name="baslangic" type="datetime-local" required class="${GIRDI} mt-1"></label>
                <label class="text-xs font-bold text-slate-500">Bitiş<input name="bitis" type="datetime-local" required class="${GIRDI} mt-1"></label>
                <label class="text-xs font-bold text-slate-500 sm:col-span-2">Açıklama<input name="aciklama" maxlength="500" class="${GIRDI} mt-1"></label>
                <button class="${BUTON} sm:col-span-2">${p ? 'Kaydet' : '+ Programa ekle'}</button>`;
            for (const i of d.icerikler) { const o = el('option', '', `${i.ad} (${i.tur})`); o.value = i.id; f.icerik_id.appendChild(o); }
            const varsay = p ? null : (d.program.length ? d.program[d.program.length - 1].bitis : Math.ceil(Date.now() / 1000 / 1800) * 1800);
            f.baslik.value = p?.baslik || ''; f.aciklama.value = p?.aciklama || ''; f.icerik_id.value = p?.icerik?.id || '';
            f.baslangic.value = yerelZaman(p ? p.baslangic : varsay); f.bitis.value = yerelZaman(p ? p.bitis : varsay + 3600);
            f.icerik_id.onchange = () => { if (!f.baslik.value) f.baslik.value = f.icerik_id.selectedOptions[0].textContent.replace(/ \(\w+\)$/, ''); };
            f.addEventListener('submit', (e) => { e.preventDefault(); islem('yonetim_program', { id: p?.id, baslik: f.baslik.value, aciklama: f.aciklama.value, icerik_id: f.icerik_id.value, baslangic: f.baslangic.value, bitis: f.bitis.value }); });
            fk.appendChild(f);
        };
        progForm(null);
    }
    if (sekme === 'icerik') {
        const c = kart('🎬 Film, dizi ve program kütüphanesi');
        c.appendChild(el('p', 'text-xs text-slate-500 mb-3', 'Kaynak: https ile başlayan .mp4 / .webm / .m3u8 (HLS) bağlantısı ya da YouTube linki. Yalnızca yayın hakkına sahip olduğun içerikleri ekle.'));
        const fk = el('div', 'mb-4'); c.appendChild(fk);
        const icForm = (i) => {
            fk.replaceChildren();
            const f = el('form', 'grid sm:grid-cols-2 gap-3 rounded-2xl bg-slate-50 border border-slate-200 p-4');
            f.innerHTML = `<label class="text-xs font-bold text-slate-500">Ad<input name="ad" required class="${GIRDI} mt-1"></label>
                <label class="text-xs font-bold text-slate-500">Tür<select name="tur" class="${GIRDI} mt-1"><option value="film">Film</option><option value="dizi">Dizi</option><option value="program">Program</option><option value="diger">Diğer</option></select></label>
                <label class="text-xs font-bold text-slate-500 sm:col-span-2">Video kaynağı<input name="kaynak" placeholder="https://…" class="${GIRDI} mt-1"></label>
                <label class="text-xs font-bold text-slate-500 sm:col-span-2">Açıklama<textarea name="aciklama" rows="2" class="${GIRDI} mt-1"></textarea></label>
                <button class="${BUTON} sm:col-span-2">${i ? 'Kaydet' : '+ Kütüphaneye ekle'}</button>`;
            f.ad.value = i?.ad || ''; f.tur.value = i?.tur || 'film'; f.kaynak.value = i?.kaynak || ''; f.aciklama.value = i?.aciklama || '';
            f.addEventListener('submit', (e) => { e.preventDefault(); islem('yonetim_icerik', { id: i?.id, ad: f.ad.value, tur: f.tur.value, kaynak: f.kaynak.value, aciklama: f.aciklama.value }); });
            fk.appendChild(f);
        };
        icForm(null);
        if (!d.icerikler.length) c.appendChild(el('p', 'text-sm text-slate-400', 'Kütüphane boş.'));
        for (const i of d.icerikler) {
            const s = el('div', 'py-3 border-t border-slate-100');
            const u = el('div', 'flex flex-wrap items-center gap-2'); u.append(el('span', 'font-bold text-sm flex-1 min-w-[150px]', `${i.ad} · ${i.tur}`),
                el('span', 'text-xs font-bold text-slate-600', i.puan.ortalama ? `★ ${i.puan.ortalama.toFixed(2)} · ${i.puan.oy} oy` : 'oy yok'),
                butonla('Düzenle', KUCUK, () => icForm(i)), butonla('Sil', KIRMIZI, () => confirm('Silinsin mi?') && islem('yonetim_icerik', { sil: i.id }, 'Silindi')));
            s.appendChild(u);
            const top = Math.max(1, ...i.puanlar);
            const gr = el('div', 'flex items-end gap-1 h-10 mt-2');
            i.puanlar.forEach((n, x) => { const b = el('div', 'flex-1 flex flex-col items-center justify-end h-full'); const cub = el('div', 'w-full rounded-t bg-amber-400'); cub.style.height = Math.max(2, n / top * 100) + '%'; b.append(cub, el('span', 'text-[9px] text-slate-400', `${x + 1}★ ${n}`)); gr.appendChild(b); });
            s.appendChild(gr);
            c.appendChild(s);
        }
    }
    if (sekme === 'kanal') {
        const r = d.durum;
        const c = kart('📡 Mertixtan Studios Live');
        c.appendChild(el('p', 'text-sm mb-3', `Şu an: ${{ nosignal: 'NO SIGNAL', program: 'Program yayında: ' + (r.simdi?.baslik || ''), canli: 'Canlı yayın: ' + (r.canli?.baslik || '') }[r.mod]} · 👁 ${r.izleyici}`));
        const bt = el('div', 'flex flex-wrap gap-2 mb-4');
        if (r.canli) bt.appendChild(butonla('⏹ Canlı yayını bitir', KIRMIZI + ' py-2.5', () => confirm('Resmî canlı yayın bitirilsin mi?') && islem('yayin_bitir', { id: r.canli.id }, 'Bitirildi')));
        else bt.appendChild(butonla('📡 Canlıya geç (kamera/ekran)', BUTON, () => git('yayinla/resmi')));
        bt.appendChild(butonla(d.kanal.kapali ? '▶ Kanalı aç (NO SIGNAL kaldır)' : '⏸ Kanalı NO SIGNAL\'e al', KUCUK + ' py-2.5', () => islem('yonetim_kanal', { kapali: !d.kanal.kapali })));
        bt.appendChild(butonla('İzleyici gözüyle aç', KUCUK + ' py-2.5', () => git('resmi')));
        c.appendChild(bt);
        const f = el('form', 'grid sm:grid-cols-2 gap-3');
        f.innerHTML = `<label class="text-xs font-bold text-slate-500">NO SIGNAL mesajı<input name="nosignal" maxlength="200" class="${GIRDI} mt-1" placeholder="Şu an yayın ya da geçerli program yok."></label>
            <label class="text-xs font-bold text-slate-500">Kanal teması<select name="tema" class="${GIRDI} mt-1"></select></label><button class="${BUTON} sm:col-span-2">Kaydet</button>`;
        for (const [t, a] of Object.entries(TEMA_ADI)) { const o = el('option', '', a); o.value = t; f.tema.appendChild(o); }
        f.nosignal.value = d.kanal.nosignal; f.tema.value = d.kanal.tema;
        f.addEventListener('submit', (e) => { e.preventDefault(); islem('yonetim_kanal', { nosignal: f.nosignal.value, tema: f.tema.value }); });
        c.appendChild(f);
    }
    if (sekme === 'yayinlar') {
        const c = kart(`🎥 Aktif yayınlar (${d.aktif.length})`);
        if (!d.aktif.length) c.appendChild(el('p', 'text-sm text-slate-400', 'Açık yayın yok.'));
        for (const y of d.aktif) {
            const s = el('div', 'flex flex-wrap items-center gap-2 py-2 border-t border-slate-100');
            const a = el('div', 'flex-1 min-w-[180px]'); a.append(el('div', 'font-bold text-sm', y.baslik), adEl(y.yayinci));
            s.append(a, el('span', 'text-xs font-bold', `👁 ${y.izleyici}`), butonla(y.one_cikan ? '★ Öne çıkan' : '☆ Öne çıkar', KUCUK, () => islem('yonetim_one_cikar', { id: y.id, one_cikan: !y.one_cikan })),
                butonla('İzle', KUCUK, () => git(y.resmi ? 'resmi' : 'y/' + y.id)), butonla('Bitir', KIRMIZI, () => confirm('Bitirilsin mi?') && islem('yayin_bitir', { id: y.id }, 'Bitirildi')));
            c.appendChild(s);
        }
        const g = kart('Geçmiş yayınlar');
        for (const y of d.gecmis) { const s = el('div', 'flex flex-wrap gap-2 justify-between py-2 border-t border-slate-100 text-sm'); s.append(el('span', 'font-semibold', `${y.baslik} · ${y.yayinci.ad}`), el('span', 'text-xs text-slate-500', `${tarih(y.baslangic)} · en çok ${y.tepe} · ${y.tekil} tekil · ${y.mesaj} mesaj`)); g.appendChild(s); }
        const o = kart('🎧 Sesli odalar');
        for (const r of d.odalar) { const s = el('div', 'flex flex-wrap gap-2 items-center py-2 border-t border-slate-100 text-sm'); s.append(el('span', 'flex-1 font-semibold', `${r.baslik} · ${r.sahip.ad} · ${r.durum}`), butonla('Aç', KUCUK, () => git('oda/' + r.id))); if (r.durum === 'acik' && !r.resmi) s.appendChild(butonla('Kapat', KIRMIZI, () => islem('oda_kapat', { id: r.id }, 'Kapatıldı'))); o.appendChild(s); }
    }
    if (sekme === 'moderasyon') {
        const c = kart('🚫 Bütün Lives\'tan yasakla');
        const f = el('form', 'grid sm:grid-cols-[1fr_140px_1fr_auto] gap-2');
        f.innerHTML = `<input name="ad" required placeholder="Kullanıcı adı" class="${GIRDI}"><input name="gun" type="number" min="0" placeholder="Gün (boş=kalıcı)" class="${GIRDI}"><input name="neden" placeholder="Neden" class="${GIRDI}"><button class="${BUTON}">Yasakla</button>`;
        f.addEventListener('submit', async (e) => { e.preventDefault(); try { const p = await lv('profil?ad=' + encodeURIComponent(f.ad.value)); islem('moderasyon', { oda: '*', kid: p.kul.id, islem: 'yasak', dakika: f.gun.value ? Math.round(+f.gun.value * 1440) : null, neden: f.neden.value }, 'Yasaklandı'); } catch (err) { bildir(err.message, false); } });
        c.appendChild(f);
        const l = kart(`Aktif kısıtlamalar (${d.yasaklar.length})`);
        if (!d.yasaklar.length) l.appendChild(el('p', 'text-sm text-slate-400', 'Aktif kısıtlama yok.'));
        for (const y of d.yasaklar) {
            const s = el('div', 'flex flex-wrap items-center gap-2 py-2 border-t border-slate-100 text-sm');
            s.append(el('span', 'flex-1 min-w-[200px]', `${y.ad} · ${{ sustur: 'susturma', uzaklastir: 'uzaklaştırma', yasak: 'yasak' }[y.tur]} · ${y.oda === '*' ? 'tüm Lives' : y.oda} · ${y.bitis ? new Date(y.bitis * 1000).toLocaleString('tr-TR') + "'e kadar" : 'kalıcı'} · veren: ${y.veren_ad}${y.neden ? ' · ' + y.neden : ''}`),
                butonla('Kaldır', KUCUK, () => islem('moderasyon', { oda: y.oda, kid: y.kid, islem: 'kaldir' }, 'Kaldırıldı')));
            l.appendChild(s);
        }
    }
    if (sekme === 'raporlar') {
        const c = kart('⚑ Kullanıcı raporları');
        if (!d.raporlar.length) c.appendChild(el('p', 'text-sm text-slate-400', 'Rapor yok.'));
        for (const r of d.raporlar) {
            const s = el('div', 'py-3 border-t border-slate-100 text-sm ' + (r.durum !== 'yeni' ? 'opacity-60' : ''));
            s.append(el('div', 'font-bold', `${r.durum === 'yeni' ? '● ' : ''}${r.ayrinti}`), el('div', 'text-xs text-slate-500', `Bildiren: ${r.bildiren} · ${tarih(r.tarih)} · Neden: ${r.neden}`));
            const bt = el('div', 'flex flex-wrap gap-2 mt-2');
            bt.append(butonla('İncelendi', KUCUK, () => islem('yonetim_rapor', { id: r.id, durum: 'incelendi' })), butonla('İşlem yapıldı', KUCUK, () => islem('yonetim_rapor', { id: r.id, durum: 'islem' })));
            if (r.hedef_tur === 'yayin') bt.appendChild(butonla('Yayına git', KUCUK, () => git('y/' + r.hedef_id)));
            if (r.hedef_kid) bt.appendChild(butonla('Yazanı 1 gün yasakla', KIRMIZI, () => islem('moderasyon', { oda: '*', kid: r.hedef_kid, islem: 'yasak', dakika: 1440, neden: 'Rapor: ' + r.neden }, 'Yasaklandı')));
            s.appendChild(bt); c.appendChild(s);
        }
    }
    if (sekme === 'yayincilar') {
        const c = kart('🎙 Yayıncı yetkisi');
        c.appendChild(el('p', 'text-xs text-slate-500 mb-3', 'Pro üyeler zaten yayın açabilir. Buradan Pro olmayan kullanıcılara da yayın/oda açma yetkisi verebilirsin.'));
        const f = el('form', 'flex gap-2 mb-4'); f.innerHTML = `<input name="ad" required placeholder="Kullanıcı adı" class="${GIRDI}"><button class="${BUTON}">Yetki ver</button>`;
        f.addEventListener('submit', (e) => { e.preventDefault(); islem('yonetim_yayinci', { ad: f.ad.value, ver: true }, 'Yetki verildi'); });
        c.appendChild(f);
        for (const u of d.yayincilar) { const s = el('div', 'flex items-center gap-2 py-2 border-t border-slate-100'); s.append(adEl(u)); s.appendChild(el('span', 'flex-1')); s.appendChild(butonla('Yetkiyi al', KIRMIZI, () => islem('yonetim_yayinci', { ad: u.ad, ver: false }, 'Yetki alındı'))); c.appendChild(s); }
    }
    if (sekme === 'istatistik') {
        const s = d.istatistik; const c = kart('📊 Lives istatistikleri');
        const g = el('div', 'grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3');
        for (const [a, v] of [['Toplam yayın', s.toplam_yayin], ['Şu an canlı', s.canli], ['Toplam tekil izleyici', s.toplam_izleyici], ['En yüksek eşzamanlı', s.en_cok], ['Sohbet mesajı', s.mesaj], ['Yayıncı', s.yayinci], ['Verilen puan', s.puan], ['Resmî kanal şu an', s.resmi_izleyici], ['Yeni rapor', s.yeni_rapor]]) {
            const x = el('div', 'rounded-2xl bg-slate-50 border border-slate-200 p-4'); x.append(el('div', 'font-display font-black text-2xl', sayi(v)), el('div', 'text-[11px] font-bold uppercase text-slate-500', a)); g.appendChild(x);
        }
        c.appendChild(g);
        const p = kart('⭐ Puan istatistikleri');
        const l = [...d.icerikler].sort((a, b) => (b.puan.ortalama || 0) - (a.puan.ortalama || 0));
        if (!l.length) p.appendChild(el('p', 'text-sm text-slate-400', 'İçerik yok.'));
        for (const i of l) { const s = el('div', 'flex justify-between py-2 border-t border-slate-100 text-sm'); s.append(el('span', 'font-semibold', `${i.ad} (${i.tur})`), el('span', 'font-bold', i.puan.ortalama ? `★ ${i.puan.ortalama.toFixed(2)} · ${i.puan.oy} oy` : '—')); p.appendChild(s); }
    }
}

// ------------------------------------------------------------ başlangıç
try { if (localStorage.getItem('lv_sinema') === '1') document.documentElement.classList.add('lv-sinema'); } catch (e) {}
kur();
window.openLives = (r) => git(r || '');
// profil sayfasına "Lives profilim" bağlantısı
const prBtn = document.getElementById('pr-yonetici');
if (prBtn) { const b = el('button', KUCUK); b.type = 'button'; b.append(ikon('fa-solid fa-tower-broadcast'), document.createTextNode(' Lives profilim')); b.onclick = () => hesapBen && git('u/' + encodeURIComponent(hesapBen.ad)); prBtn.after(b); }
})();
