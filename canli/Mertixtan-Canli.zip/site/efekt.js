// Mertixtan Lives kamera efekt motoru.
// Kamera → (arka plan ayırma) → renk filtresi → 2D yüz efektleri → 3D yüz efektleri → tuval → yayın görüntüsü.
// Yüz takibi: MediaPipe Face Landmarker (478 nokta), arka plan: MediaPipe Selfie Segmenter (Tasks Vision). İkisi de /vendor altında, sunucumuzdan yüklenir.
// Modeller sadece o tür bir efekt seçilince yüklenir; efekt yoksa kamera görüntüsü olduğu gibi geçer.
(function () {
'use strict';
const DOKUNMA = matchMedia('(pointer: coarse)').matches;
const UZUN_KENAR = DOKUNMA ? 960 : 1280;

// MediaPipe Tasks Vision: tek WASM çalışma zamanı, yüz ve arka plan aynı anda güvenle çalışır
let vizyonSoz = null;
function vizyon() {
    if (!vizyonSoz) vizyonSoz = (async () => {
        const mod = await import('/vendor/mediapipe/vision_bundle.js');
        const dosyalar = await mod.FilesetResolver.forVisionTasks('/vendor/mediapipe/wasm');
        return { mod, dosyalar };
    })().catch(e => { vizyonSoz = null; throw e; });
    return vizyonSoz;
}

// ------------------------------------------------------------ efekt listeleri (arayüz bunları gösterir)
const FILTRELER = {
    yok: ['Yok', 'none'], sb: ['Siyah-beyaz', 'grayscale(1)'], sepya: ['Sepya', 'sepia(0.9)'], canli: ['Canlı', 'saturate(1.8) contrast(1.05)'],
    soguk: ['Soğuk', 'saturate(1.2) hue-rotate(-18deg) brightness(1.02)'], sicak: ['Sıcak', 'sepia(0.35) saturate(1.5) brightness(1.05)'],
    sinema: ['Sinema', 'contrast(1.35) saturate(0.85) brightness(0.92)'], vintage: ['Vintage', 'sepia(0.5) contrast(0.9) brightness(1.1) saturate(0.8)'], negatif: ['Negatif', 'invert(1)']
};
const YUZ2D = { yok: 'Yok', gozluk: '😎 Gözlük', sapka: '🥳 Parti şapkası', kedi: '🐱 Kedi', tavsan: '🐰 Tavşan', kopek: '🐶 Köpek (ağzını aç)', emoji: '😜 Emoji kafa', kalp: '😍 Kalp gözler', palyaco: '🤡 Palyaço burnu', devgoz: '👀 Dev gözler' };
const YUZ3D = { yok: 'Yok', biyik: '🥸 3D bıyık', sakal: '🧔 3D sakal', gozluk3d: '🕶 3D gözlük', tac: '👑 3D taç', boynuz: '😈 3D boynuz', ates: '🔥 Ağzını aç: ateş', kalpler: '💞 Dönen kalpler' };
const ARKA = { yok: 'Yok', bulanik: '🌫 Bulanık', plaj: '🏖 Plaj', uzay: '🌌 Uzay', sehir: '🌃 Gece şehri', orman: '🌲 Orman', studyo: '🎙 Stüdyo', resim: '🖼 Kendi resmin' };

// ------------------------------------------------------------ sanal manzaralar (prosedürel, dışarıdan görsel yok)
function manzara(ad, w, h) {
    const c = document.createElement('canvas'); c.width = w; c.height = h; const x = c.getContext('2d');
    const dg = (renkler, y0 = 0, y1 = h) => { const g = x.createLinearGradient(0, y0, 0, y1); renkler.forEach((r, i) => g.addColorStop(i / (renkler.length - 1), r)); return g; };
    if (ad === 'plaj') {
        x.fillStyle = dg(['#38bdf8', '#bae6fd']); x.fillRect(0, 0, w, h);
        x.fillStyle = '#fde047'; x.beginPath(); x.arc(w * 0.8, h * 0.2, h * 0.09, 0, 7); x.fill();
        x.fillStyle = dg(['#0284c7', '#0ea5e9'], h * 0.55, h * 0.72); x.fillRect(0, h * 0.55, w, h * 0.17);
        x.fillStyle = dg(['#fde68a', '#fbbf24'], h * 0.7, h); x.fillRect(0, h * 0.7, w, h * 0.3);
        x.strokeStyle = 'rgba(255,255,255,.6)'; x.lineWidth = 3; for (let i = 0; i < 6; i++) { x.beginPath(); x.moveTo(w * i / 6, h * 0.62); x.quadraticCurveTo(w * (i + 0.5) / 6, h * 0.6, w * (i + 1) / 6, h * 0.62); x.stroke(); }
        x.fillStyle = '#78350f'; x.fillRect(w * 0.1, h * 0.35, w * 0.015, h * 0.4); x.fillStyle = '#15803d'; for (let i = 0; i < 5; i++) { x.save(); x.translate(w * 0.108, h * 0.36); x.rotate(-1.2 + i * 0.6); x.beginPath(); x.ellipse(w * 0.06, 0, w * 0.07, h * 0.02, 0, 0, 7); x.fill(); x.restore(); }
    } else if (ad === 'uzay') {
        x.fillStyle = dg(['#020617', '#1e1b4b', '#0f172a']); x.fillRect(0, 0, w, h);
        for (let i = 0; i < 260; i++) { x.fillStyle = `rgba(255,255,255,${Math.random() * 0.9 + 0.1})`; x.fillRect(Math.random() * w, Math.random() * h, Math.random() * 2 + 0.5, Math.random() * 2 + 0.5); }
        const g = x.createRadialGradient(w * 0.75, h * 0.3, 0, w * 0.75, h * 0.3, h * 0.25); g.addColorStop(0, '#f472b6'); g.addColorStop(0.5, '#7c3aed55'); g.addColorStop(1, '#0000'); x.fillStyle = g; x.fillRect(0, 0, w, h);
        x.fillStyle = '#f59e0b'; x.beginPath(); x.arc(w * 0.18, h * 0.75, h * 0.12, 0, 7); x.fill(); x.strokeStyle = '#fde68a'; x.lineWidth = 4; x.beginPath(); x.ellipse(w * 0.18, h * 0.75, h * 0.22, h * 0.05, -0.3, 0, 7); x.stroke();
    } else if (ad === 'sehir') {
        x.fillStyle = dg(['#0b1023', '#312e81', '#7c3aed']); x.fillRect(0, 0, w, h);
        x.fillStyle = '#fef9c3'; x.beginPath(); x.arc(w * 0.85, h * 0.15, h * 0.06, 0, 7); x.fill();
        let bx = 0; while (bx < w) { const bw = w * (0.05 + Math.random() * 0.07), bh = h * (0.25 + Math.random() * 0.45); x.fillStyle = '#0f172a'; x.fillRect(bx, h - bh, bw, bh);
            for (let wy = h - bh + 10; wy < h - 10; wy += 18) for (let wx = bx + 6; wx < bx + bw - 8; wx += 14) if (Math.random() < 0.45) { x.fillStyle = Math.random() < 0.8 ? '#fde68a' : '#93c5fd'; x.fillRect(wx, wy, 6, 9); }
            bx += bw + 3; }
    } else if (ad === 'orman') {
        x.fillStyle = dg(['#bbf7d0', '#86efac', '#166534']); x.fillRect(0, 0, w, h);
        for (let k = 0; k < 3; k++) for (let i = 0; i < 14; i++) { const tx = Math.random() * w, th = h * (0.3 + k * 0.15 + Math.random() * 0.15); x.fillStyle = ['#4d7c0f', '#15803d', '#14532d'][k]; x.beginPath(); x.moveTo(tx, h - th); x.lineTo(tx - th * 0.25, h); x.lineTo(tx + th * 0.25, h); x.fill(); }
        x.fillStyle = 'rgba(255,255,200,.15)'; for (let i = 0; i < 5; i++) { x.beginPath(); x.moveTo(w * (0.2 + i * 0.15), 0); x.lineTo(w * (0.15 + i * 0.15), h); x.lineTo(w * (0.25 + i * 0.15), h); x.fill(); }
    } else {  // stüdyo
        const g = x.createRadialGradient(w / 2, h * 0.4, 0, w / 2, h * 0.4, w * 0.7); g.addColorStop(0, '#334155'); g.addColorStop(1, '#020617'); x.fillStyle = g; x.fillRect(0, 0, w, h);
        x.fillStyle = 'rgba(16,185,129,.25)'; x.font = `900 ${Math.round(h * 0.12)}px Outfit, Inter, sans-serif`; x.textAlign = 'center'; x.fillText('MERTIXTAN', w / 2, h * 0.25);
        for (let i = 0; i < 7; i++) { x.fillStyle = `hsla(${150 + i * 25},80%,60%,.18)`; x.fillRect(w * i / 7, h * 0.82, w / 7 - 6, h * 0.18); }
    }
    return c;
}

// ------------------------------------------------------------ 3D sahne (Three.js) — yüze oturan modeller
function uc(W, H) {
    const T = window.THREE; if (!T) return null;
    const tuval = document.createElement('canvas'); tuval.width = W; tuval.height = H;
    const r = new T.WebGLRenderer({ canvas: tuval, alpha: true, antialias: !DOKUNMA, preserveDrawingBuffer: true }); r.setSize(W, H, false); r.setClearColor(0, 0);
    const sahne = new T.Scene(); const kam = new T.OrthographicCamera(0, W, 0, -H, -5000, 5000); kam.position.z = 1000;
    sahne.add(new T.AmbientLight('#ffffff', 0.55)); const g = new T.DirectionalLight('#ffffff', 0.85); g.position.set(0.3, 0.6, 1); sahne.add(g);
    const kok = new T.Group(); sahne.add(kok);
    const m = (renk, extra) => new T.MeshStandardMaterial({ color: renk, roughness: 0.55, metalness: 0.15, ...(extra || {}) });
    const modeller = {
        biyik: () => { const gr = new T.Group(); for (const s of [-1, 1]) { const e = new T.CatmullRomCurve3([new T.Vector3(0, 0, 0.1), new T.Vector3(s * 0.12, -0.02, 0.1), new T.Vector3(s * 0.24, 0.0, 0.06), new T.Vector3(s * 0.32, 0.07, 0.0)]); gr.add(new T.Mesh(new T.TubeGeometry(e, 20, 0.045, 8, false), m('#3b2416'))); } return gr; },
        sakal: () => { const gr = new T.Group(); const s = new T.Mesh(new T.TorusGeometry(0.34, 0.11, 10, 24, Math.PI), m('#3b2416')); s.rotation.z = Math.PI; s.position.y = 0.08; gr.add(s); const k = new T.Mesh(new T.ConeGeometry(0.13, 0.32, 12), m('#3b2416')); k.rotation.z = Math.PI; k.position.y = -0.36; gr.add(k); for (const s2 of [-1, 1]) { const b = new T.Mesh(new T.TubeGeometry(new T.CatmullRomCurve3([new T.Vector3(0, 0.38, 0.1), new T.Vector3(s2 * 0.14, 0.36, 0.1), new T.Vector3(s2 * 0.26, 0.3, 0.06)]), 12, 0.035, 6, false), m('#3b2416')); gr.add(b); } return gr; },
        gozluk3d: () => { const gr = new T.Group(); for (const s of [-1, 1]) { const c = new T.Mesh(new T.TorusGeometry(0.17, 0.025, 8, 28), m('#0f172a', { metalness: 0.6 })); c.position.x = s * 0.22; gr.add(c); const l = new T.Mesh(new T.CircleGeometry(0.16, 28), new T.MeshStandardMaterial({ color: '#0ea5e9', transparent: true, opacity: 0.55, metalness: 0.8, roughness: 0.1 })); l.position.set(s * 0.22, 0, -0.005); gr.add(l); const sap = new T.Mesh(new T.BoxGeometry(0.03, 0.03, 0.5), m('#0f172a')); sap.position.set(s * 0.39, 0.02, -0.25); gr.add(sap); } const k = new T.Mesh(new T.TorusGeometry(0.06, 0.018, 6, 12, Math.PI), m('#0f172a')); k.position.y = 0.02; gr.add(k); return gr; },
        tac: () => { const gr = new T.Group(); const alt = new T.Mesh(new T.CylinderGeometry(0.42, 0.38, 0.14, 24, 1, true), m('#facc15', { metalness: 0.9, roughness: 0.25, side: T.DoubleSide })); gr.add(alt); for (let i = 0; i < 8; i++) { const a = i / 8 * Math.PI * 2; const u = new T.Mesh(new T.ConeGeometry(0.07, 0.22, 4), m('#facc15', { metalness: 0.9, roughness: 0.25 })); u.position.set(Math.cos(a) * 0.4, 0.17, Math.sin(a) * 0.4); gr.add(u); const t = new T.Mesh(new T.SphereGeometry(0.035, 8, 6), m(i % 2 ? '#e11d48' : '#2563eb', { metalness: 0.3, roughness: 0.1 })); t.position.set(Math.cos(a) * 0.41, 0.0, Math.sin(a) * 0.41); gr.add(t); } return gr; },
        boynuz: () => { const gr = new T.Group(); for (const s of [-1, 1]) { const b = new T.Mesh(new T.ConeGeometry(0.09, 0.42, 14), m('#b91c1c', { roughness: 0.35 })); b.position.set(s * 0.26, 0.18, 0); b.rotation.z = -s * 0.45; gr.add(b); } return gr; },
        kalpler: () => { const gr = new T.Group(); const sh = new T.Shape(); sh.moveTo(0, 0.25); sh.bezierCurveTo(0, 0.3, -0.05, 0.38, -0.15, 0.38); sh.bezierCurveTo(-0.3, 0.38, -0.3, 0.2, -0.3, 0.2); sh.bezierCurveTo(-0.3, 0.1, -0.2, 0, 0, -0.12); sh.bezierCurveTo(0.2, 0, 0.3, 0.1, 0.3, 0.2); sh.bezierCurveTo(0.3, 0.2, 0.3, 0.38, 0.15, 0.38); sh.bezierCurveTo(0.05, 0.38, 0, 0.3, 0, 0.25);
            const geo = new T.ExtrudeGeometry(sh, { depth: 0.08, bevelEnabled: true, bevelThickness: 0.02, bevelSize: 0.02, bevelSegments: 2 }); geo.center();
            for (let i = 0; i < 6; i++) { const k = new T.Mesh(geo, m(['#e11d48', '#f43f5e', '#ec4899'][i % 3], { roughness: 0.3 })); k.scale.setScalar(0.32); k.userData.a = i / 6 * Math.PI * 2; gr.add(k); } gr.userData.don = true; return gr; },
        ates: () => { const gr = new T.Group(); gr.userData.parca = []; gr.userData.ates = true; return gr; },
    };
    let aktif = null, model = null; const parcaGeo = new T.SphereGeometry(0.06, 8, 6);
    return {
        tuval,
        sec(ad) { if (model) kok.remove(model); aktif = ad; model = ad && modeller[ad] ? modeller[ad]() : null; if (model) kok.add(model); },
        ciz(y, t) {
            if (!model || !y) { r.clear(); return; }
            // yüz çapası: modelin türüne göre farklı nokta
            const capa = { biyik: y.biyikNokta, sakal: y.cene, gozluk3d: y.gozOrta, tac: y.alin, boynuz: y.alin, kalpler: y.alin, ates: y.agiz }[aktif];
            kok.position.set(capa.x, -capa.y, 0);
            kok.rotation.set(-y.pitch * 0.8, y.yaw * 1.2, -y.roll);
            const olcek = y.genislik;
            kok.scale.setScalar(olcek);
            if (aktif === 'tac') model.position.y = 0.38; else if (aktif === 'boynuz') model.position.y = 0.25; else if (aktif === 'kalpler') model.position.y = 0.15; else model.position.y = 0;
            if (model.userData.don) model.children.forEach((k, i) => { const a = k.userData.a + t * 1.6; k.position.set(Math.cos(a) * 0.75, Math.sin(t * 2 + i) * 0.08, Math.sin(a) * 0.75); k.rotation.y = -a; });
            if (model.userData.ates) {
                const p = model.userData.parca;
                if (y.agizAcik > 0.22) for (let i = 0; i < 4; i++) { const s = new T.Mesh(parcaGeo, new T.MeshBasicMaterial({ color: Math.random() < 0.5 ? '#f97316' : '#facc15', transparent: true })); s.userData.v = new T.Vector3((Math.random() - 0.5) * 0.6, -0.4 - Math.random() * 0.5, 1.6 + Math.random()); s.userData.yas = 0; model.add(s); p.push(s); }
                for (let i = p.length - 1; i >= 0; i--) { const s = p[i]; s.userData.yas += 1 / 30; s.position.addScaledVector(s.userData.v, 1 / 30); s.scale.setScalar(1 + s.userData.yas * 4); s.material.opacity = Math.max(0, 1 - s.userData.yas * 1.6); if (s.userData.yas > 0.65) { model.remove(s); s.material.dispose(); p.splice(i, 1); } }
            }
            r.render(sahne, kam);
        },
        boyut(W, H) { r.setSize(W, H, false); kam.right = W; kam.bottom = -H; kam.updateProjectionMatrix(); },
        kapat() { r.dispose(); }
    };
}

// ------------------------------------------------------------ yüz ölçüleri (MediaPipe Face Mesh noktalarından)
function yuzOlc(l, W, H) {
    const p = (i) => ({ x: l[i].x * W, y: l[i].y * H, z: l[i].z * W });
    const d = (a, b) => Math.hypot(a.x - b.x, a.y - b.y);
    const gL = p(33), gR = p(263), yanakL = p(234), yanakR = p(454), burun = p(1), ust = p(10), cene = p(152), agizU = p(13), agizA = p(14), alt = p(2), dudakUst = p(0);
    const genislik = d(yanakL, yanakR), yukseklik = d(ust, cene);
    const gozOrta = { x: (gL.x + gR.x) / 2, y: (gL.y + gR.y) / 2 };
    const gozSol = { x: (p(33).x + p(133).x) / 2, y: (p(159).y + p(145).y) / 2 }, gozSag = { x: (p(263).x + p(362).x) / 2, y: (p(386).y + p(374).y) / 2 };
    return {
        genislik, yukseklik, gozOrta, gozSol, gozSag, burun, cene, alin: ust,
        agiz: { x: (agizU.x + agizA.x) / 2, y: (agizU.y + agizA.y) / 2 }, biyikNokta: { x: (alt.x + dudakUst.x) / 2, y: (alt.y + dudakUst.y) / 2 },
        roll: Math.atan2(gR.y - gL.y, gR.x - gL.x),
        yaw: Math.max(-0.6, Math.min(0.6, (d(burun, yanakL) - d(burun, yanakR)) / genislik)),
        pitch: Math.max(-0.5, Math.min(0.5, ((burun.y - gozOrta.y) / yukseklik - 0.28) * 2)),
        agizAcik: d(agizU, agizA) / yukseklik,
    };
}

// ------------------------------------------------------------ 2D çizimler
function ciz2d(x, ad, y, t) {
    const w = y.genislik;
    const yerel = (nokta, f) => { x.save(); x.translate(nokta.x, nokta.y); x.rotate(y.roll); f(); x.restore(); };
    if (ad === 'gozluk') yerel(y.gozOrta, () => {
        x.fillStyle = 'rgba(15,23,42,.92)'; for (const s of [-1, 1]) { x.beginPath(); x.ellipse(s * w * 0.21, 0, w * 0.17, w * 0.12, 0, 0, 7); x.fill(); }
        x.strokeStyle = '#0f172a'; x.lineWidth = w * 0.03; x.beginPath(); x.moveTo(-w * 0.05, -w * 0.02); x.quadraticCurveTo(0, -w * 0.06, w * 0.05, -w * 0.02); x.stroke();
        x.fillStyle = 'rgba(255,255,255,.35)'; for (const s of [-1, 1]) { x.beginPath(); x.ellipse(s * w * 0.21 - w * 0.06, -w * 0.04, w * 0.04, w * 0.02, -0.5, 0, 7); x.fill(); }
    });
    if (ad === 'sapka') yerel(y.alin, () => {
        const h = w * 0.75; const g = x.createLinearGradient(-w * 0.2, 0, w * 0.2, 0); g.addColorStop(0, '#ec4899'); g.addColorStop(1, '#8b5cf6');
        x.fillStyle = g; x.beginPath(); x.moveTo(-w * 0.22, 0); x.lineTo(0, -h); x.lineTo(w * 0.22, 0); x.closePath(); x.fill();
        x.fillStyle = '#facc15'; for (let i = 1; i < 4; i++) { x.beginPath(); x.arc((Math.random() - 0.5) * 0.001 + (i - 2) * w * 0.06, -h * i / 4.5, w * 0.025, 0, 7); x.fill(); }
        x.fillStyle = '#fde047'; x.beginPath(); x.arc(0, -h, w * 0.06, 0, 7); x.fill();
    });
    if (ad === 'kedi' || ad === 'tavsan' || ad === 'kopek') {
        yerel(y.alin, () => {
            if (ad === 'kedi') for (const s of [-1, 1]) { x.fillStyle = '#f59e0b'; x.beginPath(); x.moveTo(s * w * 0.15, w * 0.02); x.lineTo(s * w * 0.38, -w * 0.42); x.lineTo(s * w * 0.45, w * 0.05); x.fill(); x.fillStyle = '#fda4af'; x.beginPath(); x.moveTo(s * w * 0.22, 0); x.lineTo(s * w * 0.37, -w * 0.28); x.lineTo(s * w * 0.4, 0); x.fill(); }
            if (ad === 'tavsan') for (const s of [-1, 1]) { x.save(); x.rotate(s * 0.15); x.fillStyle = '#f8fafc'; x.beginPath(); x.ellipse(s * w * 0.18, -w * 0.45, w * 0.1, w * 0.36, 0, 0, 7); x.fill(); x.fillStyle = '#fbcfe8'; x.beginPath(); x.ellipse(s * w * 0.18, -w * 0.45, w * 0.05, w * 0.27, 0, 0, 7); x.fill(); x.restore(); }
            if (ad === 'kopek') for (const s of [-1, 1]) { x.save(); x.translate(s * w * 0.42, w * 0.05); x.rotate(s * (0.35 + Math.sin(t * 3) * 0.05)); x.fillStyle = '#92400e'; x.beginPath(); x.ellipse(0, w * 0.2, w * 0.12, w * 0.3, 0, 0, 7); x.fill(); x.restore(); }
        });
        yerel(y.burun, () => {
            x.fillStyle = ad === 'tavsan' ? '#f9a8d4' : '#111827'; x.beginPath(); x.ellipse(0, 0, w * (ad === 'kopek' ? 0.09 : 0.05), w * (ad === 'kopek' ? 0.06 : 0.035), 0, 0, 7); x.fill();
            if (ad !== 'kopek') { x.strokeStyle = ad === 'kedi' ? '#1f2937' : '#e5e7eb'; x.lineWidth = Math.max(1.5, w * 0.008); for (const s of [-1, 1]) for (const a of [-0.12, 0, 0.12]) { x.beginPath(); x.moveTo(s * w * 0.07, w * 0.04); x.lineTo(s * w * 0.42, w * (0.04 + a)); x.stroke(); } }
            if (ad === 'tavsan') { x.fillStyle = '#fff'; x.fillRect(-w * 0.045, w * 0.14, w * 0.04, w * 0.07); x.fillRect(w * 0.005, w * 0.14, w * 0.04, w * 0.07); }
        });
        if (ad === 'kopek' && y.agizAcik > 0.12) yerel(y.agiz, () => { x.fillStyle = '#f472b6'; x.beginPath(); x.ellipse(0, w * 0.1 + y.agizAcik * w * 0.5, w * 0.1, w * 0.06 + y.agizAcik * w * 0.6, 0, 0, 7); x.fill(); x.strokeStyle = '#db2777'; x.lineWidth = 2; x.beginPath(); x.moveTo(0, w * 0.05); x.lineTo(0, w * 0.15 + y.agizAcik * w); x.stroke(); });
    }
    if (ad === 'emoji') yerel({ x: (y.alin.x + y.cene.x) / 2, y: (y.alin.y + y.cene.y) / 2 }, () => { x.font = `${Math.round(y.yukseklik * 1.15)}px "Apple Color Emoji","Segoe UI Emoji","Noto Color Emoji",sans-serif`; x.textAlign = 'center'; x.textBaseline = 'middle'; x.fillText(y.agizAcik > 0.18 ? '😮' : '😜', 0, y.yukseklik * 0.04); });
    if (ad === 'kalp') for (const g of [y.gozSol, y.gozSag]) yerel(g, () => { const s = w * 0.15 * (1 + Math.sin(t * 6) * 0.08); x.fillStyle = '#e11d48'; x.beginPath(); x.moveTo(0, s * 0.35); x.bezierCurveTo(-s, -s * 0.3, -s * 0.5, -s, 0, -s * 0.45); x.bezierCurveTo(s * 0.5, -s, s, -s * 0.3, 0, s * 0.35); x.fill(); });
    if (ad === 'palyaco') yerel(y.burun, () => { const g = x.createRadialGradient(-w * 0.03, -w * 0.03, 0, 0, 0, w * 0.1); g.addColorStop(0, '#fca5a5'); g.addColorStop(1, '#dc2626'); x.fillStyle = g; x.beginPath(); x.arc(0, 0, w * 0.1, 0, 7); x.fill(); });
}

// ------------------------------------------------------------ motor
async function olustur(ayar = {}) {
    let yon = ayar.yon || 'user';
    const video = document.createElement('video'); video.muted = true; video.playsInline = true; video.autoplay = true;
    const cikis = document.createElement('canvas'); cikis.width = 1280; cikis.height = 720; const cx = cikis.getContext('2d');
    const birlesik = document.createElement('canvas'); const bx = birlesik.getContext('2d');
    const filtreVar = 'filter' in cx;
    let akis = null, kameraAcik = true, calis = true, cihazlar = [], cihazNo = 0;
    const secim = { filtre: 'yok', yuz2d: 'yok', yuz3d: 'yok', arka: 'yok' };
    let yuz = null, yuzZaman = 0, maske = null, yuzModel = null, segModel = null, ucd = null, manzaraC = null, ozelResim = null;
    const yukleniyor = { y: false, s: false }, zaman = { y: 0, s: 0 };
    // Maske küçük bir tuvale alfa olarak yazılır; çizimde ölçeklenir (mobilde ucuz)
    const maskeC = document.createElement('canvas'), mx = maskeC.getContext('2d', { willReadFrequently: true });
    const girdiC = document.createElement('canvas'), gx = girdiC.getContext('2d');
    let maskeVeri = null;
    const durum = { yuzVar: false, model: '', hata: '' };

    async function kameraAc_() {
        akis?.getTracks().forEach(t => t.stop());
        const kisit = { width: { ideal: 1280 }, height: { ideal: 720 }, frameRate: { ideal: 30 } };
        cihazlar = (await navigator.mediaDevices.enumerateDevices().catch(() => [])).filter(d => d.kind === 'videoinput');
        if (cihazlar.length > 1 && cihazlar[cihazNo]?.deviceId && ayar._cihazIle) kisit.deviceId = { exact: cihazlar[cihazNo].deviceId };
        else kisit.facingMode = { ideal: yon };
        akis = await navigator.mediaDevices.getUserMedia({ video: kisit, audio: false });
        video.srcObject = akis; await video.play().catch(() => {});
        await new Promise(r => { if (video.videoWidth) r(); else video.onloadedmetadata = r; });
        const vw = video.videoWidth, vh = video.videoHeight, k = Math.min(1, UZUN_KENAR / Math.max(vw, vh));
        cikis.width = birlesik.width = Math.round(vw * k / 2) * 2; cikis.height = birlesik.height = Math.round(vh * k / 2) * 2;
        manzaraC = null; ucd?.boyut(cikis.width, cikis.height);
        yon = akis.getVideoTracks()[0].getSettings().facingMode || yon;
    }
    await kameraAc_();

    async function gorevYap(tur, ayarlar) {
        const v = await vizyon();
        try { return await v.mod[tur].createFromOptions(v.dosyalar, { ...ayarlar, baseOptions: { ...ayarlar.baseOptions, delegate: 'GPU' } }); }
        catch (e) { return await v.mod[tur].createFromOptions(v.dosyalar, { ...ayarlar, baseOptions: { ...ayarlar.baseOptions, delegate: 'CPU' } }); }
    }
    async function modelHazirla() {
        try {
            if ((secim.yuz2d !== 'yok' || secim.yuz3d !== 'yok') && !yuzModel && !yukleniyor.y) {
                yukleniyor.y = true; durum.model = 'Yüz takibi yükleniyor…';
                try { yuzModel = await gorevYap('FaceLandmarker', { baseOptions: { modelAssetPath: '/vendor/mediapipe/face_landmarker.task' }, runningMode: 'VIDEO', numFaces: 1, minFaceDetectionConfidence: 0.5, minTrackingConfidence: 0.5 }); }
                finally { yukleniyor.y = false; }
            }
            if (secim.arka !== 'yok' && !segModel && !yukleniyor.s) {
                yukleniyor.s = true; durum.model = 'Arka plan modeli yükleniyor…';
                try { segModel = await gorevYap('ImageSegmenter', { baseOptions: { modelAssetPath: '/vendor/mediapipe/selfie_segmenter.tflite' }, runningMode: 'VIDEO', outputConfidenceMasks: true, outputCategoryMask: false }); }
                finally { yukleniyor.s = false; }
            }
            if (secim.yuz3d !== 'yok' && !ucd) { ucd = uc(cikis.width, cikis.height); }
            ucd?.sec(secim.yuz3d === 'yok' ? null : secim.yuz3d);
            durum.model = ''; durum.hata = '';
        } catch (e) { durum.hata = 'Efekt modeli yüklenemedi: ' + (e?.message || e); durum.model = ''; }
    }
    function yumusat(eski, yeni) {
        if (!eski || eski.length !== yeni.length) return yeni.map(p => ({ x: p.x, y: p.y, z: p.z }));
        const a = 0.55; return yeni.map((p, i) => ({ x: eski[i].x + (p.x - eski[i].x) * a, y: eski[i].y + (p.y - eski[i].y) * a, z: eski[i].z + (p.z - eski[i].z) * a }));
    }
    function damga(tur) { const n = Math.max(zaman[tur] + 1, Math.round(performance.now())); zaman[tur] = n; return n; }
    let sira = 0;
    // İki model aynı karede çalışmaz: sırayla (biri bir kare, öteki sonraki kare) — mobilde kare hızını korur
    function besle() {
        if (!calis || !kameraAcik || video.readyState < 2) return;
        const yuzLazim = yuzModel && (secim.yuz2d !== 'yok' || secim.yuz3d !== 'yok');
        const segLazim = segModel && secim.arka !== 'yok';
        sira++;
        const hangisi = yuzLazim && segLazim ? (sira % 2 ? 'y' : 's') : yuzLazim ? 'y' : segLazim ? 's' : null;
        try {
            if (hangisi === 'y') {
                const r = yuzModel.detectForVideo(video, damga('y'));
                const l = r?.faceLandmarks?.[0];
                if (l) { yuz = yumusat(yuz, l); yuzZaman = performance.now(); } else if (performance.now() - yuzZaman > 400) yuz = null;
                durum.yuzVar = !!yuz;
            } else if (hangisi === 's') {
                const w_ = 256, h_ = Math.max(2, Math.round(256 * video.videoHeight / video.videoWidth));
                if (girdiC.width !== w_ || girdiC.height !== h_) { girdiC.width = w_; girdiC.height = h_; }
                gx.drawImage(video, 0, 0, w_, h_);
                segModel.segmentForVideo(girdiC, damga('s'), (r) => {
                    const m = r?.confidenceMasks?.[0]; if (!m) return;
                    const mw = m.width, mh = m.height, d = m.getAsFloat32Array();
                    if (maskeC.width !== mw || maskeC.height !== mh || !maskeVeri) { maskeC.width = mw; maskeC.height = mh; maskeVeri = mx.createImageData(mw, mh); }
                    const p = maskeVeri.data;
                    for (let i = 0, j = 3; i < d.length; i++, j += 4) { const v = d[i]; p[j] = v < 0.25 ? 0 : v > 0.75 ? 255 : (v - 0.25) * 510; }
                    mx.putImageData(maskeVeri, 0, 0); maske = maskeC;
                });  // geri çağrı bitince maskeler kütüphanece serbest bırakılır
            }
        } catch (e) { durum.hata = 'Efekt hatası: ' + (e?.message || e); }
    }

    const t0 = performance.now();
    function kare() {
        if (!calis) return;
        requestAnimationFrame(kare);
        const W = cikis.width, H = cikis.height, t = (performance.now() - t0) / 1000;
        if (!kameraAcik) {
            cx.filter = 'none'; cx.fillStyle = '#0f172a'; cx.fillRect(0, 0, W, H);
            cx.fillStyle = '#94a3b8'; cx.font = `700 ${Math.round(H / 16)}px Inter, sans-serif`; cx.textAlign = 'center'; cx.fillText('Kamera kapalı', W / 2, H / 2); return;
        }
        if (video.readyState < 2) return;
        besle();
        // 1) arka plan + kişi
        if (secim.arka !== 'yok' && maske) {
            bx.save(); bx.clearRect(0, 0, W, H);
            bx.drawImage(maske, 0, 0, W, H);
            bx.globalCompositeOperation = 'source-in'; bx.drawImage(video, 0, 0, W, H);
            bx.globalCompositeOperation = 'destination-over';
            if (secim.arka === 'bulanik') { bx.filter = `blur(${Math.round(W / 90)}px)`; bx.drawImage(video, 0, 0, W, H); bx.filter = 'none'; }
            else if (secim.arka === 'resim' && ozelResim) { const k = Math.max(W / ozelResim.width, H / ozelResim.height); bx.drawImage(ozelResim, (W - ozelResim.width * k) / 2, (H - ozelResim.height * k) / 2, ozelResim.width * k, ozelResim.height * k); }
            else { if (!manzaraC || manzaraC._ad !== secim.arka) { manzaraC = manzara(secim.arka === 'resim' ? 'studyo' : secim.arka, W, H); manzaraC._ad = secim.arka; } bx.drawImage(manzaraC, 0, 0); }
            bx.restore();
        } else { bx.drawImage(video, 0, 0, W, H); }
        // 2) renk filtresi
        cx.filter = filtreVar ? FILTRELER[secim.filtre][1] : 'none';
        cx.drawImage(birlesik, 0, 0);
        // 3) yüz efektleri
        const y = yuz ? yuzOlc(yuz, W, H) : null;
        if (y && secim.yuz2d === 'devgoz') for (const g of [y.gozSol, y.gozSag]) {
            const r = y.genislik * 0.13, b = 1.7; cx.save(); cx.beginPath(); cx.arc(g.x, g.y, r * b, 0, 7); cx.clip();
            cx.drawImage(birlesik, g.x - r, g.y - r, r * 2, r * 2, g.x - r * b, g.y - r * b, r * 2 * b, r * 2 * b); cx.restore();
        }
        cx.filter = 'none';
        if (y && secim.yuz2d !== 'yok' && secim.yuz2d !== 'devgoz') ciz2d(cx, secim.yuz2d, y, t);
        if (ucd && secim.yuz3d !== 'yok') { ucd.ciz(y, t); if (y) cx.drawImage(ucd.tuval, 0, 0); }
    }
    requestAnimationFrame(kare);
    const yayin = cikis.captureStream(30);

    return {
        cikis: yayin.getVideoTracks()[0], tuval: cikis, durum, secim, filtreVar,
        get onKamera() { return yon !== 'environment'; },
        async efekt(tur, ad) { secim[tur] = ad; await modelHazirla(); },
        ozelArka(resim) { ozelResim = resim; secim.arka = 'resim'; return modelHazirla(); },
        async kameraDegistir() {
            if (cihazlar.length > 1) { cihazNo = (cihazNo + 1) % cihazlar.length; ayar._cihazIle = true; }
            yon = yon === 'user' ? 'environment' : 'user';
            await kameraAc_(); return cihazlar.length;
        },
        async kameraAc(ac) { kameraAcik = ac; if (!ac) akis?.getTracks().forEach(t => t.stop()); else await kameraAc_(); },
        get kameraAcik() { return kameraAcik; },
        durdur() { calis = false; akis?.getTracks().forEach(t => t.stop()); yayin.getTracks().forEach(t => t.stop()); try { yuzModel?.close(); } catch (e) {} try { segModel?.close(); } catch (e) {} ucd?.kapat(); },
    };
}

window.MxEfekt = { olustur, FILTRELER, YUZ2D, YUZ3D, ARKA };
})();
