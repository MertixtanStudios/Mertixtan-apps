// İsorp: Mertixtan'ın tarayıcıda oynanan çok oyunculu rol yapma oyunu.
// 3D dünya Three.js ile; gerçek zamanlı oyuncular WebSocket (/isorp/ws); para, eşya, ev, avatar sunucuda (/api/isorp).
// Bütün karakter, bina ve eşya modelleri burada basit şekillerden üretilir; dışarıdan model/görsel kullanılmaz.
(function () {
'use strict';
if (!window.THREE) return;
const T = THREE;
const api = (yol, veri) => fetch('/api/isorp/' + yol, veri === undefined ? { cache: 'no-store', credentials: 'same-origin' }
    : { method: 'POST', credentials: 'same-origin', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(veri) })
    .then(async r => { let j = {}; try { j = await r.json(); } catch (e) {} if (!r.ok) { const h = new Error(j.hata || 'Sunucuya ulaşılamadı'); h.kod = r.status; throw h; } return j; });
const bt = (yazi, sinif, f) => { const b = el('button', sinif, yazi); b.type = 'button'; if (f) b.onclick = f; return b; };
const HUD_BTN = 'px-3 py-2 rounded-xl bg-white/90 hover:bg-white text-slate-800 text-xs sm:text-sm font-bold shadow-lg backdrop-blur flex items-center gap-1.5';
const DOKUNMA = matchMedia('(pointer: coarse)').matches;
const EMOJI = ['👋', '😂', '😍', '😎', '🔥', '👍', '❤️', '🎉', '😮', '😢', '💃', '🕺', '⭐', '💎', '👑'];

let S = null;            // sunucudaki oyuncu verisi (para, avatar, envanter, ev)
let KATALOG = [], TENLER = [];
let sahne, kamera, cizici, saat, kare = null, tuval;
let mod = 'sehir', evSahibi = null, evDuzen = false;
let ben = null, digerleri = new Map(), ws = null, wsOda = null, sonGonder = 0;
const tus = {}; let joy = { x: 0, y: 0 }, kamYaw = Math.PI, kamPitch = 0.42, kamUzak = 9;
let engeller = [], etkilesimler = [], yakin = null, dunyaGrup = null, evEsyalar = [], secili = null;

// ------------------------------------------------------------ avatar modeli
const mat = (c) => new T.MeshLambertMaterial({ color: c });
function avatarYap(av, boy) {
    const g = new T.Group(); const p = {};
    const ten = mat(av.ten), ust = mat(av.ust_renk), alt = mat(av.alt_renk), ayk = mat(av.ayakkabi_renk), sac = mat(av.sac_renk), aks = mat(av.aksesuar_renk);
    // bacaklar (kalçadan dönen pivotlar)
    for (const [ad, x] of [['bacakL', -0.13], ['bacakR', 0.13]]) {
        const piv = new T.Group(); piv.position.set(x, 0.78, 0);
        const sortMu = av.alt === 'alt:sort';
        const ust_ = new T.Mesh(new T.BoxGeometry(0.2, sortMu ? 0.3 : 0.62, 0.22), alt); ust_.position.y = sortMu ? -0.15 : -0.31; piv.add(ust_);
        if (sortMu) { const alt_ = new T.Mesh(new T.BoxGeometry(0.17, 0.34, 0.19), ten); alt_.position.y = -0.47; piv.add(alt_); }
        const ayak = new T.Mesh(new T.BoxGeometry(0.22, av.ayakkabi === 'ayakkabi:bot' ? 0.22 : 0.12, 0.32), ayk); ayak.position.set(0, av.ayakkabi === 'ayakkabi:bot' ? -0.66 : -0.71, 0.05); piv.add(ayak);
        if (av.ayakkabi === 'ayakkabi:sandalet') ayak.scale.y = 0.5;
        g.add(piv); p[ad] = piv;
    }
    if (av.alt === 'alt:etek') { const e = new T.Mesh(new T.CylinderGeometry(0.22, 0.36, 0.42, 12), alt); e.position.y = 0.66; g.add(e); }
    if (av.alt === 'alt:esofman') for (const x of [-0.13, 0.13]) { const s = new T.Mesh(new T.BoxGeometry(0.02, 0.6, 0.23), mat('#ffffff')); s.position.set(x + (x < 0 ? -0.1 : 0.1), 0.48, 0); g.add(s); }
    // gövde
    const govde = new T.Mesh(new T.BoxGeometry(0.5, 0.6, 0.3), ust); govde.position.y = 1.08; g.add(govde);
    if (av.ust === 'ust:kapusonlu') { const k = new T.Mesh(new T.BoxGeometry(0.44, 0.14, 0.2), ust); k.position.set(0, 1.42, -0.12); g.add(k); const c = new T.Mesh(new T.BoxGeometry(0.3, 0.14, 0.02), mat('#00000033')); c.position.set(0, 0.92, 0.16); g.add(c); }
    if (av.ust === 'ust:gomlek') { const y = new T.Mesh(new T.BoxGeometry(0.2, 0.08, 0.02), mat('#ffffff')); y.position.set(0, 1.34, 0.16); g.add(y); }
    if (av.ust === 'ust:ceket' || av.ust === 'ust:yelek') { const ic = new T.Mesh(new T.BoxGeometry(0.16, 0.58, 0.02), mat(av.ust === 'ust:ceket' ? '#f8fafc' : av.ten)); ic.position.set(0, 1.08, 0.16); g.add(ic); }
    if (av.ust === 'ust:forma') { const s = new T.Mesh(new T.BoxGeometry(0.51, 0.08, 0.31), mat('#2563eb')); s.position.y = 1.18; g.add(s); }
    // kollar (omuzdan)
    for (const [ad, x] of [['kolL', -0.33], ['kolR', 0.33]]) {
        const piv = new T.Group(); piv.position.set(x, 1.34, 0);
        const kol = av.ust === 'ust:yelek' ? ten : ust;
        const k = new T.Mesh(new T.BoxGeometry(0.15, 0.32, 0.17), kol); k.position.y = -0.16; piv.add(k);
        const el_ = new T.Mesh(new T.BoxGeometry(0.13, 0.28, 0.15), (av.ust === 'ust:tisort' || av.ust === 'ust:forma' || av.ust === 'ust:yelek') ? ten : kol); el_.position.y = -0.45; piv.add(el_);
        g.add(piv); p[ad] = piv;
    }
    // baş
    const bas = new T.Group(); bas.position.y = 1.62; g.add(bas); p.bas = bas;
    bas.add(new T.Mesh(new T.BoxGeometry(0.4, 0.42, 0.38), ten));
    for (const x of [-0.09, 0.09]) { const goz = new T.Mesh(new T.BoxGeometry(0.06, 0.07, 0.02), mat('#1e293b')); goz.position.set(x, 0.03, 0.2); bas.add(goz); }
    const agiz = new T.Mesh(new T.BoxGeometry(0.12, 0.025, 0.02), mat('#9f1239')); agiz.position.set(0, -0.1, 0.2); bas.add(agiz);
    // saç
    const s = av.sac;
    if (s !== 'sac:kel') { const ust_ = new T.Mesh(new T.BoxGeometry(0.43, 0.12, 0.41), sac); ust_.position.y = 0.24; bas.add(ust_); const arka = new T.Mesh(new T.BoxGeometry(0.43, 0.3, 0.08), sac); arka.position.set(0, 0.08, -0.19); bas.add(arka); }
    if (s === 'sac:uzun') { const u = new T.Mesh(new T.BoxGeometry(0.45, 0.55, 0.1), sac); u.position.set(0, -0.12, -0.2); bas.add(u); for (const x of [-0.22, 0.22]) { const y = new T.Mesh(new T.BoxGeometry(0.05, 0.4, 0.3), sac); y.position.set(x, -0.02, -0.03); bas.add(y); } }
    if (s === 'sac:kivircik') for (let i = 0; i < 9; i++) { const b = new T.Mesh(new T.SphereGeometry(0.09, 6, 5), sac); b.position.set(((i % 3) - 1) * 0.14, 0.27 + (i > 5 ? 0.05 : 0), ((Math.floor(i / 3)) - 1) * 0.13); bas.add(b); }
    if (s === 'sac:at_kuyrugu') { const k = new T.Mesh(new T.CylinderGeometry(0.06, 0.03, 0.4, 6), sac); k.position.set(0, -0.05, -0.27); k.rotation.x = 0.4; bas.add(k); }
    if (s === 'sac:dikenli') for (let i = 0; i < 5; i++) { const k = new T.Mesh(new T.ConeGeometry(0.06, 0.2, 5), sac); k.position.set((i - 2) * 0.08, 0.38, 0); bas.add(k); }
    if (s === 'sac:topuz') { const t = new T.Mesh(new T.SphereGeometry(0.12, 8, 6), sac); t.position.set(0, 0.36, -0.08); bas.add(t); }
    if (s === 'sac:kakul') { const k = new T.Mesh(new T.BoxGeometry(0.3, 0.12, 0.06), sac); k.position.set(-0.05, 0.16, 0.2); k.rotation.z = 0.2; bas.add(k); }
    // aksesuar
    const a = av.aksesuar;
    if (a === 'aksesuar:kep') { const t = new T.Mesh(new T.BoxGeometry(0.45, 0.12, 0.43), aks); t.position.y = 0.3; bas.add(t); const s_ = new T.Mesh(new T.BoxGeometry(0.4, 0.03, 0.2), aks); s_.position.set(0, 0.25, 0.28); bas.add(s_); }
    if (a === 'aksesuar:sapka') { const k = new T.Mesh(new T.CylinderGeometry(0.4, 0.4, 0.03, 16), aks); k.position.y = 0.26; bas.add(k); const t = new T.Mesh(new T.CylinderGeometry(0.22, 0.24, 0.25, 16), aks); t.position.y = 0.4; bas.add(t); }
    if (a === 'aksesuar:gozluk') { for (const x of [-0.1, 0.1]) { const c = new T.Mesh(new T.BoxGeometry(0.15, 0.09, 0.02), mat('#0f172a')); c.position.set(x, 0.03, 0.21); bas.add(c); } const k = new T.Mesh(new T.BoxGeometry(0.42, 0.02, 0.02), aks); k.position.set(0, 0.05, 0.21); bas.add(k); }
    if (a === 'aksesuar:kulaklik') { const b = new T.Mesh(new T.TorusGeometry(0.24, 0.03, 6, 16, Math.PI), aks); b.position.y = 0.08; bas.add(b); for (const x of [-0.23, 0.23]) { const k = new T.Mesh(new T.CylinderGeometry(0.09, 0.09, 0.07, 12), aks); k.rotation.z = Math.PI / 2; k.position.set(x, 0.02, 0); bas.add(k); } }
    if (a === 'aksesuar:tac') { const t = new T.Mesh(new T.CylinderGeometry(0.2, 0.18, 0.1, 8, 1, true), mat('#facc15')); t.position.y = 0.36; bas.add(t); for (let i = 0; i < 6; i++) { const u = new T.Mesh(new T.ConeGeometry(0.035, 0.1, 4), mat('#facc15')); u.position.set(Math.cos(i * 1.047) * 0.19, 0.45, Math.sin(i * 1.047) * 0.19); bas.add(u); } const m = new T.Mesh(new T.OctahedronGeometry(0.04), mat('#e0115f')); m.position.set(0, 0.38, 0.19); bas.add(m); }
    if (a === 'aksesuar:pelerin') { const pl = new T.Mesh(new T.BoxGeometry(0.56, 1.0, 0.03), aks); pl.position.set(0, 0.92, -0.2); pl.rotation.x = 0.12; g.add(pl); p.pelerin = pl; }
    if (a === 'aksesuar:hale') { const hl = new T.Mesh(new T.TorusGeometry(0.2, 0.025, 6, 24), new T.MeshBasicMaterial({ color: av.aksesuar_renk })); hl.rotation.x = Math.PI / 2; hl.position.y = 0.48; bas.add(hl); p.hale = hl; }
    const olc = boy || av.boy || 1; g.scale.set(olc, olc, olc);
    g.userData.parca = p;
    return g;
}
function animasyon(g, hareket, t) {
    const p = g.userData.parca; if (!p) return;
    const s = hareket ? Math.sin(t * 9) * 0.6 : 0;
    p.bacakL.rotation.x = s; p.bacakR.rotation.x = -s; p.kolL.rotation.x = -s * 0.8; p.kolR.rotation.x = s * 0.8;
    p.bas.position.y = 1.62 + (hareket ? Math.abs(Math.sin(t * 9)) * 0.03 : Math.sin(t * 2) * 0.008);
    if (p.pelerin) p.pelerin.rotation.x = 0.12 + (hareket ? 0.35 + Math.sin(t * 7) * 0.08 : Math.sin(t * 1.5) * 0.03);
    if (p.hale) p.hale.rotation.z = t;
}
function etiket(ad, rozet) {
    const c = document.createElement('canvas'); c.width = 512; c.height = 96; const x = c.getContext('2d');
    x.font = '800 44px Inter, system-ui, sans-serif'; x.textAlign = 'center'; x.textBaseline = 'middle';
    const yazi = ad + (rozet?.admin ? ' 💎' : rozet?.pro ? ' 👑' : '') + (rozet?.onayli ? ' ✔' : '');
    const w = Math.min(500, x.measureText(yazi).width + 40);
    x.fillStyle = 'rgba(15,23,42,0.6)'; x.beginPath(); x.roundRect?.((512 - w) / 2, 14, w, 68, 34); x.fill();
    if (rozet?.admin) { const g = x.createLinearGradient(0, 0, 512, 0); g.addColorStop(0, '#ff8fab'); g.addColorStop(0.5, '#e0115f'); g.addColorStop(1, '#ff8fab'); x.fillStyle = g; }
    else if (rozet?.pro) { const g = x.createLinearGradient(0, 0, 512, 0); g.addColorStop(0, '#fde68a'); g.addColorStop(0.5, '#facc15'); g.addColorStop(1, '#fde68a'); x.fillStyle = g; }
    else x.fillStyle = '#ffffff';
    x.fillText(yazi, 256, 50);
    const sp = new T.Sprite(new T.SpriteMaterial({ map: new T.CanvasTexture(c), depthTest: false, transparent: true }));
    sp.scale.set(2.2, 0.41, 1); sp.position.y = 2.35; sp.renderOrder = 10;
    return sp;
}
function balon(metin, emoji) {
    const c = document.createElement('canvas'); c.width = 512; c.height = 160; const x = c.getContext('2d');
    x.font = emoji ? '96px system-ui' : '600 34px Inter, system-ui, sans-serif'; x.textAlign = 'center'; x.textBaseline = 'middle';
    if (!emoji) {
        const satirlar = []; let s = '';
        for (const k of metin.split(' ')) { if (x.measureText(s + ' ' + k).width > 440) { satirlar.push(s); s = k; } else s = (s + ' ' + k).trim(); }
        satirlar.push(s); const l = satirlar.slice(0, 3);
        x.fillStyle = 'white'; x.beginPath(); x.roundRect?.(16, 8, 480, 40 + l.length * 38, 24); x.fill();
        x.fillStyle = '#0f172a'; l.forEach((t, i) => x.fillText(t, 256, 30 + i * 38 + 6));
    } else x.fillText(metin, 256, 80);
    const sp = new T.Sprite(new T.SpriteMaterial({ map: new T.CanvasTexture(c), depthTest: false, transparent: true }));
    sp.scale.set(3, 0.94, 1); sp.position.y = emoji ? 3.0 : 3.1; sp.renderOrder = 11;
    return sp;
}
function balonGoster(o, metin, emoji) {
    if (!o) return;
    if (o.balon) { o.grup.remove(o.balon); o.balon.material.map.dispose(); }
    o.balon = balon(metin, emoji); o.grup.add(o.balon);
    clearTimeout(o.balonZ); o.balonZ = setTimeout(() => { if (o.balon) { o.grup.remove(o.balon); o.balon = null; } }, emoji ? 2500 : 6000);
}

// ------------------------------------------------------------ dünya: İsorp Şehri
function kutu(w, h, d, renk, x, y, z, grup) { const m = new T.Mesh(new T.BoxGeometry(w, h, d), mat(renk)); m.position.set(x, y, z); (grup || dunyaGrup).add(m); return m; }
function yaziPano(metin, renk, w) {
    const c = document.createElement('canvas'); c.width = 512; c.height = 128; const x = c.getContext('2d');
    x.fillStyle = renk; x.fillRect(0, 0, 512, 128); x.fillStyle = 'white'; x.font = '900 64px Outfit, Inter, sans-serif'; x.textAlign = 'center'; x.textBaseline = 'middle'; x.fillText(metin, 256, 68);
    return new T.Mesh(new T.PlaneGeometry(w, w / 4), new T.MeshBasicMaterial({ map: new T.CanvasTexture(c) }));
}
function bina(x, z, w, d, h, renk, cati, ad, panoRenk, eylem) {
    kutu(w, h, d, renk, x, h / 2, z);
    const c = new T.Mesh(new T.ConeGeometry(Math.max(w, d) * 0.75, 2.2, 4), mat(cati)); c.position.set(x, h + 1.1, z); c.rotation.y = Math.PI / 4; dunyaGrup.add(c);
    kutu(1.6, 2.4, 0.1, '#7c2d12', x, 1.2, z + d / 2 + 0.03);
    for (const dx of [-w / 3, w / 3]) kutu(1.2, 1, 0.08, '#bae6fd', x + dx, h * 0.6, z + d / 2 + 0.03);
    if (ad) { const p = yaziPano(ad, panoRenk, 4); p.position.set(x, h - 0.6, z + d / 2 + 0.06); dunyaGrup.add(p); }
    engeller.push({ x1: x - w / 2, x2: x + w / 2, z1: z - d / 2, z2: z + d / 2 });
    if (eylem) etkilesimler.push({ x, z: z + d / 2 + 1.4, ad, eylem });
}
function agac(x, z) {
    const g = dunyaGrup;
    const gv = new T.Mesh(new T.CylinderGeometry(0.18, 0.25, 1.4, 6), mat('#78350f')); gv.position.set(x, 0.7, z); g.add(gv);
    for (let i = 0; i < 3; i++) { const y = new T.Mesh(new T.ConeGeometry(1.2 - i * 0.3, 1.4, 7), mat(['#15803d', '#16a34a', '#22c55e'][i])); y.position.set(x, 1.7 + i * 0.7, z); g.add(y); }
    engeller.push({ x1: x - 0.35, x2: x + 0.35, z1: z - 0.35, z2: z + 0.35 });
}
function sehirKur() {
    dunyaGrup = new T.Group(); sahne.add(dunyaGrup); engeller = []; etkilesimler = [];
    sahne.background = new T.Color('#9bd7ff'); sahne.fog = new T.Fog('#9bd7ff', 50, 110);
    const zemin = new T.Mesh(new T.PlaneGeometry(130, 130), mat('#7cc36a')); zemin.rotation.x = -Math.PI / 2; dunyaGrup.add(zemin);
    for (const [w, d] of [[130, 6], [6, 130]]) { const yol = new T.Mesh(new T.PlaneGeometry(w, d), mat('#64748b')); yol.rotation.x = -Math.PI / 2; yol.position.y = 0.01; dunyaGrup.add(yol); }
    for (let i = -60; i <= 60; i += 6) { kutu(2.5, 0.02, 0.25, '#f8fafc', i, 0.02, 0); kutu(0.25, 0.02, 2.5, '#f8fafc', 0, 0.02, i); }
    // meydan + fıskiye
    const meydan = new T.Mesh(new T.CircleGeometry(11, 32), mat('#e7e5e4')); meydan.rotation.x = -Math.PI / 2; meydan.position.y = 0.02; dunyaGrup.add(meydan);
    const havuz = new T.Mesh(new T.CylinderGeometry(3, 3.2, 0.6, 24), mat('#cbd5e1')); havuz.position.y = 0.3; dunyaGrup.add(havuz);
    const su = new T.Mesh(new T.CylinderGeometry(2.7, 2.7, 0.1, 24), new T.MeshLambertMaterial({ color: '#38bdf8', transparent: true, opacity: 0.85 })); su.position.y = 0.58; dunyaGrup.add(su);
    const sut = new T.Mesh(new T.CylinderGeometry(0.3, 0.45, 2.4, 10), mat('#e2e8f0')); sut.position.y = 1.5; dunyaGrup.add(sut);
    const elmas = new T.Mesh(new T.OctahedronGeometry(0.6), new T.MeshLambertMaterial({ color: '#10b981', emissive: '#065f46' })); elmas.position.y = 3.2; dunyaGrup.add(elmas); dunyaGrup.userData.elmas = elmas;
    engeller.push({ x1: -3.2, x2: 3.2, z1: -3.2, z2: 3.2 });
    // binalar (kuzeybatı: mağaza, kuzeydoğu: oyun salonu, güney: evler)
    bina(-16, -16, 9, 7, 5, '#fde68a', '#dc2626', 'MAĞAZA', '#059669', () => magazaAc());
    bina(16, -16, 10, 8, 6, '#c7d2fe', '#4338ca', 'OYUN SALONU', '#7c3aed', () => oyunSalonu());
    bina(0, 22, 8, 6, 4.5, '#fecaca', '#7f1d1d', 'EVİM', '#e11d48', () => evimeGit());
    bina(-22, 16, 6, 6, 4, '#bbf7d0', '#166534'); bina(22, 16, 6, 6, 7, '#e9d5ff', '#6b21a8'); bina(-28, -2, 5, 8, 9, '#fed7aa', '#9a3412'); bina(28, -4, 6, 6, 5, '#bae6fd', '#0369a1');
    for (const [x, z] of [[-9, 9], [9, 9], [-9, -9], [9, -9], [-34, 30], [34, 30], [-40, -30], [40, -30], [-12, 32], [12, 34], [30, -34], [-30, -36], [0, -40], [44, 6], [-44, 8], [-20, 40], [20, 42]]) agac(x, z);
    for (const [x, z] of [[-6, 4], [6, 4], [-6, -4], [6, -4]]) { const d = new T.Mesh(new T.CylinderGeometry(0.08, 0.1, 3, 6), mat('#334155')); d.position.set(x * 1.6, 1.5, z * 1.6); dunyaGrup.add(d); const l = new T.Mesh(new T.SphereGeometry(0.28, 8, 6), new T.MeshBasicMaterial({ color: '#fef9c3' })); l.position.set(x * 1.6, 3.1, z * 1.6); dunyaGrup.add(l); }
    for (const [x, z, r] of [[-7, 0, Math.PI / 2], [7, 0, -Math.PI / 2]]) { const b = new T.Group(); kutu(2, 0.12, 0.6, '#92400e', 0, 0.5, 0, b); kutu(2, 0.5, 0.1, '#92400e', 0, 0.8, -0.28, b); b.position.set(x, 0, z); b.rotation.y = r; dunyaGrup.add(b); }
    // tabela
    const tab = yaziPano('İSORP', '#0f172a', 6); tab.position.set(0, 4.6, -6); dunyaGrup.add(tab);
    kutu(0.2, 4, 0.2, '#334155', -2.6, 2, -6); kutu(0.2, 4, 0.2, '#334155', 2.6, 2, -6);
}

// ------------------------------------------------------------ ev
const MOBILYA = {
    'mobilya:koltuk': (g, r) => { kutu(2, 0.5, 0.9, r, 0, 0.35, 0, g); kutu(2, 0.7, 0.25, r, 0, 0.75, -0.35, g); kutu(0.25, 0.6, 0.9, r, -0.9, 0.55, 0, g); kutu(0.25, 0.6, 0.9, r, 0.9, 0.55, 0, g); },
    'mobilya:masa': (g) => { kutu(1.4, 0.08, 0.8, '#a16207', 0, 0.75, 0, g); for (const [x, z] of [[-0.6, -0.32], [0.6, -0.32], [-0.6, 0.32], [0.6, 0.32]]) kutu(0.08, 0.75, 0.08, '#78350f', x, 0.37, z, g); },
    'mobilya:sandalye': (g) => { kutu(0.5, 0.06, 0.5, '#b45309', 0, 0.45, 0, g); kutu(0.5, 0.55, 0.06, '#b45309', 0, 0.75, -0.22, g); for (const [x, z] of [[-0.2, -0.2], [0.2, -0.2], [-0.2, 0.2], [0.2, 0.2]]) kutu(0.05, 0.45, 0.05, '#78350f', x, 0.22, z, g); },
    'mobilya:yatak': (g) => { kutu(1.6, 0.4, 2.2, '#e2e8f0', 0, 0.25, 0, g); kutu(1.6, 0.15, 1.4, '#3b82f6', 0, 0.5, 0.35, g); kutu(0.6, 0.15, 0.4, '#ffffff', -0.4, 0.52, -0.75, g); kutu(0.6, 0.15, 0.4, '#ffffff', 0.4, 0.52, -0.75, g); kutu(1.7, 0.9, 0.12, '#7c2d12', 0, 0.5, -1.1, g); },
    'mobilya:lamba': (g) => { kutu(0.3, 0.05, 0.3, '#334155', 0, 0.03, 0, g); kutu(0.05, 1.5, 0.05, '#334155', 0, 0.75, 0, g); const s = new T.Mesh(new T.ConeGeometry(0.3, 0.4, 12, 1, true), new T.MeshBasicMaterial({ color: '#fef3c7', side: T.DoubleSide })); s.position.y = 1.6; g.add(s); },
    'mobilya:bitki': (g) => { const s = new T.Mesh(new T.CylinderGeometry(0.22, 0.17, 0.35, 10), mat('#c2410c')); s.position.y = 0.17; g.add(s); for (let i = 0; i < 5; i++) { const y = new T.Mesh(new T.SphereGeometry(0.2, 6, 5), mat('#16a34a')); y.position.set(Math.cos(i) * 0.15, 0.5 + (i % 2) * 0.15, Math.sin(i) * 0.15); g.add(y); } },
    'mobilya:tv': (g) => { kutu(1.4, 0.5, 0.45, '#44403c', 0, 0.25, 0, g); kutu(1.3, 0.75, 0.06, '#0f172a', 0, 0.95, 0, g); const e = new T.Mesh(new T.PlaneGeometry(1.2, 0.66), new T.MeshBasicMaterial({ color: '#38bdf8' })); e.position.set(0, 0.95, 0.04); g.add(e); },
    'mobilya:hali': (g) => { const h = new T.Mesh(new T.PlaneGeometry(2.4, 1.6), mat('#be123c')); h.rotation.x = -Math.PI / 2; h.position.y = 0.015; g.add(h); const i = new T.Mesh(new T.PlaneGeometry(2, 1.2), mat('#fda4af')); i.rotation.x = -Math.PI / 2; i.position.y = 0.02; g.add(i); },
    'mobilya:kitaplik': (g) => { kutu(1.2, 1.8, 0.4, '#92400e', 0, 0.9, 0, g); for (let r = 0; r < 3; r++) for (let i = 0; i < 6; i++) kutu(0.12, 0.4, 0.3, ['#dc2626', '#2563eb', '#16a34a', '#ca8a04', '#7c3aed', '#0891b2'][(i + r) % 6], -0.42 + i * 0.17, 0.4 + r * 0.55, 0.06, g); },
    'mobilya:buzdolabi': (g) => { kutu(0.8, 1.9, 0.7, '#e2e8f0', 0, 0.95, 0, g); kutu(0.05, 0.5, 0.05, '#64748b', 0.3, 1.3, 0.37, g); kutu(0.82, 0.02, 0.72, '#94a3b8', 0, 1.25, 0, g); },
    'mobilya:dolap': (g) => { kutu(1.4, 2, 0.6, '#a16207', 0, 1, 0, g); kutu(0.02, 1.9, 0.02, '#451a03', 0, 1, 0.31, g); },
    'mobilya:konsol': (g) => { kutu(0.6, 0.12, 0.4, '#111827', 0, 0.06, 0, g); kutu(0.2, 0.04, 0.12, '#10b981', -0.12, 0.14, 0.05, g); kutu(0.2, 0.04, 0.12, '#e11d48', 0.12, 0.14, 0.05, g); },
    'mobilya:akvaryum': (g) => { kutu(1.2, 0.5, 0.5, '#1f2937', 0, 0.25, 0, g); const s = new T.Mesh(new T.BoxGeometry(1.2, 0.7, 0.5), new T.MeshLambertMaterial({ color: '#7dd3fc', transparent: true, opacity: 0.6 })); s.position.y = 0.85; g.add(s); for (let i = 0; i < 4; i++) kutu(0.14, 0.08, 0.04, ['#f97316', '#facc15', '#ec4899', '#22c55e'][i], -0.4 + i * 0.25, 0.7 + (i % 2) * 0.2, 0, g); },
    'mobilya:dj': (g) => { kutu(1.6, 0.9, 0.7, '#111827', 0, 0.45, 0, g); for (const x of [-0.45, 0.45]) { const p = new T.Mesh(new T.CylinderGeometry(0.25, 0.25, 0.04, 16), mat('#a855f7')); p.position.set(x, 0.92, 0); g.add(p); } kutu(1.6, 0.04, 0.05, '#22d3ee', 0, 0.6, 0.36, g); },
};
function mobilyaYap(id) { const g = new T.Group(); (MOBILYA[id] || MOBILYA['mobilya:masa'])(g, '#0ea5e9'); g.userData.esya = id; return g; }
function evKur(duzen) {
    dunyaGrup = new T.Group(); sahne.add(dunyaGrup); engeller = []; etkilesimler = []; evEsyalar = [];
    sahne.background = new T.Color('#fef3c7'); sahne.fog = null;
    const zemin = new T.Mesh(new T.PlaneGeometry(10, 10), mat('#d6a76c')); zemin.rotation.x = -Math.PI / 2; zemin.name = 'zemin'; dunyaGrup.add(zemin);
    for (let i = -5; i < 5; i += 1) kutu(0.02, 0.005, 10, '#b88a52', i, 0.005, 0);
    kutu(10, 3, 0.2, '#fde4cf', 0, 1.5, -5.1); kutu(0.2, 3, 10, '#fbcfe8', -5.1, 1.5, 0); kutu(0.2, 3, 10, '#fbcfe8', 5.1, 1.5, 0);
    kutu(1.6, 1.1, 0.05, '#bae6fd', -2, 1.8, -4.98); kutu(1.6, 1.1, 0.05, '#bae6fd', 2, 1.8, -4.98);
    const kapi = kutu(1.4, 0.05, 0.6, '#7c2d12', 0, 0.03, 4.6);
    etkilesimler.push({ x: 0, z: 4.6, ad: 'Şehre dön', eylem: () => sehreDon() });
    for (const e of duzen || []) esyaEkle(e);
}
function esyaEkle(e) { const m = mobilyaYap(e.id); m.position.set(e.x, 0, e.z); m.rotation.y = (e.r || 0) * Math.PI / 2; dunyaGrup.add(m); evEsyalar.push(m); return m; }

// ------------------------------------------------------------ çarpışma ve hareket
function itMe(p) {
    for (const e of engeller) {
        const cx = Math.max(e.x1, Math.min(p.x, e.x2)), cz = Math.max(e.z1, Math.min(p.z, e.z2));
        const dx = p.x - cx, dz = p.z - cz, d = Math.hypot(dx, dz), r = 0.4;
        if (d < r) { if (d === 0) { p.z = e.z2 + r; continue; } p.x = cx + dx / d * r; p.z = cz + dz / d * r; }
    }
    const s = mod === 'sehir' ? 58 : 4.6; p.x = Math.max(-s, Math.min(s, p.x)); p.z = Math.max(-s, Math.min(s, p.z));
}
function oyuncuEkle(d, benMi) {
    const o = { id: d.id, ad: d.ad, rozet: d.rozet, avatar: d.avatar, hedef: { x: d.x, z: d.z, ry: d.ry }, a: d.a || 0 };
    o.grup = new T.Group(); o.model = avatarYap(d.avatar); o.grup.add(o.model); o.grup.add(etiket(d.ad, d.rozet));
    o.grup.position.set(d.x, 0, d.z); o.model.rotation.y = d.ry || 0; o.grup.userData.oyuncu = d.id;
    sahne.add(o.grup);
    if (benMi) ben = o; else digerleri.set(d.id, o);
    return o;
}
function oyuncuSil(id) { const o = digerleri.get(id); if (o) { sahne.remove(o.grup); digerleri.delete(id); } oyuncuSayisi(); }
function avatarDegis(o, av) { o.avatar = av; o.grup.remove(o.model); o.model = avatarYap(av); o.grup.add(o.model); }

// ------------------------------------------------------------ ağ (WebSocket)
function baglan(oda) {
    if (ws) { ws.onclose = null; ws.close(); }
    for (const id of [...digerleri.keys()]) oyuncuSil(id);
    if (ben) { sahne.remove(ben.grup); ben = null; }
    wsOda = oda; durumYaz('Bağlanıyor…');
    ws = new WebSocket((location.protocol === 'https:' ? 'wss://' : 'ws://') + location.host + '/isorp/ws?oda=' + encodeURIComponent(oda));
    ws.onmessage = (e) => {
        const m = JSON.parse(e.data);
        if (m.t === 'hosgeldin') {
            for (const p of m.oyuncular) oyuncuEkle(p, p.id === m.ben);
            durumYaz(''); oyuncuSayisi(); $('is-oda').textContent = m.tur === 'ev' ? (evSahibi?.ad === S.ad ? 'Evim' : `${evSahibi?.ad} evi`) : 'İsorp Şehri · ' + m.oda.split('-')[1];
        } else if (m.t === 'katildi') { if (!digerleri.has(m.p.id) && m.p.id !== ben?.id) oyuncuEkle(m.p); oyuncuSayisi(); sohbetSatir(null, `${m.p.ad} geldi`); }
        else if (m.t === 'ayrildi') oyuncuSil(m.id);
        else if (m.t === 'konum') for (const [id, x, z, ry, a] of m.l) { const o = digerleri.get(id); if (o) { o.hedef = { x, z, ry }; o.a = a; } }
        else if (m.t === 'sohbet') { const o = m.id === ben?.id ? ben : digerleri.get(m.id); balonGoster(o, m.m); sohbetSatir(m, m.m); }
        else if (m.t === 'emoji') { const o = m.id === ben?.id ? ben : digerleri.get(m.id); balonGoster(o, m.e, true); }
        else if (m.t === 'avatar') { const o = m.id === ben?.id ? ben : digerleri.get(m.id); if (o) avatarDegis(o, m.avatar); }
        else if (m.t === 'duzelt' && ben) { ben.grup.position.x = m.x; ben.grup.position.z = m.z; }
        else if (m.t === 'uyari') bildir(m.m, false);
    };
    ws.onclose = (e) => { if (wsOda !== oda) return; durumYaz('Bağlantı koptu, yeniden bağlanılıyor…'); setTimeout(() => { if (wsOda === oda && !$('isorp-view').classList.contains('hidden')) baglan(oda); }, 3000); };
}
function gonder(m) { if (ws?.readyState === 1) ws.send(JSON.stringify(m)); }
function durumYaz(m) { const d = $('is-durum'); d.textContent = m; d.classList.toggle('hidden', !m); }
function oyuncuSayisi() { $('is-sayi').textContent = `👥 ${digerleri.size + (ben ? 1 : 0)}`; }

// ------------------------------------------------------------ döngü
let sonT = 0, adimT = 0;
function dongu(t) {
    if ($('isorp-view').classList.contains('hidden')) { durdur(); return; }  // başka sayfaya geçildi: bağlantıyı kapat
    kare = requestAnimationFrame(dongu);
    const dt = Math.min(0.05, (t - sonT) / 1000 || 0); sonT = t; adimT += dt;
    if (dunyaGrup?.userData.elmas) { dunyaGrup.userData.elmas.rotation.y += dt; dunyaGrup.userData.elmas.position.y = 3.2 + Math.sin(t / 600) * 0.15; }
    if (ben && !evDuzen) {
        let ix = (tus.d || tus.arrowright ? 1 : 0) - (tus.a || tus.arrowleft ? 1 : 0) + joy.x;
        let iz = (tus.s || tus.arrowdown ? 1 : 0) - (tus.w || tus.arrowup ? 1 : 0) + joy.y;
        const l = Math.hypot(ix, iz); const hareket = l > 0.1;
        if (hareket) {
            ix /= Math.max(1, l); iz /= Math.max(1, l);
            const hiz = 5.2 * (tus.shift ? 1.3 : 1);
            const sin = Math.sin(kamYaw), cos = Math.cos(kamYaw);
            const dx = (ix * cos + iz * sin) * hiz * dt, dz = (-ix * sin + iz * cos) * hiz * dt;
            const p = ben.grup.position; p.x += dx; p.z += dz; itMe(p);
            ben.model.rotation.y = Math.atan2(dx, dz);
        }
        ben.a = hareket ? 1 : 0;
        animasyon(ben.model, hareket, adimT);
        if (t - sonGonder > 100 && (hareket || ben.sonA !== ben.a)) { sonGonder = t; ben.sonA = ben.a; gonder({ t: 'hareket', x: +ben.grup.position.x.toFixed(2), z: +ben.grup.position.z.toFixed(2), ry: +ben.model.rotation.y.toFixed(2), a: ben.a }); }
        // yakındaki kapı / eylem
        let en = null, ed = 3.2;
        for (const e of etkilesimler) { const d = Math.hypot(e.x - ben.grup.position.x, e.z - ben.grup.position.z); if (d < ed) { ed = d; en = e; } }
        if (en !== yakin) { yakin = en; const b = $('is-eylem'); b.classList.toggle('hidden', !en); if (en) b.textContent = (DOKUNMA ? '' : '[E] ') + (en.ad === 'MAĞAZA' ? '🛍 Mağazaya gir' : en.ad === 'OYUN SALONU' ? '🎮 Oyun salonuna gir' : en.ad === 'EVİM' ? '🏠 Evine git' : '🚪 ' + en.ad); }
        // kamera
        const p = ben.grup.position;
        const hk = new T.Vector3(p.x + Math.sin(kamYaw) * Math.cos(kamPitch) * kamUzak, 1.6 + Math.sin(kamPitch) * kamUzak, p.z + Math.cos(kamYaw) * Math.cos(kamPitch) * kamUzak);
        kamera.position.lerp(hk, 1 - Math.pow(0.001, dt)); kamera.lookAt(p.x, 1.4, p.z);
    } else if (evDuzen) { kamera.position.set(0, 11, 7); kamera.lookAt(0, 0, 0); }
    for (const o of digerleri.values()) {
        const p = o.grup.position, k = 1 - Math.pow(0.0005, dt);
        p.x += (o.hedef.x - p.x) * k; p.z += (o.hedef.z - p.z) * k;
        let d = o.hedef.ry - o.model.rotation.y; d = Math.atan2(Math.sin(d), Math.cos(d)); o.model.rotation.y += d * k;
        animasyon(o.model, o.a === 1, adimT + o.id);
    }
    cizici.render(sahne, kamera);
}
function boyutla() {
    const k = $('is-sahne'); if (!k || !cizici) return;
    const w = k.clientWidth, h = k.clientHeight; cizici.setSize(w, h, false); kamera.aspect = w / h; kamera.updateProjectionMatrix();
}

// ------------------------------------------------------------ arayüz
function kur() {
    const m = el('main', 'hidden bg-slate-900'); m.id = 'isorp-view';
    m.innerHTML = `<div id="is-sahne" class="relative w-full overflow-hidden select-none" style="height:calc(100dvh - 81px);touch-action:none">
        <div class="absolute top-3 left-3 right-3 z-10 flex flex-wrap items-start justify-between gap-2 pointer-events-none">
            <div class="flex flex-wrap gap-2 pointer-events-auto"><span class="px-3 py-2 rounded-xl bg-slate-900/80 text-white text-xs sm:text-sm font-black shadow-lg">🪙 <span id="is-para">0</span></span>
                <span id="is-oda" class="px-3 py-2 rounded-xl bg-slate-900/80 text-white text-xs font-bold shadow-lg"></span><span id="is-sayi" class="px-3 py-2 rounded-xl bg-slate-900/80 text-white text-xs font-bold shadow-lg"></span></div>
            <div class="flex flex-wrap gap-2 justify-end pointer-events-auto" id="is-menu"></div>
        </div>
        <div id="is-durum" class="hidden absolute top-20 left-1/2 -translate-x-1/2 z-10 px-4 py-2 rounded-xl bg-black/70 text-white text-sm font-bold"></div>
        <button id="is-eylem" type="button" class="hidden absolute bottom-28 sm:bottom-24 left-1/2 -translate-x-1/2 z-10 px-6 py-3 rounded-2xl bg-gradient-to-r from-primary-500 to-accent-600 text-white font-black shadow-2xl text-sm sm:text-base"></button>
        <div id="is-joy" class="${DOKUNMA ? '' : 'hidden'} absolute left-5 bottom-24 z-10 w-32 h-32 rounded-full bg-white/20 border-2 border-white/40"><div class="absolute w-14 h-14 rounded-full bg-white/80 shadow-lg" style="left:36px;top:36px"></div></div>
        <div class="absolute left-3 right-3 bottom-3 z-10 flex flex-col gap-2 pointer-events-none">
            <div id="is-sohbet" class="max-w-md max-h-32 overflow-y-auto space-y-0.5 text-xs sm:text-sm pointer-events-auto"></div>
            <div id="is-emojiler" class="hidden flex flex-wrap gap-1 pointer-events-auto max-w-md bg-white/90 rounded-2xl p-2"></div>
            <form id="is-form" class="flex gap-2 pointer-events-auto max-w-xl"><button type="button" id="is-emo" class="w-11 h-11 rounded-xl bg-white/90 text-xl shrink-0">😀</button>
                <input id="is-girdi" maxlength="120" placeholder="Sohbet… (Enter)" class="flex-1 min-w-0 rounded-xl bg-white/90 px-3 text-sm outline-none" aria-label="Sohbet">
                <button class="w-11 h-11 rounded-xl bg-primary-600 text-white shrink-0" aria-label="Gönder"><i class="fa-solid fa-paper-plane"></i></button></form>
        </div>
        <div id="is-panel" class="hidden absolute inset-0 z-20 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-3"></div>
    </div>`;
    $('detail-page-view').before(m);
    YENI_GORUNUMLER.push('isorp-view'); TUM_GORUNUMLER.push('isorp-view');
    const menu = $('is-menu');
    for (const [y, f] of [['🧍 Avatar', avatarPaneli], ['🛍 Mağaza', magazaAc], ['🏠 Evim', evimeGit], ['🎮 Oyunlar', oyunSalonu], ['🏙 Şehir', () => sehreDon()], ['⛶', () => document.fullscreenElement ? document.exitFullscreen() : $('is-sahne').requestFullscreen?.()]])
        menu.appendChild(bt(y, HUD_BTN, f));
    $('is-eylem').onclick = () => yakin?.eylem();
    $('is-emo').onclick = () => $('is-emojiler').classList.toggle('hidden');
    for (const e of EMOJI) $('is-emojiler').appendChild(bt(e, 'w-9 h-9 text-xl hover:bg-slate-100 rounded-lg', () => { gonder({ t: 'emoji', e }); $('is-emojiler').classList.add('hidden'); }));
    $('is-form').addEventListener('submit', (e) => { e.preventDefault(); const i = $('is-girdi'); if (i.value.trim()) gonder({ t: 'sohbet', m: i.value }); i.value = ''; i.blur(); });
    // klavye
    addEventListener('keydown', (e) => {
        if ($('isorp-view').classList.contains('hidden') || ['INPUT', 'TEXTAREA', 'SELECT'].includes(document.activeElement?.tagName)) return;
        const k = e.key.toLowerCase(); tus[k] = true; if (e.shiftKey) tus.shift = true;
        if (k === 'e' && yakin) yakin.eylem();
        if (k === 'enter') { e.preventDefault(); $('is-girdi').focus(); }
        if (['arrowup', 'arrowdown', 'arrowleft', 'arrowright', ' '].includes(k)) e.preventDefault();
    });
    addEventListener('keyup', (e) => { tus[e.key.toLowerCase()] = false; if (!e.shiftKey) tus.shift = false; });
    addEventListener('blur', () => { for (const k in tus) tus[k] = false; });
    // joystick
    const j = $('is-joy'), top_ = j.firstElementChild; let jid = null;
    const jHareket = (t) => { const r = j.getBoundingClientRect(); let x = (t.clientX - r.left - 64) / 50, y = (t.clientY - r.top - 64) / 50; const l = Math.hypot(x, y); if (l > 1) { x /= l; y /= l; } joy = { x, y }; top_.style.left = 36 + x * 40 + 'px'; top_.style.top = 36 + y * 40 + 'px'; };
    j.addEventListener('pointerdown', (e) => { jid = e.pointerId; j.setPointerCapture(jid); jHareket(e); });
    j.addEventListener('pointermove', (e) => { if (e.pointerId === jid) jHareket(e); });
    const jBirak = () => { jid = null; joy = { x: 0, y: 0 }; top_.style.left = '36px'; top_.style.top = '36px'; };
    j.addEventListener('pointerup', jBirak); j.addEventListener('pointercancel', jBirak);
    addEventListener('resize', boyutla);
    const eskiKapat = window.closeAllViews;
    window.closeAllViews = function (...a) { durdur(); if (location.hash.startsWith('#isorp')) history.replaceState(null, '', location.pathname + location.search); return eskiKapat.apply(this, a); };
    for (const ad of ['openMimoView', 'openGameView', 'openYoneticiView']) { const e = window[ad]; window[ad] = function (...a) { durdur(); return e.apply(this, a); }; }
    // menü bağlantıları
    const lv = document.querySelector('nav a[href="#lives"]') || document.querySelector('nav a[href="#mimo"]');
    if (lv) { const a = el('a', 'hover:text-primary-600 transition-colors flex items-center gap-1.5 whitespace-nowrap'); a.href = '#isorp'; a.innerHTML = '🎮 İsorp'; lv.after(a); }
    const mob = document.querySelector('#mobile-menu a[href="#lives"]') || document.querySelector('#mobile-menu a[href="#mimo"]');
    if (mob) { const a = el('a', 'block px-4 py-2.5 rounded-xl bg-primary-50 text-primary-700 font-bold text-sm flex items-center gap-2'); a.href = '#isorp'; a.onclick = () => toggleMobileMenu(); a.textContent = '🎮 İsorp (oyna)'; mob.after(a); }
    addEventListener('hashchange', () => { if (location.hash === '#isorp') ac(); });
    const eskiG = window.hesapGoster; let ilk = true;
    window.hesapGoster = function (...a) { const r = eskiG.apply(this, a); if (ilk && location.hash === '#isorp') { ilk = false; ac(); } ilk = false; return r; };
}
function sahneKur() {
    if (cizici) return;
    tuval = document.createElement('canvas'); tuval.className = 'absolute inset-0 w-full h-full'; $('is-sahne').prepend(tuval);
    cizici = new T.WebGLRenderer({ canvas: tuval, antialias: !DOKUNMA }); cizici.setPixelRatio(Math.min(devicePixelRatio, DOKUNMA ? 1.25 : 1.75));
    sahne = new T.Scene(); kamera = new T.PerspectiveCamera(55, 1, 0.1, 200);
    sahne.add(new T.HemisphereLight('#ffffff', '#64748b', 0.9)); const g = new T.DirectionalLight('#ffffff', 0.7); g.position.set(20, 30, 10); sahne.add(g);
    // kamera döndürme (sürükle) + tıklayınca oyuncu kartı / eşya seçimi
    let surukle = null;
    tuval.addEventListener('pointerdown', (e) => { surukle = { x: e.clientX, y: e.clientY, yaw: kamYaw, pitch: kamPitch, hareket: false, id: e.pointerId }; });
    tuval.addEventListener('pointermove', (e) => {
        if (!surukle || surukle.id !== e.pointerId) return;
        const dx = e.clientX - surukle.x, dy = e.clientY - surukle.y; if (Math.hypot(dx, dy) > 6) surukle.hareket = true;
        if (evDuzen && secili && surukle.hareket) { const z = zeminNokta(e); if (z) { secili.position.x = Math.max(-4.4, Math.min(4.4, Math.round(z.x * 4) / 4)); secili.position.z = Math.max(-4.4, Math.min(4.4, Math.round(z.z * 4) / 4)); } return; }
        if (!evDuzen) { kamYaw = surukle.yaw - dx * 0.008; kamPitch = Math.max(0.12, Math.min(1.2, surukle.pitch + dy * 0.005)); }
    });
    tuval.addEventListener('pointerup', (e) => { if (surukle && !surukle.hareket) tikla(e); surukle = null; });
    tuval.addEventListener('wheel', (e) => { kamUzak = Math.max(4, Math.min(18, kamUzak + e.deltaY * 0.01)); e.preventDefault(); }, { passive: false });
}
const isin = new T.Raycaster();
function fareNokta(e) { const r = tuval.getBoundingClientRect(); return new T.Vector2(((e.clientX - r.left) / r.width) * 2 - 1, -((e.clientY - r.top) / r.height) * 2 + 1); }
function zeminNokta(e) { isin.setFromCamera(fareNokta(e), kamera); const z = dunyaGrup.children.find(c => c.name === 'zemin'); const h = z && isin.intersectObject(z)[0]; return h?.point; }
function tikla(e) {
    isin.setFromCamera(fareNokta(e), kamera);
    if (evDuzen) {
        const h = isin.intersectObjects(evEsyalar, true)[0];
        let o = h?.object; while (o && !o.userData.esya) o = o.parent;
        esyaSec(o || null); return;
    }
    const gruplar = [...digerleri.values()].map(o => o.grup);
    const h = isin.intersectObjects(gruplar, true)[0];
    let o = h?.object; while (o && o.userData.oyuncu === undefined) o = o.parent;
    if (o) oyuncuKarti(digerleri.get(o.userData.oyuncu));
}
function sohbetSatir(m, metin) {
    const k = $('is-sohbet'); const s = el('div', 'px-2 py-0.5 rounded-lg bg-black/45 text-white w-fit max-w-full break-words');
    if (m) { const a = el('b', m.rozet?.admin ? 'text-rose-300' : m.rozet?.pro ? 'text-amber-300' : 'text-emerald-300', m.ad + ': '); s.append(a, document.createTextNode(metin)); }
    else { s.className += ' italic text-white/70'; s.textContent = metin; }
    k.appendChild(s); while (k.children.length > 40) k.firstChild.remove(); k.scrollTop = k.scrollHeight;
}
function paraYaz() { $('is-para').textContent = sayi(S.para); }

function panel(baslik, genis) {
    const p = $('is-panel'); p.classList.remove('hidden'); p.replaceChildren();
    const k = el('div', 'bg-white rounded-3xl shadow-2xl w-full ' + (genis ? 'max-w-4xl' : 'max-w-lg') + ' max-h-[92%] overflow-y-auto p-4 sm:p-6 relative');
    const ust = el('div', 'flex items-center justify-between mb-4 sticky top-0 bg-white z-10 -mt-1 pt-1');
    ust.append(el('h2', 'font-display font-black text-xl sm:text-2xl text-slate-900', baslik), bt('✕', 'w-10 h-10 rounded-xl bg-slate-100 font-bold', panelKapat));
    k.appendChild(ust); p.appendChild(k);
    p.onclick = (e) => { if (e.target === p) panelKapat(); };
    return k;
}
function panelKapat() { const p = $('is-panel'); p.classList.add('hidden'); p.replaceChildren(); onizlemeDur?.(); }

// ------------------------------------------------------------ avatar düzenleyici (canlı önizleme)
let onizlemeDur = null;
function avatarPaneli() {
    const k = panel('🧍 Avatarını düzenle', true);
    const av = { ...S.avatar };
    const izg = el('div', 'grid grid-cols-1 md:grid-cols-[260px_1fr] gap-4'); k.appendChild(izg);
    const onz = el('div', 'rounded-2xl bg-gradient-to-b from-sky-100 to-emerald-50 h-64 md:h-[420px] relative overflow-hidden'); izg.appendChild(onz);
    const c = document.createElement('canvas'); c.className = 'w-full h-full'; onz.appendChild(c);
    const r = new T.WebGLRenderer({ canvas: c, antialias: true, alpha: true }); r.setPixelRatio(Math.min(devicePixelRatio, 2));
    const sc = new T.Scene(); sc.add(new T.HemisphereLight('#fff', '#94a3b8', 1)); const kam = new T.PerspectiveCamera(35, 1, 0.1, 50); kam.position.set(0, 1.3, 4.2); kam.lookAt(0, 1, 0);
    let model = null; const yenile = () => { if (model) sc.remove(model); model = avatarYap(av); sc.add(model); };
    yenile(); let calis = true, t0 = performance.now();
    const ciz = () => { if (!calis) return; const w = c.clientWidth, h = c.clientHeight; if (c.width !== w * r.getPixelRatio()) { r.setSize(w, h, false); kam.aspect = w / h; kam.updateProjectionMatrix(); } model.rotation.y = Math.sin((performance.now() - t0) / 1500) * 0.7; animasyon(model, false, (performance.now() - t0) / 1000); r.render(sc, kam); requestAnimationFrame(ciz); };
    ciz(); onizlemeDur = () => { calis = false; r.dispose(); onizlemeDur = null; };
    const sag = el('div', 'space-y-4'); izg.appendChild(sag);
    const env = S.envanter;
    const bolum = (baslik, alan, renkAlan) => {
        const b = el('div'); b.appendChild(el('div', 'text-xs font-black uppercase tracking-wider text-slate-500 mb-1.5', baslik));
        const sat = el('div', 'flex flex-wrap gap-1.5 items-center');
        for (const i of KATALOG.filter(x => x.id.startsWith(alan + ':'))) {
            const var_ = i.fiyat === 0 || env[i.id];
            const d = bt(i.ad.replace(' ✨', '') + (var_ ? '' : ' 🔒'), 'px-3 py-1.5 rounded-xl text-xs font-bold border-2 ' + (av[alan] === i.id ? 'border-primary-500 bg-primary-50 text-primary-700' : var_ ? 'border-slate-200' : 'border-slate-100 text-slate-400'), () => {
                if (!var_) { bildir('Önce mağazadan al: ' + i.ad, false); return; } av[alan] = i.id; yenile(); bolumler();
            });
            sat.appendChild(d);
        }
        if (renkAlan) { const r_ = el('input', 'w-10 h-9 rounded-lg border border-slate-200 ml-1'); r_.type = 'color'; r_.value = av[renkAlan]; r_.oninput = () => { av[renkAlan] = r_.value; yenile(); }; r_.setAttribute('aria-label', baslik + ' rengi'); sat.appendChild(r_); }
        b.appendChild(sat); return b;
    };
    const bolumler = () => {
        sag.replaceChildren();
        const t = el('div'); t.appendChild(el('div', 'text-xs font-black uppercase tracking-wider text-slate-500 mb-1.5', 'Ten'));
        const ts = el('div', 'flex gap-2'); for (const r_ of TENLER) { const b = bt('', 'w-9 h-9 rounded-full border-4 ' + (av.ten === r_ ? 'border-primary-500' : 'border-white shadow'), () => { av.ten = r_; yenile(); bolumler(); }); b.style.background = r_; b.setAttribute('aria-label', 'Ten ' + r_); ts.appendChild(b); }
        t.appendChild(ts); sag.appendChild(t);
        sag.append(bolum('Saç', 'sac', 'sac_renk'), bolum('Üst', 'ust', 'ust_renk'), bolum('Alt', 'alt', 'alt_renk'), bolum('Ayakkabı', 'ayakkabi', 'ayakkabi_renk'), bolum('Aksesuar', 'aksesuar', 'aksesuar_renk'));
        const by = el('label', 'block text-xs font-black uppercase tracking-wider text-slate-500'); by.textContent = 'Boy';
        const bi = el('input', 'w-full accent-emerald-600'); bi.type = 'range'; bi.min = 0.9; bi.max = 1.1; bi.step = 0.01; bi.value = av.boy || 1; bi.oninput = () => { av.boy = +bi.value; yenile(); }; by.appendChild(bi); sag.appendChild(by);
        sag.appendChild(bt('💾 Kaydet', BUTON + ' w-full py-3', async () => {
            try { const r_ = await api('avatar', { avatar: av }); S.avatar = r_.avatar; gonder({ t: 'avatar' }); bildir('Avatar kaydedildi ✓'); panelKapat(); } catch (e) { bildir(e.message, false); }
        }));
        sag.appendChild(el('p', 'text-xs text-slate-500', '🔒 olanları mağazadan alabilirsin. Renkler ücretsiz.'));
    };
    bolumler();
}

// ------------------------------------------------------------ mağaza
function magazaAc() {
    const k = panel('🛍 İsorp Mağazası', true);
    const ust = el('div', 'flex flex-wrap items-center justify-between gap-2 mb-4 rounded-2xl bg-amber-50 border border-amber-200 p-3');
    ust.appendChild(el('div', 'font-black text-amber-900', `🪙 ${sayi(S.para)} para`));
    if (S.gunluk_alinabilir) ust.appendChild(bt('🎁 Günlük ödülü al (+100)', 'px-4 py-2 rounded-xl bg-amber-400 text-amber-950 text-sm font-black', async () => { try { const r = await api('gunluk', {}); S = r.oyuncu; paraYaz(); bildir(`+${r.odul} para 🎉`); magazaAc(); } catch (e) { bildir(e.message, false); } }));
    else ust.appendChild(el('span', 'text-xs text-amber-800', 'Günlük ödül alındı · yarın yine gel'));
    k.appendChild(ust);
    const gruplar = [['sac', '💇 Saç'], ['ust', '👕 Üst'], ['alt', '👖 Alt'], ['ayakkabi', '👟 Ayakkabı'], ['aksesuar', '🎩 Aksesuar'], ['mobilya', '🛋 Mobilya']];
    for (const [g, ad] of gruplar) {
        k.appendChild(el('h3', 'font-black text-slate-900 mt-4 mb-2', ad));
        const iz = el('div', 'grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2');
        for (const i of KATALOG.filter(x => x.id.startsWith(g + ':') && x.fiyat > 0)) {
            const var_ = S.envanter[i.id] || 0, mob = g === 'mobilya';
            const c = el('div', 'rounded-2xl border p-3 flex flex-col gap-1 ' + (i.pro ? 'border-amber-300 bg-gradient-to-br from-amber-50 to-white' : 'border-slate-200'));
            c.append(el('div', 'font-bold text-sm text-slate-900', i.ad), el('div', 'text-xs text-slate-500', mob && var_ ? `Elinde: ${var_}` : var_ ? 'Sende var ✓' : (i.pro ? '👑 Pro üyelere özel' : '')));
            const fiyat = el('div', 'font-black text-amber-700 text-sm', `🪙 ${i.fiyat}`); c.appendChild(fiyat);
            if (!var_ || mob) c.appendChild(bt(i.pro && !(S.pro || S.yonetici) ? 'Pro gerekli' : 'Satın al', 'mt-1 px-3 py-1.5 rounded-xl text-xs font-black ' + (i.pro && !(S.pro || S.yonetici) ? 'bg-slate-100 text-slate-500' : S.para >= i.fiyat ? 'bg-primary-600 text-white' : 'bg-slate-100 text-slate-400'), async () => {
                if (i.pro && !(S.pro || S.yonetici)) { panelKapat(); openUyelik?.(); return; }
                try { S = (await api('satin_al', { esya: i.id })).oyuncu; paraYaz(); bildir(`${i.ad} alındı 🎉`); magazaAc(); } catch (e) { bildir(e.message, false); }
            }));
            iz.appendChild(c);
        }
        k.appendChild(iz);
    }
}

// ------------------------------------------------------------ ev: kendi evin / ziyaret, eşya yerleştirme
async function evimeGit() { panelKapat(); evSahibi = { ad: S.ad, id: S.id }; dunyaGecis('ev', S.ev); baglan('ev:' + S.id); evAraclari(); }
async function evZiyaret(ad) {
    panelKapat();
    try { const d = await api('ev?ad=' + encodeURIComponent(ad)); evSahibi = { ad: d.ad, id: d.id }; dunyaGecis('ev', d.ev); baglan('ev:' + d.id); evAraclari(); } catch (e) { bildir(e.message, false); }
}
function sehreDon() { panelKapat(); evDuzen = false; evSahibi = null; dunyaGecis('sehir'); baglan('sehir'); evAraclari(); }
function dunyaGecis(m, duzen) {
    mod = m; if (dunyaGrup) sahne.remove(dunyaGrup);
    if (m === 'sehir') sehirKur(); else evKur(duzen);
    kamUzak = m === 'ev' ? 7 : 9; yakin = null; $('is-eylem').classList.add('hidden');
}
function evAraclari() {
    document.getElementById('is-evarac')?.remove();
    if (mod !== 'ev' || evSahibi?.id !== S.id) return;
    const a = el('div', 'absolute top-16 left-3 z-10 flex flex-col gap-2'); a.id = 'is-evarac';
    a.appendChild(bt(evDuzen ? '✓ Düzenlemeyi bitir' : '🛠 Evi düzenle', HUD_BTN, () => { evDuzen ? duzenBitir() : duzenBasla(); }));
    if (evDuzen) {
        const ek = bt('➕ Eşya ekle', HUD_BTN, () => esyaListesi()); a.appendChild(ek);
        const sec = el('div', 'flex gap-1.5'); sec.id = 'is-secarac';
        sec.append(bt('⟳ Döndür', HUD_BTN, () => { if (secili) secili.rotation.y += Math.PI / 2; }), bt('🗑 Kaldır', HUD_BTN, () => { if (secili) { dunyaGrup.remove(secili); evEsyalar.splice(evEsyalar.indexOf(secili), 1); esyaSec(null); } }));
        sec.classList.toggle('hidden', !secili); a.appendChild(sec);
        a.appendChild(el('div', 'px-3 py-2 rounded-xl bg-slate-900/80 text-white text-[11px] max-w-[200px]', 'Eşyaya dokun → seç; sürükleyerek taşı.'));
    }
    $('is-sahne').appendChild(a);
}
function duzenBasla() { evDuzen = true; evAraclari(); }
async function duzenBitir() {
    const esyalar = evEsyalar.map(m => ({ id: m.userData.esya, x: +m.position.x.toFixed(2), z: +m.position.z.toFixed(2), r: Math.round(m.rotation.y / (Math.PI / 2)) % 4 }));
    try { S.ev = (await api('ev', { esyalar })).ev; bildir('Evin kaydedildi ✓'); evDuzen = false; esyaSec(null); evAraclari(); } catch (e) { bildir(e.message, false); }
}
function esyaSec(m) {
    if (secili) secili.traverse(o => { if (o.material?.emissive) o.material.emissive.set('#000000'); });
    secili = m;
    if (secili) secili.traverse(o => { if (o.material?.emissive) { o.material = o.material.clone(); o.material.emissive.set('#1d4ed8'); } });
    document.getElementById('is-secarac')?.classList.toggle('hidden', !secili);
}
function esyaListesi() {
    const k = panel('➕ Eşya ekle');
    const say = {}; for (const m of evEsyalar) say[m.userData.esya] = (say[m.userData.esya] || 0) + 1;
    const l = KATALOG.filter(i => i.id.startsWith('mobilya:') && (S.envanter[i.id] || 0) > 0);
    if (!l.length) { k.appendChild(el('p', 'text-sm text-slate-500 mb-3', 'Henüz mobilyan yok. Mağazadan alabilirsin.')); k.appendChild(bt('🛍 Mağazaya git', BUTON, magazaAc)); return; }
    const iz = el('div', 'grid grid-cols-2 gap-2'); k.appendChild(iz);
    for (const i of l) {
        const kalan = S.envanter[i.id] - (say[i.id] || 0);
        iz.appendChild(bt(`${i.ad.replace(' ✨', '')} (${kalan})`, 'px-3 py-3 rounded-2xl border-2 text-sm font-bold ' + (kalan > 0 ? 'border-slate-200 hover:border-primary-400' : 'border-slate-100 text-slate-400'), () => {
            if (kalan <= 0) return bildir('Hepsini yerleştirdin; mağazadan bir tane daha alabilirsin', false);
            panelKapat(); const m = esyaEkle({ id: i.id, x: 0, z: 0, r: 0 }); esyaSec(m); evAraclari();
        }));
    }
}

// ------------------------------------------------------------ oyuncu kartı
function oyuncuKarti(o) {
    if (!o) return;
    const k = panel(o.ad);
    const r = o.rozet || {};
    const rz = el('div', 'flex flex-wrap gap-1.5 mb-4');
    if (r.admin) rz.appendChild(el('span', 'px-2 py-1 rounded-lg text-xs font-black text-white bg-rose-700', '💎 Yönetici'));
    if (r.pro) rz.appendChild(el('span', 'px-2 py-1 rounded-lg text-xs font-black text-amber-950 bg-amber-300', '👑 Pro'));
    if (r.onayli) rz.appendChild(el('span', 'px-2 py-1 rounded-lg text-xs font-black bg-blue-100 text-blue-700', '✓ Onaylı'));
    k.appendChild(rz);
    const b = el('div', 'grid gap-2'); k.appendChild(b);
    b.append(bt('🏠 Evini ziyaret et', BUTON + ' py-3', () => evZiyaret(o.ad)), bt('📺 Lives profili', KUCUK + ' py-3', () => { panelKapat(); location.hash = 'lives/u/' + encodeURIComponent(o.ad); }),
        bt('👋 El salla', KUCUK + ' py-3', () => { gonder({ t: 'emoji', e: '👋' }); panelKapat(); }),
        bt('⚑ Raporla', 'px-3 py-3 rounded-lg text-xs font-bold bg-red-50 text-red-600', async () => { const n = prompt('Neden raporluyorsun?'); if (!n) return; try { await fetch('/api/lives/rapor', { method: 'POST', credentials: 'same-origin', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ hedef_tur: 'kullanici', hedef_id: o.id, neden: 'İsorp: ' + n }) }); bildir('Rapor iletildi'); panelKapat(); } catch (e) { bildir('Gönderilemedi', false); } }));
}

// ------------------------------------------------------------ oyun salonu: mini oyunlar
async function oyunSalonu() {
    const k = panel('🎮 Oyun Salonu');
    k.appendChild(el('p', 'text-sm text-slate-600 mb-4', `Oyna, para kazan. Bugün mini oyunlardan kazanabileceğin: 🪙 ${S.oyun_kalan}`));
    for (const [id, ad, ac, f] of [['para_yagmuru', '💰 Para Yağmuru', '45 saniye boyunca yağan paraları topla, bombalardan kaç. Para başına 2 🪙.', paraYagmuru], ['hafiza', '🃏 Hafıza Kartları', '8 çifti en az hamleyle bul. Daha az hamle = daha çok para (en çok 48 🪙).', hafiza]]) {
        const c = el('div', 'rounded-2xl border border-slate-200 p-4 mb-3');
        c.append(el('div', 'font-black text-slate-900', ad), el('p', 'text-xs text-slate-500 mb-2', ac));
        const sk = el('div', 'text-xs text-slate-600 mb-2'); c.appendChild(sk);
        api('skorlar?oyun=' + id).then(d => { sk.textContent = d.skorlar.length ? '🏆 ' + d.skorlar.slice(0, 5).map((s, i) => `${i + 1}. ${s.ad} (${s.skor})`).join(' · ') : 'Henüz skor yok, ilk sen ol!'; }).catch(() => {});
        c.appendChild(bt('▶ Oyna', BUTON, () => f()));
        k.appendChild(c);
    }
}
async function oyunBitir(jeton, skor, ad) {
    try {
        const r = await api('oyun_bitir', { jeton, skor });
        S = r.oyuncu; paraYaz();
        const k = panel('🏁 ' + ad);
        k.append(el('div', 'text-center text-5xl mb-2', r.kazanc ? '🎉' : '🙂'), el('div', 'text-center font-black text-2xl text-slate-900', `Skor: ${skor}`),
            el('div', 'text-center text-lg font-bold text-amber-700 mt-1', `+${r.kazanc} 🪙`), el('div', 'text-center text-xs text-slate-500 mt-1', `Rekorun: ${r.rekor}${r.tavan_doldu ? ' · Bugünkü mini oyun kazanç sınırına ulaştın' : ''}`));
        k.appendChild(el('div', 'grid grid-cols-2 gap-2 mt-5')).append(bt('🔁 Tekrar', BUTON, () => (ad.includes('Para') ? paraYagmuru : hafiza)()), bt('Kapat', KUCUK + ' py-3', panelKapat));
    } catch (e) { bildir(e.message, false); panelKapat(); }
}
async function paraYagmuru() {
    let jeton; try { jeton = (await api('oyun_basla', { oyun: 'para_yagmuru' })).jeton; } catch (e) { return bildir(e.message, false); }
    const k = panel('💰 Para Yağmuru', true);
    const c = document.createElement('canvas'); c.width = 640; c.height = 400; c.className = 'w-full rounded-2xl bg-sky-200 touch-none'; k.appendChild(c);
    const bilgi = el('div', 'flex justify-between font-black text-slate-800 mt-2'); k.appendChild(bilgi);
    k.appendChild(el('p', 'text-xs text-slate-500 mt-1', '← → tuşları ya da parmağınla sürükle.'));
    const x = c.getContext('2d'); let px = 320, skor = 0, d = [], bitti = false; const bas = performance.now(); let sonDog = 0;
    const tus_ = {}; const kd = (e) => { tus_[e.key] = e.type === 'keydown'; }; addEventListener('keydown', kd); addEventListener('keyup', kd);
    c.addEventListener('pointermove', (e) => { const r = c.getBoundingClientRect(); px = (e.clientX - r.left) / r.width * 640; });
    c.addEventListener('pointerdown', (e) => { const r = c.getBoundingClientRect(); px = (e.clientX - r.left) / r.width * 640; });
    let son = performance.now();
    const ciz = (t) => {
        if (bitti || $('is-panel').classList.contains('hidden')) { removeEventListener('keydown', kd); removeEventListener('keyup', kd); return; }
        const dt = (t - son) / 1000; son = t; const gecen = (t - bas) / 1000, kalan = Math.max(0, 45 - gecen);
        if (tus_.ArrowLeft) px -= 420 * dt; if (tus_.ArrowRight) px += 420 * dt; px = Math.max(30, Math.min(610, px));
        if (t - sonDog > 500) { sonDog = t; d.push({ x: 20 + Math.random() * 600, y: -20, v: 140 + Math.random() * 120 + gecen * 3, bomba: Math.random() < 0.22 }); }
        x.fillStyle = '#bae6fd'; x.fillRect(0, 0, 640, 400); x.fillStyle = '#86efac'; x.fillRect(0, 360, 640, 40);
        for (const o of d) {
            o.y += o.v * dt;
            if (!o.al && o.y > 320 && o.y < 365 && Math.abs(o.x - px) < 44) { o.al = true; if (o.bomba) skor = Math.max(0, skor - 3); else skor++; }
            if (!o.al) { x.font = '30px system-ui'; x.textAlign = 'center'; x.fillText(o.bomba ? '💣' : '🪙', o.x, o.y); }
        }
        d = d.filter(o => !o.al && o.y < 420);
        x.fillStyle = S.avatar.ust_renk; x.fillRect(px - 40, 330, 80, 26); x.fillStyle = S.avatar.ten; x.beginPath(); x.arc(px, 316, 16, 0, 7); x.fill();
        bilgi.replaceChildren(el('span', '', `🪙 ${skor}`), el('span', '', `⏱ ${Math.ceil(kalan)} sn`));
        if (kalan <= 0) { bitti = true; removeEventListener('keydown', kd); removeEventListener('keyup', kd); return oyunBitir(jeton, skor, 'Para Yağmuru'); }
        requestAnimationFrame(ciz);
    };
    requestAnimationFrame(ciz);
}
async function hafiza() {
    let jeton; try { jeton = (await api('oyun_basla', { oyun: 'hafiza' })).jeton; } catch (e) { return bildir(e.message, false); }
    const k = panel('🃏 Hafıza Kartları');
    const kartlar = ['🎮', '🚀', '💎', '🍕', '🎧', '🐱', '⚽', '🌈'].flatMap(x => [x, x]).sort(() => Math.random() - 0.5);
    const iz = el('div', 'grid grid-cols-4 gap-2'); k.appendChild(iz);
    const bilgi = el('div', 'text-center font-black text-slate-800 mt-3'); k.appendChild(bilgi);
    let acik = [], bulunan = 0, hamle = 0, kilit = false;
    const yaz = () => { bilgi.textContent = `Hamle: ${hamle} · Bulunan: ${bulunan}/8`; };
    kartlar.forEach((e, i) => {
        const b = bt('', 'aspect-square rounded-2xl bg-gradient-to-br from-primary-500 to-accent-600 text-3xl sm:text-4xl font-black text-white shadow transition-transform', async () => {
            if (kilit || b.dataset.acik) return;
            b.dataset.acik = '1'; b.textContent = e; b.className = b.className.replace('from-primary-500 to-accent-600 text-white', 'from-white to-slate-100 text-slate-900');
            acik.push(b);
            if (acik.length === 2) {
                hamle++; kilit = true;
                const [x1, x2] = acik;
                if (x1.textContent === x2.textContent) { bulunan++; acik = []; kilit = false; }
                else { await new Promise(r => setTimeout(r, 700)); for (const x of acik) { delete x.dataset.acik; x.textContent = ''; x.className = x.className.replace('from-white to-slate-100 text-slate-900', 'from-primary-500 to-accent-600 text-white'); } acik = []; kilit = false; }
                yaz();
                if (bulunan === 8) { const skor = Math.max(1, Math.min(8, 8 - Math.floor(Math.max(0, hamle - 10) / 3))); setTimeout(() => oyunBitir(jeton, skor, 'Hafıza Kartları'), 500); }
            }
        });
        iz.appendChild(b);
    });
    yaz();
}

// ------------------------------------------------------------ açma / kapama
async function ac() {
    gorunum('isorp-view');
    $('top-back-btn').classList.remove('hidden');
    if (!hesapBen) { const k = panel('🎮 İsorp'); k.append(el('p', 'text-sm text-slate-600 mb-4', 'İsorp, Mertixtan\'ın çok oyunculu şehir oyunu. Mertixtan hesabınla giriş yap; yeni hesap gerekmez.'), bt('Giriş yap', BUTON + ' w-full py-3', () => hesapPencere('giris'))); return; }
    try { const d = await api('ben'); S = d.oyuncu; KATALOG = d.katalog; TENLER = d.tenler; } catch (e) { bildir(e.message, false); return; }
    sahneKur(); boyutla(); paraYaz();
    if (!kare) { sonT = performance.now(); kare = requestAnimationFrame(dongu); }
    if (!wsOda) { dunyaGecis('sehir'); baglan('sehir'); }
    if (S.gunluk_alinabilir) setTimeout(() => bildir('🎁 Mağazada günlük ödülün seni bekliyor!'), 1500);
    setTimeout(boyutla, 50);
}
function durdur() {
    if (kare) { cancelAnimationFrame(kare); kare = null; }
    if (ws) { wsOda = null; ws.onclose = null; ws.close(); ws = null; }
    panelKapat();
}
window.openIsorp = () => { location.hash = 'isorp'; ac(); };
kur();
})();
