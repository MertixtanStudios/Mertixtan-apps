#!/usr/bin/env bash
# Mertixtan Studios: siteyi ve MIMO'yu sunucuda canlıya alır. Yükleyici paketi açınca bunu root olarak çalıştırır.
# Elle de çalışır:  cd <paket klasörü> && bash kur.sh
set -euo pipefail
PAKET="$(cd "$(dirname "$0")" && pwd)"
SITE=/var/www/mertixtan
MIMO=/opt/mimo
adim() { echo; echo "==> $*"; }

adim "Gerekli programlar kuruluyor"
export DEBIAN_FRONTEND=noninteractive
apt-get update -y -qq
apt-get install -y -qq nginx git cmake build-essential ca-certificates openssl curl >/dev/null

adim "Site yayına alınıyor"
mkdir -p "$SITE"
cp -r "$PAKET/site/." "$SITE/"
chown -R www-data:www-data "$SITE"

adim "MIMO hazırlanıyor"
mkdir -p "$MIMO"
if [ ! -x "$MIMO/llama.cpp/build/bin/llama-server" ]; then
  echo "llama.cpp derleniyor (ilk kurulumda 5-15 dakika sürer)..."
  [ -d "$MIMO/llama.cpp" ] || git clone -q --depth 1 https://github.com/ggml-org/llama.cpp "$MIMO/llama.cpp"
  cmake -S "$MIMO/llama.cpp" -B "$MIMO/llama.cpp/build" -DCMAKE_BUILD_TYPE=Release -DLLAMA_CURL=OFF -DGGML_NATIVE=ON >/dev/null
  cmake --build "$MIMO/llama.cpp/build" --target llama-server -j "$(nproc)" >/dev/null
fi
# MIMO'nun çekirdeği: Qwen2.5-Coder-7B-Instruct (Apache 2.0). Bellek yetmezse 3B sürümü.
# /opt/mimo/model_adi hangi modelin kurulu olduğunu tutar. "ozel" = yükleyiciyle elle atılmış model, dokunulmaz.
gguf_mu() { [ -f "$1" ] && [ "$(head -c 4 "$1")" = "GGUF" ] && [ "$(stat -c %s "$1")" -ge "${MIN_BOYUT:-500000000}" ]; }
RAM_MB=$(awk '/MemTotal/ {print int($2/1024)}' /proc/meminfo)
if [ "$RAM_MB" -ge 7000 ]; then
  ISTENEN="qwen2.5-coder-7b-q4km"; ACIKLAMA="Qwen2.5-Coder 7B (~4.7 GB)"
  URLLER="https://huggingface.co/bartowski/Qwen2.5-Coder-7B-Instruct-GGUF/resolve/main/Qwen2.5-Coder-7B-Instruct-Q4_K_M.gguf
https://huggingface.co/unsloth/Qwen2.5-Coder-7B-Instruct-GGUF/resolve/main/Qwen2.5-Coder-7B-Instruct-Q4_K_M.gguf
https://huggingface.co/Qwen/Qwen2.5-Coder-7B-Instruct-GGUF/resolve/main/qwen2.5-coder-7b-instruct-q4_k_m.gguf"
else
  ISTENEN="qwen2.5-coder-3b-q4km"; ACIKLAMA="Qwen2.5-Coder 3B (bellek ${RAM_MB} MB, 7B sığmaz; ~2 GB)"
  URLLER="https://huggingface.co/bartowski/Qwen2.5-Coder-3B-Instruct-GGUF/resolve/main/Qwen2.5-Coder-3B-Instruct-Q4_K_M.gguf
https://huggingface.co/Qwen/Qwen2.5-Coder-3B-Instruct-GGUF/resolve/main/qwen2.5-coder-3b-instruct-q4_k_m.gguf"
fi
[ -n "${MODEL_URLLERI:-}" ] && URLLER="$MODEL_URLLERI"
KURULU=$(cat "$MIMO/model_adi" 2>/dev/null || true)
if [ "$KURULU" = "ozel" ] && gguf_mu "$MIMO/mimo.gguf"; then
  echo "Elle yüklenmiş özel model kullanılıyor (değiştirilmedi)."
elif [ "$KURULU" = "$ISTENEN" ] && gguf_mu "$MIMO/mimo.gguf"; then
  echo "MIMO çekirdeği hazır: $ACIKLAMA"
else
  echo "MIMO'nun çekirdeği indiriliyor: $ACIKLAMA (bağlantına göre 2-15 dakika)..."
  INDI=0
  for u in $URLLER; do
    echo "  deneniyor: $u"
    if curl -fL --retry 3 --connect-timeout 20 -o "$MIMO/indirilen.gguf" "$u" 2>/dev/null && gguf_mu "$MIMO/indirilen.gguf"; then
      mv "$MIMO/indirilen.gguf" "$MIMO/mimo.gguf"; echo "$ISTENEN" > "$MIMO/model_adi"; echo "  indirildi ✓"; INDI=1; break
    fi
    rm -f "$MIMO/indirilen.gguf"
  done
  if [ "$INDI" = 0 ]; then
    echo "UYARI: Model indirilemedi (Hugging Face erişimini kontrol et). Eldeki model kullanılıyor."
    [ -f "$MIMO/mimo.gguf" ] || cp "$PAKET/model/mimo.gguf" "$MIMO/mimo.gguf" 2>/dev/null || true
  fi
fi
[ -f "$MIMO/anahtar" ] || openssl rand -hex 24 > "$MIMO/anahtar"
id mimo >/dev/null 2>&1 || useradd --system --home "$MIMO" --shell /usr/sbin/nologin mimo
chown mimo:mimo "$MIMO/anahtar"; chmod 600 "$MIMO/anahtar"
[ -f "$MIMO/mimo.gguf" ] && chown mimo:mimo "$MIMO/mimo.gguf"
ANAHTAR=$(cat "$MIMO/anahtar")

IPLIK=$(( $(nproc) > 2 ? $(nproc) - 1 : 1 ))  # bir çekirdek canlı yayın ve site için boş kalsın
# MIMO yalnızca sunucunun içinden erişilir (127.0.0.1); dışarıya nginx üzerinden açılır
cat > /etc/systemd/system/mimo.service <<SERVIS
[Unit]
Description=MIMO yapay zeka (llama.cpp)
After=network-online.target

[Service]
User=mimo
ExecStart=$MIMO/llama.cpp/build/bin/llama-server -m $MIMO/mimo.gguf --host 127.0.0.1 --port 8080 --api-key-file $MIMO/anahtar --jinja --alias mimo --threads $IPLIK --ctx-size 8192 --parallel 2 --n-predict 1024
Restart=always
RestartSec=5
NoNewPrivileges=true
PrivateTmp=true
ProtectSystem=strict
ProtectHome=true
ProtectKernelTunables=true
ProtectKernelModules=true
ProtectControlGroups=true
RestrictSUIDSGID=true
LockPersonality=true
RestrictAddressFamilies=AF_INET AF_INET6 AF_UNIX

[Install]
WantedBy=multi-user.target
SERVIS
systemctl daemon-reload
if [ -f "$MIMO/mimo.gguf" ]; then systemctl enable -q mimo; systemctl restart mimo; fi

adim "Mertixtan Lives: canlı yayın sunucusu (LiveKit)"
mkdir -p /opt/livekit /etc/mertixtan; chmod 700 /etc/mertixtan
if [ "$(uname -m)" = x86_64 ] && [ -f "$PAKET/livekit/livekit-server" ]; then
  install -m 755 "$PAKET/livekit/livekit-server" /opt/livekit/livekit-server.yeni && mv /opt/livekit/livekit-server.yeni /opt/livekit/livekit-server
elif [ ! -x /opt/livekit/livekit-server ]; then
  echo "Bu işlemci ($(uname -m)) için LiveKit resmi kurulum betiğiyle indiriliyor..."
  curl -sSL https://get.livekit.io | bash && cp "$(command -v livekit-server)" /opt/livekit/livekit-server
fi
/opt/livekit/livekit-server --version || echo "UYARI: LiveKit kurulamadı; canlı görüntü/ses çalışmaz (sohbet ve program yine çalışır)."
if [ ! -f /etc/mertixtan/livekit.env ]; then
  printf 'LIVEKIT_KEY=API%s\nLIVEKIT_SECRET=%s\nLIVEKIT_URL=http://127.0.0.1:7880\nKAPAK_DIZIN=/var/lib/mertixtan-kapak\n' "$(openssl rand -hex 6)" "$(openssl rand -hex 32)" > /etc/mertixtan/livekit.env
  chmod 600 /etc/mertixtan/livekit.env
fi
. /etc/mertixtan/livekit.env
id livekit >/dev/null 2>&1 || useradd --system --no-create-home --shell /usr/sbin/nologin livekit
cat > /etc/livekit.yaml <<LKAYAR
port: 7880
rtc:
  tcp_port: 7881
  port_range_start: 50000
  port_range_end: 50200
  use_external_ip: ${LK_DIS_IP:-true}
turn:
  enabled: true
  udp_port: 3478
  domain: ${ALAN:-mertixtanstudios.com}
keys:
  $LIVEKIT_KEY: $LIVEKIT_SECRET
room:
  empty_timeout: 300
  departure_timeout: 20
logging:
  level: warn
LKAYAR
chown root:livekit /etc/livekit.yaml; chmod 640 /etc/livekit.yaml
cat > /etc/systemd/system/livekit.service <<'SERVIS'
[Unit]
Description=Mertixtan Lives medya sunucusu (LiveKit)
After=network-online.target

[Service]
User=livekit
ExecStart=/opt/livekit/livekit-server --config /etc/livekit.yaml
Restart=always
RestartSec=3
LimitNOFILE=65535
NoNewPrivileges=true
PrivateTmp=true
ProtectSystem=strict
ProtectHome=true

[Install]
WantedBy=multi-user.target
SERVIS
mkdir -p /var/lib/mertixtan-kapak
systemctl daemon-reload; systemctl enable -q livekit; systemctl restart livekit
if command -v ufw >/dev/null && ufw status | grep -q "Status: active"; then
  ufw allow 7881/tcp >/dev/null; ufw allow 50000:50200/udp >/dev/null; ufw allow 3478/udp >/dev/null
fi

adim "Hesap sistemi (giriş / kayıt / yönetici paneli) kuruluyor"
id mertixtan >/dev/null 2>&1 || useradd --system --home /var/lib/mertixtan --shell /usr/sbin/nologin mertixtan
mkdir -p /opt/mertixtan/hesap /var/lib/mertixtan
cp "$PAKET/hesap/hesap.py" "$PAKET/hesap/site_api.py" "$PAKET/hesap/lives.py" "$PAKET/hesap/yedek.py" /opt/mertixtan/hesap/
chown mertixtan:mertixtan /var/lib/mertixtan-kapak; chmod 755 /var/lib/mertixtan-kapak
chown -R root:root /opt/mertixtan/hesap; chmod 755 /opt/mertixtan/hesap; chmod 644 /opt/mertixtan/hesap/*.py
chmod 755 /opt/mertixtan; chmod 700 /opt/mertixtan/paket 2>/dev/null || true; chmod 600 /opt/mertixtan/son_paket.zip 2>/dev/null || true
chown -R mertixtan:mertixtan /var/lib/mertixtan; chmod 700 /var/lib/mertixtan
cat > /etc/systemd/system/mertixtan-hesap.service <<SERVIS
[Unit]
Description=Mertixtan hesap servisi
After=network-online.target

[Service]
User=mertixtan
Environment=HESAP_DB=/var/lib/mertixtan/hesap.db
EnvironmentFile=-/etc/mertixtan/livekit.env
ExecStart=/usr/bin/python3 /opt/mertixtan/hesap/hesap.py
Restart=always
RestartSec=3
ReadWritePaths=/var/lib/mertixtan /var/lib/mertixtan-kapak
NoNewPrivileges=true
PrivateTmp=true
ProtectSystem=strict
ProtectHome=true
ProtectKernelTunables=true
ProtectKernelModules=true
ProtectControlGroups=true
RestrictSUIDSGID=true
LockPersonality=true
RestrictAddressFamilies=AF_INET AF_INET6 AF_UNIX

[Install]
WantedBy=multi-user.target
SERVIS
systemctl daemon-reload
systemctl enable -q mertixtan-hesap
systemctl restart mertixtan-hesap

adim "Gece yedeklemesi kuruluyor"
cp "$PAKET/hesap/yedek.py" /opt/mertixtan/hesap/; chmod 644 /opt/mertixtan/hesap/yedek.py
mkdir -p /var/lib/mertixtan/yedek; chown mertixtan:mertixtan /var/lib/mertixtan/yedek; chmod 700 /var/lib/mertixtan/yedek
cat > /etc/systemd/system/mertixtan-yedek.service <<'SERVIS'
[Unit]
Description=Mertixtan veritabanı yedeği
[Service]
Type=oneshot
User=mertixtan
Environment=HESAP_DB=/var/lib/mertixtan/hesap.db
ExecStart=/usr/bin/python3 /opt/mertixtan/hesap/yedek.py
NoNewPrivileges=true
ProtectSystem=strict
ReadWritePaths=/var/lib/mertixtan
SERVIS
cat > /etc/systemd/system/mertixtan-yedek.timer <<'SERVIS'
[Unit]
Description=Mertixtan gece yedeği (03:17)
[Timer]
OnCalendar=*-*-* 03:17:00
Persistent=true
[Install]
WantedBy=timers.target
SERVIS
systemctl daemon-reload; systemctl enable -q --now mertixtan-yedek.timer
[ -n "$(ls /var/lib/mertixtan/yedek 2>/dev/null)" ] || systemctl start mertixtan-yedek.service || true  # ilk yedek hemen

# İsorp kaldırıldı: eski kurulumdan kalan servis ve dosyaları temizle
if [ -f /etc/systemd/system/isorp.service ]; then systemctl disable --now isorp 2>/dev/null || true; rm -f /etc/systemd/system/isorp.service; systemctl daemon-reload; fi
rm -f /opt/mertixtan/hesap/isorp.py /opt/mertixtan/hesap/isorp_sunucu.py "$SITE/isorp.js"
# İsorp oyuncu kayıtlarını (para, avatar, ev, skorlar) veritabanından sil
[ -f /var/lib/mertixtan/hesap.db ] && python3 -c "
import sqlite3; c = sqlite3.connect('/var/lib/mertixtan/hesap.db', timeout=30)
for t in ('isorp_oyuncu', 'isorp_oyun', 'isorp_skor'): c.execute('DROP TABLE IF EXISTS ' + t)
c.commit()" || true

adim "Web sunucusu (nginx) ayarlanıyor"
# kişi başı istek sınırı: kötü niyetli biri sunucuyu yoramasın
cat > /etc/nginx/conf.d/mimo_sinir.conf <<'SINIR'
limit_req_zone $binary_remote_addr zone=mimo:10m rate=12r/m;
limit_req_zone $binary_remote_addr zone=hesap:10m rate=20r/m;
limit_req_zone $binary_remote_addr zone=site:10m rate=120r/m;
limit_req_zone $binary_remote_addr zone=lives:10m rate=240r/m;
limit_conn_zone $binary_remote_addr zone=lv_akis:10m;
SINIR
ALAN="${ALAN:-mertixtanstudios.com}"
IP=$(curl -s --max-time 5 https://api.ipify.org || hostname -I | awk '{print $1}')
V6=0; [ -s /proc/net/if_inet6 ] && V6=1   # IPv6 kapalı sunucularda nginx başlamasın diye
dinle() { echo "listen $1;"; [ $V6 = 1 ] && echo "    listen [::]:$1;"; true; }

# Güvenlik başlıkları: başka siteye gömülme (tıklama tuzağı), tür tahmini, yönlendiren bilgisi
cat > /etc/nginx/snippets/mertixtan_baslik.conf <<'BASLIK'
add_header X-Frame-Options "DENY" always;
add_header X-Content-Type-Options "nosniff" always;
add_header Referrer-Policy "strict-origin-when-cross-origin" always;
add_header Permissions-Policy "camera=(self), microphone=(self), display-capture=(self), autoplay=(self), fullscreen=(self), geolocation=(), payment=()" always;
add_header Content-Security-Policy "frame-ancestors 'none'; object-src 'none'; base-uri 'self'; form-action 'self'" always;
BASLIK
echo "server_tokens off;" > /etc/nginx/conf.d/mertixtan_gizle.conf

# Site ve API yolları (http ve https aynı)
mkdir -p /etc/nginx/snippets
cat > /etc/nginx/snippets/mertixtan_yollar.conf <<NGINX
root $SITE;
index index.html;
include snippets/mertixtan_baslik.conf;
location ~ /\. { deny all; }
location / { try_files \$uri \$uri/ /index.html; }
location = /api/mimo/health {
    proxy_pass http://127.0.0.1:8080/health;
}
location = /api/mimo/v1/chat/completions {
    limit_req zone=mimo burst=6 nodelay;
    limit_except POST { deny all; }
    client_max_body_size 64k;
    proxy_pass http://127.0.0.1:8080/v1/chat/completions;
    proxy_set_header Authorization "Bearer $ANAHTAR";
    proxy_set_header Host \$host;
    proxy_buffering off;
    proxy_read_timeout 600s;
}
location ~ ^/api/hesap/(giris|kayit|google|sifre)$ {
    limit_req zone=hesap burst=5 nodelay;
    client_max_body_size 16k;
    proxy_pass http://127.0.0.1:8090;
    proxy_set_header X-Real-IP \$remote_addr;
    proxy_set_header X-Forwarded-Proto \$scheme;
}
location /api/hesap/ {
    client_max_body_size 16k;
    proxy_pass http://127.0.0.1:8090;
    proxy_set_header X-Real-IP \$remote_addr;
    proxy_set_header X-Forwarded-Proto \$scheme;
}
location = /api/lives/akis {
    limit_conn lv_akis 12;
    proxy_pass http://127.0.0.1:8090;
    proxy_buffering off;
    proxy_cache off;
    proxy_read_timeout 3600s;
    proxy_set_header X-Real-IP \$remote_addr;
    proxy_set_header X-Forwarded-Proto \$scheme;
}
location = /api/lives/kapak {
    limit_req zone=hesap burst=5 nodelay;
    client_max_body_size 2m;
    proxy_pass http://127.0.0.1:8090;
    proxy_set_header X-Real-IP \$remote_addr;
    proxy_set_header X-Forwarded-Proto \$scheme;
}
location /api/lives/ {
    limit_req zone=lives burst=60 nodelay;
    client_max_body_size 64k;
    proxy_pass http://127.0.0.1:8090;
    proxy_set_header X-Real-IP \$remote_addr;
    proxy_set_header X-Forwarded-Proto \$scheme;
}
location /livekit/ {
    proxy_pass http://127.0.0.1:7880/;
    proxy_http_version 1.1;
    proxy_set_header Upgrade \$http_upgrade;
    proxy_set_header Connection "upgrade";
    proxy_set_header Host \$host;
    proxy_set_header X-Real-IP \$remote_addr;
    proxy_read_timeout 3600s;
}
location /kapak/ {
    alias /var/lib/mertixtan-kapak/;
    include snippets/mertixtan_baslik.conf;
    add_header Cache-Control "public, max-age=604800";
    location ~ \\.(jpg|png|webp)\$ { include snippets/mertixtan_baslik.conf; add_header Cache-Control "public, max-age=604800"; }
    location ~ . { return 404; }
}
location /api/site/ {
    limit_req zone=site burst=40 nodelay;
    client_max_body_size 64k;
    proxy_pass http://127.0.0.1:8090;
    proxy_set_header X-Real-IP \$remote_addr;
    proxy_set_header X-Forwarded-Proto \$scheme;
}
location /api/ { return 404; }
location ~ ^/(mx|lives)\\.js\$ { include snippets/mertixtan_baslik.conf; add_header Cache-Control "no-cache"; }
NGINX
chmod 640 /etc/nginx/snippets/mertixtan_yollar.conf

http_sunucu() {  # $1=1 ise https'e yönlendir
cat > /etc/nginx/sites-available/mertixtan <<NGINX
server {
    $(dinle "80 default_server")
    server_name _;
    location ^~ /.well-known/acme-challenge/ { root $SITE; }
    $( [ "$1" = 1 ] && echo "location / { return 301 https://$ALAN\$request_uri; }" || echo "include snippets/mertixtan_yollar.conf;" )
}
NGINX
}
https_sunucu() {
cat >> /etc/nginx/sites-available/mertixtan <<NGINX
server {
    $(dinle "443 ssl http2")
    server_name $ALANLAR;
    ssl_certificate /etc/letsencrypt/live/$ALAN/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/$ALAN/privkey.pem;
    ssl_protocols TLSv1.2 TLSv1.3;
    add_header Strict-Transport-Security "max-age=31536000" always;
    include snippets/mertixtan_yollar.conf;
}
NGINX
}
etkinlestir() { nginx -t && { systemctl enable -q nginx; systemctl reload nginx || systemctl restart nginx; }; }

rm -f /etc/nginx/sites-enabled/default
ln -sf /etc/nginx/sites-available/mertixtan /etc/nginx/sites-enabled/mertixtan
SERT=/etc/letsencrypt/live/$ALAN/fullchain.pem
if [ -f "$SERT" ]; then
  ALANLAR="$(openssl x509 -in "$SERT" -noout -ext subjectAltName 2>/dev/null | grep -o 'DNS:[^,]*' | cut -d: -f2 | tr '\n' ' ')"
  http_sunucu 1; https_sunucu
else http_sunucu 0; fi
etkinlestir
if command -v ufw >/dev/null && ufw status | grep -q "Status: active"; then ufw allow 80/tcp >/dev/null; ufw allow 443/tcp >/dev/null; fi

adim "Alan adı ve https: $ALAN"
alan_ip() { getent ahostsv4 "$1" | awk '{print $1; exit}'; }
ALANLAR="$ALAN"; [ "$(alan_ip "www.$ALAN")" = "$IP" ] && ALANLAR="$ALAN www.$ALAN"
if [ "$(alan_ip "$ALAN")" != "$IP" ]; then
  echo "BEKLENİYOR: $ALAN henüz bu sunucuyu ($IP) göstermiyor (şu an: $(alan_ip "$ALAN" || echo yok))."
  echo "DNS'te şu kayıtları yap:  A  @  $IP    ve    A  www  $IP"
  echo "Kayıt yayılınca aynı komutu çalıştırıp paketi tekrar yükle; https kendiliğinden kurulur."
else
  apt-get install -y -qq certbot >/dev/null
  ARG=""; for a in $ALANLAR; do ARG="$ARG -d $a"; done
  if certbot certonly --webroot -w "$SITE" $ARG --non-interactive --agree-tos --register-unsafely-without-email \
       --keep-until-expiring --expand --deploy-hook "systemctl reload nginx" -q; then
    http_sunucu 1; https_sunucu; etkinlestir
  else
    echo "UYARI: https sertifikası alınamadı; site şimdilik http ile yayında."
  fi
fi

sleep 2
if curl -s --max-time 5 http://127.0.0.1:8080/health | grep -q ok; then DURUM="çalışıyor"; else DURUM="açılıyor (birkaç saniye sonra hazır olur)"; fi
if [ -f "$SERT" ]; then ADRES="https://$ALAN"; else ADRES="http://$IP"; fi
echo
echo "=============================================================="
echo " YAYINDA:  $ADRES/"
echo " LIVES:    $ADRES/#lives"
echo " Canlı görüntü/ses için sağlayıcının güvenlik duvarında açık olmalı: 7881/tcp, 50000-50200/udp, 3478/udp"
echo " MIMO:     $ADRES/#mimo   ($DURUM)"
echo " PANEL:    $ADRES/#yonetici"
echo "=============================================================="
