"""Mertixtan Lives: canlı yayın platformu (sunucu tarafı).

- Gerçek zamanlı sohbet: Server-Sent Events (/api/lives/akis), mesajlar SQLite'a kalıcı yazılır.
- Görüntü / ses / ekran: LiveKit (aynı sunucuda, 127.0.0.1:7880). Bu modül LiveKit erişim jetonlarını üretir ve
  susturma / çıkarma / yayını kapatma gibi işlemleri LiveKit'in sunucu API'siyle yapar.
- Bütün yetkiler (yönetici, yayıncı, oda sahibi, Pro) burada, sunucuda denetlenir.
hesap.py içinden /api/lives/... olarak çağrılır.
"""
import base64, datetime, hashlib, hmac, json, os, queue, re, secrets, shutil, subprocess, threading, time, urllib.parse, urllib.request

import site_api as site
Hata = site.Hata

LK_ANAHTAR = os.environ.get("LIVEKIT_KEY", "")
LK_GIZLI = os.environ.get("LIVEKIT_SECRET", "")
LK_ADRES = os.environ.get("LIVEKIT_URL", "http://127.0.0.1:7880")
KAPAK_DIZIN = os.environ.get("KAPAK_DIZIN", "/var/lib/mertixtan-kapak")
VIDEO_DIZIN = os.environ.get("VIDEO_DIZIN", "/var/lib/mertixtan-video")
YASLAR = ("genel", "7", "10", "13", "16", "18")
ICERIK_KATEGORI = ("Film", "Dizi", "Program", "Belgesel", "Müzik", "Oyun", "Eğitim", "Çocuk", "Spor", "Diğer")
TR = datetime.timezone(datetime.timedelta(hours=3))
KATEGORILER = ("Sohbet", "Oyun", "Yazılım", "Müzik", "Eğitim", "Sanat", "Spor", "Film & Dizi", "Diğer")
TEMALAR = ("klasik", "gece", "neon", "yakut", "altin", "okyanus")

SEMA = """
CREATE TABLE IF NOT EXISTS yayin(id INTEGER PRIMARY KEY, kid INTEGER, baslik TEXT, aciklama TEXT, kategori TEXT, tur TEXT,
    kapak TEXT, ozel INTEGER DEFAULT 0, tema TEXT DEFAULT 'klasik', resmi INTEGER DEFAULT 0, durum TEXT DEFAULT 'canli',
    baslangic INTEGER, bitis INTEGER, tepe INTEGER DEFAULT 0, tekil INTEGER DEFAULT 0, mesaj INTEGER DEFAULT 0,
    one_cikan INTEGER DEFAULT 0, konusmaya_acik INTEGER DEFAULT 0);
CREATE TABLE IF NOT EXISTS ses_oda(id INTEGER PRIMARY KEY, kid INTEGER, baslik TEXT, aciklama TEXT, resmi INTEGER DEFAULT 0,
    durum TEXT DEFAULT 'acik', olusturma INTEGER, kapanis INTEGER, tepe INTEGER DEFAULT 0);
CREATE TABLE IF NOT EXISTS icerik(id INTEGER PRIMARY KEY, ad TEXT, tur TEXT, aciklama TEXT, kapak TEXT, kaynak TEXT, olusturma INTEGER);
CREATE TABLE IF NOT EXISTS program(id INTEGER PRIMARY KEY, icerik_id INTEGER, baslik TEXT, aciklama TEXT, baslangic INTEGER, bitis INTEGER);
CREATE TABLE IF NOT EXISTS puan(icerik_id INTEGER, kid INTEGER, puan INTEGER, tarih INTEGER, PRIMARY KEY(icerik_id, kid));
CREATE TABLE IF NOT EXISTS lmesaj(id INTEGER PRIMARY KEY, oda TEXT, kid INTEGER, metin TEXT, yanit_id INTEGER, tarih INTEGER, silindi INTEGER DEFAULT 0);
CREATE TABLE IF NOT EXISTS oda_durum(oda TEXT PRIMARY KEY, sabit INTEGER);
CREATE TABLE IF NOT EXISTS yasak(id INTEGER PRIMARY KEY, oda TEXT, kid INTEGER, tur TEXT, bitis INTEGER, veren INTEGER, neden TEXT, tarih INTEGER);
CREATE TABLE IF NOT EXISTS takip(yayinci INTEGER, kid INTEGER, tarih INTEGER, PRIMARY KEY(yayinci, kid));
-- Destekçiler. 'tutar' ileride ücretli destek için ayrıldı; şu an hiçbir para işlemi yok, hep NULL.
CREATE TABLE IF NOT EXISTS destekci(yayinci INTEGER, kid INTEGER, tarih INTEGER, tutar INTEGER, PRIMARY KEY(yayinci, kid));
CREATE TABLE IF NOT EXISTS lrapor(id INTEGER PRIMARY KEY, kid INTEGER, hedef_tur TEXT, hedef_id TEXT, neden TEXT, tarih INTEGER, durum TEXT DEFAULT 'yeni');
CREATE TABLE IF NOT EXISTS konusmaci(oda TEXT, kid INTEGER, PRIMARY KEY(oda, kid));
CREATE TABLE IF NOT EXISTS lanket(id INTEGER PRIMARY KEY, oda TEXT, soru TEXT, secenekler TEXT, durum TEXT DEFAULT 'acik', olusturma INTEGER, bitis INTEGER);
CREATE TABLE IF NOT EXISTS lanket_oy(anket_id INTEGER, kid INTEGER, secim INTEGER, PRIMARY KEY(anket_id, kid));
CREATE TABLE IF NOT EXISTS lhatirlatma(program_id INTEGER, kid INTEGER, tarih INTEGER, PRIMARY KEY(program_id, kid));
CREATE TABLE IF NOT EXISTS yayin_ornek(yayin_id INTEGER, t INTEGER, n INTEGER);
CREATE TABLE IF NOT EXISTS yukleme(id TEXT PRIMARY KEY, kid INTEGER, boyut INTEGER, alinan INTEGER DEFAULT 0, uzanti TEXT, bilgi TEXT, tarih INTEGER);
CREATE INDEX IF NOT EXISTS yayin_ornek_y ON yayin_ornek(yayin_id, t);
CREATE INDEX IF NOT EXISTS lmesaj_oda ON lmesaj(oda, id);
CREATE INDEX IF NOT EXISTS program_zaman ON program(baslangic);
CREATE INDEX IF NOT EXISTS yasak_kim ON yasak(kid, oda);
"""


def semayi_kur(db):
    db.executescript(SEMA)
    sut = {r[1] for r in db.execute("PRAGMA table_info(kullanici)")}
    if "yayinci" not in sut: db.execute("ALTER TABLE kullanici ADD COLUMN yayinci INTEGER DEFAULT 0")
    # V2: içerik kategorisi, yaş sınırı, süre, yerel video dosyası ve işlenme durumu; yayında toplam izlenme süresi
    isut = {r[1] for r in db.execute("PRAGMA table_info(icerik)")}
    for ad, tur in (("kategori", "TEXT"), ("yas", "TEXT DEFAULT 'genel'"), ("sure", "INTEGER"), ("dosya", "TEXT"), ("durum", "TEXT DEFAULT 'hazir'")):
        if ad not in isut: db.execute(f"ALTER TABLE icerik ADD COLUMN {ad} {tur}")
    ysut = {r[1] for r in db.execute("PRAGMA table_info(yayin)")}
    if "izleme_sn" not in ysut: db.execute("ALTER TABLE yayin ADD COLUMN izleme_sn INTEGER DEFAULT 0")
    if not db.execute("SELECT 1 FROM ses_oda WHERE resmi=1").fetchone():
        db.execute("INSERT INTO ses_oda(kid,baslik,aciklama,resmi,olusturma) VALUES(NULL,?,?,1,?)",
                   ("Mertixtan Studios Özel Canlı Sohbet", "Stüdyonun resmî sesli sohbet odası. Herkese açık; yöneticiler yönetir.", int(time.time())))
    for r in db.execute("SELECT id FROM yayin WHERE durum='canli'"):  # servis yeniden başladıysa yarım kalan yayınlar
        pass
    db.commit()


# ------------------------------------------------------------------ yardımcılar
def su(): return int(time.time())


def kul(db, kid):
    return db.execute("SELECT * FROM kullanici WHERE id=?", (kid,)).fetchone() if kid else None


def rozet(k):
    """Rozetler yalnızca gerçek yetkilerden gelir."""
    if not k: return {}
    return {"admin": bool(k["yonetici"]), "pro": bool(k["pro"]), "onayli": bool(k["dogrulanmis"])}


def kisi(k):
    if not k: return {"ad": "silinmiş üye", "rozet": {}}
    return {"id": k["id"], "ad": k["ad"], "renk": k["renk"], "rozet": rozet(k)}


def yayin_yetkili(k): return bool(k and (k["pro"] or k["yonetici"] or k["yayinci"]))


def oda_coz(db, oda):
    """oda anahtarı: 'resmi' | 'y<id>' (yayın) | 's<id>' (sesli oda). (tur, satır, sahip_kid) döner."""
    if oda == "resmi": return "resmi", None, None
    m = re.fullmatch(r"([ys])(\d{1,9})", oda or "")
    if not m: raise Hata(400, "Geçersiz oda")
    if m.group(1) == "y":
        r = db.execute("SELECT * FROM yayin WHERE id=?", (int(m.group(2)),)).fetchone()
        if not r: raise Hata(404, "Yayın bulunamadı")
        return "yayin", r, r["kid"]
    r = db.execute("SELECT * FROM ses_oda WHERE id=?", (int(m.group(2)),)).fetchone()
    if not r: raise Hata(404, "Oda bulunamadı")
    return "ses", r, r["kid"]


def moderator_mu(db, k, oda):
    if not k: return False
    if k["yonetici"]: return True
    if oda == "resmi": return False
    tur, r, sahip = oda_coz(db, oda)
    return sahip == k["id"]


def aktif_yasak(db, kid, oda, turler=("yasak", "uzaklastir", "sustur")):
    if not kid: return None
    q = "SELECT * FROM yasak WHERE kid=? AND (oda=? OR oda='*') AND tur IN (%s) AND (bitis IS NULL OR bitis>?) ORDER BY bitis IS NULL DESC, bitis DESC" % ",".join("?" * len(turler))
    return db.execute(q, (kid, oda, *turler, su())).fetchone()


def sure_metni(y):
    if not y["bitis"]: return "kalıcı olarak"
    dk = max(1, (y["bitis"] - su() + 59) // 60)
    return f"{dk} dakika boyunca"


# ------------------------------------------------------------------ canlı olaylar (SSE yayını) ve izleyici sayımı
class Oda:
    def __init__(self):
        self.abone = {}      # queue -> kim
        self.tekil = set()
        self.tepe = 0
        self.giris = {}      # queue -> izlemeye başlama zamanı (izlenme süresi için)


ODALAR = {}
ODA_KILIT = threading.Lock()


def yayinla(oda, olay):
    with ODA_KILIT:
        o = ODALAR.get(oda)
        hedefler = list(o.abone) if o else []
    for q in hedefler:
        try: q.put_nowait(olay)
        except queue.Full: pass


def _say(o): return len({k for k in o.abone.values() if not k.startswith("!")})  # "!" = yayıncının kendisi, sayılmaz


def izleyici_say(oda):
    with ODA_KILIT:
        o = ODALAR.get(oda)
        return _say(o) if o else 0


def _abone_ol(oda, kim):
    q = queue.Queue(maxsize=200)
    with ODA_KILIT:
        o = ODALAR.setdefault(oda, Oda())
        o.abone[q] = kim; o.giris[q] = time.time()
        if not kim.startswith("!"): o.tekil.add(kim)
        n = _say(o); o.tepe = max(o.tepe, n)
        tekil, tepe = len(o.tekil), o.tepe
    return q, n, tekil, tepe


def _abonelik_bitir(oda, q):
    with ODA_KILIT:
        o = ODALAR.get(oda)
        if not o: return 0, time.time()
        o.abone.pop(q, None)
        return _say(o), o.giris.pop(q, time.time())


def akis(h, db, kilit, oda):
    """SSE: odanın sohbet ve durum olaylarını canlı akıtır. Kilit sadece kısa DB işlemlerinde tutulur."""
    q_ = dict(urllib.parse.parse_qsl(urllib.parse.urlparse(h.path).query))
    with kilit:
        k = h.kullanici(db)
        tur, r, sahip = oda_coz(db, oda)
        y = aktif_yasak(db, k["id"] if k else None, oda, ("yasak", "uzaklastir"))
        if y: raise Hata(403, f"Bu odadan {sure_metni(y)} uzaklaştırıldın")
        if tur == "ses" and not k: raise Hata(401, "Sesli odalara katılmak için giriş yap")
    istemci = re.sub(r"[^a-zA-Z0-9]", "", q_.get("c", ""))[:24] or secrets.token_hex(6)
    kim = f"k{k['id']}" if k else f"m{istemci}"
    with kilit:
        yayinci_mi = bool(k and ((tur == "yayin" and sahip == k["id"]) or (tur == "resmi" and k["yonetici"] and db.execute("SELECT 1 FROM yayin WHERE resmi=1 AND durum='canli' AND kid=?", (k["id"],)).fetchone())))
    if yayinci_mi: kim = "!" + kim  # yayıncı kendi yayınının izleyicisi sayılmaz
    q, n, tekil, tepe = _abone_ol(oda, kim)
    h.send_response(200)
    h.send_header("Content-Type", "text/event-stream; charset=utf-8")
    h.send_header("Cache-Control", "no-store"); h.send_header("X-Accel-Buffering", "no")
    h.end_headers()
    yayinla(oda, {"tip": "izleyici", "sayi": n})
    if tur == "yayin":
        with kilit:
            db.execute("UPDATE yayin SET tepe=MAX(tepe,?), tekil=MAX(tekil,?) WHERE id=?", (tepe, tekil, r["id"])); db.commit()
    elif tur == "ses":
        with kilit:
            db.execute("UPDATE ses_oda SET tepe=MAX(tepe,?) WHERE id=?", (tepe, r["id"])); db.commit()
    try:
        h.wfile.write(b"retry: 3000\n\n"); h.wfile.flush()
        while True:
            try:
                olay = q.get(timeout=20)
                h.wfile.write(("data: " + json.dumps(olay, ensure_ascii=False) + "\n\n").encode())
            except queue.Empty:
                h.wfile.write(b": nabiz\n\n")
            h.wfile.flush()
    except (BrokenPipeError, ConnectionResetError, OSError):
        pass
    finally:
        n, giris_zamani = _abonelik_bitir(oda, q)
        yayinla(oda, {"tip": "izleyici", "sayi": n})
        if not kim.startswith("!") and tur in ("yayin", "resmi"):  # gerçek izlenme süresi (yalnız yayın canlıyken geçen kısım)
            try:
                with kilit:
                    y_ = db.execute("SELECT id, baslangic FROM yayin WHERE id=? AND durum='canli'", (r["id"],)).fetchone() if tur == "yayin" else db.execute("SELECT id, baslangic FROM yayin WHERE resmi=1 AND durum='canli'").fetchone()
                    if y_: db.execute("UPDATE yayin SET izleme_sn=izleme_sn+? WHERE id=?", (max(0, int(time.time() - max(giris_zamani, y_["baslangic"]))), y_["id"])); db.commit()
            except Exception as e: print("izleme süresi:", repr(e)[:120], flush=True)


# ------------------------------------------------------------------ LiveKit
def b64u(b): return base64.urlsafe_b64encode(b).rstrip(b"=").decode()


def lk_jeton(kimlik, ad, oda, izinler, meta=None, sure=6 * 3600):
    if not LK_ANAHTAR or not LK_GIZLI: raise Hata(503, "Canlı yayın sunucusu (LiveKit) ayarlı değil")
    govde = {"iss": LK_ANAHTAR, "sub": kimlik, "name": ad, "nbf": su() - 10, "exp": su() + sure,
             "video": {"room": oda, **izinler}, "metadata": json.dumps(meta or {}, ensure_ascii=False)}
    bas = b64u(json.dumps({"alg": "HS256", "typ": "JWT"}).encode())
    ic = b64u(json.dumps(govde, ensure_ascii=False).encode())
    imza = b64u(hmac.new(LK_GIZLI.encode(), f"{bas}.{ic}".encode(), hashlib.sha256).digest())
    return f"{bas}.{ic}.{imza}"


def lk_api(yontem, oda, veri):
    """LiveKit RoomService (Twirp). Hata olursa sessiz geçer: sohbet/DB tarafı yine çalışsın."""
    try:
        j = lk_jeton("mertixtan-sunucu", "sunucu", oda, {"roomAdmin": True, "roomList": True, "roomCreate": True}, sure=120)
        r = urllib.request.Request(f"{LK_ADRES}/twirp/livekit.RoomService/{yontem}", data=json.dumps(veri).encode(),
                                   headers={"Authorization": "Bearer " + j, "Content-Type": "application/json"})
        return json.loads(urllib.request.urlopen(r, timeout=5).read() or b"{}")
    except Exception as e:
        print("LiveKit API:", yontem, repr(e)[:200], flush=True)
        return None


def lk_cikar(oda, kid): lk_api("RemoveParticipant", oda, {"room": oda, "identity": f"k{kid}"})


def lk_konusma(oda, kid, izin):
    lk_api("UpdateParticipant", oda, {"room": oda, "identity": f"k{kid}", "permission": {
        "can_subscribe": True, "can_publish_data": True, "can_publish": bool(izin), "can_publish_sources": ["MICROPHONE"] if izin else []}})


def lk_kapat(oda): lk_api("DeleteRoom", oda, {"room": oda})


# ------------------------------------------------------------------ resmî kanal: program ve NO SIGNAL
def kanal_ayar(db):
    ay = site.ayarlar(db)
    return {"tema": ay.get("resmi_tema", "klasik"), "nosignal": ay.get("resmi_nosignal", ""), "kapali": ay.get("resmi_kapali", "0") == "1",
            "logo": ay.get("resmi_logo", ""), "kapak": ay.get("resmi_kapak", ""), "aciklama": ay.get("resmi_aciklama", ""),
            "renk": ay.get("resmi_renk", "#e0115f"), "tasarim": ay.get("resmi_tasarim", "sinema")}


def icerik_disari(db, i, kid=None):
    if not i: return None
    p = db.execute("SELECT COUNT(*) n, AVG(puan) ort FROM puan WHERE icerik_id=?", (i["id"],)).fetchone()
    benim = db.execute("SELECT puan FROM puan WHERE icerik_id=? AND kid=?", (i["id"], kid)).fetchone() if kid else None
    return {"id": i["id"], "ad": i["ad"], "tur": i["tur"], "aciklama": i["aciklama"], "kapak": i["kapak"], "kaynak": i["kaynak"],
            "kategori": i["kategori"], "yas": i["yas"] or "genel", "sure": i["sure"], "dosya": bool(i["dosya"]), "durum": i["durum"] or "hazir",
            "puan": {"ortalama": round(p["ort"], 2) if p["ort"] else None, "oy": p["n"], "benim": benim["puan"] if benim else None}}


def program_disari(db, p, kid=None):
    i = db.execute("SELECT * FROM icerik WHERE id=?", (p["icerik_id"],)).fetchone() if p["icerik_id"] else None
    t = su()
    durum = "yayinda" if p["baslangic"] <= t < p["bitis"] else ("bitti" if p["bitis"] <= t else "sirada")
    hat = db.execute("SELECT COUNT(*) FROM lhatirlatma WHERE program_id=?", (p["id"],)).fetchone()[0]
    return {"id": p["id"], "baslik": p["baslik"], "aciklama": p["aciklama"], "baslangic": p["baslangic"], "bitis": p["bitis"],
            "durum": durum, "icerik": icerik_disari(db, i, kid), "hatirlatma_sayisi": hat,
            "hatirlatiyorum": bool(kid and db.execute("SELECT 1 FROM lhatirlatma WHERE program_id=? AND kid=?", (p["id"], kid)).fetchone())}


def resmi_durum(db, kid=None):
    ay = kanal_ayar(db); t = su()
    canli = db.execute("SELECT * FROM yayin WHERE resmi=1 AND durum='canli' ORDER BY id DESC").fetchone()
    simdi = db.execute("SELECT * FROM program WHERE baslangic<=? AND bitis>? ORDER BY baslangic DESC", (t, t)).fetchone()
    sonraki = db.execute("SELECT * FROM program WHERE baslangic>? ORDER BY baslangic LIMIT 1", (t,)).fetchone()
    if ay["kapali"]: mod = "nosignal"
    elif canli: mod = "canli"
    elif simdi: mod = "program"
    else: mod = "nosignal"
    return {"mod": mod, "tema": ay["tema"], "nosignal_mesaj": ay["nosignal"], "zorla_kapali": ay["kapali"],
            "kanal": {a: ay[a] for a in ("logo", "kapak", "aciklama", "renk", "tasarim")},
            "canli": yayin_disari(db, canli) if canli else None,
            "simdi": program_disari(db, simdi, kid) if simdi and mod == "program" else None,
            "ofset": (t - simdi["baslangic"]) if simdi and mod == "program" else None,
            "sonraki": program_disari(db, sonraki, kid) if sonraki else None,
            "izleyici": izleyici_say("resmi"), "sunucu_zamani": t}


def gun_araligi(gun):
    d = datetime.datetime.strptime(gun, "%Y-%m-%d").replace(tzinfo=TR)
    return int(d.timestamp()), int((d + datetime.timedelta(days=1)).timestamp())


# ------------------------------------------------------------------ dışarıya verilen biçimler
def yayin_disari(db, r):
    k = kul(db, r["kid"])
    return {"id": r["id"], "oda": f"y{r['id']}", "baslik": r["baslik"], "aciklama": r["aciklama"], "kategori": r["kategori"],
            "tur": r["tur"], "kapak": r["kapak"], "ozel": bool(r["ozel"]), "tema": r["tema"], "resmi": bool(r["resmi"]),
            "durum": r["durum"], "baslangic": r["baslangic"], "bitis": r["bitis"], "tepe": r["tepe"], "tekil": r["tekil"],
            "mesaj": r["mesaj"], "one_cikan": bool(r["one_cikan"]), "konusmaya_acik": bool(r["konusmaya_acik"]),
            "izleyici": izleyici_say(f"y{r['id']}") if r["durum"] == "canli" else 0,
            "yayinci": {"ad": "Mertixtan Studios Live", "rozet": {"admin": True, "onayli": True}, "resmi": True} if r["resmi"] else kisi(k)}


def oda_disari(db, r):
    k = kul(db, r["kid"])
    return {"id": r["id"], "oda": f"s{r['id']}", "baslik": r["baslik"], "aciklama": r["aciklama"], "resmi": bool(r["resmi"]),
            "durum": r["durum"], "olusturma": r["olusturma"], "tepe": r["tepe"], "katilimci": izleyici_say(f"s{r['id']}"),
            "sahip": {"ad": "Mertixtan Studios", "rozet": {"admin": True, "onayli": True}} if r["resmi"] else kisi(k)}


def mesaj_disari(db, m):
    k = kul(db, m["kid"])
    y = None
    if m["yanit_id"]:
        yy = db.execute("SELECT l.metin, l.silindi, k.ad FROM lmesaj l LEFT JOIN kullanici k ON k.id=l.kid WHERE l.id=?", (m["yanit_id"],)).fetchone()
        if yy: y = {"id": m["yanit_id"], "ad": yy["ad"], "metin": "silinmiş mesaj" if yy["silindi"] else yy["metin"][:120]}
    return {"id": m["id"], "metin": m["metin"], "tarih": m["tarih"], "yanit": y, "kul": kisi(k)}


def mesajlar(db, oda, n=60):
    l = db.execute("SELECT * FROM lmesaj WHERE oda=? AND silindi=0 ORDER BY id DESC LIMIT ?", (oda, n)).fetchall()
    return [mesaj_disari(db, m) for m in reversed(l)]


def sabit_mesaj(db, oda):
    s = db.execute("SELECT sabit FROM oda_durum WHERE oda=?", (oda,)).fetchone()
    if not s or not s["sabit"]: return None
    m = db.execute("SELECT * FROM lmesaj WHERE id=? AND silindi=0", (s["sabit"],)).fetchone()
    return mesaj_disari(db, m) if m else None


def benim_yetkim(db, k, oda):
    y = aktif_yasak(db, k["id"], oda) if k else None
    return {"giris": bool(k), "moderator": moderator_mu(db, k, oda), "admin": bool(k and k["yonetici"]),
            "susturuldu": {"tur": y["tur"], "bitis": y["bitis"]} if y else None, "id": k["id"] if k else None}


# ------------------------------------------------------------------ herkese açık uçlar
def get_kesfet(h, db, q):
    k = h.kullanici(db)
    canli = [yayin_disari(db, r) for r in db.execute("SELECT * FROM yayin WHERE durum='canli' AND ozel=0 AND resmi=0")]
    canli.sort(key=lambda y: (not y["one_cikan"], not y["yayinci"].get("rozet", {}).get("pro"), -y["izleyici"], -y["baslangic"]))
    populer = sorted(canli, key=lambda y: -y["izleyici"])[:12]
    uyeler = [y for y in canli if y["yayinci"].get("rozet", {}).get("pro")]
    sinir = su() - 14 * 86400
    yeni = []
    for r in db.execute("""SELECT kid, MIN(baslangic) ilk, MAX(id) son FROM yayin WHERE resmi=0 GROUP BY kid HAVING ilk>? ORDER BY ilk DESC LIMIT 12""", (sinir,)):
        u = kul(db, r["kid"])
        if u and not u["engelli"]:
            y = db.execute("SELECT * FROM yayin WHERE id=?", (r["son"],)).fetchone()
            yeni.append({"kul": kisi(u), "ilk": r["ilk"], "son_yayin": yayin_disari(db, y) if y and not y["ozel"] else None})
    odalar = [oda_disari(db, r) for r in db.execute("SELECT * FROM ses_oda WHERE durum='acik' ORDER BY resmi DESC, id DESC LIMIT 30")]
    takip = []
    if k:
        takip = [yayin_disari(db, r) for r in db.execute("SELECT y.* FROM yayin y JOIN takip t ON t.yayinci=y.kid WHERE t.kid=? AND y.durum='canli' AND y.ozel=0", (k["id"],))]
    h.cevap(200, {"resmi": resmi_durum(db, k["id"] if k else None), "canli": canli, "populer": populer, "uyeler": uyeler,
                  "yeni": yeni, "odalar": odalar, "takip": takip, "ben": {"yayin_yetkili": yayin_yetkili(k), "giris": bool(k)},
                  "kategoriler": KATEGORILER, "temalar": TEMALAR})


def get_resmi(h, db, q):
    k = h.kullanici(db); kid = k["id"] if k else None
    bas, son = gun_araligi(q.get("gun") or datetime.datetime.now(TR).strftime("%Y-%m-%d"))
    prog = [program_disari(db, p, kid) for p in db.execute("SELECT * FROM program WHERE bitis>? AND baslangic<? ORDER BY baslangic", (bas, son))]
    h.cevap(200, {"durum": resmi_durum(db, kid), "program": prog, "mesajlar": mesajlar(db, "resmi"), "sabit": sabit_mesaj(db, "resmi"),
                  "yetki": benim_yetkim(db, k, "resmi"), "anket": acik_anket(db, "resmi", k), "kategoriler": ICERIK_KATEGORI, "yaslar": YASLAR})


def get_yayin(h, db, q):
    k = h.kullanici(db)
    r = db.execute("SELECT * FROM yayin WHERE id=?", (int(q.get("id", 0)),)).fetchone()
    if not r: raise Hata(404, "Yayın bulunamadı")
    oda = f"y{r['id']}"
    y = yayin_disari(db, r)
    destek = [kisi(kul(db, d["kid"])) | {"tarih": d["tarih"]} for d in db.execute("SELECT * FROM destekci WHERE yayinci=? ORDER BY tarih DESC LIMIT 100", (r["kid"],))]
    destek.sort(key=lambda d: (not d.get("rozet", {}).get("pro"), -d["tarih"]))
    takipci = db.execute("SELECT COUNT(*) FROM takip WHERE yayinci=?", (r["kid"],)).fetchone()[0]
    h.cevap(200, {"yayin": y, "mesajlar": mesajlar(db, oda), "sabit": sabit_mesaj(db, oda), "yetki": benim_yetkim(db, k, oda) | {"sahip": bool(k and k["id"] == r["kid"])},
                  "destekciler": destek, "takipci": takipci,
                  "takip_ediyorum": bool(k and db.execute("SELECT 1 FROM takip WHERE yayinci=? AND kid=?", (r["kid"], k["id"])).fetchone()),
                  "destekliyorum": bool(k and db.execute("SELECT 1 FROM destekci WHERE yayinci=? AND kid=?", (r["kid"], k["id"])).fetchone()),
                  "konusmacilar": [x["kid"] for x in db.execute("SELECT kid FROM konusmaci WHERE oda=?", (oda,))],
                  "anket": acik_anket(db, oda, k)})


def get_oda(h, db, q):
    k = h.kullanici(db)
    r = db.execute("SELECT * FROM ses_oda WHERE id=?", (int(q.get("id", 0)),)).fetchone()
    if not r: raise Hata(404, "Oda bulunamadı")
    oda = f"s{r['id']}"
    h.cevap(200, {"oda": oda_disari(db, r), "mesajlar": mesajlar(db, oda), "sabit": sabit_mesaj(db, oda),
                  "yetki": benim_yetkim(db, k, oda) | {"sahip": bool(k and k["id"] == r["kid"])}})


def get_mesajlar(h, db, q):
    oda = str(q.get("oda", "")); oda_coz(db, oda)
    h.cevap(200, {"mesajlar": mesajlar(db, oda), "sabit": sabit_mesaj(db, oda)})


def get_profil(h, db, q):
    k = h.kullanici(db)
    u = db.execute("SELECT * FROM kullanici WHERE ad=? AND gizli=0 AND engelli=0", (str(q.get("ad", "")),)).fetchone()
    if not u: raise Hata(404, "Kullanıcı bulunamadı")
    aktif = db.execute("SELECT * FROM yayin WHERE kid=? AND durum='canli' AND resmi=0 AND (ozel=0 OR kid=?)", (u["id"], k["id"] if k else -1)).fetchone()
    gecmis = [yayin_disari(db, r) for r in db.execute("SELECT * FROM yayin WHERE kid=? AND durum='bitti' AND resmi=0 AND ozel=0 ORDER BY id DESC LIMIT 20", (u["id"],))]
    say = lambda s: db.execute(s, (u["id"],)).fetchone()[0]
    h.cevap(200, {"kul": kisi(u) | {"biyografi": u["biyografi"], "unvan": u["unvan"], "katilim": u["olusturma"]},
                  "aktif": yayin_disari(db, aktif) if aktif else None, "gecmis": gecmis,
                  "takipci": say("SELECT COUNT(*) FROM takip WHERE yayinci=?"), "destekci": say("SELECT COUNT(*) FROM destekci WHERE yayinci=?"),
                  "yayin_sayisi": say("SELECT COUNT(*) FROM yayin WHERE kid=? AND resmi=0"),
                  "takip_ediyorum": bool(k and db.execute("SELECT 1 FROM takip WHERE yayinci=? AND kid=?", (u["id"], k["id"])).fetchone()),
                  "destekliyorum": bool(k and db.execute("SELECT 1 FROM destekci WHERE yayinci=? AND kid=?", (u["id"], k["id"])).fetchone()),
                  "ben_miyim": bool(k and k["id"] == u["id"])})


# ------------------------------------------------------------------ sohbet
SPAM = {}  # kid -> [(zaman, metin)]


def spam_denetle(kid, metin):
    t = time.time()
    l = [x for x in SPAM.get(kid, []) if t - x[0] < 60]
    if l and t - l[-1][0] < 1.2: raise Hata(429, "Biraz yavaş: mesajlar arası en az 1 saniye")
    if len(l) >= 20: raise Hata(429, "Dakikada en fazla 20 mesaj")
    if any(m == metin and t - z < 30 for z, m in l): raise Hata(429, "Aynı mesajı tekrar tekrar gönderme")
    l.append((t, metin)); SPAM[kid] = l
    if len(SPAM) > 20000: SPAM.clear()


def post_mesaj(h, db):
    k = site.giris_sart(h, db); v = h.govde()
    oda = str(v.get("oda", "")); tur, r, sahip = oda_coz(db, oda)
    if tur == "yayin" and r["durum"] != "canli": raise Hata(400, "Yayın bitti; sohbet kapandı")
    if tur == "ses" and r["durum"] != "acik": raise Hata(400, "Oda kapalı")
    y = aktif_yasak(db, k["id"], oda)
    if y: raise Hata(403, f"Sohbette {sure_metni(y)} {'yasaklısın' if y['tur'] == 'yasak' else ('uzaklaştırıldın' if y['tur'] == 'uzaklastir' else 'susturuldun')}")
    metin_ = re.sub(r"\s+", " ", site.metin(v, "metin", 1, 300)).strip()
    if not metin_: raise Hata(400, "Boş mesaj")
    spam_denetle(k["id"], metin_.lower())
    yanit = int(v.get("yanit_id") or 0) or None
    if yanit and not db.execute("SELECT 1 FROM lmesaj WHERE id=? AND oda=?", (yanit, oda)).fetchone(): yanit = None
    db.execute("INSERT INTO lmesaj(oda,kid,metin,yanit_id,tarih) VALUES(?,?,?,?,?)", (oda, k["id"], metin_, yanit, su()))
    mid = db.execute("SELECT last_insert_rowid()").fetchone()[0]
    if tur == "yayin": db.execute("UPDATE yayin SET mesaj=mesaj+1 WHERE id=?", (r["id"],))
    db.commit()
    m = mesaj_disari(db, db.execute("SELECT * FROM lmesaj WHERE id=?", (mid,)).fetchone())
    yayinla(oda, {"tip": "mesaj", "m": m})
    h.cevap(200, {"m": m})


def post_mesaj_sil(h, db):
    k = site.giris_sart(h, db); v = h.govde()
    m = db.execute("SELECT * FROM lmesaj WHERE id=?", (int(v.get("id") or 0),)).fetchone()
    if not m: raise Hata(404, "Mesaj yok")
    if m["kid"] != k["id"] and not moderator_mu(db, k, m["oda"]): raise Hata(403, "Bu mesajı silemezsin")
    db.execute("UPDATE lmesaj SET silindi=1 WHERE id=?", (m["id"],))
    db.execute("UPDATE oda_durum SET sabit=NULL WHERE oda=? AND sabit=?", (m["oda"], m["id"])); db.commit()
    yayinla(m["oda"], {"tip": "sil", "id": m["id"]})
    h.cevap(200, {"tamam": True})


def post_sabitle(h, db):
    k = site.giris_sart(h, db); v = h.govde()
    oda = str(v.get("oda", "")); oda_coz(db, oda)
    if not moderator_mu(db, k, oda): raise Hata(403, "Mesaj sabitlemek için yetkin yok")
    mid = int(v.get("id") or 0) or None
    if mid and not db.execute("SELECT 1 FROM lmesaj WHERE id=? AND oda=? AND silindi=0", (mid, oda)).fetchone(): raise Hata(404, "Mesaj yok")
    db.execute("INSERT INTO oda_durum VALUES(?,?) ON CONFLICT(oda) DO UPDATE SET sabit=excluded.sabit", (oda, mid)); db.commit()
    yayinla(oda, {"tip": "sabit", "m": sabit_mesaj(db, oda)})
    h.cevap(200, {"tamam": True})


def post_moderasyon(h, db):
    """sustur / uzaklastir / yasak / kaldir. Oda sahibi kendi odasında, yönetici her yerde (oda='*' = bütün Lives)."""
    k = site.giris_sart(h, db); v = h.govde()
    oda = str(v.get("oda", "")); islem = v.get("islem")
    hedef = db.execute("SELECT * FROM kullanici WHERE id=?", (int(v.get("kid") or 0),)).fetchone()
    if not hedef: raise Hata(404, "Kullanıcı yok")
    if oda == "*":
        if not k["yonetici"]: raise Hata(403, "Bütün Lives'tan yasaklamak yöneticilere özel")
    else:
        oda_coz(db, oda)
        if not moderator_mu(db, k, oda): raise Hata(403, "Bu odada moderasyon yetkin yok")
    if hedef["id"] == k["id"]: raise Hata(400, "Kendine uygulayamazsın")
    if hedef["yonetici"] and not k["yonetici"]: raise Hata(403, "Yöneticiye uygulanamaz")
    if hedef["gizli"]: raise Hata(403, "Uygulanamaz")
    if islem == "kaldir":
        db.execute("DELETE FROM yasak WHERE kid=? AND oda=?", (hedef["id"], oda)); db.commit()
        yayinla(oda, {"tip": "sistem", "metin": f"{hedef['ad']} için kısıtlama kaldırıldı", "kid": hedef["id"]})
        return h.cevap(200, {"tamam": True})
    if islem not in ("sustur", "uzaklastir", "yasak"): raise Hata(400, "Bilinmeyen işlem")
    dk = v.get("dakika")
    dk = None if dk in (None, "", 0, "0") else max(1, min(60 * 24 * 365, int(dk)))
    if islem != "yasak" and not dk: dk = 10
    bitis = su() + dk * 60 if dk else None
    db.execute("INSERT INTO yasak(oda,kid,tur,bitis,veren,neden,tarih) VALUES(?,?,?,?,?,?,?)",
               (oda, hedef["id"], islem, bitis, k["id"], site.metin(v, "neden", 0, 200, False), su()))
    db.commit()
    sure = f"{dk} dakika" if dk else "kalıcı olarak"
    ad = {"sustur": "susturuldu", "uzaklastir": "uzaklaştırıldı", "yasak": "yasaklandı"}[islem]
    if oda == "*":
        for o in list(ODALAR): yayinla(o, {"tip": "yasak", "kid": hedef["id"], "islem": islem, "bitis": bitis})
    else:
        yayinla(oda, {"tip": "sistem", "metin": f"{hedef['ad']} {sure} {ad}", "kid": hedef["id"]})
        yayinla(oda, {"tip": "yasak", "kid": hedef["id"], "islem": islem, "bitis": bitis})
    if islem in ("uzaklastir", "yasak"):
        for o in ([oda] if oda != "*" else list(ODALAR)):
            if o == "resmi" or o[:1] in "ys": lk_cikar(o, hedef["id"])
    h.cevap(200, {"tamam": True})


# ------------------------------------------------------------------ takip, destek, puan, rapor
def _hedef_kul(db, v):
    u = db.execute("SELECT * FROM kullanici WHERE ad=? AND gizli=0", (str(v.get("ad", "")),)).fetchone()
    if not u: raise Hata(404, "Kullanıcı yok")
    return u


def post_takip(h, db):
    k = site.giris_sart(h, db); u = _hedef_kul(db, h.govde())
    if u["id"] == k["id"]: raise Hata(400, "Kendini takip edemezsin")
    if db.execute("DELETE FROM takip WHERE yayinci=? AND kid=?", (u["id"], k["id"])).rowcount == 0:
        db.execute("INSERT INTO takip VALUES(?,?,?)", (u["id"], k["id"], su()))
    db.commit()
    h.cevap(200, {"takip": bool(db.execute("SELECT 1 FROM takip WHERE yayinci=? AND kid=?", (u["id"], k["id"])).fetchone()),
                  "takipci": db.execute("SELECT COUNT(*) FROM takip WHERE yayinci=?", (u["id"],)).fetchone()[0]})


def post_destek(h, db):
    """Destekliyoruz: şu an ücretsiz bir gösterge. Para transferi yok."""
    k = site.giris_sart(h, db); site.sinir(h, "ldestek", 20, 60); u = _hedef_kul(db, h.govde())
    if u["id"] == k["id"]: raise Hata(400, "Kendini destekleyemezsin")
    if db.execute("DELETE FROM destekci WHERE yayinci=? AND kid=?", (u["id"], k["id"])).rowcount == 0:
        db.execute("INSERT INTO destekci(yayinci,kid,tarih) VALUES(?,?,?)", (u["id"], k["id"], su()))
        for r in db.execute("SELECT id FROM yayin WHERE kid=? AND durum='canli'", (u["id"],)):
            yayinla(f"y{r['id']}", {"tip": "destek", "kul": kisi(k)})
    db.commit()
    h.cevap(200, {"destek": bool(db.execute("SELECT 1 FROM destekci WHERE yayinci=? AND kid=?", (u["id"], k["id"])).fetchone())})


def post_puan(h, db):
    k = site.giris_sart(h, db); v = h.govde()
    i = db.execute("SELECT * FROM icerik WHERE id=?", (int(v.get("icerik_id") or 0),)).fetchone()
    if not i: raise Hata(404, "İçerik yok")
    p = int(v.get("puan") or 0)
    if not 1 <= p <= 5: raise Hata(400, "Puan 1-5 arası olmalı")
    db.execute("INSERT INTO puan VALUES(?,?,?,?) ON CONFLICT(icerik_id,kid) DO UPDATE SET puan=excluded.puan, tarih=excluded.tarih", (i["id"], k["id"], p, su()))
    db.commit()
    h.cevap(200, icerik_disari(db, i, k["id"])["puan"])


def post_rapor(h, db):
    k = site.giris_sart(h, db); site.sinir(h, "lrapor", 5, 600); v = h.govde()
    tur = v.get("hedef_tur")
    if tur not in ("yayin", "mesaj", "kullanici", "oda"): raise Hata(400, "Geçersiz")
    db.execute("INSERT INTO lrapor(kid,hedef_tur,hedef_id,neden,tarih) VALUES(?,?,?,?,?)",
               (k["id"], tur, str(v.get("hedef_id", ""))[:40], site.metin(v, "neden", 3, 500), su()))
    db.commit(); h.cevap(200, {"tamam": True})


# ------------------------------------------------------------------ yayın açma / bitirme, sesli odalar
def post_yayin_baslat(h, db):
    k = site.giris_sart(h, db); v = h.govde()
    resmi = bool(v.get("resmi"))
    if resmi and not k["yonetici"]: raise Hata(403, "Resmî kanala sadece yöneticiler yayın açar")
    if not resmi and not yayin_yetkili(k): raise Hata(403, "Yayın açmak için Pro üyelik ya da yayıncı yetkisi gerekir")
    if aktif_yasak(db, k["id"], "*", ("yasak",)): raise Hata(403, "Lives'tan yasaklısın")
    tur = v.get("tur")
    if tur not in ("kamera", "ekran", "sesli"): raise Hata(400, "Yayın türü: kamera, ekran ya da sesli")
    kat = v.get("kategori") if v.get("kategori") in KATEGORILER else "Diğer"
    tema = v.get("tema") if v.get("tema") in TEMALAR else "klasik"
    kapak = str(v.get("kapak") or "")
    if kapak and not re.fullmatch(r"/kapak/[0-9a-f]{32}\.(jpg|png|webp)", kapak): raise Hata(400, "Kapak geçersiz")
    eski = db.execute("SELECT id FROM yayin WHERE kid=? AND durum='canli' AND resmi=?", (k["id"], int(resmi))).fetchone()
    if eski: raise Hata(409, f"Zaten açık bir yayının var (#{eski['id']}). Önce onu bitir.")
    if resmi and db.execute("SELECT 1 FROM yayin WHERE resmi=1 AND durum='canli'").fetchone(): raise Hata(409, "Resmî kanalda zaten canlı yayın var")
    db.execute("""INSERT INTO yayin(kid,baslik,aciklama,kategori,tur,kapak,ozel,tema,resmi,baslangic,konusmaya_acik) VALUES(?,?,?,?,?,?,?,?,?,?,?)""",
               (k["id"], site.metin(v, "baslik", 3, 100), site.metin(v, "aciklama", 0, 500, False), kat, tur, kapak or None,
                0 if resmi else int(bool(v.get("ozel"))), tema, int(resmi), su(), int(bool(v.get("konusmaya_acik")))))
    yid = db.execute("SELECT last_insert_rowid()").fetchone()[0]
    db.execute("INSERT INTO yayin_ornek VALUES(?,?,0)", (yid, su())); db.commit()
    if resmi: yayinla("resmi", {"tip": "durum"})
    h.cevap(200, {"id": yid, "oda": "resmi" if resmi else f"y{yid}"})


def _yayin_bitir(db, r):
    oda_ = "resmi" if r["resmi"] else f"y{r['id']}"
    db.execute("INSERT INTO yayin_ornek VALUES(?,?,?)", (r["id"], su(), izleyici_say(oda_)))
    simdi, izleme = time.time(), 0
    with ODA_KILIT:  # yayın biterken hâlâ izleyenlerin süresi de sayılır
        o = ODALAR.get(oda_)
        if o:
            for q, kim in o.abone.items():
                if kim.startswith("!"): continue
                izleme += max(0, int(simdi - max(o.giris.get(q, simdi), r["baslangic"])))
                o.giris[q] = simdi
    if izleme: db.execute("UPDATE yayin SET izleme_sn=izleme_sn+? WHERE id=?", (izleme, r["id"]))
    db.execute("UPDATE yayin SET durum='bitti', bitis=? WHERE id=?", (su(), r["id"]))
    with ODA_KILIT:
        o = ODALAR.get(f"y{r['id']}")
        if o: db.execute("UPDATE yayin SET tepe=MAX(tepe,?), tekil=MAX(tekil,?) WHERE id=?", (o.tepe, len(o.tekil), r["id"]))
    db.execute("DELETE FROM konusmaci WHERE oda=?", (f"y{r['id']}",)); db.commit()
    oda = "resmi" if r["resmi"] else f"y{r['id']}"
    lk_kapat(oda)
    yayinla(oda, {"tip": "durum", "bitti": True})


def post_yayin_bitir(h, db):
    k = site.giris_sart(h, db); v = h.govde()
    r = db.execute("SELECT * FROM yayin WHERE id=?", (int(v.get("id") or 0),)).fetchone()
    if not r: raise Hata(404, "Yayın yok")
    if r["kid"] != k["id"] and not k["yonetici"]: raise Hata(403, "Bu yayını bitiremezsin")
    if r["durum"] == "canli": _yayin_bitir(db, r)
    r = db.execute("SELECT * FROM yayin WHERE id=?", (r["id"],)).fetchone()
    y = yayin_disari(db, r)
    y["destekci"] = db.execute("SELECT COUNT(*) FROM destekci WHERE yayinci=? AND tarih>=?", (r["kid"], r["baslangic"])).fetchone()[0]
    y["takipci_yeni"] = db.execute("SELECT COUNT(*) FROM takip WHERE yayinci=? AND tarih>=?", (r["kid"], r["baslangic"])).fetchone()[0]
    y |= yayin_istatistik(db, r)
    h.cevap(200, {"istatistik": y})


def yayin_istatistik(db, r):
    """Gerçek verilerden: izlenme süresi, izleyici grafiği (30 sn'lik örnekler), anket sonuçları, performans özeti."""
    oda = "resmi" if r["resmi"] else f"y{r['id']}"
    ornek = [{"t": o["t"], "n": o["n"]} for o in db.execute("SELECT t, n FROM yayin_ornek WHERE yayin_id=? ORDER BY t", (r["id"],))]
    sure = max(1, (r["bitis"] or su()) - r["baslangic"])
    anketler = []
    for a in db.execute("SELECT * FROM lanket WHERE oda=? AND olusturma>=? ORDER BY id", (oda, r["baslangic"] - 5)):
        anketler.append(anket_disari(db, a))
    izleme = r["izleme_sn"] or 0
    ort = round(izleme / r["tekil"]) if r["tekil"] else 0
    ozet = []
    if r["tekil"]: ozet.append(f"{r['tekil']} farklı kişi izledi, en kalabalık anda {r['tepe']} kişi vardı.")
    if ort: ozet.append(f"Bir izleyici ortalama {ort // 60} dk {ort % 60} sn kaldı.")
    if r["mesaj"]: ozet.append(f"Sohbette {r['mesaj']} mesaj yazıldı (dakikada {r['mesaj'] / (sure / 60):.1f}).")
    if ornek:
        enc = max(ornek, key=lambda o: o["n"])
        if enc["n"]: ozet.append(f"İzleyici zirvesi yayının {(enc['t'] - r['baslangic']) // 60}. dakikasındaydı.")
    if not ozet: ozet.append("Bu yayını henüz kimse izlemedi; yayın bağlantısını paylaşarak izleyici toplayabilirsin.")
    return {"sure": sure, "izleme_sn": izleme, "ort_izleme_sn": ort, "grafik": ornek, "anketler": anketler, "ozet": ozet}


def post_yayin_ayar(h, db):
    """Yayıncı (ya da yönetici): sesli yayında konuşmaya açık/kapalı, tema."""
    k = site.giris_sart(h, db); v = h.govde()
    r = db.execute("SELECT * FROM yayin WHERE id=? AND durum='canli'", (int(v.get("id") or 0),)).fetchone()
    if not r or (r["kid"] != k["id"] and not k["yonetici"]): raise Hata(403, "Yetkin yok")
    if "tema" in v and v["tema"] in TEMALAR: db.execute("UPDATE yayin SET tema=? WHERE id=?", (v["tema"], r["id"]))
    if "konusmaya_acik" in v: db.execute("UPDATE yayin SET konusmaya_acik=? WHERE id=?", (int(bool(v["konusmaya_acik"])), r["id"]))
    db.commit()
    yayinla("resmi" if r["resmi"] else f"y{r['id']}", {"tip": "durum"})
    h.cevap(200, {"tamam": True})


def post_konusmaci(h, db):
    """Sesli yayın / sesli oda: birine konuşma izni ver ya da susturup dinleyici yap."""
    k = site.giris_sart(h, db); v = h.govde()
    oda = str(v.get("oda", "")); tur, r, sahip = oda_coz(db, oda)
    if not moderator_mu(db, k, oda): raise Hata(403, "Yetkin yok")
    kid = int(v.get("kid") or 0); izin = bool(v.get("izin"))
    if izin: db.execute("INSERT OR IGNORE INTO konusmaci VALUES(?,?)", (oda, kid)); db.execute("DELETE FROM yasak WHERE oda=? AND kid=? AND tur='mikrofon'", (oda, kid))
    else:
        db.execute("DELETE FROM konusmaci WHERE oda=? AND kid=?", (oda, kid))
        if tur == "ses": db.execute("INSERT INTO yasak(oda,kid,tur,bitis,veren,tarih) VALUES(?,?,?,?,?,?)", (oda, kid, "mikrofon", None, k["id"], su()))
    db.commit()
    lk_konusma(oda, kid, izin)
    yayinla(oda, {"tip": "konusmaci", "kid": kid, "izin": izin})
    h.cevap(200, {"tamam": True})


def post_cikar(h, db):
    """Sesli odadan / yayından çıkar (LiveKit'ten at + belirtilen süre uzaklaştır)."""
    k = site.giris_sart(h, db); v = h.govde()
    oda = str(v.get("oda", "")); oda_coz(db, oda)
    if not moderator_mu(db, k, oda): raise Hata(403, "Yetkin yok")
    hedef = kul(db, int(v.get("kid") or 0))
    if not hedef or hedef["id"] == k["id"] or (hedef["yonetici"] and not k["yonetici"]): raise Hata(403, "Uygulanamaz")
    db.execute("INSERT INTO yasak(oda,kid,tur,bitis,veren,tarih) VALUES(?,?,?,?,?,?)", (oda, hedef["id"], "uzaklastir", su() + 600, k["id"], su()))
    db.commit()
    lk_cikar(oda, hedef["id"])
    yayinla(oda, {"tip": "yasak", "kid": hedef["id"], "islem": "uzaklastir", "bitis": su() + 600})
    yayinla(oda, {"tip": "sistem", "metin": f"{hedef['ad']} odadan çıkarıldı (10 dk)"})
    h.cevap(200, {"tamam": True})


def post_oda_ac(h, db):
    k = site.giris_sart(h, db); v = h.govde()
    if not yayin_yetkili(k): raise Hata(403, "Sesli oda açmak için Pro üyelik ya da yayıncı yetkisi gerekir")
    if db.execute("SELECT COUNT(*) FROM ses_oda WHERE kid=? AND durum='acik'", (k["id"],)).fetchone()[0] >= 2: raise Hata(409, "En fazla 2 açık odan olabilir")
    db.execute("INSERT INTO ses_oda(kid,baslik,aciklama,olusturma) VALUES(?,?,?,?)", (k["id"], site.metin(v, "baslik", 3, 80), site.metin(v, "aciklama", 0, 300, False), su()))
    oid = db.execute("SELECT last_insert_rowid()").fetchone()[0]; db.commit()
    h.cevap(200, {"id": oid})


def post_oda_kapat(h, db):
    k = site.giris_sart(h, db); v = h.govde()
    r = db.execute("SELECT * FROM ses_oda WHERE id=?", (int(v.get("id") or 0),)).fetchone()
    if not r: raise Hata(404, "Oda yok")
    if r["resmi"] and not k["yonetici"]: raise Hata(403, "Resmî oda kapatılamaz")
    if r["kid"] != k["id"] and not k["yonetici"]: raise Hata(403, "Yetkin yok")
    ac = bool(v.get("ac"))
    db.execute("UPDATE ses_oda SET durum=?, kapanis=? WHERE id=?", ("acik" if ac else "kapali", None if ac else su(), r["id"])); db.commit()
    if not ac: lk_kapat(f"s{r['id']}")
    yayinla(f"s{r['id']}", {"tip": "durum", "bitti": not ac})
    h.cevap(200, {"tamam": True})


def post_token(h, db):
    """LiveKit erişim jetonu. Yetkiler burada belirlenir; tarayıcı kendine yetki veremez."""
    k = h.kullanici(db); v = h.govde()
    oda = str(v.get("oda", "")); mod = v.get("mod", "izle")
    tur, r, sahip = oda_coz(db, oda)
    if k and aktif_yasak(db, k["id"], oda, ("yasak", "uzaklastir")): raise Hata(403, "Bu odaya giremezsin")
    istemci = re.sub(r"[^a-zA-Z0-9]", "", str(v.get("c", "")))[:24] or secrets.token_hex(6)
    kimlik = f"k{k['id']}" if k else f"m{istemci}"
    ad = k["ad"] if k else "Misafir"
    meta = {"ad": ad, "rozet": rozet(k), "id": k["id"] if k else None}
    izin = {"roomJoin": True, "canSubscribe": True, "canPublish": False, "canPublishData": False}
    if tur == "resmi":
        canli = db.execute("SELECT * FROM yayin WHERE resmi=1 AND durum='canli'").fetchone()
        if mod == "yayinla":
            if not (k and k["yonetici"] and canli): raise Hata(403, "Resmî kanalda yayın için yönetici olmalı ve yayın açılmış olmalı")
            izin |= {"canPublish": True, "canPublishSources": ["camera", "microphone", "screen_share", "screen_share_audio"]}
            meta["yayinci"] = True
    elif tur == "yayin":
        if r["durum"] != "canli": raise Hata(410, "Yayın bitti")
        if mod == "yayinla":
            if not k or k["id"] != r["kid"]: raise Hata(403, "Bu yayını sadece sahibi yayınlayabilir")
            kaynak = {"kamera": ["camera", "microphone"], "ekran": ["screen_share", "screen_share_audio", "microphone"], "sesli": ["microphone"]}[r["tur"]]
            izin |= {"canPublish": True, "canPublishSources": kaynak}; meta["yayinci"] = True
        elif r["tur"] == "sesli" and k and (r["konusmaya_acik"] or db.execute("SELECT 1 FROM konusmaci WHERE oda=? AND kid=?", (oda, k["id"])).fetchone()):
            izin |= {"canPublish": True, "canPublishSources": ["microphone"]}
    else:  # sesli oda
        if r["durum"] != "acik": raise Hata(410, "Oda kapalı")
        if not k: raise Hata(401, "Sesli odalara katılmak için giriş yap")
        if not db.execute("SELECT 1 FROM yasak WHERE oda=? AND kid=? AND tur='mikrofon'", (oda, k["id"])).fetchone():
            izin |= {"canPublish": True, "canPublishSources": ["microphone"]}
        izin["canPublishData"] = True
    h.cevap(200, {"token": lk_jeton(kimlik, ad, oda, izin, meta), "kimlik": kimlik, "yayinlayabilir": izin["canPublish"]})


# ------------------------------------------------------------------ yönetim (sadece yönetici)
def post_yonetim_icerik(h, db):
    site.yonetici_sart(h, db); v = h.govde()
    if v.get("sil"):
        i = db.execute("SELECT * FROM icerik WHERE id=?", (int(v["sil"]),)).fetchone()
        db.execute("DELETE FROM icerik WHERE id=?", (int(v["sil"]),)); db.execute("UPDATE program SET icerik_id=NULL WHERE icerik_id=?", (int(v["sil"]),))
        db.execute("DELETE FROM puan WHERE icerik_id=?", (int(v["sil"]),))
        db.commit()
        if i and i["dosya"]:
            for f in (i["dosya"], i["dosya"].rsplit(".", 1)[0] + ".jpg"):
                try: os.remove(os.path.join(VIDEO_DIZIN, f))
                except OSError: pass
        return h.cevap(200, {"tamam": True})
    tur = v.get("tur") if v.get("tur") in ("film", "dizi", "program", "diger") else "program"
    kaynak = str(v.get("kaynak") or "").strip()
    eski = db.execute("SELECT * FROM icerik WHERE id=?", (int(v.get("id") or 0),)).fetchone()
    if eski and eski["dosya"] and not kaynak: kaynak = eski["kaynak"]  # yüklenmiş videonun kaynağı korunur
    if kaynak and not (re.fullmatch(r"https://\S{4,800}", kaynak) or re.fullmatch(r"/video/[0-9a-f]{32}\.(mp4|webm)", kaynak)):
        raise Hata(400, "Kaynak https:// ile başlayan bir video bağlantısı olmalı (mp4, m3u8 ya da YouTube) ya da yüklenmiş video")
    kapak = str(v.get("kapak") or "").strip()
    if kapak and not (re.fullmatch(r"/(kapak|video)/[0-9a-f]{32}\.(jpg|png|webp)", kapak) or re.fullmatch(r"https://\S{4,500}", kapak)): raise Hata(400, "Kapak geçersiz")
    kat = v.get("kategori") if v.get("kategori") in ICERIK_KATEGORI else None
    yas = v.get("yas") if v.get("yas") in YASLAR else "genel"
    alan = (site.metin(v, "ad", 1, 120), tur, site.metin(v, "aciklama", 0, 1000, False), kapak or (eski["kapak"] if eski else None), kaynak or None, kat, yas)
    iid = int(v.get("id") or 0)
    if iid: db.execute("UPDATE icerik SET ad=?, tur=?, aciklama=?, kapak=?, kaynak=?, kategori=?, yas=? WHERE id=?", (*alan, iid))
    else: db.execute("INSERT INTO icerik(ad,tur,aciklama,kapak,kaynak,kategori,yas,olusturma) VALUES(?,?,?,?,?,?,?,?)", (*alan, su())); iid = db.execute("SELECT last_insert_rowid()").fetchone()[0]
    db.commit(); yayinla("resmi", {"tip": "durum"})
    h.cevap(200, {"id": iid})


def zaman_coz(s):
    try: return int(datetime.datetime.strptime(str(s), "%Y-%m-%dT%H:%M").replace(tzinfo=TR).timestamp())
    except ValueError: raise Hata(400, "Tarih/saat biçimi: 2026-11-28T20:00")


def post_yonetim_program(h, db):
    site.yonetici_sart(h, db); v = h.govde()
    if v.get("sil"):
        db.execute("DELETE FROM program WHERE id=?", (int(v["sil"]),)); db.commit(); yayinla("resmi", {"tip": "durum"})
        return h.cevap(200, {"tamam": True})
    bas, bit = zaman_coz(v.get("baslangic")), zaman_coz(v.get("bitis"))
    if bit <= bas: raise Hata(400, "Bitiş başlangıçtan sonra olmalı")
    if bit - bas > 24 * 3600: raise Hata(400, "Bir program en fazla 24 saat olabilir")
    pid = int(v.get("id") or 0)
    cakisan = db.execute("SELECT baslik FROM program WHERE id!=? AND baslangic<? AND bitis>?", (pid, bit, bas)).fetchone()
    if cakisan: raise Hata(409, f"Bu saatte başka program var: {cakisan['baslik']}")
    iid = int(v.get("icerik_id") or 0) or None
    if iid and not db.execute("SELECT 1 FROM icerik WHERE id=?", (iid,)).fetchone(): raise Hata(404, "İçerik yok")
    alan = (iid, site.metin(v, "baslik", 1, 120), site.metin(v, "aciklama", 0, 500, False), bas, bit)
    if pid: db.execute("UPDATE program SET icerik_id=?, baslik=?, aciklama=?, baslangic=?, bitis=? WHERE id=?", (*alan, pid))
    else: db.execute("INSERT INTO program(icerik_id,baslik,aciklama,baslangic,bitis) VALUES(?,?,?,?,?)", alan); pid = db.execute("SELECT last_insert_rowid()").fetchone()[0]
    db.commit(); yayinla("resmi", {"tip": "durum"})
    h.cevap(200, {"id": pid})


def post_yonetim_program_kopyala(h, db):
    """Bir günün programını başka güne kopyala (günlük güncellemeyi hızlandırır)."""
    site.yonetici_sart(h, db); v = h.govde()
    kb, ks = gun_araligi(str(v.get("kaynak_gun"))); hb, _ = gun_araligi(str(v.get("hedef_gun")))
    fark = hb - kb; n = 0
    for p in db.execute("SELECT * FROM program WHERE baslangic>=? AND baslangic<?", (kb, ks)).fetchall():
        if not db.execute("SELECT 1 FROM program WHERE baslangic<? AND bitis>?", (p["bitis"] + fark, p["baslangic"] + fark)).fetchone():
            db.execute("INSERT INTO program(icerik_id,baslik,aciklama,baslangic,bitis) VALUES(?,?,?,?,?)", (p["icerik_id"], p["baslik"], p["aciklama"], p["baslangic"] + fark, p["bitis"] + fark)); n += 1
    db.commit(); yayinla("resmi", {"tip": "durum"})
    h.cevap(200, {"kopyalanan": n})


def post_yonetim_kanal(h, db):
    site.yonetici_sart(h, db); v = h.govde()
    for ad, anahtar in (("tema", "resmi_tema"), ("nosignal", "resmi_nosignal"), ("kapali", "resmi_kapali"), ("logo", "resmi_logo"),
                        ("kapak", "resmi_kapak"), ("aciklama", "resmi_aciklama"), ("renk", "resmi_renk"), ("tasarim", "resmi_tasarim")):
        if ad not in v: continue
        d = v[ad]
        if ad == "tema" and d not in TEMALAR: raise Hata(400, "Tema geçersiz")
        if ad in ("logo", "kapak") and d and not re.fullmatch(r"/kapak/[0-9a-f]{32}\.(jpg|png|webp)", str(d)): raise Hata(400, "Görsel geçersiz")
        if ad == "renk" and not re.fullmatch(r"#[0-9a-fA-F]{6}", str(d)): raise Hata(400, "Renk geçersiz")
        if ad == "tasarim" and d not in ("sinema", "modern", "klasik", "neon"): raise Hata(400, "Tasarım geçersiz")
        d = ("1" if d else "0") if ad == "kapali" else str(d).strip()[:600 if ad == "aciklama" else 200]
        db.execute("INSERT INTO ayar VALUES(?,?) ON CONFLICT(ad) DO UPDATE SET deger=excluded.deger", (anahtar, d))
    db.commit(); yayinla("resmi", {"tip": "durum"})
    h.cevap(200, {"tamam": True})


def post_yonetim_one_cikar(h, db):
    site.yonetici_sart(h, db); v = h.govde()
    db.execute("UPDATE yayin SET one_cikan=? WHERE id=?", (int(bool(v.get("one_cikan"))), int(v.get("id") or 0))); db.commit()
    h.cevap(200, {"tamam": True})


def post_yonetim_yayinci(h, db):
    site.yonetici_sart(h, db); u = _hedef_kul(db, h.govde()); v = h._govde
    db.execute("UPDATE kullanici SET yayinci=? WHERE id=?", (int(bool(v.get("ver"))), u["id"])); db.commit()
    h.cevap(200, {"tamam": True})


def post_yonetim_rapor(h, db):
    site.yonetici_sart(h, db); v = h.govde()
    if v.get("durum") not in ("yeni", "incelendi", "islem"): raise Hata(400, "Geçersiz")
    db.execute("UPDATE lrapor SET durum=? WHERE id=?", (v["durum"], int(v.get("id") or 0))); db.commit()
    h.cevap(200, {"tamam": True})


def get_yonetim(h, db, q):
    site.yonetici_sart(h, db)
    gun = q.get("gun") or datetime.datetime.now(TR).strftime("%Y-%m-%d")
    bas, son = gun_araligi(gun)
    say = lambda s, *a: db.execute(s, a).fetchone()[0]
    icerikler = [icerik_disari(db, i) | {"puanlar": [say("SELECT COUNT(*) FROM puan WHERE icerik_id=? AND puan=?", i["id"], n) for n in range(1, 6)]}
                 for i in db.execute("SELECT * FROM icerik ORDER BY id DESC")]
    yasaklar = [dict(y) | {"ad": (kul(db, y["kid"]) or {"ad": "?"})["ad"], "veren_ad": (kul(db, y["veren"]) or {"ad": "?"})["ad"]}
                for y in db.execute("SELECT * FROM yasak WHERE tur!='mikrofon' AND (bitis IS NULL OR bitis>?) ORDER BY id DESC LIMIT 200", (su(),))]
    raporlar = []
    for r in db.execute("SELECT * FROM lrapor ORDER BY durum='yeni' DESC, id DESC LIMIT 200"):
        d = dict(r) | {"bildiren": (kul(db, r["kid"]) or {"ad": "?"})["ad"]}
        if r["hedef_tur"] == "mesaj":
            m = db.execute("SELECT l.*, k.ad FROM lmesaj l LEFT JOIN kullanici k ON k.id=l.kid WHERE l.id=?", (r["hedef_id"],)).fetchone()
            d["ayrinti"] = f"{m['ad']}: {m['metin']}" if m else "mesaj silinmiş"
            d["hedef_kid"] = m["kid"] if m else None; d["oda"] = m["oda"] if m else None
        elif r["hedef_tur"] == "yayin":
            y = db.execute("SELECT baslik, durum FROM yayin WHERE id=?", (r["hedef_id"],)).fetchone()
            d["ayrinti"] = f"Yayın #{r['hedef_id']}: {y['baslik']} ({y['durum']})" if y else "yayın yok"
        else: d["ayrinti"] = f"{r['hedef_tur']} {r['hedef_id']}"
        raporlar.append(d)
    h.cevap(200, {
        "gun": gun, "kanal": kanal_ayar(db), "durum": resmi_durum(db), "kategoriler": ICERIK_KATEGORI, "yaslar": YASLAR,
        "program": [program_disari(db, p) for p in db.execute("SELECT * FROM program WHERE bitis>? AND baslangic<? ORDER BY baslangic", (bas, son))],
        "icerikler": icerikler,
        "aktif": [yayin_disari(db, r) for r in db.execute("SELECT * FROM yayin WHERE durum='canli' ORDER BY id DESC")],
        "gecmis": [yayin_disari(db, r) for r in db.execute("SELECT * FROM yayin WHERE durum='bitti' ORDER BY id DESC LIMIT 50")],
        "odalar": [oda_disari(db, r) for r in db.execute("SELECT * FROM ses_oda ORDER BY durum='acik' DESC, id DESC LIMIT 50")],
        "yasaklar": yasaklar, "raporlar": raporlar,
        "yayincilar": [kisi(u) for u in db.execute("SELECT * FROM kullanici WHERE yayinci=1 AND gizli=0")],
        "istatistik": {"toplam_yayin": say("SELECT COUNT(*) FROM yayin"), "canli": say("SELECT COUNT(*) FROM yayin WHERE durum='canli'"),
                       "toplam_izleyici": say("SELECT COALESCE(SUM(tekil),0) FROM yayin"), "en_cok": say("SELECT COALESCE(MAX(tepe),0) FROM yayin"),
                       "mesaj": say("SELECT COUNT(*) FROM lmesaj"), "yayinci": say("SELECT COUNT(DISTINCT kid) FROM yayin WHERE resmi=0"),
                       "puan": say("SELECT COUNT(*) FROM puan"), "yeni_rapor": say("SELECT COUNT(*) FROM lrapor WHERE durum='yeni'"),
                       "resmi_izleyici": izleyici_say("resmi")},
    })


# ------------------------------------------------------------------ kapak görseli yükleme (gövde = ham resim)
def kapak_yukle(h, db, kilit):
    with kilit:
        k = site.giris_sart(h, db)
        if not (yayin_yetkili(k) or k["yonetici"]): raise Hata(403, "Kapak yüklemek için yayın yetkisi gerekir")
        site.sinir(h, "kapak", 10, 600)
    try: n = int(h.headers.get("Content-Length", 0))
    except ValueError: n = -1
    if not 12 <= n <= 2 * 1024 * 1024: raise Hata(413, "Kapak en fazla 2 MB olabilir")
    veri = h.rfile.read(n)
    if veri[:3] == b"\xff\xd8\xff": uz = "jpg"
    elif veri[:8] == b"\x89PNG\r\n\x1a\n": uz = "png"
    elif veri[:4] == b"RIFF" and veri[8:12] == b"WEBP": uz = "webp"
    else: raise Hata(400, "Sadece JPG, PNG ya da WEBP")
    os.makedirs(KAPAK_DIZIN, exist_ok=True)
    ad = secrets.token_hex(16) + "." + uz
    with open(os.path.join(KAPAK_DIZIN, ad), "wb") as f: f.write(veri)
    os.chmod(os.path.join(KAPAK_DIZIN, ad), 0o644)
    h.cevap(200, {"kapak": "/kapak/" + ad})


# ------------------------------------------------------------------ V2: canlı anketler
def anket_disari(db, a, kid=None):
    sec = json.loads(a["secenekler"]); say = [0] * len(sec)
    for r in db.execute("SELECT secim, COUNT(*) c FROM lanket_oy WHERE anket_id=? GROUP BY secim", (a["id"],)):
        if 0 <= r["secim"] < len(say): say[r["secim"]] = r["c"]
    benim = db.execute("SELECT secim FROM lanket_oy WHERE anket_id=? AND kid=?", (a["id"], kid)).fetchone() if kid else None
    return {"id": a["id"], "soru": a["soru"], "secenekler": sec, "oylar": say, "toplam": sum(say), "durum": a["durum"], "benim": benim["secim"] if benim else None}


def acik_anket(db, oda, k):
    a = db.execute("SELECT * FROM lanket WHERE oda=? ORDER BY id DESC LIMIT 1", (oda,)).fetchone()
    if not a or (a["durum"] != "acik" and su() - (a["bitis"] or 0) > 120): return None  # biten anket 2 dk ekranda kalır
    return anket_disari(db, a, k["id"] if k else None)


def post_anket_olustur(h, db):
    k = site.giris_sart(h, db); v = h.govde()
    oda = str(v.get("oda", "")); tur, r, sahip = oda_coz(db, oda)
    if not moderator_mu(db, k, oda): raise Hata(403, "Anketi sadece yayın sahibi ya da yönetici açabilir")
    if tur == "yayin" and r["durum"] != "canli": raise Hata(400, "Yayın bitti")
    sec = [str(s).strip()[:80] for s in (v.get("secenekler") or []) if str(s).strip()]
    if not 2 <= len(sec) <= 6: raise Hata(400, "2 ile 6 arası seçenek gir")
    db.execute("UPDATE lanket SET durum='bitti', bitis=? WHERE oda=? AND durum='acik'", (su(), oda))
    db.execute("INSERT INTO lanket(oda,soru,secenekler,olusturma) VALUES(?,?,?,?)", (oda, site.metin(v, "soru", 3, 150), json.dumps(sec, ensure_ascii=False), su()))
    a = db.execute("SELECT * FROM lanket WHERE id=last_insert_rowid()").fetchone(); db.commit()
    yayinla(oda, {"tip": "anket", "anket": anket_disari(db, a)})
    h.cevap(200, {"anket": anket_disari(db, a, k["id"])})


def post_anket_oy(h, db):
    k = site.giris_sart(h, db); v = h.govde()
    a = db.execute("SELECT * FROM lanket WHERE id=?", (int(v.get("id") or 0),)).fetchone()
    if not a: raise Hata(404, "Anket yok")
    if a["durum"] != "acik": raise Hata(400, "Anket bitti")
    s = int(v.get("secim", -1))
    if not 0 <= s < len(json.loads(a["secenekler"])): raise Hata(400, "Geçersiz seçenek")
    if db.execute("SELECT 1 FROM lanket_oy WHERE anket_id=? AND kid=?", (a["id"], k["id"])).fetchone(): raise Hata(409, "Bu ankette zaten oy kullandın")
    db.execute("INSERT INTO lanket_oy VALUES(?,?,?)", (a["id"], k["id"], s)); db.commit()
    yayinla(a["oda"], {"tip": "anket", "anket": anket_disari(db, a)})
    h.cevap(200, {"anket": anket_disari(db, a, k["id"])})


def post_anket_bitir(h, db):
    k = site.giris_sart(h, db); v = h.govde()
    a = db.execute("SELECT * FROM lanket WHERE id=?", (int(v.get("id") or 0),)).fetchone()
    if not a: raise Hata(404, "Anket yok")
    if not moderator_mu(db, k, a["oda"]): raise Hata(403, "Yetkin yok")
    db.execute("UPDATE lanket SET durum='bitti', bitis=? WHERE id=?", (su(), a["id"])); db.commit()
    a = db.execute("SELECT * FROM lanket WHERE id=?", (a["id"],)).fetchone()
    yayinla(a["oda"], {"tip": "anket", "anket": anket_disari(db, a)})
    h.cevap(200, {"anket": anket_disari(db, a, k["id"])})


# ------------------------------------------------------------------ V2: program hatırlatmaları
def post_hatirlat(h, db):
    k = site.giris_sart(h, db); v = h.govde()
    p = db.execute("SELECT * FROM program WHERE id=?", (int(v.get("program_id") or 0),)).fetchone()
    if not p: raise Hata(404, "Program yok")
    if p["baslangic"] <= su(): raise Hata(400, "Bu program başladı ya da bitti")
    if db.execute("DELETE FROM lhatirlatma WHERE program_id=? AND kid=?", (p["id"], k["id"])).rowcount == 0:
        if db.execute("SELECT COUNT(*) FROM lhatirlatma WHERE kid=?", (k["id"],)).fetchone()[0] >= 100: raise Hata(400, "En çok 100 hatırlatma")
        db.execute("INSERT INTO lhatirlatma VALUES(?,?,?)", (p["id"], k["id"], su()))
    db.commit()
    h.cevap(200, {"hatirlatiyorum": bool(db.execute("SELECT 1 FROM lhatirlatma WHERE program_id=? AND kid=?", (p["id"], k["id"])).fetchone())})


def get_hatirlatmalar(h, db, q):
    k = site.giris_sart(h, db)
    db.execute("DELETE FROM lhatirlatma WHERE kid=? AND program_id IN (SELECT id FROM program WHERE bitis<?)", (k["id"], su()))
    l = [program_disari(db, p, k["id"]) for p in db.execute("SELECT p.* FROM program p JOIN lhatirlatma h ON h.program_id=p.id WHERE h.kid=? ORDER BY p.baslangic", (k["id"],))]
    yaklasan = [program_disari(db, p, k["id"]) for p in db.execute("SELECT * FROM program WHERE baslangic>? ORDER BY baslangic LIMIT 20", (su(),))]
    db.commit()
    h.cevap(200, {"hatirlatmalar": l, "yaklasan": yaklasan, "sunucu_zamani": su()})


# ------------------------------------------------------------------ V2: takvim ve YouTube programı
def get_takvim(h, db, q):
    k = h.kullanici(db)
    bas, _ = gun_araligi(q.get("gun") or datetime.datetime.now(TR).strftime("%Y-%m-%d"))
    son = bas + 7 * 86400
    h.cevap(200, {"bas": bas, "program": [program_disari(db, p, k["id"] if k else None) for p in db.execute("SELECT * FROM program WHERE bitis>? AND baslangic<? ORDER BY baslangic", (bas, son))]})


def youtube_kimlik(url):
    m = re.fullmatch(r"https://(?:www\.|m\.)?(?:youtube\.com/(?:watch\?(?:.*&)?v=|embed/|live/|shorts/)|youtu\.be/)([\w-]{11})(?:[?&#].*)?", url.strip())
    return m.group(1) if m else None


def post_yonetim_youtube(h, db):
    """Tek adımda: YouTube bağlantısından içerik + programa ekleme."""
    site.yonetici_sart(h, db); v = h.govde()
    yt = youtube_kimlik(str(v.get("url", "")))
    if not yt: raise Hata(400, "Geçerli bir YouTube video bağlantısı gir (youtube.com/watch?v=… ya da youtu.be/…)")
    bas = zaman_coz(v.get("baslangic"))
    sure_dk = max(1, min(24 * 60, int(v.get("sure_dk") or 60)))
    bit = bas + sure_dk * 60
    if db.execute("SELECT baslik FROM program WHERE baslangic<? AND bitis>?", (bit, bas)).fetchone(): raise Hata(409, "Bu saatte başka program var")
    ad = site.metin(v, "ad", 1, 120)
    kat = v.get("kategori") if v.get("kategori") in ICERIK_KATEGORI else "Program"
    yas = v.get("yas") if v.get("yas") in YASLAR else "genel"
    db.execute("INSERT INTO icerik(ad,tur,aciklama,kapak,kaynak,kategori,yas,sure,olusturma) VALUES(?,?,?,?,?,?,?,?,?)",
               (ad, "program", site.metin(v, "aciklama", 0, 1000, False), f"https://i.ytimg.com/vi/{yt}/hqdefault.jpg", f"https://www.youtube.com/watch?v={yt}", kat, yas, sure_dk * 60, su()))
    iid = db.execute("SELECT last_insert_rowid()").fetchone()[0]
    db.execute("INSERT INTO program(icerik_id,baslik,aciklama,baslangic,bitis) VALUES(?,?,?,?,?)", (iid, ad, site.metin(v, "aciklama", 0, 500, False), bas, bit))
    db.commit(); yayinla("resmi", {"tip": "durum"})
    h.cevap(200, {"icerik_id": iid})


# ------------------------------------------------------------------ V2: video yükleme (parça parça, yöneticiler)
VIDEO_EN_COK = 4 * 1024 ** 3   # 4 GB
PARCA = 8 * 1024 * 1024        # tarayıcı 8 MB'lık parçalar gönderir


def post_video_basla(h, db):
    k = site.yonetici_sart(h, db); v = h.govde()
    boyut = int(v.get("boyut") or 0)
    if not 1024 <= boyut <= VIDEO_EN_COK: raise Hata(400, "Video 4 GB'tan küçük olmalı")
    uz = {"video/mp4": "mp4", "video/quicktime": "mp4", "video/webm": "webm", "video/x-m4v": "mp4"}.get(str(v.get("tur", "")))
    if not uz: raise Hata(400, "Sadece MP4, MOV ya da WEBM video yüklenebilir")
    os.makedirs(VIDEO_DIZIN, exist_ok=True)
    bos = shutil.disk_usage(VIDEO_DIZIN).free
    if boyut > bos - 3 * 1024 ** 3: raise Hata(507, f"Sunucuda yer yok (boş: {bos // 1024 ** 2} MB; en az 3 GB boş kalmalı)")
    bilgi = {"ad": site.metin(v, "ad", 1, 120), "aciklama": site.metin(v, "aciklama", 0, 1000, False), "kapak": str(v.get("kapak") or ""),
             "kategori": v.get("kategori") if v.get("kategori") in ICERIK_KATEGORI else "Film", "yas": v.get("yas") if v.get("yas") in YASLAR else "genel",
             "tur": v.get("icerik_tur") if v.get("icerik_tur") in ("film", "dizi", "program", "diger") else "film"}
    if bilgi["kapak"] and not re.fullmatch(r"/kapak/[0-9a-f]{32}\.(jpg|png|webp)", bilgi["kapak"]): raise Hata(400, "Kapak geçersiz")
    yid = secrets.token_hex(16)
    db.execute("DELETE FROM yukleme WHERE tarih<?", (su() - 86400,))
    db.execute("INSERT INTO yukleme(id,kid,boyut,uzanti,bilgi,tarih) VALUES(?,?,?,?,?,?)", (yid, k["id"], boyut, uz, json.dumps(bilgi, ensure_ascii=False), su()))
    db.commit()
    open(os.path.join(VIDEO_DIZIN, f".{yid}.part"), "wb").close()
    h.cevap(200, {"id": yid, "parca": PARCA})


def video_parca(h, db, kilit):
    """Gövde = ham video parçası. ?id=…&ofset=… ; sıradaki parça olmak zorunda (yarıda kalan yükleme kaldığı yerden sürer)."""
    q = dict(urllib.parse.parse_qsl(urllib.parse.urlparse(h.path).query))
    with kilit:
        k = site.yonetici_sart(h, db)
        y = db.execute("SELECT * FROM yukleme WHERE id=? AND kid=?", (str(q.get("id", "")), k["id"])).fetchone()
    if not y: raise Hata(404, "Yükleme bulunamadı")
    yol = os.path.join(VIDEO_DIZIN, f".{y['id']}.part")
    try: n = int(h.headers.get("Content-Length", 0)); ofset = int(q.get("ofset", -1))
    except ValueError: raise Hata(400, "Bozuk istek")
    mevcut = os.path.getsize(yol) if os.path.exists(yol) else 0
    if ofset != mevcut: return h.cevap(409, {"hata": "Sıra dışı parça", "alinan": mevcut})
    if not 0 < n <= PARCA or mevcut + n > y["boyut"]: raise Hata(413, "Parça boyutu geçersiz")
    with open(yol, "ab") as f:
        kalan = n
        while kalan:
            b = h.rfile.read(min(1 << 20, kalan))
            if not b: raise Hata(400, "Parça yarıda kesildi")
            f.write(b); kalan -= len(b)
    with kilit:
        db.execute("UPDATE yukleme SET alinan=? WHERE id=?", (mevcut + n, y["id"])); db.commit()
    h.cevap(200, {"alinan": mevcut + n})


def post_video_bitir(h, db):
    k = site.yonetici_sart(h, db); v = h.govde()
    y = db.execute("SELECT * FROM yukleme WHERE id=? AND kid=?", (str(v.get("id", "")), k["id"])).fetchone()
    if not y: raise Hata(404, "Yükleme bulunamadı")
    gecici = os.path.join(VIDEO_DIZIN, f".{y['id']}.part")
    if not os.path.exists(gecici) or os.path.getsize(gecici) != y["boyut"]: raise Hata(400, "Video tamamen yüklenmedi")
    with open(gecici, "rb") as f: bas = f.read(12)
    if not (bas[4:8] == b"ftyp" or bas[:4] == b"\x1a\x45\xdf\xa3"):
        os.remove(gecici); db.execute("DELETE FROM yukleme WHERE id=?", (y["id"],)); db.commit()
        raise Hata(400, "Bu dosya geçerli bir MP4/MOV/WEBM video değil")
    ad = secrets.token_hex(16) + "." + y["uzanti"]
    os.replace(gecici, os.path.join(VIDEO_DIZIN, ad)); os.chmod(os.path.join(VIDEO_DIZIN, ad), 0o644)
    b = json.loads(y["bilgi"])
    db.execute("INSERT INTO icerik(ad,tur,aciklama,kapak,kaynak,kategori,yas,dosya,durum,olusturma) VALUES(?,?,?,?,?,?,?,?,?,?)",
               (b["ad"], b["tur"], b["aciklama"], b["kapak"] or None, "/video/" + ad, b["kategori"], b["yas"], ad, "isleniyor", su()))
    iid = db.execute("SELECT last_insert_rowid()").fetchone()[0]
    db.execute("DELETE FROM yukleme WHERE id=?", (y["id"],)); db.commit()
    threading.Thread(target=video_isle, args=(h.server.db, ARKA["kilit"], iid, ad, not b["kapak"]), daemon=True).start()
    h.cevap(200, {"icerik_id": iid})


def video_isle(db, kilit, iid, ad, kapak_uret):
    """ffmpeg: moov atomunu başa al (yükleme bitmeden oynatma başlasın), süreyi oku, kapak yoksa bir kare çıkar."""
    yol = os.path.join(VIDEO_DIZIN, ad); sure = None; kapak = None
    try:
        if ad.endswith(".mp4"):
            gec = yol + ".fs.mp4"
            r = subprocess.run(["ffmpeg", "-v", "error", "-y", "-i", yol, "-c", "copy", "-map", "0", "-movflags", "+faststart", gec], capture_output=True, timeout=3600)
            if r.returncode == 0 and os.path.getsize(gec) > 0: os.replace(gec, yol); os.chmod(yol, 0o644)
            elif os.path.exists(gec): os.remove(gec)
        r = subprocess.run(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "default=nw=1:nk=1", yol], capture_output=True, text=True, timeout=120)
        try: sure = int(float(r.stdout.strip()))
        except ValueError: sure = None
        if kapak_uret:
            k = yol.rsplit(".", 1)[0] + ".jpg"
            an = str(min(5, max(0, (sure or 10) // 4)))
            r = subprocess.run(["ffmpeg", "-v", "error", "-y", "-ss", an, "-i", yol, "-frames:v", "1", "-vf", "scale=640:-2", k], capture_output=True, timeout=120)
            if r.returncode == 0 and os.path.exists(k): os.chmod(k, 0o644); kapak = "/video/" + os.path.basename(k)
        durum = "hazir"
    except FileNotFoundError:
        durum = "hazir"  # ffmpeg yoksa video yine de oynar (sadece süre/kapak eksik)
    except Exception as e:
        print("video işleme:", repr(e)[:200], flush=True); durum = "hazir"
    with kilit:
        db.execute("UPDATE icerik SET durum=?, sure=COALESCE(?, sure), kapak=COALESCE(kapak, ?) WHERE id=?", (durum, sure, kapak, iid)); db.commit()
    yayinla("resmi", {"tip": "durum"})


def get_yonetim_videolar(h, db, q):
    site.yonetici_sart(h, db)
    l = [icerik_disari(db, i) | {"boyut": os.path.getsize(os.path.join(VIDEO_DIZIN, i["dosya"])) if os.path.exists(os.path.join(VIDEO_DIZIN, i["dosya"])) else 0}
         for i in db.execute("SELECT * FROM icerik WHERE dosya IS NOT NULL ORDER BY id DESC")]
    try: bos = shutil.disk_usage(VIDEO_DIZIN).free
    except OSError: bos = 0
    h.cevap(200, {"videolar": l, "bos": bos, "kategoriler": ICERIK_KATEGORI, "yaslar": YASLAR})


# ------------------------------------------------------------------ V2: arka plan (izleyici grafiği için örnekleme)
ARKA = {"kilit": None, "basladi": False}


def arkaplan_baslat(db, kilit):
    ARKA["kilit"] = kilit
    if ARKA["basladi"]: return
    ARKA["basladi"] = True
    def dongu():
        while True:
            time.sleep(30)
            try:
                with kilit:
                    for r in db.execute("SELECT id, resmi FROM yayin WHERE durum='canli'").fetchall():
                        db.execute("INSERT INTO yayin_ornek VALUES(?,?,?)", (r["id"], su(), izleyici_say("resmi" if r["resmi"] else f"y{r['id']}")))
                    db.commit()
            except Exception as e: print("örnekleme:", repr(e)[:150], flush=True)
    threading.Thread(target=dongu, daemon=True).start()


# ------------------------------------------------------------------ yönlendirme
def calis(h, yontem, yol):
    db = h.server.db
    ad = yol.replace("/", "_").replace("-", "_")
    try:
        if yontem == "GET":
            f = globals().get("get_" + ad)
            if not f: raise Hata(404, "Bulunamadı")
            q = {a: b[0] for a, b in urllib.parse.parse_qs(urllib.parse.urlparse(h.path).query).items()}
            return f(h, db, q)
        f = globals().get("post_" + ad)
        if not f: raise Hata(404, "Bulunamadı")
        f(h, db)
    except (TypeError, ValueError, KeyError, AttributeError) as e:
        if isinstance(e, Hata): raise
        print("lives hata:", repr(e)[:200], flush=True)
        raise Hata(400, "Bozuk istek")
