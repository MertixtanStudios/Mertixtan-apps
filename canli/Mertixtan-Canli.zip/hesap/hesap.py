"""Mertixtan hesap servisi: kayıt, giriş (kullanıcı adı / e-posta / telefon + şifre, Google), oturum ve yönetici paneli.
Yalnızca 127.0.0.1:8090'da dinler; dışarıya nginx /api/hesap/ üzerinden açılır. Sadece Python standart kütüphanesi.

python3 hesap.py   (ortam: HESAP_DB=/var/lib/mertixtan/hesap.db  HESAP_PORT=8090)
"""
import site_api as site
import base64, hashlib, hmac, http.server, json, os, re, secrets, sqlite3, threading, time, urllib.parse, urllib.request

DB = os.environ.get("HESAP_DB", "/var/lib/mertixtan/hesap.db")
PORT = int(os.environ.get("HESAP_PORT", "8090"))
CEREZ = "mx_oturum"
OTURUM_SURE = 30 * 24 * 3600

# Önceden kurulmuş, doğrulanmış yönetici. Şifrenin kendisi değil, yalnızca scrypt özeti burada durur.
# Sadece hesap yoksa oluşturulur; panelden şifre değiştirince bu satır artık bir şey yapmaz.
YONETICI_AD = "MertixtanStudios"
SAHTE_OZET = "scrypt$AAAAAAAAAAAAAAAAAAAAAA==$AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA="  # olmayan hesapta da aynı süre geçsin
YONETICI_OZET = "scrypt$lkGgOwXg+5rIATxfKZRHxA==$tS16eqlo0p6op7N5TRVybFwAeW+3DksaivUKEjeyMXE="

kilit = threading.Lock()
hatalar = {}  # ip -> [zamanlar]  (yanlış şifre denemeleri)


def baglan():
    db = sqlite3.connect(DB, check_same_thread=False)
    db.row_factory = sqlite3.Row
    return db


def kur():
    os.makedirs(os.path.dirname(DB), exist_ok=True)
    db = baglan()
    db.executescript("""
    CREATE TABLE IF NOT EXISTS kullanici(
        id INTEGER PRIMARY KEY, ad TEXT UNIQUE COLLATE NOCASE NOT NULL, eposta TEXT UNIQUE COLLATE NOCASE,
        telefon TEXT UNIQUE, sifre TEXT, google TEXT UNIQUE, yonetici INTEGER DEFAULT 0, dogrulanmis INTEGER DEFAULT 0,
        engelli INTEGER DEFAULT 0, gizli INTEGER DEFAULT 0, olusturma INTEGER, son_giris INTEGER);
    CREATE TABLE IF NOT EXISTS oturum(jeton TEXT PRIMARY KEY, kid INTEGER, bitis INTEGER);
    CREATE TABLE IF NOT EXISTS ayar(ad TEXT PRIMARY KEY, deger TEXT);
    """)
    site.semayi_kur(db)
    if not db.execute("SELECT 1 FROM kullanici WHERE ad=?", (YONETICI_AD,)).fetchone():
        db.execute("INSERT INTO kullanici(ad,sifre,yonetici,dogrulanmis,gizli,olusturma) VALUES(?,?,1,1,1,?)",
                   (YONETICI_AD, YONETICI_OZET, int(time.time())))
    db.commit()
    return db


def ozetle(sifre):
    tuz = os.urandom(16)
    h = hashlib.scrypt(sifre.encode(), salt=tuz, n=2 ** 14, r=8, p=1, dklen=32)
    return "scrypt$" + base64.b64encode(tuz).decode() + "$" + base64.b64encode(h).decode()


def dogru_mu(sifre, ozet):
    try:
        _, tuz, h = ozet.split("$")
        y = hashlib.scrypt(sifre.encode(), salt=base64.b64decode(tuz), n=2 ** 14, r=8, p=1, dklen=32)
        return hmac.compare_digest(y, base64.b64decode(h))
    except Exception:
        return False


def telefon_duzelt(t):
    t = re.sub(r"[^\d+]", "", t or "")
    if not t: return None
    if t.startswith("0"): t = "+90" + t[1:]
    elif not t.startswith("+"): t = "+90" + t if len(t) == 10 else "+" + t
    return t if re.fullmatch(r"\+\d{10,15}", t) else ""


def sifre_uygun(s):
    return isinstance(s, str) and 8 <= len(s) <= 200 and re.search(r"[A-Za-zÇĞİÖŞÜçğıöşü]", s) and re.search(r"\d", s)


def disari(k):
    return {"id": k["id"], "ad": k["ad"], "eposta": k["eposta"], "telefon": k["telefon"], "yonetici": bool(k["yonetici"]),
            "dogrulanmis": bool(k["dogrulanmis"]), "engelli": bool(k["engelli"]), "google": bool(k["google"]),
            "olusturma": k["olusturma"], "son_giris": k["son_giris"],
            "unvan": k["unvan"], "renk": k["renk"], "biyografi": k["biyografi"], "pro": bool(k["pro"]),
            "sifre_degistir": k["sifre"] == YONETICI_OZET}


def google_dogrula(kimlik_jetonu, istemci):
    u = "https://oauth2.googleapis.com/tokeninfo?id_token=" + urllib.parse.quote(kimlik_jetonu)
    v = json.loads(urllib.request.urlopen(u, timeout=8).read())
    if v.get("aud") != istemci or v.get("iss") not in ("accounts.google.com", "https://accounts.google.com"):
        raise ValueError("Google jetonu bu site için değil")
    if int(v.get("exp", 0)) < time.time(): raise ValueError("Google jetonunun süresi dolmuş")
    if v.get("email_verified") not in (True, "true"): raise ValueError("Google e-postası doğrulanmamış")
    return v["sub"], v["email"], v.get("name") or v["email"].split("@")[0]


class Hata(Exception):
    def __init__(self, kod, mesaj): self.kod, self.mesaj = kod, mesaj


class Isleyici(http.server.BaseHTTPRequestHandler):
    def log_message(self, *a): pass

    # ---- yardımcılar
    def ip(self): return self.headers.get("X-Real-IP") or self.client_address[0]

    def cevap(self, kod, veri, cerez=None):
        g = json.dumps(veri, ensure_ascii=False).encode()
        self.send_response(kod)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        if cerez is not None:
            guvenli = "; Secure" if self.headers.get("X-Forwarded-Proto") == "https" else ""
            yas = OTURUM_SURE if cerez else 0
            self.send_header("Set-Cookie", f"{CEREZ}={cerez}; Path=/; Max-Age={yas}; HttpOnly; SameSite=Lax{guvenli}")
        self.send_header("Content-Length", str(len(g)))
        self.end_headers(); self.wfile.write(g)

    def govde(self):
        if "application/json" not in self.headers.get("Content-Type", ""): raise Hata(415, "JSON bekleniyor")
        try: n = int(self.headers.get("Content-Length", 0))
        except ValueError: raise Hata(400, "Bozuk istek")
        if n < 0 or n > 65536: raise Hata(413, "Çok büyük")
        if hasattr(self, "_govde"): return self._govde
        try: v = json.loads(self.rfile.read(n) or b"{}")
        except ValueError: raise Hata(400, "Bozuk istek")
        if not isinstance(v, dict): raise Hata(400, "Bozuk istek")
        self._govde = v
        return v

    def jeton(self):
        for p in self.headers.get("Cookie", "").split(";"):
            a, _, d = p.strip().partition("=")
            if a == CEREZ: return d
        return None

    def kullanici(self, db):
        j = self.jeton()
        if not j: return None
        return db.execute("SELECT k.* FROM oturum o JOIN kullanici k ON k.id=o.kid WHERE o.jeton=? AND o.bitis>? AND k.engelli=0",
                          (hashlib.sha256(j.encode()).hexdigest(), int(time.time()))).fetchone()

    def oturum_ac(self, db, k):
        j = secrets.token_urlsafe(32)
        db.execute("DELETE FROM oturum WHERE bitis<?", (int(time.time()),))
        db.execute("INSERT INTO oturum VALUES(?,?,?)", (hashlib.sha256(j.encode()).hexdigest(), k["id"], int(time.time()) + OTURUM_SURE))
        db.execute("UPDATE kullanici SET son_giris=? WHERE id=?", (int(time.time()), k["id"]))
        db.commit()
        return j

    def deneme_sinir(self, anahtar, adet, saniye=900):
        su = time.time()
        l = [t for t in hatalar.get(anahtar, []) if su - t < saniye]
        hatalar[anahtar] = l
        if len(hatalar) > 50000: hatalar.clear()
        if len(l) >= adet: raise Hata(429, "Çok fazla deneme. 15 dakika sonra tekrar dene.")

    # ---- yönlendirme
    def do_GET(self): self.calis("GET")
    def do_POST(self): self.calis("POST")

    def calis(self, yontem):
        yol = urllib.parse.urlparse(self.path).path.rstrip("/")
        if yol.startswith("/api/site"):
            return self.site_calis(yontem, yol[len("/api/site"):].strip("/"))
        yol = yol[len("/api/hesap"):] if yol.startswith("/api/hesap") else yol
        try:
            if yontem == "POST" and yol.strip("/") == "google":
                with kilit:
                    r = self.server.db.execute("SELECT deger FROM ayar WHERE ad='google_istemci'").fetchone()
                if not r or not r["deger"]: raise Hata(503, "Google ile giriş henüz ayarlanmadı")
                self.deneme_sinir("g:" + self.ip(), 20)
                hatalar.setdefault("g:" + self.ip(), []).append(time.time())
                try: self._google = google_dogrula(self.govde().get("credential") or "", r["deger"])
                except Hata: raise
                except Exception as e: raise Hata(401, f"Google girişi doğrulanamadı: {e}")
            with kilit:
                db = self.server.db
                f = getattr(self, f"{yontem.lower()}_{yol.strip('/').replace('/', '_') or 'kok'}", None)
                if not f: raise Hata(404, "Bulunamadı")
                f(db)
        except Hata as h:
            self.cevap(h.kod, {"hata": h.mesaj})
        except (TypeError, ValueError, AttributeError, KeyError):
            self.cevap(400, {"hata": "Bozuk istek"})
        except Exception as e:
            self.cevap(500, {"hata": "Sunucu hatası"}); print("HATA:", repr(e), flush=True)

    def site_calis(self, yontem, yol):
        try:
            with kilit:
                site.calis(self, yontem, yol)
        except Hata as h:
            self.cevap(h.kod, {"hata": h.mesaj})
        except site.Hata as h:
            self.cevap(h.kod, {"hata": h.mesaj})
        except Exception as e:
            self.cevap(500, {"hata": "Sunucu hatası"}); print("HATA:", repr(e), flush=True)

    # ---- herkese açık
    def get_ayar(self, db):
        r = db.execute("SELECT deger FROM ayar WHERE ad='google_istemci'").fetchone()
        d = db.execute("SELECT deger FROM ayar WHERE ad='duyuru'").fetchone()
        self.cevap(200, {"google_istemci": r["deger"] if r else "", "duyuru": d["deger"] if d else ""})

    def get_ben(self, db):
        k = self.kullanici(db)
        self.cevap(200, {"kullanici": disari(k) if k else None})

    def post_kayit(self, db):
        self.deneme_sinir("k:" + self.ip(), 5, 3600)
        v = self.govde()
        ad = (v.get("ad") or "").strip()
        eposta = (v.get("eposta") or "").strip().lower() or None
        telefon = telefon_duzelt(v.get("telefon"))
        sifre = v.get("sifre") or ""
        if not re.fullmatch(r"[A-Za-z0-9_.ÇĞİÖŞÜçğıöşü-]{3,24}", ad): raise Hata(400, "Kullanıcı adı 3-24 karakter olmalı (harf, rakam, _ . -)")
        if eposta and not re.fullmatch(r"[^@\s]+@[^@\s]+\.[^@\s]+", eposta): raise Hata(400, "E-posta geçersiz")
        if telefon == "": raise Hata(400, "Telefon numarası geçersiz")
        if not eposta and not telefon: raise Hata(400, "E-posta ya da telefon gir")
        if not sifre_uygun(sifre): raise Hata(400, "Şifre en az 8 karakter olmalı, harf ve rakam içermeli")
        for alan, deger, ad_ in (("ad", ad, "Bu kullanıcı adı alınmış"), ("eposta", eposta, "Bu e-posta kayıtlı"), ("telefon", telefon, "Bu telefon kayıtlı")):
            if deger and db.execute(f"SELECT 1 FROM kullanici WHERE {alan}=?", (deger,)).fetchone(): raise Hata(409, ad_)
        db.execute("INSERT INTO kullanici(ad,eposta,telefon,sifre,olusturma) VALUES(?,?,?,?,?)", (ad, eposta, telefon, ozetle(sifre), int(time.time())))
        hatalar.setdefault("k:" + self.ip(), []).append(time.time())
        k = db.execute("SELECT * FROM kullanici WHERE ad=?", (ad,)).fetchone()
        self.cevap(200, {"kullanici": disari(k)}, cerez=self.oturum_ac(db, k))

    def post_giris(self, db):
        self.deneme_sinir(self.ip(), 10)
        v = self.govde()
        kimlik = str(v.get("kimlik") or "").strip()[:200]
        self.deneme_sinir("h:" + kimlik.lower(), 30)
        tel = telefon_duzelt(kimlik) if re.fullmatch(r"[\d\s+()-]{10,20}", kimlik) else None
        k = db.execute("SELECT * FROM kullanici WHERE ad=? OR eposta=? OR (telefon IS NOT NULL AND telefon=?)",
                       (kimlik, kimlik.lower(), tel or "")).fetchone()
        dogru = dogru_mu(str(v.get("sifre") or ""), k["sifre"] if k and k["sifre"] else SAHTE_OZET)
        if not k or not k["sifre"] or not dogru:
            hatalar.setdefault(self.ip(), []).append(time.time())
            hatalar.setdefault("h:" + kimlik.lower(), []).append(time.time())
            raise Hata(401, "Kullanıcı adı ya da şifre yanlış")
        if k["engelli"]: raise Hata(403, "Bu hesap engellenmiş")
        self.cevap(200, {"kullanici": disari(k)}, cerez=self.oturum_ac(db, k))

    def post_google(self, db):
        sub, eposta, isim = self._google  # kilit dışında doğrulandı
        k = db.execute("SELECT * FROM kullanici WHERE google=?", (sub,)).fetchone()
        if not k:
            k = db.execute("SELECT * FROM kullanici WHERE eposta=?", (eposta.lower(),)).fetchone()
            if k and k["yonetici"]:
                raise Hata(403, "Yönetici hesabına Google bağlanamaz; şifrenle gir")
            if k:  # aynı e-postalı hesap varsa Google'ı ona bağla (Google e-postanın sahibini doğruladı)
                if not k["dogrulanmis"]:
                    # e-posta hiç doğrulanmamıştı: hesabı başkası açmış olabilir. Eski şifre ve oturumlar geçersiz olsun.
                    db.execute("UPDATE kullanici SET sifre=NULL WHERE id=?", (k["id"],))
                    db.execute("DELETE FROM oturum WHERE kid=?", (k["id"],))
                db.execute("UPDATE kullanici SET google=?, dogrulanmis=1 WHERE id=?", (sub, k["id"]))
            else:
                ad = re.sub(r"[^A-Za-z0-9_.-]", "", isim.replace(" ", "_"))[:20] or "uye"
                while db.execute("SELECT 1 FROM kullanici WHERE ad=?", (ad,)).fetchone(): ad = ad[:18] + str(secrets.randbelow(100))
                db.execute("INSERT INTO kullanici(ad,eposta,google,dogrulanmis,olusturma) VALUES(?,?,?,1,?)", (ad, eposta.lower(), sub, int(time.time())))
            k = db.execute("SELECT * FROM kullanici WHERE google=?", (sub,)).fetchone()
        if k["engelli"]: raise Hata(403, "Bu hesap engellenmiş")
        self.cevap(200, {"kullanici": disari(k)}, cerez=self.oturum_ac(db, k))

    def post_cikis(self, db):
        j = self.jeton()
        if j: db.execute("DELETE FROM oturum WHERE jeton=?", (hashlib.sha256(j.encode()).hexdigest(),)); db.commit()
        self.cevap(200, {"tamam": True}, cerez="")

    def post_sifre(self, db):
        k = self.kullanici(db)
        if not k: raise Hata(401, "Giriş yapmalısın")
        v = self.govde()
        self.deneme_sinir("s:" + str(k["id"]), 10)
        if k["sifre"] and not dogru_mu(str(v.get("eski") or ""), k["sifre"]):
            hatalar.setdefault("s:" + str(k["id"]), []).append(time.time())
            raise Hata(401, "Mevcut şifre yanlış")
        if not sifre_uygun(v.get("yeni")): raise Hata(400, "Yeni şifre en az 8 karakter olmalı, harf ve rakam içermeli")
        db.execute("UPDATE kullanici SET sifre=? WHERE id=?", (ozetle(v["yeni"]), k["id"]))
        db.execute("DELETE FROM oturum WHERE kid=?", (k["id"],))  # diğer cihazlardaki oturumları kapat
        db.commit()
        k = db.execute("SELECT * FROM kullanici WHERE id=?", (k["id"],)).fetchone()
        self.cevap(200, {"kullanici": disari(k)}, cerez=self.oturum_ac(db, k))

    # ---- yönetici
    def yonetici(self, db):
        k = self.kullanici(db)
        if not k or not k["yonetici"]: raise Hata(403, "Yönetici yetkisi gerekli")
        return k

    def get_yonetici_ozet(self, db):
        self.yonetici(db)
        su = int(time.time())
        say = lambda q, *a: db.execute(q, a).fetchone()[0]
        liste = [disari(k) for k in db.execute("SELECT * FROM kullanici WHERE gizli=0 ORDER BY id DESC LIMIT 500")]
        ayar = {r["ad"]: r["deger"] for r in db.execute("SELECT * FROM ayar")}
        self.cevap(200, {
            "sayilar": {"toplam": say("SELECT COUNT(*) FROM kullanici WHERE gizli=0"),
                        "bugun": say("SELECT COUNT(*) FROM kullanici WHERE gizli=0 AND olusturma>?", su - 86400),
                        "hafta": say("SELECT COUNT(*) FROM kullanici WHERE gizli=0 AND olusturma>?", su - 7 * 86400),
                        "cevrimici": say("SELECT COUNT(DISTINCT kid) FROM oturum WHERE bitis>?", su),
                        "google": say("SELECT COUNT(*) FROM kullanici WHERE gizli=0 AND google IS NOT NULL"),
                        "engelli": say("SELECT COUNT(*) FROM kullanici WHERE engelli=1")},
            "kullanicilar": liste, "site": site.yonetici_ozet(db),
            "google_istemci": ayar.get("google_istemci", ""), "duyuru": ayar.get("duyuru", "")})

    def post_yonetici_kullanici(self, db):
        ben = self.yonetici(db)
        v = self.govde()
        hedef = db.execute("SELECT * FROM kullanici WHERE id=? AND gizli=0", (int(v.get("id") or 0),)).fetchone()
        if not hedef: raise Hata(404, "Kullanıcı yok")
        if hedef["id"] == ben["id"]: raise Hata(400, "Kendi hesabında bunu yapamazsın")
        islem = v.get("islem")
        if islem == "engelle": db.execute("UPDATE kullanici SET engelli=1 WHERE id=?", (hedef["id"],)); db.execute("DELETE FROM oturum WHERE kid=?", (hedef["id"],))
        elif islem == "ac": db.execute("UPDATE kullanici SET engelli=0 WHERE id=?", (hedef["id"],))
        elif islem == "yonetici": db.execute("UPDATE kullanici SET yonetici=1 WHERE id=?", (hedef["id"],))
        elif islem == "uye": db.execute("UPDATE kullanici SET yonetici=0 WHERE id=?", (hedef["id"],))
        elif islem == "dogrula": db.execute("UPDATE kullanici SET dogrulanmis=1 WHERE id=?", (hedef["id"],))
        elif islem == "pro_ac": db.execute("UPDATE kullanici SET pro=1 WHERE id=?", (hedef["id"],))
        elif islem == "pro_kapat": db.execute("UPDATE kullanici SET pro=0 WHERE id=?", (hedef["id"],))
        elif islem == "sil": db.execute("DELETE FROM oturum WHERE kid=?", (hedef["id"],)); db.execute("DELETE FROM kullanici WHERE id=?", (hedef["id"],))
        else: raise Hata(400, "Bilinmeyen işlem")
        db.commit()
        self.cevap(200, {"tamam": True})

    def post_yonetici_ayar(self, db):
        self.yonetici(db)
        v = self.govde()
        for ad in ("google_istemci", "duyuru"):
            if ad in v:
                d = str(v[ad]).strip()[:500]
                if ad == "google_istemci" and d and not re.fullmatch(r"[\w.-]+\.apps\.googleusercontent\.com", d):
                    raise Hata(400, "Google istemci kimliği ...apps.googleusercontent.com ile bitmeli")
                db.execute("INSERT INTO ayar VALUES(?,?) ON CONFLICT(ad) DO UPDATE SET deger=excluded.deger", (ad, d))
        db.commit()
        self.cevap(200, {"tamam": True})


if __name__ == "__main__":
    s = http.server.ThreadingHTTPServer(("127.0.0.1", PORT), Isleyici)
    s.db = kur()
    print(f"hesap servisi 127.0.0.1:{PORT} · {DB}", flush=True)
    s.serve_forever()
