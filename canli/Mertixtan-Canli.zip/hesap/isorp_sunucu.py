"""İsorp gerçek zamanlı dünya sunucusu (WebSocket, sadece Python standart kütüphanesi).

nginx /isorp/ws isteklerini buraya (127.0.0.1:8095) yönlendirir. Oturum, sitenin giriş çereziyle (mx_oturum) doğrulanır.
Oyuncular şehirlere (sehir-1, sehir-2, ... en çok 30 kişi) ya da evlere (ev:<oyuncu id>) bölünür.
Sunucu konumları denetler (dünya sınırı, en yüksek hız), sohbeti sınırlar (spam, susturma, yasak) ve
herkese saniyede 10 kez toplu konum gönderir. Kalıcı veriler (para, eşya) burada değil, hesap servisinde.
"""
import asyncio, base64, hashlib, json, math, os, re, sqlite3, time, urllib.parse

DB = os.environ.get("HESAP_DB", "/var/lib/mertixtan/hesap.db")
PORT = int(os.environ.get("ISORP_PORT", "8095"))
SEHIR_KAPASITE, EV_KAPASITE = 30, 20
SINIR = {"sehir": 58.0, "ev": 4.7}
EN_HIZ = 9.0  # m/sn (koşu 6; ağ gecikmesi payı)
EMOJILER = {"👋", "😂", "😍", "😎", "🔥", "👍", "❤️", "🎉", "😮", "😢", "💃", "🕺", "⭐", "💎", "👑"}
GUID = "258EAFA5-E914-47DA-95CA-C5AB0DC85B11"
BASLANGIC = {"ten": "#e0b08a", "sac": "sac:kisa", "sac_renk": "#3b2416", "ust": "ust:tisort", "ust_renk": "#10b981", "alt": "alt:pantolon",
             "alt_renk": "#1e3a8a", "ayakkabi": "ayakkabi:spor", "ayakkabi_renk": "#f8fafc", "aksesuar": "aksesuar:yok", "aksesuar_renk": "#facc15", "boy": 1.0}


def vt():
    c = sqlite3.connect(f"file:{DB}?mode=ro", uri=True, timeout=5)
    c.row_factory = sqlite3.Row
    return c


def kimlik_bul(cerez):
    """Çerezden oyuncuyu bul (salt okunur). None = giriş yok / engelli / yasaklı."""
    jeton = None
    for p in (cerez or "").split(";"):
        a, _, d = p.strip().partition("=")
        if a == "mx_oturum": jeton = d
    if not jeton: return None, "giris"
    with vt() as c:
        k = c.execute("SELECT k.* FROM oturum o JOIN kullanici k ON k.id=o.kid WHERE o.jeton=? AND o.bitis>? AND k.engelli=0",
                      (hashlib.sha256(jeton.encode()).hexdigest(), int(time.time()))).fetchone()
        if not k: return None, "giris"
        if c.execute("SELECT 1 FROM yasak WHERE kid=? AND oda IN ('*','isorp') AND tur IN ('yasak','uzaklastir') AND (bitis IS NULL OR bitis>?)",
                     (k["id"], int(time.time()))).fetchone():
            return None, "yasak"
        r = c.execute("SELECT avatar FROM isorp_oyuncu WHERE kid=?", (k["id"],)).fetchone()
        return {"id": k["id"], "ad": k["ad"], "rozet": {"admin": bool(k["yonetici"]), "pro": bool(k["pro"]), "onayli": bool(k["dogrulanmis"])},
                "avatar": json.loads(r["avatar"]) if r else BASLANGIC}, None


def susturuldu_mu(kid):
    with vt() as c:
        return bool(c.execute("SELECT 1 FROM yasak WHERE kid=? AND oda IN ('*','isorp') AND tur IN ('sustur','yasak','uzaklastir') AND (bitis IS NULL OR bitis>?)",
                              (kid, int(time.time()))).fetchone())


def avatar_oku(kid):
    with vt() as c:
        r = c.execute("SELECT avatar FROM isorp_oyuncu WHERE kid=?", (kid,)).fetchone()
        return json.loads(r["avatar"]) if r else BASLANGIC


# ------------------------------------------------------------ WebSocket çerçeveleri
def cerceve(veri, opkod=1):
    b = veri.encode() if isinstance(veri, str) else veri
    n = len(b)
    if n < 126: bas = bytes([0x80 | opkod, n])
    elif n < 65536: bas = bytes([0x80 | opkod, 126]) + n.to_bytes(2, "big")
    else: bas = bytes([0x80 | opkod, 127]) + n.to_bytes(8, "big")
    return bas + b


async def cerceve_oku(okur):
    b1, b2 = await okur.readexactly(2)
    opkod, maskeli, n = b1 & 0x0F, b2 & 0x80, b2 & 0x7F
    if not b1 & 0x80 or not maskeli: raise ValueError("parçalı/maskesiz çerçeve")
    if n == 126: n = int.from_bytes(await okur.readexactly(2), "big")
    elif n == 127: n = int.from_bytes(await okur.readexactly(8), "big")
    if n > 4096: raise ValueError("çok büyük çerçeve")
    maske = await okur.readexactly(4)
    v = await okur.readexactly(n)
    return opkod, bytes(x ^ maske[i % 4] for i, x in enumerate(v))


# ------------------------------------------------------------ oyuncu ve odalar
class Oyuncu:
    def __init__(self, bilgi, yazici, tur):
        self.__dict__.update(bilgi)
        self.yazici, self.tur = yazici, tur
        d = 6 if tur == "sehir" else 1.5
        import random
        self.x, self.z, self.ry, self.a = random.uniform(-d, d), (random.uniform(-d, d) if tur == "sehir" else 3.8), math.pi, 0
        self.son_hareket = time.monotonic(); self.kirli = True
        self.sohbet_zaman = []; self.son_emoji = 0; self.son_mesaj = ""; self.oda = None; self.son_veri = time.monotonic()

    def durum(self): return {"id": self.id, "ad": self.ad, "rozet": self.rozet, "avatar": self.avatar, "x": round(self.x, 2), "z": round(self.z, 2), "ry": round(self.ry, 2), "a": self.a}

    async def gonder(self, olay):
        try:
            self.yazici.write(cerceve(json.dumps(olay, ensure_ascii=False)))
            await asyncio.wait_for(self.yazici.drain(), 5)
        except Exception:
            pass


class Oda:
    def __init__(self, ad, tur):
        self.ad, self.tur, self.oyuncular = ad, tur, {}

    async def herkese(self, olay, haric=None):
        await asyncio.gather(*(o.gonder(olay) for o in list(self.oyuncular.values()) if o is not haric))


ODALAR = {}
BAGLI = {}  # oyuncu id -> Oyuncu (aynı hesapla ikinci bağlantı eskisini kapatır)


def oda_sec(istek):
    if istek.startswith("ev:") and re.fullmatch(r"ev:\d{1,9}", istek):
        o = ODALAR.setdefault(istek, Oda(istek, "ev"))
        return o if len(o.oyuncular) < EV_KAPASITE else None
    i = 1
    while True:
        ad = f"sehir-{i}"
        o = ODALAR.setdefault(ad, Oda(ad, "sehir"))
        if len(o.oyuncular) < SEHIR_KAPASITE: return o
        i += 1


async def isle(oyuncu, oda, v):
    t = v.get("t")
    simdi = time.monotonic()
    if t == "hareket":
        try: x, z, ry, a = float(v["x"]), float(v["z"]), float(v.get("ry", 0)), int(v.get("a", 0))
        except (KeyError, TypeError, ValueError): return
        if not all(map(math.isfinite, (x, z, ry))): return
        s = SINIR[oda.tur]
        x, z = max(-s, min(s, x)), max(-s, min(s, z))
        dt = max(0.05, simdi - oyuncu.son_hareket)
        if math.hypot(x - oyuncu.x, z - oyuncu.z) / dt > EN_HIZ:  # ışınlanma / hız hilesi: konumu geri al
            await oyuncu.gonder({"t": "duzelt", "x": round(oyuncu.x, 2), "z": round(oyuncu.z, 2)}); oyuncu.son_hareket = simdi; return
        oyuncu.x, oyuncu.z, oyuncu.ry, oyuncu.a = x, z, ry % (2 * math.pi), a if a in (0, 1, 2, 3) else 0
        oyuncu.son_hareket = simdi; oyuncu.kirli = True
    elif t == "sohbet":
        m = re.sub(r"\s+", " ", str(v.get("m", ""))).strip()[:120]
        if not m: return
        oyuncu.sohbet_zaman = [z for z in oyuncu.sohbet_zaman if simdi - z < 60]
        if oyuncu.sohbet_zaman and simdi - oyuncu.sohbet_zaman[-1] < 1.2: return await oyuncu.gonder({"t": "uyari", "m": "Biraz yavaş yaz"})
        if len(oyuncu.sohbet_zaman) >= 15: return await oyuncu.gonder({"t": "uyari", "m": "Dakikada en fazla 15 mesaj"})
        if m.lower() == oyuncu.son_mesaj and oyuncu.sohbet_zaman and simdi - oyuncu.sohbet_zaman[-1] < 20: return await oyuncu.gonder({"t": "uyari", "m": "Aynı mesajı tekrarlama"})
        if await asyncio.to_thread(susturuldu_mu, oyuncu.id): return await oyuncu.gonder({"t": "uyari", "m": "Sohbette susturuldun"})
        oyuncu.sohbet_zaman.append(simdi); oyuncu.son_mesaj = m.lower()
        await oda.herkese({"t": "sohbet", "id": oyuncu.id, "ad": oyuncu.ad, "rozet": oyuncu.rozet, "m": m})
    elif t == "emoji":
        e = v.get("e")
        if e in EMOJILER and simdi - oyuncu.son_emoji > 0.8:
            oyuncu.son_emoji = simdi
            await oda.herkese({"t": "emoji", "id": oyuncu.id, "e": e})
    elif t == "avatar":
        oyuncu.avatar = await asyncio.to_thread(avatar_oku, oyuncu.id)
        await oda.herkese({"t": "avatar", "id": oyuncu.id, "avatar": oyuncu.avatar})


async def baglanti(okur, yazici):
    oyuncu = oda = None
    try:
        istek = await asyncio.wait_for(okur.readuntil(b"\r\n\r\n"), 10)
        if len(istek) > 8192: return
        satirlar = istek.decode("latin-1").split("\r\n")
        yontem, yol, _ = (satirlar[0].split(" ") + ["", ""])[:3]
        bas = {}
        for s in satirlar[1:]:
            a, _, d = s.partition(":")
            if a: bas[a.strip().lower()] = d.strip()
        u = urllib.parse.urlparse(yol); q = dict(urllib.parse.parse_qsl(u.query))
        if u.path == "/isorp/durum":
            g = json.dumps({"sehir": sum(len(o.oyuncular) for o in ODALAR.values() if o.tur == "sehir"),
                            "evler": {o.ad: len(o.oyuncular) for o in ODALAR.values() if o.tur == "ev" and o.oyuncular}}).encode()
            yazici.write(b"HTTP/1.1 200 OK\r\nContent-Type: application/json\r\nCache-Control: no-store\r\nContent-Length: " + str(len(g)).encode() + b"\r\n\r\n" + g)
            await yazici.drain(); return
        if u.path != "/isorp/ws" or bas.get("upgrade", "").lower() != "websocket" or "sec-websocket-key" not in bas:
            yazici.write(b"HTTP/1.1 400 Bad Request\r\nContent-Length: 0\r\n\r\n"); await yazici.drain(); return
        bilgi, neden = await asyncio.to_thread(kimlik_bul, bas.get("cookie", ""))
        if not bilgi:
            kod = b"403 Forbidden" if neden == "yasak" else b"401 Unauthorized"
            yazici.write(b"HTTP/1.1 " + kod + b"\r\nContent-Length: 0\r\n\r\n"); await yazici.drain(); return
        oda = oda_sec(q.get("oda", "sehir"))
        if not oda:
            yazici.write(b"HTTP/1.1 503 Service Unavailable\r\nContent-Length: 0\r\n\r\n"); await yazici.drain(); return
        kabul = base64.b64encode(hashlib.sha1((bas["sec-websocket-key"] + GUID).encode()).digest()).decode()
        yazici.write(f"HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Accept: {kabul}\r\n\r\n".encode())
        await yazici.drain()
        eski = BAGLI.get(bilgi["id"])
        if eski:  # aynı hesapla ikinci sekme: eskisini kapat
            try: eski.yazici.write(cerceve(b"\x0f\xa0ikinci baglanti", 8)); eski.yazici.close()
            except Exception: pass
        oyuncu = Oyuncu(bilgi, yazici, oda.tur); oyuncu.oda = oda
        BAGLI[oyuncu.id] = oyuncu
        oda.oyuncular[oyuncu.id] = oyuncu
        await oyuncu.gonder({"t": "hosgeldin", "ben": oyuncu.id, "oda": oda.ad, "tur": oda.tur, "oyuncular": [o.durum() for o in oda.oyuncular.values()]})
        await oda.herkese({"t": "katildi", "p": oyuncu.durum()}, haric=oyuncu)
        while True:
            opkod, v = await asyncio.wait_for(cerceve_oku(okur), 70)
            oyuncu.son_veri = time.monotonic()
            if opkod == 8: break
            if opkod == 9: yazici.write(cerceve(v, 10)); continue
            if opkod == 10: continue
            if opkod != 1: break
            try: mesaj = json.loads(v.decode())
            except ValueError: continue
            if isinstance(mesaj, dict): await isle(oyuncu, oda, mesaj)
    except (asyncio.IncompleteReadError, asyncio.TimeoutError, ConnectionError, ValueError, asyncio.LimitOverrunError):
        pass
    except Exception as e:
        print("isorp bağlantı hatası:", repr(e)[:200], flush=True)
    finally:
        if oyuncu and oda and oda.oyuncular.get(oyuncu.id) is oyuncu:
            del oda.oyuncular[oyuncu.id]
            if BAGLI.get(oyuncu.id) is oyuncu: del BAGLI[oyuncu.id]
            await oda.herkese({"t": "ayrildi", "id": oyuncu.id})
            if not oda.oyuncular and oda.ad != "sehir-1": ODALAR.pop(oda.ad, None)
        try: yazici.close()
        except Exception: pass


async def tik():
    """Saniyede 10 kez: değişen konumları her odaya tek mesajda gönder; arada canlılık yoklaması."""
    say = 0
    while True:
        await asyncio.sleep(0.1); say += 1
        for oda in list(ODALAR.values()):
            l = [[o.id, round(o.x, 2), round(o.z, 2), round(o.ry, 2), o.a] for o in oda.oyuncular.values() if o.kirli]
            for o in oda.oyuncular.values(): o.kirli = False
            if l: await oda.herkese({"t": "konum", "l": l})
            if say % 250 == 0:  # 25 sn'de bir ping
                for o in list(oda.oyuncular.values()):
                    try: o.yazici.write(cerceve(b"", 9))
                    except Exception: pass


async def ana():
    s = await asyncio.start_server(baglanti, "127.0.0.1", PORT, limit=16384)
    asyncio.create_task(tik())
    print(f"İsorp dünya sunucusu 127.0.0.1:{PORT}", flush=True)
    async with s: await s.serve_forever()


if __name__ == "__main__":
    asyncio.run(ana())
