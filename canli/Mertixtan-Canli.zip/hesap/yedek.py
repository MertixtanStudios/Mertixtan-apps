"""Mertixtan veritabanı yedeği. Gece systemd zamanlayıcısıyla, ya da yönetici panelinden "Şimdi yedek al" ile çalışır.
SQLite'ın çevrimiçi yedek API'si kullanılır: site çalışırken bile tutarlı bir kopya alınır. Son 14 yedek saklanır."""
import datetime, gzip, os, re, shutil, sqlite3, sys

DB = os.environ.get("HESAP_DB", "/var/lib/mertixtan/hesap.db")
DIZIN = os.path.join(os.path.dirname(DB), "yedek")
SAKLA = 14
AD = re.compile(r"hesap-\d{4}-\d{2}-\d{2}_\d{6}\.db\.gz")


def al(kaynak=None):
    """kaynak: açık bir sqlite3 bağlantısı (servisin içinden) ya da None (dosyadan aç)."""
    os.makedirs(DIZIN, mode=0o700, exist_ok=True)
    ad = "hesap-" + datetime.datetime.now().strftime("%Y-%m-%d_%H%M%S") + ".db.gz"
    gecici = os.path.join(DIZIN, ".gecici.db")
    k = kaynak or sqlite3.connect(DB)
    try:
        hedef = sqlite3.connect(gecici)
        with hedef: k.backup(hedef)
        sonuc = hedef.execute("PRAGMA integrity_check").fetchone()[0]
        hedef.close()
        if sonuc != "ok": raise RuntimeError("yedek bütünlük denetimini geçemedi: " + sonuc)
        with open(gecici, "rb") as g, gzip.open(os.path.join(DIZIN, ad) + ".tmp", "wb", 6) as c: shutil.copyfileobj(g, c)
        os.replace(os.path.join(DIZIN, ad) + ".tmp", os.path.join(DIZIN, ad))
        os.chmod(os.path.join(DIZIN, ad), 0o600)
    finally:
        if not kaynak: k.close()
        if os.path.exists(gecici): os.remove(gecici)
    for eski in liste()[SAKLA:]: os.remove(os.path.join(DIZIN, eski["ad"]))
    return ad


def liste():
    if not os.path.isdir(DIZIN): return []
    l = [{"ad": f, "boyut": os.path.getsize(os.path.join(DIZIN, f)), "tarih": int(os.path.getmtime(os.path.join(DIZIN, f)))}
         for f in os.listdir(DIZIN) if AD.fullmatch(f)]
    return sorted(l, key=lambda x: x["ad"], reverse=True)


if __name__ == "__main__":
    try: print("yedek alındı:", al())
    except Exception as e: print("YEDEK HATASI:", e); sys.exit(1)
