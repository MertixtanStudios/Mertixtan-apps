"""İsorp: Mertixtan'ın tarayıcıda oynanan çok oyunculu rol yapma oyunu (sunucu tarafı, kalıcı veriler).

Avatar, para, envanter, ev düzeni, mağaza, günlük ödül ve mini oyun ödülleri burada; hepsi sunucuda doğrulanır.
Gerçek zamanlı dünya (konumlar, konuşma balonları) ayrı WebSocket sunucusunda: isorp_sunucu.py.
hesap.py içinden /api/isorp/... olarak çağrılır.
"""
import datetime, json, re, secrets, time

import site_api as site
Hata = site.Hata
TR = datetime.timezone(datetime.timedelta(hours=3))

SEMA = """
CREATE TABLE IF NOT EXISTS isorp_oyuncu(kid INTEGER PRIMARY KEY, avatar TEXT, para INTEGER DEFAULT 300, envanter TEXT DEFAULT '{}',
    ev TEXT DEFAULT '[]', gunluk TEXT, oyun_gun TEXT, oyun_kazanc INTEGER DEFAULT 0, olusturma INTEGER);
CREATE TABLE IF NOT EXISTS isorp_oyun(jeton TEXT PRIMARY KEY, kid INTEGER, oyun TEXT, baslangic REAL);
CREATE TABLE IF NOT EXISTS isorp_skor(id INTEGER PRIMARY KEY, kid INTEGER, oyun TEXT, skor INTEGER, kazanc INTEGER, tarih INTEGER);
"""

# ------------------------------------------------------------ katalog (fiyat 0 = herkese baştan açık)
# tur: sac / ust / alt / ayakkabi / aksesuar / mobilya ; pro: sadece Pro üyeler alabilir
KATALOG = {
    "sac:kisa": ("Kısa saç", 0), "sac:uzun": ("Uzun saç", 0), "sac:kivircik": ("Kıvırcık", 0), "sac:kel": ("Kel", 0),
    "sac:at_kuyrugu": ("At kuyruğu", 80), "sac:dikenli": ("Dikenli", 120), "sac:topuz": ("Topuz", 120), "sac:kakul": ("Perçem", 90),
    "ust:tisort": ("Tişört", 0), "ust:kapusonlu": ("Kapüşonlu", 150), "ust:gomlek": ("Gömlek", 120), "ust:ceket": ("Ceket", 250),
    "ust:forma": ("Mertixtan forması", 200), "ust:yelek": ("Yelek", 160),
    "alt:pantolon": ("Pantolon", 0), "alt:sort": ("Şort", 60), "alt:etek": ("Etek", 90), "alt:esofman": ("Eşofman", 110),
    "ayakkabi:spor": ("Spor ayakkabı", 0), "ayakkabi:bot": ("Bot", 140), "ayakkabi:sandalet": ("Sandalet", 70),
    "aksesuar:yok": ("Yok", 0), "aksesuar:kep": ("Kep", 100), "aksesuar:sapka": ("Şapka", 160), "aksesuar:gozluk": ("Güneş gözlüğü", 130),
    "aksesuar:kulaklik": ("Kulaklık", 180), "aksesuar:tac": ("Altın taç ✨", 400), "aksesuar:pelerin": ("Kahraman pelerini ✨", 450),
    "aksesuar:hale": ("Işık halesi ✨", 500),
    "mobilya:koltuk": ("Koltuk", 120), "mobilya:masa": ("Masa", 80), "mobilya:sandalye": ("Sandalye", 50), "mobilya:yatak": ("Yatak", 200),
    "mobilya:lamba": ("Ayaklı lamba", 60), "mobilya:bitki": ("Saksı bitkisi", 40), "mobilya:tv": ("Televizyon", 220), "mobilya:hali": ("Halı", 70),
    "mobilya:kitaplik": ("Kitaplık", 150), "mobilya:buzdolabi": ("Buzdolabı", 180), "mobilya:dolap": ("Gardırop", 160),
    "mobilya:konsol": ("Oyun konsolu ✨", 350), "mobilya:akvaryum": ("Akvaryum ✨", 420), "mobilya:dj": ("DJ masası ✨", 480),
}
PRO_ESYA = {"aksesuar:tac", "aksesuar:pelerin", "aksesuar:hale", "mobilya:konsol", "mobilya:akvaryum", "mobilya:dj"}
BASLANGIC_AVATAR = {"ten": "#e0b08a", "sac": "sac:kisa", "sac_renk": "#3b2416", "ust": "ust:tisort", "ust_renk": "#10b981",
                    "alt": "alt:pantolon", "alt_renk": "#1e3a8a", "ayakkabi": "ayakkabi:spor", "ayakkabi_renk": "#f8fafc",
                    "aksesuar": "aksesuar:yok", "aksesuar_renk": "#facc15", "boy": 1.0}
TENLER = ("#f6d7c3", "#e0b08a", "#c68642", "#8d5524", "#5c3a21", "#3b2219")
GUNLUK_ODUL = 100
OYUN_GUNLUK_TAVAN = 800  # mini oyunlardan günde en çok kazanılacak para

# Mini oyunlar: (en kısa geçerli süre sn, en yüksek skor hesabı(süre), para hesabı(skor))
OYUNLAR = {
    "para_yagmuru": {"sure": 44, "en_cok": lambda gecen: int(min(gecen, 50) * 2.2) + 5, "para": lambda s: s * 2},
    "hafiza": {"sure": 8, "en_cok": lambda gecen: 8, "para": lambda s: s * 6},  # 8 çift
}


def semayi_kur(db):
    db.executescript(SEMA)
    db.commit()


def gun(): return datetime.datetime.now(TR).strftime("%Y-%m-%d")


def oyuncu(db, k):
    r = db.execute("SELECT * FROM isorp_oyuncu WHERE kid=?", (k["id"],)).fetchone()
    if not r:
        db.execute("INSERT INTO isorp_oyuncu(kid,avatar,olusturma) VALUES(?,?,?)", (k["id"], json.dumps(BASLANGIC_AVATAR), int(time.time())))
        db.commit()
        r = db.execute("SELECT * FROM isorp_oyuncu WHERE kid=?", (k["id"],)).fetchone()
    return r


def sahip_mi(envanter, esya):
    return KATALOG.get(esya, (None, -1))[1] == 0 or envanter.get(esya, 0) > 0


def disari(db, k, r):
    return {"ad": k["ad"], "id": k["id"], "pro": bool(k["pro"]), "yonetici": bool(k["yonetici"]), "onayli": bool(k["dogrulanmis"]),
            "avatar": json.loads(r["avatar"]), "para": r["para"], "envanter": json.loads(r["envanter"]), "ev": json.loads(r["ev"]),
            "gunluk_alinabilir": r["gunluk"] != gun(),
            "oyun_kalan": OYUN_GUNLUK_TAVAN - (r["oyun_kazanc"] if r["oyun_gun"] == gun() else 0)}


# ------------------------------------------------------------ uçlar
def get_ben(h, db, q):
    k = site.giris_sart(h, db)
    h.cevap(200, {"oyuncu": disari(db, k, oyuncu(db, k)),
                  "katalog": [{"id": i, "ad": a, "fiyat": f, "pro": i in PRO_ESYA} for i, (a, f) in KATALOG.items()], "tenler": TENLER})


RENK = re.compile(r"#[0-9a-fA-F]{6}")


def post_avatar(h, db):
    k = site.giris_sart(h, db); r = oyuncu(db, k); v = h.govde().get("avatar") or {}
    env = json.loads(r["envanter"]); yeni = dict(BASLANGIC_AVATAR)
    for alan in ("sac", "ust", "alt", "ayakkabi", "aksesuar"):
        e = str(v.get(alan, yeni[alan]))
        if not e.startswith(alan + ":") or e not in KATALOG: raise Hata(400, "Geçersiz " + alan)
        if not sahip_mi(env, e): raise Hata(403, f"{KATALOG[e][0]} sende yok; önce mağazadan al")
        yeni[alan] = e
    for alan in ("ten", "sac_renk", "ust_renk", "alt_renk", "ayakkabi_renk", "aksesuar_renk"):
        c = str(v.get(alan, yeni[alan]))
        if not RENK.fullmatch(c): raise Hata(400, "Renk geçersiz")
        yeni[alan] = c.lower()
    try: yeni["boy"] = max(0.9, min(1.1, float(v.get("boy", 1.0))))
    except (TypeError, ValueError): pass
    db.execute("UPDATE isorp_oyuncu SET avatar=? WHERE kid=?", (json.dumps(yeni), k["id"])); db.commit()
    h.cevap(200, {"avatar": yeni})


def post_satin_al(h, db):
    k = site.giris_sart(h, db); site.sinir(h, "isorp_al", 30, 60); r = oyuncu(db, k)
    e = str(h.govde().get("esya", ""))
    if e not in KATALOG: raise Hata(404, "Böyle bir eşya yok")
    ad, fiyat = KATALOG[e]
    if fiyat == 0: raise Hata(400, "Bu zaten ücretsiz")
    if e in PRO_ESYA and not (k["pro"] or k["yonetici"]): raise Hata(403, "Bu eşya Pro üyelere özel")
    env = json.loads(r["envanter"])
    if not e.startswith("mobilya:") and env.get(e): raise Hata(409, "Bu zaten sende var")
    if e.startswith("mobilya:") and env.get(e, 0) >= 10: raise Hata(409, "Bu eşyadan en fazla 10 tane olabilir")
    # para düşümü tek SQL'de, yetmiyorsa hiçbir şey değişmez
    if db.execute("UPDATE isorp_oyuncu SET para=para-? WHERE kid=? AND para>=?", (fiyat, k["id"], fiyat)).rowcount == 0:
        raise Hata(402, f"Paran yetmiyor ({fiyat} gerekiyor)")
    env[e] = env.get(e, 0) + 1
    db.execute("UPDATE isorp_oyuncu SET envanter=? WHERE kid=?", (json.dumps(env), k["id"])); db.commit()
    h.cevap(200, {"oyuncu": disari(db, k, oyuncu(db, k))})


def post_ev(h, db):
    k = site.giris_sart(h, db); r = oyuncu(db, k); l = h.govde().get("esyalar")
    if not isinstance(l, list) or len(l) > 60: raise Hata(400, "En fazla 60 eşya")
    env = json.loads(r["envanter"]); say = {}; temiz = []
    for x in l:
        if not isinstance(x, dict): raise Hata(400, "Bozuk")
        e = str(x.get("id", ""))
        if not e.startswith("mobilya:") or e not in KATALOG: raise Hata(400, "Geçersiz eşya")
        say[e] = say.get(e, 0) + 1
        if say[e] > env.get(e, 0): raise Hata(403, f"{KATALOG[e][0]}: elindekinden fazla yerleştirilemez")
        try: temiz.append({"id": e, "x": round(max(-4.4, min(4.4, float(x.get("x", 0)))), 2), "z": round(max(-4.4, min(4.4, float(x.get("z", 0)))), 2), "r": int(x.get("r", 0)) % 4})
        except (TypeError, ValueError): raise Hata(400, "Bozuk konum")
    db.execute("UPDATE isorp_oyuncu SET ev=? WHERE kid=?", (json.dumps(temiz), k["id"])); db.commit()
    h.cevap(200, {"ev": temiz})


def get_ev(h, db, q):
    site.giris_sart(h, db)
    u = db.execute("SELECT * FROM kullanici WHERE ad=? AND gizli=0 AND engelli=0", (str(q.get("ad", "")),)).fetchone()
    if not u: raise Hata(404, "Oyuncu yok")
    r = db.execute("SELECT ev, avatar FROM isorp_oyuncu WHERE kid=?", (u["id"],)).fetchone()
    h.cevap(200, {"ad": u["ad"], "id": u["id"], "ev": json.loads(r["ev"]) if r else [], "avatar": json.loads(r["avatar"]) if r else BASLANGIC_AVATAR})


def post_gunluk(h, db):
    k = site.giris_sart(h, db); oyuncu(db, k)
    if db.execute("UPDATE isorp_oyuncu SET para=para+?, gunluk=? WHERE kid=? AND (gunluk IS NULL OR gunluk!=?)", (GUNLUK_ODUL, gun(), k["id"], gun())).rowcount == 0:
        raise Hata(409, "Bugünkü ödülünü zaten aldın; yarın tekrar gel")
    db.commit()
    h.cevap(200, {"oyuncu": disari(db, k, oyuncu(db, k)), "odul": GUNLUK_ODUL})


def post_oyun_basla(h, db):
    k = site.giris_sart(h, db); site.sinir(h, "isorp_oyun", 20, 60); oyuncu(db, k)
    o = str(h.govde().get("oyun", ""))
    if o not in OYUNLAR: raise Hata(404, "Böyle bir oyun yok")
    db.execute("DELETE FROM isorp_oyun WHERE kid=? OR baslangic<?", (k["id"], time.time() - 3600))
    j = secrets.token_urlsafe(16)
    db.execute("INSERT INTO isorp_oyun VALUES(?,?,?,?)", (j, k["id"], o, time.time())); db.commit()
    h.cevap(200, {"jeton": j})


def post_oyun_bitir(h, db):
    k = site.giris_sart(h, db); v = h.govde()
    g = db.execute("SELECT * FROM isorp_oyun WHERE jeton=? AND kid=?", (str(v.get("jeton", "")), k["id"])).fetchone()
    if not g: raise Hata(400, "Oyun oturumu bulunamadı")
    db.execute("DELETE FROM isorp_oyun WHERE jeton=?", (g["jeton"],)); db.commit()
    kural = OYUNLAR[g["oyun"]]; gecen = time.time() - g["baslangic"]
    try: skor = max(0, int(v.get("skor", 0)))
    except (TypeError, ValueError): raise Hata(400, "Bozuk skor")
    if gecen < kural["sure"] or skor > kural["en_cok"](gecen): raise Hata(400, "Bu skor oyunun kurallarına uymuyor")
    r = oyuncu(db, k)
    kazanilan_bugun = r["oyun_kazanc"] if r["oyun_gun"] == gun() else 0
    kazanc = max(0, min(kural["para"](skor), OYUN_GUNLUK_TAVAN - kazanilan_bugun))
    db.execute("UPDATE isorp_oyuncu SET para=para+?, oyun_gun=?, oyun_kazanc=? WHERE kid=?", (kazanc, gun(), kazanilan_bugun + kazanc, k["id"]))
    db.execute("INSERT INTO isorp_skor(kid,oyun,skor,kazanc,tarih) VALUES(?,?,?,?,?)", (k["id"], g["oyun"], skor, kazanc, int(time.time())))
    db.commit()
    rek = db.execute("SELECT MAX(skor) FROM isorp_skor WHERE kid=? AND oyun=?", (k["id"], g["oyun"])).fetchone()[0]
    h.cevap(200, {"kazanc": kazanc, "rekor": rek, "tavan_doldu": kazanc < kural["para"](skor), "oyuncu": disari(db, k, oyuncu(db, k))})


def get_skorlar(h, db, q):
    o = str(q.get("oyun", ""))
    if o not in OYUNLAR: raise Hata(404, "Oyun yok")
    l = [{"ad": r["ad"], "skor": r["s"]} for r in db.execute(
        "SELECT k.ad, MAX(s.skor) s FROM isorp_skor s JOIN kullanici k ON k.id=s.kid WHERE s.oyun=? AND k.engelli=0 GROUP BY s.kid ORDER BY s DESC LIMIT 10", (o,))]
    h.cevap(200, {"skorlar": l})


def calis(h, yontem, yol):
    db = h.server.db
    ad = yol.replace("/", "_")
    try:
        if yontem == "GET":
            f = globals().get("get_" + ad)
            if not f: raise Hata(404, "Bulunamadı")
            import urllib.parse
            q = {a: b[0] for a, b in urllib.parse.parse_qs(urllib.parse.urlparse(h.path).query).items()}
            return f(h, db, q)
        f = globals().get("post_" + ad)
        if not f: raise Hata(404, "Bulunamadı")
        f(h, db)
    except (TypeError, ValueError, KeyError, AttributeError) as e:
        if isinstance(e, Hata): raise
        print("isorp hata:", repr(e)[:200], flush=True)
        raise Hata(400, "Bozuk istek")
