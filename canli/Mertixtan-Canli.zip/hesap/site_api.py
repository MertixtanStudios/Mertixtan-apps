"""Mertixtan site içeriği: haberler, yorumlar, yol haritası, SSS, anketler, fikir panosu, indirmeler, lisanslar,
iletişim, bülten, MIMO sohbet geçmişi ve eğitim verisi, oyun skorları, destekçi sayacı, ziyaret istatistiği.
hesap.py içinden /api/site/... olarak çağrılır. Her şey sunucuda, SQLite'ta durur; yönetici panelinden yönetilir."""
import base64, datetime, hashlib, hmac, json, re, secrets, time, urllib.parse


class Hata(Exception):
    def __init__(self, kod, mesaj): self.kod, self.mesaj = kod, mesaj


SEMA = """
CREATE TABLE IF NOT EXISTS haber(id INTEGER PRIMARY KEY, baslik TEXT, ozet TEXT, icerik TEXT, etiket TEXT, tarih INTEGER, yayinda INTEGER DEFAULT 1);
CREATE TABLE IF NOT EXISTS yorum(id INTEGER PRIMARY KEY, haber_id INTEGER, kid INTEGER, metin TEXT, tarih INTEGER);
CREATE TABLE IF NOT EXISTS yol(id INTEGER PRIMARY KEY, baslik TEXT, aciklama TEXT, durum TEXT DEFAULT 'plan', sira INTEGER DEFAULT 0);
CREATE TABLE IF NOT EXISTS sss(id INTEGER PRIMARY KEY, soru TEXT, cevap TEXT, sira INTEGER DEFAULT 0);
CREATE TABLE IF NOT EXISTS anket(id INTEGER PRIMARY KEY, soru TEXT, secenekler TEXT, aktif INTEGER DEFAULT 1, tarih INTEGER);
CREATE TABLE IF NOT EXISTS oy(anket_id INTEGER, kid INTEGER, secim INTEGER, PRIMARY KEY(anket_id, kid));
CREATE TABLE IF NOT EXISTS fikir(id INTEGER PRIMARY KEY, kid INTEGER, baslik TEXT, aciklama TEXT, durum TEXT DEFAULT 'yeni', yanit TEXT, tarih INTEGER);
CREATE TABLE IF NOT EXISTS fikir_oy(fikir_id INTEGER, kid INTEGER, PRIMARY KEY(fikir_id, kid));
CREATE TABLE IF NOT EXISTS indirme(id INTEGER PRIMARY KEY, ad TEXT, surum TEXT, platform TEXT, kategori TEXT, url TEXT, notlar TEXT, pro INTEGER DEFAULT 0, sayac INTEGER DEFAULT 0, tarih INTEGER);
CREATE TABLE IF NOT EXISTS lisans(anahtar TEXT PRIMARY KEY, urun TEXT, kid INTEGER, olusturma INTEGER, etkinlesme INTEGER, notu TEXT);
CREATE TABLE IF NOT EXISTS mesaj(id INTEGER PRIMARY KEY, kid INTEGER, ad TEXT, eposta TEXT, konu TEXT, metin TEXT, tarih INTEGER, okundu INTEGER DEFAULT 0);
CREATE TABLE IF NOT EXISTS bulten(eposta TEXT PRIMARY KEY COLLATE NOCASE, tarih INTEGER);
CREATE TABLE IF NOT EXISTS sohbet(id INTEGER PRIMARY KEY, kid INTEGER, baslik TEXT, mesajlar TEXT, guncelleme INTEGER);
CREATE TABLE IF NOT EXISTS mimo_ders(id INTEGER PRIMARY KEY, kid INTEGER, mesajlar TEXT, puan INTEGER, duzeltme TEXT, durum TEXT DEFAULT 'bekliyor', tarih INTEGER);
CREATE TABLE IF NOT EXISTS skor(id INTEGER PRIMARY KEY, kid INTEGER, mesafe INTEGER, altin INTEGER, seviye INTEGER, tarih INTEGER);
CREATE TABLE IF NOT EXISTS destek(kim TEXT PRIMARY KEY, tarih INTEGER);
CREATE TABLE IF NOT EXISTS ziyaret(gun TEXT, kim TEXT, sayi INTEGER DEFAULT 1, PRIMARY KEY(gun, kim));
CREATE TABLE IF NOT EXISTS indirme_kim(indirme_id INTEGER, kim TEXT, PRIMARY KEY(indirme_id, kim));
CREATE TABLE IF NOT EXISTS ucus(jeton TEXT PRIMARY KEY, kid INTEGER, baslangic REAL);
CREATE TABLE IF NOT EXISTS siparis(orderid TEXT PRIMARY KEY, eposta TEXT COLLATE NOCASE, ad TEXT, fiyat TEXT, urun TEXT, test INTEGER, kid INTEGER, anahtar TEXT, tarih INTEGER);
CREATE INDEX IF NOT EXISTS yorum_haber ON yorum(haber_id);
CREATE INDEX IF NOT EXISTS skor_mesafe ON skor(mesafe DESC);
"""

# Kurulumda bir kez yazılan başlangıç içeriği (sonra tamamen panelden değişir)
BASLANGIC_HABER = [
    ("MIMO-Sıfır eğitimde", "Kendi yapay zekâmızı sıfırdan eğitiyoruz.", "Kendi yapay zekâmız MIMO'yu ChatGPT'nin tarifiyle sıfırdan eğitiyoruz: önce Transformer mimarisi, sonra Türkçe Vikipedi ile ön eğitim, ardından sohbet dersleri.\n\nSitede MIMO ile konuşup cevaplarını 👍 / 👎 ile puanlayabilir, yanlış cevapların doğrusunu yazabilirsin. Bu düzeltmeler bir sonraki eğitimde MIMO'ya ders olarak verilir.", "YAPAY ZEKÂ", 1795737600),
    ("MX Dev 0.1.0", "Telefon ile bilgisayarı birleştiren geliştirici uygulaması.", "MX Dev'in ilk sürümü hazır: QR ile şifreli eşleşme, pano paylaşımı ve dosya aktarımı. Windows ve Android için İndirme Merkezi'nde.", "YAZILIM", 1795651200),
    ("MertixtanOS'a Kod Editörü", "Rust ile yazdığımız işletim sistemine kendi derleyicisi geldi.", "MertixtanOS 0.8 ile kendi Rust derleyicisi, Kod Editörü ve .mos uygulama paketleri geliyor. Uygulamanı yaz, derle, tek dokunuşla yükle.", "İŞLETİM SİSTEMİ", 1795219200),
    ("3D Gökyüzü Ustası yayında", "Uçağını geliştir, rekorunu skor tablosuna yazdır.", "3D Gökyüzü Ustası artık oynanabilir. Giriş yaptıysan her uçuşun skor tablosuna kaydedilir; en uzağa uçan ilk sıraya çıkar.", "OYUN", 1795132800),
]
BASLANGIC_YOL = [("3D Gökyüzü Ustası", "Oynanabilir sürüm ve skor tablosu", "bitti"), ("Hesap sistemi ve yönetici paneli", "Giriş, kayıt, profil, panel", "bitti"),
                 ("MIMO-Sıfır ön eğitimi", "Türkçe Vikipedi ile 130M parametre", "yapiliyor"), ("MX Dev Pro", "Alet çantası, canlı önizleme, stüdyo", "yapiliyor"),
                 ("İlk YouTube videosu", "Montaj aşamasında", "yapiliyor"), ("MertixtanOS 1.0", "Kararlı sürüm, Windows ve Android", "plan")]
BASLANGIC_SSS = [("MIMO nedir?", "Mertixtan Studios'un Türkçe yapay zekâ asistanı; açık kaynak Qwen2.5-Coder modeli üzerinde, kendi sunucumuzda çalışır. Yanılabilir; 👍/👎 ve düzeltmelerinle gelişir."),
                 ("Hesap açmak ücretli mi?", "Hayır. Kayıt olmak, oyun oynamak, oy vermek ve MIMO ile konuşmak ücretsiz."),
                 ("Pro lisansı nasıl alırım?", "Shopier mağazamızdan satın aldığında sana bir lisans anahtarı gelir. Profil sayfanda 'Lisans etkinleştir' bölümüne yapıştırman yeterli."),
                 ("Verilerim güvende mi?", "Şifreler geri çözülemeyen bir özet olarak saklanır; bilgilerin üçüncü kişilerle paylaşılmaz. Hesabını istediğin an profilinden silebilirsin.")]


def semayi_kur(db):
    db.executescript(SEMA)
    sutunlar = {r[1] for r in db.execute("PRAGMA table_info(kullanici)")}
    for ad, tur in (("unvan", "TEXT"), ("renk", "TEXT"), ("biyografi", "TEXT"), ("pro", "INTEGER DEFAULT 0")):
        if ad not in sutunlar: db.execute(f"ALTER TABLE kullanici ADD COLUMN {ad} {tur}")
    if not db.execute("SELECT 1 FROM ayar WHERE ad='baslangic'").fetchone():
        for b, o, i, e, t in BASLANGIC_HABER: db.execute("INSERT INTO haber(baslik,ozet,icerik,etiket,tarih) VALUES(?,?,?,?,?)", (b, o, i, e, t))
        for n, (b, a, d) in enumerate(BASLANGIC_YOL): db.execute("INSERT INTO yol(baslik,aciklama,durum,sira) VALUES(?,?,?,?)", (b, a, d, n))
        for n, (s, c) in enumerate(BASLANGIC_SSS): db.execute("INSERT INTO sss(soru,cevap,sira) VALUES(?,?,?)", (s, c, n))
        db.execute("INSERT INTO anket(soru,secenekler,tarih) VALUES(?,?,?)", ("İlk önce hangisi gelsin?", json.dumps(["İlk büyük YouTube videosu", "Özel oyun modu & turnuva", "MX Dev Pro"]), int(time.time())))
        db.execute("INSERT INTO indirme(ad,surum,platform,kategori,url,notlar,tarih) VALUES(?,?,?,?,?,?,?)",
                   ("MertixtanOS", "0.8.3", "Android", "yazilim", "https://github.com/MertixtanStudios/Mertixtan-apps/raw/main/MertixtanOS-0.8.3%20(5).apk", "Tablet ve telefon için", int(time.time())))
        db.execute("INSERT INTO indirme(ad,surum,platform,kategori,url,notlar,tarih) VALUES(?,?,?,?,?,?,?)",
                   ("MertixtanOS", "0.8.1", "Windows", "yazilim", "https://github.com/MertixtanStudios/Mertixtan-apps/raw/main/MertixtanOS-0.8.1-Windows.zip", "Zip'i aç, .exe'yi çalıştır", int(time.time())))
        acilis = (datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=3))) + datetime.timedelta(days=14)).strftime("%Y-%m-%dT%H:%M")
        for a, d in (("baslangic", "1"), ("acilis", acilis), ("serit", "MERTIXTANSTUDIOS YAYINDA\nMIMO İLE SOHBET ET\n3D GÖKYÜZÜ USTASI SKOR TABLOSU\nFİKRİNİ PANOYA YAZ")):
            db.execute("INSERT OR IGNORE INTO ayar VALUES(?,?)", (a, d))
    db.commit()


# ---------------------------------------------------------------- yardımcılar
SINIRLAR = {}  # (ip, grup) -> [zaman]


def sinir(h, grup, adet, saniye):
    su = time.time(); a = (h.ip(), grup)
    l = [t for t in SINIRLAR.get(a, []) if su - t < saniye]
    if len(l) >= adet: raise Hata(429, "Çok hızlısın, biraz bekle.")
    l.append(su); SINIRLAR[a] = l
    if len(SINIRLAR) > 50000: SINIRLAR.clear()


def metin(v, ad, en_az=1, en_cok=2000, zorunlu=True):
    x = v.get(ad)
    if x is not None and not isinstance(x, (str, int, float)): raise Hata(400, f"'{ad}' geçersiz")
    s = str(x or "").strip()
    if zorunlu and len(s) < en_az: raise Hata(400, f"'{ad}' çok kısa")
    if len(s) > en_cok: raise Hata(400, f"'{ad}' en çok {en_cok} karakter olabilir")
    return s


def giris_sart(h, db):
    k = h.kullanici(db)
    if not k: raise Hata(401, "Bunun için giriş yapmalısın")
    return k


def yonetici_sart(h, db):
    k = h.kullanici(db)
    if not k or not k["yonetici"]: raise Hata(403, "Yönetici yetkisi gerekli")
    return k


def satirlar(db, q, *a): return [dict(r) for r in db.execute(q, a)]
def ayarlar(db): return {r["ad"]: r["deger"] for r in db.execute("SELECT * FROM ayar")}
def bugun(): return datetime.date.today().isoformat()
def kim(h, k): return f"k{k['id']}" if k else "i" + hashlib.sha256((h.ip() + bugun()).encode()).hexdigest()[:16]


def anket_disari(db, a, kid):
    sec = json.loads(a["secenekler"])
    say = [0] * len(sec)
    for r in db.execute("SELECT secim, COUNT(*) c FROM oy WHERE anket_id=? GROUP BY secim", (a["id"],)):
        if 0 <= r["secim"] < len(say): say[r["secim"]] = r["c"]
    benim = db.execute("SELECT secim FROM oy WHERE anket_id=? AND kid=?", (a["id"], kid)).fetchone() if kid else None
    return {"id": a["id"], "soru": a["soru"], "secenekler": sec, "oylar": say, "benim": benim["secim"] if benim else None, "aktif": bool(a["aktif"])}


# ---------------------------------------------------------------- herkese açık uçlar
def get_icerik(h, db, q):
    k = h.kullanici(db); kid = k["id"] if k else None
    ay = ayarlar(db)
    say = lambda s, *a: db.execute(s, a).fetchone()[0]
    h.cevap(200, {
        "haberler": satirlar(db, "SELECT id,baslik,ozet,etiket,tarih,(SELECT COUNT(*) FROM yorum y WHERE y.haber_id=haber.id) yorum FROM haber WHERE yayinda=1 ORDER BY tarih DESC LIMIT 30"),
        "yol": satirlar(db, "SELECT id,baslik,aciklama,durum FROM yol ORDER BY sira, id"),
        "sss": satirlar(db, "SELECT id,soru,cevap FROM sss ORDER BY sira, id"),
        "anketler": [anket_disari(db, a, kid) for a in db.execute("SELECT * FROM anket WHERE aktif=1 ORDER BY id DESC")],
        "indirmeler": satirlar(db, "SELECT id,ad,surum,platform,kategori,notlar,pro,sayac,tarih FROM indirme ORDER BY tarih DESC"),
        "ayar": {a: ay.get(a, "") for a in ("acilis", "youtube", "serit", "pro_link", "pro_fiyat", "duyuru", "google_istemci")},
        "destek": {"sayi": say("SELECT COUNT(*) FROM destek WHERE kim LIKE 'k%'"), "ben": bool(k and db.execute("SELECT 1 FROM destek WHERE kim=?", (kim(h, k),)).fetchone())},
        "istatistik": {"uye": say("SELECT COUNT(*) FROM kullanici WHERE gizli=0"), "ucus": say("SELECT COUNT(*) FROM skor"),
                       "fikir": say("SELECT COUNT(*) FROM fikir"), "ders": say("SELECT COUNT(*) FROM mimo_ders"),
                       "indirme": say("SELECT COALESCE(SUM(sayac),0) FROM indirme")},
    })


def get_haber(h, db, q):
    hb = db.execute("SELECT * FROM haber WHERE id=? AND yayinda=1", (int(q.get("id", 0)),)).fetchone()
    if not hb: raise Hata(404, "Haber bulunamadı")
    yorumlar = satirlar(db, "SELECT y.id, y.metin, y.tarih, k.ad, k.renk, k.yonetici FROM yorum y JOIN kullanici k ON k.id=y.kid WHERE y.haber_id=? ORDER BY y.id", hb["id"])
    h.cevap(200, {"haber": dict(hb), "yorumlar": yorumlar})


def post_yorum(h, db):
    k = giris_sart(h, db); sinir(h, "yorum", 5, 60)
    v = h.govde(); hid = int(v.get("haber_id") or 0)
    if not db.execute("SELECT 1 FROM haber WHERE id=? AND yayinda=1", (hid,)).fetchone(): raise Hata(404, "Haber yok")
    db.execute("INSERT INTO yorum(haber_id,kid,metin,tarih) VALUES(?,?,?,?)", (hid, k["id"], metin(v, "metin", 2, 1000), int(time.time())))
    db.commit(); h.cevap(200, {"tamam": True})


def post_yorum_sil(h, db):
    k = giris_sart(h, db); v = h.govde()
    y = db.execute("SELECT * FROM yorum WHERE id=?", (int(v.get("id") or 0),)).fetchone()
    if not y or (y["kid"] != k["id"] and not k["yonetici"]): raise Hata(403, "Bu yorumu silemezsin")
    db.execute("DELETE FROM yorum WHERE id=?", (y["id"],)); db.commit(); h.cevap(200, {"tamam": True})


def post_oy(h, db):
    k = giris_sart(h, db); v = h.govde()
    a = db.execute("SELECT * FROM anket WHERE id=? AND aktif=1", (int(v.get("anket_id") or 0),)).fetchone()
    if not a: raise Hata(404, "Anket yok")
    s = int(v.get("secim", -1))
    if not 0 <= s < len(json.loads(a["secenekler"])): raise Hata(400, "Geçersiz seçenek")
    db.execute("INSERT INTO oy VALUES(?,?,?) ON CONFLICT(anket_id,kid) DO UPDATE SET secim=excluded.secim", (a["id"], k["id"], s))
    db.commit(); h.cevap(200, anket_disari(db, a, k["id"]))


def post_destek(h, db):
    k = giris_sart(h, db); sinir(h, "destek", 5, 60)
    db.execute("INSERT OR IGNORE INTO destek VALUES(?,?)", (kim(h, k), int(time.time())))
    db.commit(); h.cevap(200, {"sayi": db.execute("SELECT COUNT(*) FROM destek WHERE kim LIKE 'k%'").fetchone()[0], "ben": True})


def get_fikirler(h, db, q):
    k = h.kullanici(db); kid = k["id"] if k else 0
    l = satirlar(db, """SELECT f.id,f.baslik,f.aciklama,f.durum,f.yanit,f.tarih,k.ad,
        (SELECT COUNT(*) FROM fikir_oy o WHERE o.fikir_id=f.id) oy, EXISTS(SELECT 1 FROM fikir_oy o WHERE o.fikir_id=f.id AND o.kid=?) benim
        FROM fikir f LEFT JOIN kullanici k ON k.id=f.kid ORDER BY (f.durum IN ('bitti','red')), oy DESC, f.id DESC LIMIT 200""", kid)
    h.cevap(200, {"fikirler": l})


def post_fikir(h, db):
    k = giris_sart(h, db); sinir(h, "fikir", 3, 600); v = h.govde()
    db.execute("INSERT INTO fikir(kid,baslik,aciklama,tarih) VALUES(?,?,?,?)", (k["id"], metin(v, "baslik", 4, 120), metin(v, "aciklama", 0, 1500, False), int(time.time())))
    fid = db.execute("SELECT last_insert_rowid()").fetchone()[0]
    db.execute("INSERT INTO fikir_oy VALUES(?,?)", (fid, k["id"])); db.commit(); h.cevap(200, {"tamam": True})


def post_fikir_oy(h, db):
    k = giris_sart(h, db); v = h.govde(); fid = int(v.get("id") or 0)
    if not db.execute("SELECT 1 FROM fikir WHERE id=?", (fid,)).fetchone(): raise Hata(404, "Fikir yok")
    if db.execute("SELECT 1 FROM fikir_oy WHERE fikir_id=? AND kid=?", (fid, k["id"])).fetchone():
        db.execute("DELETE FROM fikir_oy WHERE fikir_id=? AND kid=?", (fid, k["id"]))
    else: db.execute("INSERT INTO fikir_oy VALUES(?,?)", (fid, k["id"]))
    db.commit(); h.cevap(200, {"tamam": True})


def get_indir(h, db, q):
    i = db.execute("SELECT * FROM indirme WHERE id=?", (int(q.get("id", 0)),)).fetchone()
    if not i: raise Hata(404, "Dosya yok")
    if i["pro"]:
        k = h.kullanici(db)
        if not k or not (k["pro"] or k["yonetici"]): raise Hata(403, "Bu dosya Pro üyelere özel")
    sinir(h, "indir", 30, 60)
    k = h.kullanici(db)
    if db.execute("INSERT OR IGNORE INTO indirme_kim VALUES(?,?)", (i["id"], kim(h, k))).rowcount:
        db.execute("UPDATE indirme SET sayac=sayac+1 WHERE id=?", (i["id"],))
    db.commit()
    h.send_response(302); h.send_header("Location", i["url"]); h.send_header("Cache-Control", "no-store"); h.end_headers()


def post_lisans(h, db):
    k = giris_sart(h, db); sinir(h, "lisans", 10, 600); v = h.govde()
    a = metin(v, "anahtar", 10, 64).upper()
    l = db.execute("SELECT * FROM lisans WHERE anahtar=?", (a,)).fetchone()
    if not l: raise Hata(404, "Lisans anahtarı bulunamadı")
    if l["kid"] and l["kid"] != k["id"]: raise Hata(409, "Bu anahtar başka bir hesapta kullanılmış")
    db.execute("UPDATE lisans SET kid=?, etkinlesme=COALESCE(etkinlesme,?) WHERE anahtar=?", (k["id"], int(time.time()), a))
    db.execute("UPDATE kullanici SET pro=1 WHERE id=?", (k["id"],)); db.commit()
    h.cevap(200, {"tamam": True, "urun": l["urun"]})


def get_lisans_dogrula(h, db, q):
    """MX Dev gibi uygulamalar Pro anahtarını buradan doğrular."""
    sinir(h, "dogrula", 30, 60)
    l = db.execute("SELECT urun, kid FROM lisans WHERE anahtar=?", (str(q.get("anahtar", "")).upper(),)).fetchone()
    h.cevap(200, {"gecerli": bool(l), "urun": l["urun"] if l else None, "etkin": bool(l and l["kid"])})


def post_iletisim(h, db):
    k = h.kullanici(db); sinir(h, "iletisim", 3, 600); v = h.govde()
    eposta = metin(v, "eposta", 0, 200, False) or (k["eposta"] if k else "")
    db.execute("INSERT INTO mesaj(kid,ad,eposta,konu,metin,tarih) VALUES(?,?,?,?,?,?)",
               (k["id"] if k else None, metin(v, "ad", 2, 80), eposta, metin(v, "konu", 2, 120), metin(v, "metin", 5, 3000), int(time.time())))
    db.commit(); h.cevap(200, {"tamam": True})


def post_bulten(h, db):
    sinir(h, "bulten", 5, 600); v = h.govde()
    e = metin(v, "eposta", 5, 200).lower()
    if not re.fullmatch(r"[^@\s]+@[^@\s]+\.[^@\s]+", e): raise Hata(400, "E-posta geçersiz")
    db.execute("INSERT OR IGNORE INTO bulten VALUES(?,?)", (e, int(time.time()))); db.commit(); h.cevap(200, {"tamam": True})


def get_skorlar(h, db, q):
    l = satirlar(db, """SELECT k.ad, k.renk, k.pro, MAX(s.mesafe) mesafe, MAX(s.seviye) seviye, SUM(s.altin) altin, COUNT(*) ucus
        FROM skor s JOIN kullanici k ON k.id=s.kid WHERE k.engelli=0 GROUP BY s.kid ORDER BY mesafe DESC LIMIT 20""")
    k = h.kullanici(db)
    ben = db.execute("SELECT MAX(mesafe) m, COUNT(*) c FROM skor WHERE kid=?", (k["id"],)).fetchone() if k else None
    h.cevap(200, {"skorlar": l, "ben": {"rekor": ben["m"], "ucus": ben["c"]} if ben and ben["c"] else None})


HIZ_SINIRI = 40  # m/sn: oyundaki en hızlı uçuştan bile yüksek; daha hızlı "uçuş" sahtedir


def post_skor_basla(h, db):
    """Uçuş başlarken sunucudan jeton alınır; skor sadece gerçekten geçen süreye uygunsa kaydedilir."""
    k = giris_sart(h, db); sinir(h, "skor_basla", 20, 60)
    db.execute("DELETE FROM ucus WHERE kid=? OR baslangic<?", (k["id"], time.time() - 3600))
    j = secrets.token_urlsafe(16)
    db.execute("INSERT INTO ucus VALUES(?,?,?)", (j, k["id"], time.time())); db.commit()
    h.cevap(200, {"jeton": j})


def post_skor(h, db):
    k = giris_sart(h, db); sinir(h, "skor", 6, 60); v = h.govde()
    try: m, a, s = int(v.get("mesafe") or 0), int(v.get("altin") or 0), int(v.get("seviye") or 1)
    except (TypeError, ValueError): raise Hata(400, "Geçersiz skor")
    u = db.execute("SELECT * FROM ucus WHERE jeton=? AND kid=?", (str(v.get("jeton") or ""), k["id"])).fetchone()
    if not u: raise Hata(400, "Uçuş jetonu yok; skor kaydedilmedi")
    db.execute("DELETE FROM ucus WHERE jeton=?", (u["jeton"],)); db.commit()
    gecen = time.time() - u["baslangic"]
    onceki = db.execute("SELECT COALESCE(MAX(seviye),0) FROM skor WHERE kid=?", (k["id"],)).fetchone()[0]
    hedef = 100 + 75 * (s - 1)  # oyunda bu seviyenin bitiş çizgisi
    if not (0 <= m <= hedef + 30 and 0 <= a <= 500 and 1 <= s <= max(onceki, 2) + 1) or m > gecen * HIZ_SINIRI:
        raise Hata(400, "Bu skor oyunun kurallarına uymuyor; kaydedilmedi")
    db.execute("INSERT INTO skor(kid,mesafe,altin,seviye,tarih) VALUES(?,?,?,?,?)", (k["id"], m, a, s, int(time.time())))
    db.commit(); h.cevap(200, {"tamam": True})


def post_ziyaret(h, db):
    sinir(h, "ziyaret", 30, 60)
    db.execute("INSERT INTO ziyaret(gun,kim) VALUES(?,?) ON CONFLICT(gun,kim) DO UPDATE SET sayi=sayi+1", (bugun(), kim(h, None)))
    db.commit(); h.cevap(200, {"tamam": True})


def get_ara(h, db, q):
    s = str(q.get("q", "")).strip()[:60]
    if len(s) < 2: return h.cevap(200, {"sonuclar": []})
    d = f"%{s}%"
    r = [{"tur": "Haber", "id": x["id"], "baslik": x["baslik"], "ozet": x["ozet"]} for x in db.execute("SELECT id,baslik,ozet FROM haber WHERE yayinda=1 AND (baslik LIKE ? OR icerik LIKE ?) LIMIT 8", (d, d))]
    r += [{"tur": "SSS", "id": x["id"], "baslik": x["soru"], "ozet": x["cevap"][:140]} for x in db.execute("SELECT id,soru,cevap FROM sss WHERE soru LIKE ? OR cevap LIKE ? LIMIT 6", (d, d))]
    r += [{"tur": "İndirme", "id": x["id"], "baslik": f"{x['ad']} {x['surum']} ({x['platform']})", "ozet": x["notlar"] or ""} for x in db.execute("SELECT * FROM indirme WHERE ad LIKE ? OR notlar LIKE ? OR platform LIKE ? LIMIT 6", (d, d, d))]
    r += [{"tur": "Fikir", "id": x["id"], "baslik": x["baslik"], "ozet": (x["aciklama"] or "")[:140]} for x in db.execute("SELECT id,baslik,aciklama FROM fikir WHERE baslik LIKE ? OR aciklama LIKE ? LIMIT 6", (d, d))]
    h.cevap(200, {"sonuclar": r})


# ---- profil
def get_profil(h, db, q):
    k = giris_sart(h, db)
    rozet = []
    if k["id"] <= 101 and not k["gizli"]: rozet.append("Kurucu Üye")
    if k["pro"]: rozet.append("Pro")
    if k["dogrulanmis"]: rozet.append("Doğrulanmış")
    say = lambda s: db.execute(s, (k["id"],)).fetchone()[0]
    if say("SELECT COUNT(*) FROM mimo_ders WHERE kid=?") >= 5: rozet.append("MIMO Öğretmeni")
    if say("SELECT COUNT(*) FROM fikir WHERE kid=?") >= 1: rozet.append("Fikir Babası")
    if (say("SELECT COALESCE(MAX(mesafe),0) FROM skor WHERE kid=?") or 0) >= 1000: rozet.append("Pilot")
    h.cevap(200, {"siparisler": satirlar(db, "SELECT orderid, tarih, test FROM siparis WHERE kid=?", k["id"]), "rozetler": rozet, "lisanslar": satirlar(db, "SELECT anahtar, urun, etkinlesme FROM lisans WHERE kid=?", k["id"]),
                  "sayilar": {"yorum": say("SELECT COUNT(*) FROM yorum WHERE kid=?"), "fikir": say("SELECT COUNT(*) FROM fikir WHERE kid=?"),
                              "ders": say("SELECT COUNT(*) FROM mimo_ders WHERE kid=?"), "ucus": say("SELECT COUNT(*) FROM skor WHERE kid=?")}})


def post_profil(h, db):
    k = giris_sart(h, db); v = h.govde()
    renk = str(v.get("renk") or "")
    if renk and not re.fullmatch(r"#[0-9a-fA-F]{6}", renk): raise Hata(400, "Renk geçersiz")
    db.execute("UPDATE kullanici SET unvan=?, renk=?, biyografi=? WHERE id=?", (metin(v, "unvan", 0, 30, False), renk or None, metin(v, "biyografi", 0, 300, False), k["id"]))
    db.commit(); h.cevap(200, {"tamam": True})


def post_hesap_sil(h, db):
    k = giris_sart(h, db)
    if k["yonetici"]: raise Hata(400, "Yönetici hesabı buradan silinemez")
    for t in ("oturum", "yorum", "oy", "fikir_oy", "sohbet", "skor"): db.execute(f"DELETE FROM {t} WHERE kid=?", (k["id"],))
    db.execute("UPDATE fikir SET kid=NULL WHERE kid=?", (k["id"],)); db.execute("UPDATE mimo_ders SET kid=NULL WHERE kid=?", (k["id"],))
    db.execute("DELETE FROM kullanici WHERE id=?", (k["id"],)); db.commit()
    h.cevap(200, {"tamam": True}, cerez="")


# ---- MIMO: sohbet geçmişi ve öğretme
def get_sohbetler(h, db, q):
    k = giris_sart(h, db)
    if q.get("id"):
        s = db.execute("SELECT * FROM sohbet WHERE id=? AND kid=?", (int(q["id"]), k["id"])).fetchone()
        if not s: raise Hata(404, "Sohbet yok")
        return h.cevap(200, {"id": s["id"], "baslik": s["baslik"], "mesajlar": json.loads(s["mesajlar"])})
    h.cevap(200, {"sohbetler": satirlar(db, "SELECT id,baslik,guncelleme FROM sohbet WHERE kid=? ORDER BY guncelleme DESC LIMIT 50", k["id"])})


def post_sohbet(h, db):
    k = giris_sart(h, db); v = h.govde()
    m = v.get("mesajlar")
    if not isinstance(m, list) or len(m) > 60 or not all(isinstance(x, dict) and x.get("role") in ("user", "assistant") and isinstance(x.get("content"), str) for x in m):
        raise Hata(400, "Bozuk sohbet")
    m = [{"role": x["role"], "content": x["content"][:4000]} for x in m]
    baslik = (next((x["content"] for x in m if x["role"] == "user"), "Yeni sohbet"))[:60]
    sid = int(v.get("id") or 0)
    if sid and db.execute("SELECT 1 FROM sohbet WHERE id=? AND kid=?", (sid, k["id"])).fetchone():
        db.execute("UPDATE sohbet SET mesajlar=?, guncelleme=? WHERE id=?", (json.dumps(m, ensure_ascii=False), int(time.time()), sid))
    else:
        if db.execute("SELECT COUNT(*) FROM sohbet WHERE kid=?", (k["id"],)).fetchone()[0] >= 100: raise Hata(400, "En çok 100 sohbet saklanır; eskileri sil")
        db.execute("INSERT INTO sohbet(kid,baslik,mesajlar,guncelleme) VALUES(?,?,?,?)", (k["id"], baslik, json.dumps(m, ensure_ascii=False), int(time.time())))
        sid = db.execute("SELECT last_insert_rowid()").fetchone()[0]
    db.commit(); h.cevap(200, {"id": sid})


def post_sohbet_sil(h, db):
    k = giris_sart(h, db); v = h.govde()
    db.execute("DELETE FROM sohbet WHERE id=? AND kid=?", (int(v.get("id") or 0), k["id"])); db.commit(); h.cevap(200, {"tamam": True})


def post_mimo_ogret(h, db):
    """👍 / 👎 ve 'doğrusu şu' düzeltmeleri: bir sonraki ince ayarda MIMO'ya ders olur."""
    k = h.kullanici(db); sinir(h, "ogret", 20, 60)
    if not k: sinir(h, "ogret_misafir", 10, 3600)
    if db.execute("SELECT COUNT(*) FROM mimo_ders WHERE durum='bekliyor'").fetchone()[0] >= 5000: raise Hata(503, "Ders kutusu dolu, yönetici inceledikten sonra tekrar dene")
    v = h.govde()
    m = v.get("mesajlar")
    if not isinstance(m, list) or not 2 <= len(m) <= 20: raise Hata(400, "Bozuk istek")
    m = [{"role": x.get("role"), "content": str(x.get("content", ""))[:4000]} for x in m if x.get("role") in ("user", "assistant")]
    puan = 1 if int(v.get("puan") or 0) > 0 else -1
    duz = metin(v, "duzeltme", 0, 4000, False)
    db.execute("INSERT INTO mimo_ders(kid,mesajlar,puan,duzeltme,tarih) VALUES(?,?,?,?,?)",
               (k["id"] if k else None, json.dumps(m, ensure_ascii=False), puan, duz or None, int(time.time())))
    db.commit(); h.cevap(200, {"tamam": True})


# ---------------------------------------------------------------- yönetici
DUZENLENEBILIR = {
    "haber": {"baslik": 160, "ozet": 300, "icerik": 20000, "etiket": 30, "tarih": "int", "yayinda": "int"},
    "yol": {"baslik": 120, "aciklama": 400, "durum": ("plan", "yapiliyor", "bitti"), "sira": "int"},
    "sss": {"soru": 200, "cevap": 3000, "sira": "int"},
    "anket": {"soru": 200, "secenekler": "liste", "aktif": "int"},
    "indirme": {"ad": 80, "surum": 30, "platform": 30, "kategori": ("yazilim", "tasarim", "oyun"), "url": "url", "notlar": 600, "pro": "int"},
    "fikir": {"durum": ("yeni", "planlandi", "yapiliyor", "bitti", "red"), "yanit": 600},
}


def yonetici_ozet(db):
    say = lambda s, *a: db.execute(s, a).fetchone()[0]
    gunler = [(datetime.date.today() - datetime.timedelta(days=i)).isoformat() for i in range(13, -1, -1)]
    z = {r["gun"]: (r["tekil"], r["toplam"]) for r in db.execute("SELECT gun, COUNT(*) tekil, SUM(sayi) toplam FROM ziyaret WHERE gun>=? GROUP BY gun", (gunler[0],))}
    return {"ziyaret": [{"gun": g, "tekil": z.get(g, (0, 0))[0], "toplam": z.get(g, (0, 0))[1]} for g in gunler],
            "okunmamis": say("SELECT COUNT(*) FROM mesaj WHERE okundu=0"), "bekleyen_ders": say("SELECT COUNT(*) FROM mimo_ders WHERE durum='bekliyor'"),
            "yeni_fikir": say("SELECT COUNT(*) FROM fikir WHERE durum='yeni'"), "bulten": say("SELECT COUNT(*) FROM bulten"),
            "lisans": say("SELECT COUNT(*) FROM lisans"), "lisans_kullanilan": say("SELECT COUNT(*) FROM lisans WHERE kid IS NOT NULL")}


def get_yonetici_shopier(h, db, q):
    yonetici_sart(h, db); ay = ayarlar(db)
    h.cevap(200, {"osb_kullanici": ay.get("osb_kullanici", ""), "osb_anahtar_var": bool(ay.get("osb_anahtar")), "pro_fiyat": ay.get("pro_fiyat", "")})


def get_yonetici_liste(h, db, q):
    yonetici_sart(h, db)
    t = q.get("tablo")
    sorgular = {
        "haber": "SELECT * FROM haber ORDER BY tarih DESC", "yol": "SELECT * FROM yol ORDER BY sira, id", "sss": "SELECT * FROM sss ORDER BY sira, id",
        "anket": "SELECT * FROM anket ORDER BY id DESC", "indirme": "SELECT * FROM indirme ORDER BY tarih DESC",
        "fikir": "SELECT f.*, k.ad, (SELECT COUNT(*) FROM fikir_oy o WHERE o.fikir_id=f.id) oy FROM fikir f LEFT JOIN kullanici k ON k.id=f.kid ORDER BY f.id DESC",
        "lisans": "SELECT l.*, k.ad FROM lisans l LEFT JOIN kullanici k ON k.id=l.kid ORDER BY l.olusturma DESC",
        "mesaj": "SELECT m.*, COALESCE(k.pro,0) pro FROM mesaj m LEFT JOIN kullanici k ON k.id=m.kid ORDER BY m.okundu, COALESCE(k.pro,0) DESC, m.id DESC LIMIT 300",
        "siparis": "SELECT s.*, k.ad uye FROM siparis s LEFT JOIN kullanici k ON k.id=s.kid ORDER BY s.tarih DESC LIMIT 500", "bulten": "SELECT * FROM bulten ORDER BY tarih DESC",
        "mimo_ders": "SELECT d.*, k.ad FROM mimo_ders d LEFT JOIN kullanici k ON k.id=d.kid ORDER BY d.id DESC LIMIT 300",
        "yorum": "SELECT y.*, k.ad, h.baslik FROM yorum y JOIN kullanici k ON k.id=y.kid JOIN haber h ON h.id=y.haber_id ORDER BY y.id DESC LIMIT 300",
    }
    if t not in sorgular: raise Hata(400, "Bilinmeyen tablo")
    l = satirlar(db, sorgular[t])
    if t == "anket":
        for a in l: a.update(anket_disari(db, a, None))
    h.cevap(200, {"satirlar": l})


def post_yonetici_kaydet(h, db):
    yonetici_sart(h, db); v = h.govde()
    t = v.get("tablo"); alan = DUZENLENEBILIR.get(t)
    if not alan: raise Hata(400, "Bilinmeyen tablo")
    d = {}
    for ad, kural in alan.items():
        if ad not in v: continue
        x = v[ad]
        if kural == "int": x = int(x or 0)
        elif kural == "liste":
            x = [str(s).strip()[:120] for s in (x if isinstance(x, list) else str(x).split("\n")) if str(s).strip()]
            if not 2 <= len(x) <= 8: raise Hata(400, "Ankette 2-8 seçenek olmalı")
            x = json.dumps(x, ensure_ascii=False)
        elif kural == "url":
            x = str(x).strip()
            if not re.fullmatch(r"https://\S{4,500}", x): raise Hata(400, "Bağlantı https:// ile başlamalı")
        elif isinstance(kural, tuple):
            if x not in kural: raise Hata(400, f"{ad} geçersiz")
        else: x = str(x or "").strip()[:kural]
        d[ad] = x
    sid = int(v.get("id") or 0)
    if sid:
        if not d: raise Hata(400, "Değişiklik yok")
        db.execute(f"UPDATE {t} SET " + ",".join(f"{a}=?" for a in d) + " WHERE id=?", (*d.values(), sid))
    else:
        if t == "fikir": raise Hata(400, "Fikirleri üyeler ekler")
        if t in ("haber", "anket", "indirme") and "tarih" not in d: d["tarih"] = int(time.time())
        db.execute(f"INSERT INTO {t}(" + ",".join(d) + ") VALUES(" + ",".join("?" * len(d)) + ")", tuple(d.values()))
        sid = db.execute("SELECT last_insert_rowid()").fetchone()[0]
    db.commit(); h.cevap(200, {"id": sid})


def post_yonetici_sil(h, db):
    yonetici_sart(h, db); v = h.govde(); t = v.get("tablo")
    anahtar = {"haber": "id", "yol": "id", "sss": "id", "anket": "id", "indirme": "id", "fikir": "id", "mesaj": "id", "yorum": "id",
               "mimo_ders": "id", "lisans": "anahtar", "bulten": "eposta", "siparis": "orderid"}.get(t)
    if not anahtar: raise Hata(400, "Bilinmeyen tablo")
    db.execute(f"DELETE FROM {t} WHERE {anahtar}=?", (v.get("id"),))
    if t == "haber": db.execute("DELETE FROM yorum WHERE haber_id=?", (v.get("id"),))
    if t == "anket": db.execute("DELETE FROM oy WHERE anket_id=?", (v.get("id"),))
    if t == "fikir": db.execute("DELETE FROM fikir_oy WHERE fikir_id=?", (v.get("id"),))
    db.commit(); h.cevap(200, {"tamam": True})


def post_yonetici_durum(h, db):
    """Mesajı okundu yap, MIMO dersini onayla/reddet."""
    yonetici_sart(h, db); v = h.govde()
    if v.get("tablo") == "mesaj": db.execute("UPDATE mesaj SET okundu=1 WHERE id=?", (int(v.get("id") or 0),))
    elif v.get("tablo") == "mimo_ders":
        if v.get("durum") not in ("bekliyor", "onay", "red"): raise Hata(400, "Geçersiz durum")
        db.execute("UPDATE mimo_ders SET durum=?, duzeltme=COALESCE(?, duzeltme) WHERE id=?", (v["durum"], v.get("duzeltme") or None, int(v.get("id") or 0)))
    else: raise Hata(400, "Bilinmeyen")
    db.commit(); h.cevap(200, {"tamam": True})


HARF = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"


def anahtar_uret():
    return "MXD-" + "-".join("".join(secrets.choice(HARF) for _ in range(4)) for _ in range(4))


def pro_ver(db, kid, orderid):
    """Siparişi hesaba bağla: Pro aç, profilde görünsün diye bir lisans anahtarı oluştur."""
    a = anahtar_uret()
    db.execute("INSERT INTO lisans(anahtar,urun,kid,olusturma,etkinlesme,notu) VALUES(?,?,?,?,?,?)",
               (a, "MX Dev Pro", kid, int(time.time()), int(time.time()), f"Shopier sipariş {orderid}"))
    db.execute("UPDATE siparis SET kid=?, anahtar=? WHERE orderid=?", (kid, a, orderid))
    db.execute("UPDATE kullanici SET pro=1 WHERE id=?", (kid,))


def post_shopier_osb(h, db):
    """Shopier Otomatik Sipariş Bildirimi: ödeme biter bitmez Pro'yu açar.
    Gövde: res (base64 JSON) + hash = HMAC-SHA256(res + OSB kullanıcı adı, OSB anahtarı) hex."""
    ay = ayarlar(db)
    kul, anah = ay.get("osb_kullanici", ""), ay.get("osb_anahtar", "")
    def yaz(kod, metin):
        b = metin.encode(); h.send_response(kod); h.send_header("Content-Type", "text/plain; charset=utf-8")
        h.send_header("Content-Length", str(len(b))); h.end_headers(); h.wfile.write(b)
    if not kul or not anah: return yaz(503, "unconfigured")
    try: n = int(h.headers.get("Content-Length", 0))
    except ValueError: n = -1
    if not 0 < n <= 100000: return yaz(400, "bad request")
    govde = h.rfile.read(n).decode("utf-8", "replace")
    alan = {a: b[0] for a, b in urllib.parse.parse_qs(govde).items()}
    res, imza = alan.get("res", ""), alan.get("hash", "").strip().lower()
    if not res or not imza: return yaz(400, "bad request")
    beklenen = hmac.new(anah.encode(), (res + kul).encode(), hashlib.sha256).hexdigest()
    if not hmac.compare_digest(beklenen, imza): return yaz(403, "forbidden")
    try:
        v = json.loads(base64.b64decode(res).decode("utf-8"))
        orderid = str(v.get("orderid") or v.get("orderId") or "").strip()[:64]
        eposta = str(v.get("email") or "").strip().lower()[:200]
        if not orderid or "@" not in eposta: raise ValueError
    except Exception: return yaz(400, "bad request")
    if db.execute("SELECT 1 FROM siparis WHERE orderid=?", (orderid,)).fetchone(): return yaz(200, "success")  # aynı bildirim tekrar geldi
    test = 1 if str(v.get("istest") or v.get("isTest") or "0").lower() in ("1", "true") else 0
    isim = f"{v.get('buyername') or ''} {v.get('buyersurname') or ''}".strip()[:120]
    db.execute("INSERT INTO siparis(orderid,eposta,ad,fiyat,urun,test,tarih) VALUES(?,?,?,?,?,?,?)",
               (orderid, eposta, isim, str(v.get("price") or "")[:20], str(v.get("productid") or "")[:60], test, int(time.time())))
    k = db.execute("SELECT id FROM kullanici WHERE eposta=? AND engelli=0", (eposta,)).fetchone()
    if k: pro_ver(db, k["id"], orderid)
    db.commit()
    yaz(200, "success")


def post_siparis_bagla(h, db):
    """Shopier'de başka e-posta kullanan üye: sipariş no + o e-posta ile siparişi kendi hesabına bağlar."""
    k = giris_sart(h, db); sinir(h, "siparis_bagla", 5, 600); v = h.govde()
    o = db.execute("SELECT * FROM siparis WHERE orderid=? AND eposta=?", (metin(v, "orderid", 1, 64), metin(v, "eposta", 3, 200).lower())).fetchone()
    if not o: raise Hata(404, "Bu sipariş numarası ve e-posta ile sipariş bulunamadı. Ödeme yeni yapıldıysa birkaç dakika bekle.")
    if o["kid"] and o["kid"] != k["id"]: raise Hata(409, "Bu sipariş başka bir hesaba bağlı")
    if not o["kid"]: pro_ver(db, k["id"], o["orderid"]); db.commit()
    h.cevap(200, {"tamam": True})


def post_yonetici_lisans_uret(h, db):
    yonetici_sart(h, db); v = h.govde()
    adet = max(1, min(200, int(v.get("adet") or 1))); urun = metin(v, "urun", 2, 40)
    l = []
    for _ in range(adet):
        a = anahtar_uret()
        db.execute("INSERT INTO lisans(anahtar,urun,olusturma,notu) VALUES(?,?,?,?)", (a, urun, int(time.time()), metin(v, "notu", 0, 200, False)))
        l.append(a)
    db.commit(); h.cevap(200, {"anahtarlar": l})


def post_yonetici_site_ayar(h, db):
    yonetici_sart(h, db); v = h.govde()
    for ad, uz in (("acilis", 20), ("youtube", 200), ("serit", 600), ("pro_link", 300), ("pro_fiyat", 30), ("osb_kullanici", 100), ("osb_anahtar", 200)):
        if ad not in v: continue
        if ad == "osb_anahtar" and not str(v[ad]).strip(): continue  # boş bırakılırsa eskisi kalsın
        d = str(v[ad]).strip()[:uz]
        if ad == "acilis" and d and not re.fullmatch(r"\d{4}-\d\d-\d\dT\d\d:\d\d", d): raise Hata(400, "Tarih biçimi: 2026-12-31T20:00")
        if ad in ("youtube", "pro_link") and d and not d.startswith("https://"): raise Hata(400, "Bağlantı https:// ile başlamalı")
        db.execute("INSERT INTO ayar VALUES(?,?) ON CONFLICT(ad) DO UPDATE SET deger=excluded.deger", (ad, d))
    db.commit(); h.cevap(200, {"tamam": True})


def get_yonetici_yedekler(h, db, q):
    import yedek
    yonetici_sart(h, db)
    h.cevap(200, {"yedekler": yedek.liste(), "sakla": yedek.SAKLA})


def post_yonetici_yedek_al(h, db):
    import yedek
    yonetici_sart(h, db); sinir(h, "yedek", 5, 600)
    h.cevap(200, {"ad": yedek.al(db)})


def get_yonetici_yedek_indir(h, db, q):
    import os, yedek
    yonetici_sart(h, db)
    ad = str(q.get("ad", ""))
    if not yedek.AD.fullmatch(ad): raise Hata(400, "Geçersiz yedek adı")
    yol = os.path.join(yedek.DIZIN, ad)
    if not os.path.exists(yol): raise Hata(404, "Yedek yok")
    with open(yol, "rb") as f: b = f.read()
    h.send_response(200); h.send_header("Content-Type", "application/gzip"); h.send_header("Content-Disposition", f'attachment; filename="{ad}"')
    h.send_header("Cache-Control", "no-store"); h.send_header("Content-Length", str(len(b))); h.end_headers(); h.wfile.write(b)


def get_yonetici_disa(h, db, q):
    """MIMO eğitim verisi (ince_ayar.py biçimi, JSONL) ya da bülten listesi (CSV) indir."""
    yonetici_sart(h, db)
    if q.get("ne") == "bulten":
        g = "eposta,tarih\n" + "".join(f"{r['eposta']},{datetime.datetime.fromtimestamp(r['tarih']).date()}\n" for r in db.execute("SELECT * FROM bulten ORDER BY tarih"))
        ad, tur = "bulten.csv", "text/csv; charset=utf-8"
    else:
        satir = []
        for r in db.execute("SELECT * FROM mimo_ders WHERE durum='onay'"):
            m = json.loads(r["mesajlar"])
            if r["duzeltme"]:
                m = m[:-1] + [{"role": "assistant", "content": r["duzeltme"]}] if m and m[-1]["role"] == "assistant" else m + [{"role": "assistant", "content": r["duzeltme"]}]
            elif r["puan"] < 0: continue  # düzeltmesiz kötü cevap ders olmaz
            satir.append(json.dumps({"mesajlar": [{"rol": "kullanici" if x["role"] == "user" else "mimo", "metin": x["content"]} for x in m]}, ensure_ascii=False))
        g = "\n".join(satir) + ("\n" if satir else "")
        ad, tur = "mimo_dersler_site.jsonl", "application/x-ndjson; charset=utf-8"
    b = g.encode()
    h.send_response(200); h.send_header("Content-Type", tur); h.send_header("Content-Disposition", f'attachment; filename="{ad}"')
    h.send_header("Cache-Control", "no-store"); h.send_header("Content-Length", str(len(b))); h.end_headers(); h.wfile.write(b)


# ---------------------------------------------------------------- yönlendirme
def calis(h, yontem, yol):
    try: return _calis(h, yontem, yol)
    except (TypeError, ValueError, KeyError, AttributeError) as e:
        if isinstance(e, Hata): raise
        raise Hata(400, "Bozuk istek")


def _calis(h, yontem, yol):
    db = h.server.db
    ad = yol.replace("/", "_").replace("-", "_")
    if yontem == "GET":
        f = globals().get("get_" + ad)
        if not f: raise Hata(404, "Bulunamadı")
        q = {a: b[0] for a, b in urllib.parse.parse_qs(urllib.parse.urlparse(h.path).query).items()}
        return f(h, db, q)
    f = globals().get("post_" + ad)
    if not f: raise Hata(404, "Bulunamadı")
    f(h, db)
