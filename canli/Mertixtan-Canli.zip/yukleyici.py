"""Mertixtan yükleyici: tek seferlik, şifreli bağlantılı yükleme sayfası.
Tabletten paketi (.zip) ya da modeli (.gguf) seç, "Kabul et ve yayınla"ya bas: sunucu canlıya alır, sonra kapanır."""
import http.server, os, secrets, shutil, signal, ssl, subprocess, sys, time, zipfile, socket, threading, urllib.request

PORT = int(os.environ.get("PORT", "8099"))
JETON = "".join(secrets.choice("abcdefghjkmnpqrstuvwxyz23456789") for _ in range(20))
PIDDOSYA = "/run/mertixtan-yukleyici.pid"
ALAN = os.environ.get("ALAN", "mertixtanstudios.com")
SERT = f"/etc/letsencrypt/live/{ALAN}"
SURE = 30 * 60  # kullanılmazsa 30 dakikada kendini kapatır
KLASOR = "/opt/mertixtan"
EN_COK = 2 * 1024 ** 3  # 2 GB

SAYFA = """<!doctype html><html lang=tr><meta charset=utf-8><meta name=viewport content="width=device-width,initial-scale=1">
<title>Mertixtan Yükleyici</title><style>body{font-family:system-ui,sans-serif;background:#0f172a;color:#e2e8f0;display:grid;place-items:center;min-height:100vh;margin:0;padding:16px}
.k{background:#1e293b;border-radius:20px;padding:28px;max-width:420px;width:100%}h1{margin:0 0 6px;font-size:22px}p{color:#94a3b8;font-size:14px}
input{width:100%;margin:16px 0;color:#e2e8f0}button{width:100%;padding:14px;border:0;border-radius:12px;background:linear-gradient(90deg,#10b981,#2563eb);color:#fff;font-weight:700;font-size:16px}
pre{white-space:pre-wrap;background:#020617;padding:12px;border-radius:10px;font-size:12px;max-height:50vh;overflow:auto}</style>
<div class=k><h1>Mertixtan Yükleyici</h1><p>Paketi (.zip) ya da MIMO modelini (.gguf) seç. Sunucu dosyayı alıp canlıya alacak.</p>
<form method=post enctype=multipart/form-data onsubmit="b.disabled=1;b.textContent='Yükleniyor ve kuruluyor… (sayfayı kapatma)'">
<input type=file name=dosya accept=".zip,.gguf" required><button id=b>Kabul et ve yayınla</button></form></div>"""


def ip():
    try: return urllib.request.urlopen("https://api.ipify.org", timeout=5).read().decode()
    except Exception:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM); s.connect(("10.255.255.255", 1)); return s.getsockname()[0]


class Yukleyici(http.server.BaseHTTPRequestHandler):
    def log_message(self, *a): pass

    def _izinli(self):
        if not secrets.compare_digest(self.path.strip("/").encode(), JETON.encode()):
            g = ("<meta charset=utf-8><meta name=viewport content='width=device-width,initial-scale=1'><body style='font-family:system-ui;background:#0f172a;color:#e2e8f0;padding:24px'>"
                 "<h2>Bu bağlantı geçersiz</h2><p>Eski ya da yanlış yazılmış bir yükleyici bağlantısı. Terminalde komutu çalıştırdıktan sonra <b>en son çıkan</b> bağlantıyı aç.</p>").encode()
            self.send_response(404); self.send_header("Content-Type", "text/html; charset=utf-8"); self.send_header("Content-Length", str(len(g))); self.end_headers(); self.wfile.write(g)
            return False
        return True

    def do_GET(self):
        if not self._izinli(): return
        self.send_response(200); self.send_header("Content-Type", "text/html; charset=utf-8"); self.end_headers()
        self.wfile.write(SAYFA.encode())

    def do_POST(self):
        if not self._izinli(): return
        try: n = int(self.headers.get("Content-Length", 0))
        except ValueError: n = -1
        tur = self.headers.get("Content-Type", "")
        if n <= 0 or n > EN_COK or "boundary=" not in tur:
            self.send_error(400, "Dosya yok ya da çok büyük"); return
        sinir = ("--" + tur.split("boundary=")[1].strip('"')).encode()
        govde = self.rfile.read(n)
        bas = govde.index(b"\r\n\r\n") + 4
        baslik = govde[:bas].decode("utf-8", "replace")
        ad = os.path.basename(baslik.split('filename="')[1].split('"')[0]) if 'filename="' in baslik else "dosya"
        veri = govde[bas:govde.index(sinir, bas) - 2]
        self.send_response(200); self.send_header("Content-Type", "text/html; charset=utf-8"); self.end_headers()
        yaz = lambda s: (self.wfile.write(s.encode()), self.wfile.flush())
        yaz("<meta charset=utf-8><meta name=viewport content='width=device-width,initial-scale=1'><body style='font-family:system-ui;background:#0f172a;color:#e2e8f0;padding:16px'><h2>Kuruluyor</h2><pre style='white-space:pre-wrap'>")
        yaz(f"{ad} alındı ({len(veri) / 1048576:.1f} MB)\n")
        try:
            os.makedirs(KLASOR, exist_ok=True); os.chmod(KLASOR, 0o755)  # hesap servisi /opt/mertixtan/hesap içinden okur; klasör kapanmamalı
            if ad.lower().endswith(".gguf"):
                os.makedirs("/opt/mimo", exist_ok=True)
                with open("/opt/mimo/mimo.gguf", "wb") as f: f.write(veri)
                with open("/opt/mimo/model_adi", "w") as f: f.write("ozel")  # kurulum bu modeli değiştirmesin
                try: shutil.chown("/opt/mimo/mimo.gguf", "mimo", "mimo")
                except (LookupError, OSError): pass
                r = subprocess.run(["systemctl", "restart", "mimo"], capture_output=True, text=True)
                yaz("Yeni MIMO modeli yüklendi ve yeniden başlatıldı.\n" if r.returncode == 0 else f"Model kaydedildi ama MIMO başlatılamadı: {r.stderr}\nÖnce paketi (.zip) yükle.\n")
            elif ad.lower().endswith(".zip"):
                hedef = os.path.join(KLASOR, "paket")
                shutil.rmtree(hedef, ignore_errors=True); os.makedirs(hedef, mode=0o700)
                zp = os.path.join(KLASOR, "son_paket.zip")
                with open(os.open(zp, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600), "wb") as f: f.write(veri)
                with zipfile.ZipFile(zp) as z:
                    for u in z.namelist():  # zip içinden klasör dışına yazma girişimlerini engelle
                        if u.startswith("/") or ".." in u.split("/"): raise ValueError("güvensiz dosya yolu: " + u)
                    z.extractall(hedef)
                kok = hedef
                if not os.path.exists(os.path.join(kok, "kur.sh")):
                    alt = [d for d in os.listdir(hedef) if os.path.exists(os.path.join(hedef, d, "kur.sh"))]
                    if not alt: raise ValueError("pakette kur.sh yok")
                    kok = os.path.join(hedef, alt[0])
                p = subprocess.Popen(["bash", os.path.join(kok, "kur.sh")], stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, cwd=kok)
                for satir in p.stdout: yaz(satir.replace("<", "&lt;"))
                yaz("\nBİTTİ ✔\n" if p.wait() == 0 else f"\nHATA (çıkış kodu {p.returncode}). Yukarıdaki son satırlara bak.\n")
            else:
                yaz("Sadece .zip ya da .gguf kabul edilir.\n")
        except Exception as e:
            yaz(f"HATA: {e}\n")
        yaz("</pre><p>Yükleyici kapandı. Tekrar yüklemek için komutu yeniden çalıştır.</p>")
        threading.Thread(target=self.server.shutdown, daemon=True).start()


if __name__ == "__main__":
    if os.geteuid() != 0: sys.exit("root olarak çalıştır (sudo).")
    ufw = shutil.which("ufw") and "Status: active" in subprocess.run(["ufw", "status"], capture_output=True, text=True).stdout
    if ufw: subprocess.run(["ufw", "allow", f"{PORT}/tcp"], capture_output=True)
    try:  # önceki çalıştırmadan kalan yükleyici varsa kapat
        eski = int(open(PIDDOSYA).read().strip())
        if eski != os.getpid(): os.kill(eski, signal.SIGTERM); time.sleep(1); print("  (açık kalan eski yükleyici kapatıldı)")
    except (OSError, ValueError): pass
    for deneme in range(10):
        try: s = http.server.ThreadingHTTPServer(("0.0.0.0", PORT), Yukleyici); break
        except OSError:
            if deneme == 0:
                subprocess.run(["fuser", "-k", f"{PORT}/tcp"], capture_output=True)  # pid dosyası olmayan eski sürüm
            time.sleep(1)
    else: sys.exit(f"{PORT} portu başka bir program tarafından kullanılıyor. Şunu çalıştırıp tekrar dene: sudo fuser -k {PORT}/tcp")
    with open(PIDDOSYA, "w") as f: f.write(str(os.getpid()))
    if os.path.exists(SERT + "/fullchain.pem"):  # alan adının sertifikası varsa bağlantı şifreli olsun
        b = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER); b.minimum_version = ssl.TLSVersion.TLSv1_2
        b.load_cert_chain(SERT + "/fullchain.pem", SERT + "/privkey.pem")
        s.socket = b.wrap_socket(s.socket, server_side=True, do_handshake_on_connect=False)  # el sıkışma iş parçacığında olsun
        adres = f"https://{ALAN}:{PORT}/{JETON}"
    else:
        adres = f"http://{ip()}:{PORT}/{JETON}"
    zaman = threading.Timer(SURE, s.shutdown); zaman.daemon = True; zaman.start()
    import base64
    kopya = "\033]52;c;" + base64.b64encode(adres.encode()).decode() + "\a"   # terminal destekliyorsa panoya kopyalar (OSC 52)
    bag = f"\033]8;;{adres}\033\\{adres}\033]8;;\033\\"                   # dokunulabilir bağlantı (OSC 8)
    print(f"{kopya}\n  Tabletinde bu bağlantıyı aç (dokun ya da panodan yapıştır):\n\n    {bag}\n\n"
          f"  (Dosyayı yükleyince ya da 30 dakika kullanılmazsa kendiliğinden kapanır. İptal: Ctrl+C)\n", flush=True)
    try: s.serve_forever()
    except KeyboardInterrupt: pass
    try: os.remove(PIDDOSYA)
    except OSError: pass
    if ufw: subprocess.run(["ufw", "delete", "allow", f"{PORT}/tcp"], capture_output=True)
