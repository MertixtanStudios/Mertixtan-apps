# MIMO-Sıfır · Mertixtan Studios

ChatGPT'nin tarifiyle, sıfırdan eğitilen Türkçe yapay zekâ:
1. **Transformer** (2017): `mimo/model.py`, sıfırdan yazıldı (RMSNorm, RoPE, SwiGLU).
2. **Ön eğitim** (GPT-1, 2018): Türkçe Vikipedi ile; `mimo/veri.py` ve `mimo/on_egitim.py`.
3. **Sohbet ince ayarı** (ChatGPT, 2022): MIMO kimliği ve sohbet; `mimo/ince_ayar.py` ve `mimo/dersler_uret.py`.
4. **GGUF**: sunucuda llama.cpp ile çalışır; `mimo/gguf_yap.py`.

Boyut: **130 milyon parametre** (GPT-1 ve H01 boyutunda).

---

## ADIM A · Eğitim (Kaggle, bedava ekran kartı)
1. kaggle.com'da hesap aç. **Telefon doğrulaması yap**; ekran kartı ve internet için gerekli.
2. **Create → New Notebook → File → Import Notebook** → `MIMO_Sifir_Kaggle.ipynb` dosyasını yükle.
3. Sağ panelde: **Accelerator: GPU T4 x2**, **Internet: On**.
4. Sağ üstte **Save Version → Save & Run All (Commit)**. Tarayıcıyı kapatabilirsin; Kaggle arka planda çalışır (en çok 12 saat).
5. Bitince sürümün **Output** sekmesinden `mimo.gguf` dosyasını indir.
   - Son satırda "DEVAM EDECEK" yazıyorsa: **Add Input → Your Work** ile bu sürümün çıktısını ekleyip tekrar **Save & Run All** yap. Kaldığı yerden sürer.
   - Kaggle haftada yaklaşık 30 saat bedava ekran kartı verir. 130M'nin tamamı muhtemelen 2 oturum sürer.
   - Çok yavaş giderse defterdeki `BOYUT = "30M"` yap: birkaç saatte biter, daha az akıllı olur.

## ADIM B · Sunucu (8 GB)
1. `mimo.gguf` ve `sunucu/mimo-kur.sh` dosyalarını sunucuya yükle (Termius'ta SFTP ile ya da `scp`).
2. Çalıştır:
   ```
   bash mimo-kur.sh /root/mimo.gguf
   ```
3. Ekrana çıkan **MIMO_AI_URL** ve **MIMO_AI_KEY** değerlerini not al.

> Eğitim bitmeden kurulumu denemek istersen `sunucu/deneme_mimo.gguf` ile kur. Bu sadece boru hattı testi:
> minicik bir model, sadece ders cümlelerini ezberledi. Gerçek MIMO Kaggle'dan çıkan dosya.

## ADIM C · Site (Vercel)
1. `sunucu/chat.js` → projende `api/chat.js`; `sunucu/vercel.json` → projende `vercel.json`.
2. Vercel → Settings → Environment Variables: `MIMO_AI_URL`, `MIMO_AI_KEY`, `MIMO_AI_MODEL`.
3. Yeniden yayınla.

---

## Dürüst beklenti
- 130M parametre GPT-1 / küçük GPT-2 seviyesi. Akıcı Türkçe yazar, derslerdeki konularda iyidir.
- ChatGPT gibi akıl yürütemez; uydurabilir, hesap yaparken hata yapabilir.
- Daha akıllı olması için: daha çok veri, daha uzun eğitim, daha büyük boyut ve daha çok sohbet dersi.
- Model sıfırdan eğitildi. Ağırlıkların hepsi senin eğitiminden geliyor; başkasının modeli kullanılmadı.
- Vikipedi metinleri CC BY-SA lisanslıdır. Modeli dağıtırken "Türkçe Vikipedi ile eğitildi" diye kaynak belirt.

## Buradaki test (Claude yaptı)
- Bütün zincir minicik bir modelle baştan sona çalıştırıldı: veri → kelime ayırıcı → ön eğitim → ince ayar → GGUF.
- Ortaya çıkan GGUF gerçek **llama.cpp llama-server**'da açıldı, sohbet cevabı verdi ve doğru yerde durdu.
- 130M'lik gerçek eğitim burada yapılmadı; ekran kartı yok. Kaggle'da yapılacak.
