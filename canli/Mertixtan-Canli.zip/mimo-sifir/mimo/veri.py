"""Veri: Türkçe Vikipedi'yi indir, temizle; Türkçe kelime ayırıcı (SentencePiece) eğit; metni sayılara çevir."""
import bz2, os, re, sys, time, urllib.request
import xml.etree.ElementTree as ET
import numpy as np

VIKIPEDI = "https://dumps.wikimedia.org/trwiki/latest/trwiki-latest-pages-articles.xml.bz2"
AYIRAC = "\x1e"  # makaleler arası
OZEL = ["<|sistem|>", "<|kullanici|>", "<|mimo|>", "<|son|>"]  # sohbet işaretleri (kimlikleri 4, 5, 6, 7)


def indir(url, hedef):
    if os.path.exists(hedef) and os.path.getsize(hedef) > 0:
        print("zaten var:", hedef); return hedef
    print("indiriliyor:", url)
    gecici = hedef + ".iniyor"
    with urllib.request.urlopen(urllib.request.Request(url, headers={"User-Agent": "mimo-sifir/1.0"})) as r, open(gecici, "wb") as f:
        toplam = int(r.headers.get("Content-Length", 0)); n = 0; son = time.time()
        while True:
            b = r.read(1 << 20)
            if not b: break
            f.write(b); n += len(b)
            if time.time() - son > 10: print(f"  {n >> 20} / {toplam >> 20} MB", flush=True); son = time.time()
    os.replace(gecici, hedef)
    return hedef


# ------------------------------------------------------------------ vikitekst temizliği
_ic_ice = [re.compile(r"\{\{[^{}]*\}\}"), re.compile(r"\{\|[^{}]*?\|\}", re.S)]
_kurallar = [
    (re.compile(r"<ref[^>/]*/>"), ""), (re.compile(r"<ref.*?</ref>", re.S), ""), (re.compile(r"<!--.*?-->", re.S), ""),
    (re.compile(r"<[^>]+>"), ""),
    (re.compile(r"\[\[(?:Dosya|Resim|File|Image|Kategori|Category)[^\[\]]*(?:\[\[[^\]]*\]\][^\[\]]*)*\]\]", re.I), ""),
    (re.compile(r"\[\[[^\]|]*\|([^\]]*)\]\]"), r"\1"), (re.compile(r"\[\[([^\]]*)\]\]"), r"\1"),
    (re.compile(r"\[https?://[^\s\]]+ ([^\]]*)\]"), r"\1"), (re.compile(r"\[https?://[^\]]*\]"), ""),
    (re.compile(r"'{2,}"), ""), (re.compile(r"^=+\s*(.*?)\s*=+\s*$", re.M), r"\1"),
    (re.compile(r"^[*#:;]+\s*", re.M), ""), (re.compile(r"&nbsp;"), " "), (re.compile(r"[ \t]+"), " "),
    (re.compile(r"\n{3,}"), "\n\n"),
]

def temizle(t):
    for _ in range(4):
        for r in _ic_ice: t = r.sub("", t)
    for r, y in _kurallar: t = r.sub(y, t)
    satirlar = [s.strip() for s in t.split("\n")]
    # kısa, işe yaramaz satırları (liste artığı, "Kaynakça" vb.) at
    satirlar = [s for s in satirlar if not s or (len(s) > 30 and not s.startswith(("{", "|", "!")))]
    return "\n".join(satirlar).strip()


def vikipedi_metin(bz2_yol, cikti, en_cok_makale=None):
    """Makaleleri temiz metne çevir (yönlendirmeler ve kısa sayfalar atlanır)"""
    if os.path.exists(cikti) and os.path.getsize(cikti) > 0:
        print("zaten var:", cikti); return cikti
    n = 0; bayt = 0
    with bz2.open(bz2_yol, "rb") as f, open(cikti + ".tmp", "w", encoding="utf-8") as o:
        for olay, el in ET.iterparse(f, events=("end",)):
            if not el.tag.endswith("}page"): continue
            ns = el.find("{*}ns"); metin = el.find(".//{*}text")
            if ns is not None and ns.text == "0" and metin is not None and metin.text and not metin.text.lstrip().upper().startswith(("#YÖNLENDİR", "#REDIRECT")):
                baslik = el.find("{*}title").text or ""
                t = temizle(metin.text)
                if len(t) > 400:
                    o.write(baslik + "\n" + t + "\n" + AYIRAC + "\n"); n += 1; bayt += len(t)
                    if n % 20000 == 0: print(f"  {n} makale, {bayt >> 20} MB metin", flush=True)
                    if en_cok_makale and n >= en_cok_makale: break
            el.clear()
    os.replace(cikti + ".tmp", cikti)
    print(f"bitti: {n} makale, {bayt >> 20} MB")
    return cikti


# ------------------------------------------------------------------ kelime ayırıcı
def sozluk_egit(metin_yolu, onek, boyut=32000, ornek_cumle=3_000_000):
    import sentencepiece as spm
    if os.path.exists(onek + ".model"):
        print("zaten var:", onek + ".model"); return onek + ".model"
    spm.SentencePieceTrainer.train(
        input=metin_yolu, model_prefix=onek, vocab_size=boyut, model_type="bpe",
        character_coverage=0.99995, byte_fallback=True, split_digits=True, allow_whitespace_only_pieces=True,
        normalization_rule_name="identity", remove_extra_whitespaces=False, add_dummy_prefix=False,
        input_sentence_size=ornek_cumle, shuffle_input_sentence=True, max_sentence_length=8192,
        unk_id=0, bos_id=1, eos_id=2, pad_id=3, control_symbols=OZEL, num_threads=os.cpu_count(),
        minloglevel=2)
    return onek + ".model"


def kodla(metin_yolu, model_yolu, cikti):
    """Metni uint16 sayı dizisine çevir; makaleler arasına </s> (2) koy"""
    import sentencepiece as spm
    if os.path.exists(cikti):
        print("zaten var:", cikti); return cikti
    sp = spm.SentencePieceProcessor(model_file=model_yolu)
    assert sp.get_piece_size() < 65536
    parcalar, toplam, tampon = [], 0, []
    with open(metin_yolu, encoding="utf-8") as f, open(cikti + ".tmp", "wb") as o:
        makale = []
        def yaz(belgeler):
            nonlocal toplam
            for ids in sp.encode(belgeler):
                a = np.array(ids + [2], dtype=np.uint16); a.tofile(o); toplam += len(a)
        for satir in f:
            if satir.startswith(AYIRAC):
                tampon.append("".join(makale).strip()); makale = []
                if len(tampon) >= 2000: yaz(tampon); tampon = []; print(f"  {toplam / 1e6:.0f}M parça", flush=True)
            else: makale.append(satir)
        if makale: tampon.append("".join(makale).strip())
        if tampon: yaz(tampon)
    os.replace(cikti + ".tmp", cikti)
    print(f"toplam {toplam / 1e6:.1f} milyon parça")
    return cikti


if __name__ == "__main__":
    # python veri.py <klasor> [en_cok_makale]
    k = sys.argv[1]; os.makedirs(k, exist_ok=True)
    m = int(sys.argv[2]) if len(sys.argv) > 2 else None
    b = indir(VIKIPEDI, os.path.join(k, "trwiki.xml.bz2"))
    t = vikipedi_metin(b, os.path.join(k, "trwiki.txt"), m)
    s = sozluk_egit(t, os.path.join(k, "mimo_sozluk"))
    kodla(t, s, os.path.join(k, "egitim.bin"))
