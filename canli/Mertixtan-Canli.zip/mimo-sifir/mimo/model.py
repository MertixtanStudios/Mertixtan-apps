"""MIMO-Sıfır: sıfırdan yazılmış Transformer dil modeli (Mertixtan Studios).

2017'deki "Attention Is All You Need" Transformer'ının bugünkü hâli (Llama tarzı):
- RMSNorm (katman normu), RoPE (dönen konum kodlaması), SwiGLU (ileri besleme), nedensel dikkat.
- Ağırlık düzeni llama.cpp'nin GGUF biçimiyle birebir aynı: eğitilen model doğrudan llama-server'da çalışır.
"""
import math
from dataclasses import dataclass, asdict

import torch
import torch.nn as nn
import torch.nn.functional as F


@dataclass
class Ayar:
    sozluk: int = 32000        # kelime parçası sayısı
    boyut: int = 768           # gizli boyut
    katman: int = 12
    bas: int = 12              # dikkat başı
    kv_bas: int = 12
    ileri: int = 2048          # SwiGLU ara boyutu
    baglam: int = 1024         # en uzun metin (parça)
    eps: float = 1e-5
    rope_teta: float = 10000.0

    def sozluk_(self): return asdict(self)

    @staticmethod
    def boyuttan(ad: str) -> "Ayar":
        """Hazır boyutlar: 30M (deneme), 130M (GPT-1 / H01 boyutu)"""
        if ad == "minik":  return Ayar(sozluk=2000, boyut=64, katman=2, bas=4, kv_bas=4, ileri=128, baglam=128)
        if ad == "30M":    return Ayar(sozluk=32000, boyut=384, katman=6, bas=6, kv_bas=6, ileri=1024, baglam=512)
        if ad == "130M":   return Ayar()
        raise ValueError(ad)


class RMSNorm(nn.Module):
    def __init__(self, n, eps):
        super().__init__()
        self.eps = eps
        self.weight = nn.Parameter(torch.ones(n))

    def forward(self, x):
        x32 = x.float()
        return (x32 * torch.rsqrt(x32.pow(2).mean(-1, keepdim=True) + self.eps)).type_as(x) * self.weight


def rope_frekans(bas_boyut, uzunluk, teta):
    f = 1.0 / (teta ** (torch.arange(0, bas_boyut, 2).float() / bas_boyut))
    t = torch.arange(uzunluk).float()
    return torch.polar(torch.ones(uzunluk, bas_boyut // 2), torch.outer(t, f))  # karmaşık sayılar


def rope_uygula(x, f):
    # bitişik çiftler (orijinal LLaMA / llama.cpp "normal" düzeni): ağırlıklar GGUF'a olduğu gibi yazılır
    xc = torch.view_as_complex(x.float().reshape(*x.shape[:-1], -1, 2))
    return torch.view_as_real(xc * f[None, :, None, :]).flatten(3).type_as(x)


class Dikkat(nn.Module):
    def __init__(self, a: Ayar):
        super().__init__()
        self.bas, self.kv_bas, self.hd = a.bas, a.kv_bas, a.boyut // a.bas
        self.wq = nn.Linear(a.boyut, a.bas * self.hd, bias=False)
        self.wk = nn.Linear(a.boyut, a.kv_bas * self.hd, bias=False)
        self.wv = nn.Linear(a.boyut, a.kv_bas * self.hd, bias=False)
        self.wo = nn.Linear(a.bas * self.hd, a.boyut, bias=False)

    def forward(self, x, f):
        B, T, _ = x.shape
        q = rope_uygula(self.wq(x).view(B, T, self.bas, self.hd), f)
        k = rope_uygula(self.wk(x).view(B, T, self.kv_bas, self.hd), f)
        v = self.wv(x).view(B, T, self.kv_bas, self.hd)
        q, k, v = q.transpose(1, 2), k.transpose(1, 2), v.transpose(1, 2)
        if self.kv_bas != self.bas:
            k = k.repeat_interleave(self.bas // self.kv_bas, dim=1)
            v = v.repeat_interleave(self.bas // self.kv_bas, dim=1)
        y = F.scaled_dot_product_attention(q, k, v, is_causal=True)
        return self.wo(y.transpose(1, 2).reshape(B, T, -1))


class IleriBesleme(nn.Module):
    def __init__(self, a: Ayar):
        super().__init__()
        self.w1 = nn.Linear(a.boyut, a.ileri, bias=False)   # kapı
        self.w3 = nn.Linear(a.boyut, a.ileri, bias=False)   # yukarı
        self.w2 = nn.Linear(a.ileri, a.boyut, bias=False)   # aşağı

    def forward(self, x):
        return self.w2(F.silu(self.w1(x)) * self.w3(x))


class Blok(nn.Module):
    def __init__(self, a: Ayar):
        super().__init__()
        self.attention_norm = RMSNorm(a.boyut, a.eps)
        self.attention = Dikkat(a)
        self.ffn_norm = RMSNorm(a.boyut, a.eps)
        self.feed_forward = IleriBesleme(a)

    def forward(self, x, f):
        x = x + self.attention(self.attention_norm(x), f)
        return x + self.feed_forward(self.ffn_norm(x))


class Mimo(nn.Module):
    def __init__(self, a: Ayar):
        super().__init__()
        self.ayar = a
        self.tok_embeddings = nn.Embedding(a.sozluk, a.boyut)
        self.layers = nn.ModuleList(Blok(a) for _ in range(a.katman))
        self.norm = RMSNorm(a.boyut, a.eps)
        self.output = nn.Linear(a.boyut, a.sozluk, bias=False)
        self.register_buffer("frekans", rope_frekans(a.boyut // a.bas, a.baglam, a.rope_teta), persistent=False)
        self.apply(self._baslat)
        # GPT-2 tarzı: artık bağlantılara giden katmanlar daha küçük başlar
        for ad, p in self.named_parameters():
            if ad.endswith("wo.weight") or ad.endswith("w2.weight"):
                nn.init.normal_(p, 0.0, 0.02 / math.sqrt(2 * a.katman))

    @staticmethod
    def _baslat(m):
        if isinstance(m, nn.Linear): nn.init.normal_(m.weight, 0.0, 0.02)
        elif isinstance(m, nn.Embedding): nn.init.normal_(m.weight, 0.0, 0.02)

    def parametre_sayisi(self): return sum(p.numel() for p in self.parameters())

    def forward(self, idx, hedef=None, maske=None):
        T = idx.shape[1]
        x = self.tok_embeddings(idx)
        f = self.frekans[:T]
        for b in self.layers: x = b(x, f)
        logit = self.output(self.norm(x))
        if hedef is None: return logit, None
        kayip = F.cross_entropy(logit.float().view(-1, logit.size(-1)), hedef.view(-1), reduction="none").view_as(hedef)
        if maske is not None: kayip = (kayip * maske).sum() / maske.sum().clamp(min=1)
        else: kayip = kayip.mean()
        return logit, kayip

    @torch.no_grad()
    def uret(self, idx, n, sicaklik=0.8, top_k=40, dur=None):
        for _ in range(n):
            x = idx[:, -self.ayar.baglam:]
            logit, _ = self(x)
            l = logit[:, -1, :] / max(sicaklik, 1e-5)
            if top_k: l[l < torch.topk(l, top_k).values[:, [-1]]] = -float("inf")
            yeni = torch.multinomial(F.softmax(l, -1), 1)
            idx = torch.cat([idx, yeni], 1)
            if dur is not None and yeni.item() == dur: break
        return idx
