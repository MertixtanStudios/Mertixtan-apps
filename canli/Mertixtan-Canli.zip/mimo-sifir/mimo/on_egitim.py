"""Ön eğitim (GPT-1 adımı): model Türkçe metinde bir sonraki parçayı tahmin etmeyi öğrenir.
Kaldığı yerden devam eder: kontrol noktası <cikti>/on_egitim.pt

python on_egitim.py --veri egitim.bin --cikti ciktilar --boyut 130M --saat 9
"""
import argparse, math, os, time
import numpy as np
import torch
from model import Ayar, Mimo


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--veri", required=True)
    p.add_argument("--cikti", required=True)
    p.add_argument("--boyut", default="130M")
    p.add_argument("--sozluk", help="SentencePiece .model (sözlük boyutu buradan alınır)")
    p.add_argument("--saat", type=float, default=9.0, help="bu oturumda en çok kaç saat eğitilsin")
    p.add_argument("--tur", type=float, default=2.0, help="veri üzerinden toplam kaç tur (öğrenme hızı planı buna göre)")
    p.add_argument("--toplu", type=int, default=8)
    p.add_argument("--birikim", type=int, default=16)
    p.add_argument("--lr", type=float, default=6e-4)
    a = p.parse_args()
    os.makedirs(a.cikti, exist_ok=True)
    cihaz = "cuda" if torch.cuda.is_available() else "cpu"
    torch.manual_seed(1337)

    veri = np.memmap(a.veri, dtype=np.uint16, mode="r")
    n = len(veri); bolme = int(n * 0.995)
    ayar = Ayar.boyuttan(a.boyut)
    if a.sozluk:
        import sentencepiece as spm
        ayar.sozluk = spm.SentencePieceProcessor(model_file=a.sozluk).get_piece_size()
    T = ayar.baglam
    parca_adim = a.toplu * a.birikim * T
    toplam_adim = max(10, int(bolme * a.tur / parca_adim))
    isinma = min(1000, toplam_adim // 20)

    model = Mimo(ayar).to(cihaz)
    print(f"model: {model.parametre_sayisi() / 1e6:.1f}M parametre · veri: {n / 1e6:.1f}M parça · plan: {toplam_adim} adım", flush=True)
    karar = [p_ for p_ in model.parameters() if p_.dim() >= 2]
    duz = [p_ for p_ in model.parameters() if p_.dim() < 2]
    opt = torch.optim.AdamW([{"params": karar, "weight_decay": 0.1}, {"params": duz, "weight_decay": 0.0}],
                            lr=a.lr, betas=(0.9, 0.95), fused=cihaz == "cuda")
    bf16 = cihaz == "cuda" and torch.cuda.is_bf16_supported()
    tur = torch.bfloat16 if bf16 else torch.float16
    olcek = torch.amp.GradScaler(enabled=cihaz == "cuda" and not bf16)

    kayit = os.path.join(a.cikti, "on_egitim.pt")
    adim = 0
    if os.path.exists(kayit):
        k = torch.load(kayit, map_location=cihaz)
        model.load_state_dict(k["model"]); opt.load_state_dict(k["opt"]); adim = k["adim"]
        print(f"kaldığı yerden devam: adım {adim}", flush=True)

    def grup(bol):
        ust = bolme if bol == "egitim" else n
        alt = 0 if bol == "egitim" else bolme
        i = np.random.randint(alt, ust - T - 1, a.toplu)
        x = torch.from_numpy(np.stack([veri[j:j + T].astype(np.int64) for j in i]))
        y = torch.from_numpy(np.stack([veri[j + 1:j + T + 1].astype(np.int64) for j in i]))
        return x.to(cihaz, non_blocking=True), y.to(cihaz, non_blocking=True)

    def hiz(s):
        if s < isinma: return a.lr * (s + 1) / isinma
        r = min(1.0, (s - isinma) / max(1, toplam_adim - isinma))
        return a.lr * 0.1 + 0.5 * (a.lr - a.lr * 0.1) * (1 + math.cos(math.pi * r))

    @torch.no_grad()
    def dogrula():
        model.eval(); t = 0
        for _ in range(20):
            x, y = grup("dogrulama")
            with torch.autocast(cihaz, dtype=tur, enabled=cihaz == "cuda"): _, l = model(x, y)
            t += l.item()
        model.train(); return t / 20

    def kaydet():
        torch.save({"model": model.state_dict(), "opt": opt.state_dict(), "adim": adim, "ayar": ayar.sozluk_()}, kayit + ".tmp")
        os.replace(kayit + ".tmp", kayit)

    bas = time.time(); son_kayit = bas; son_rapor = bas; ilk_adim = adim
    model.train()
    while adim < toplam_adim and time.time() - bas < a.saat * 3600:
        for g in opt.param_groups: g["lr"] = hiz(adim)
        for _ in range(a.birikim):
            x, y = grup("egitim")
            with torch.autocast(cihaz, dtype=tur, enabled=cihaz == "cuda"):
                _, kayip = model(x, y)
            olcek.scale(kayip / a.birikim).backward()
        olcek.unscale_(opt)
        torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
        olcek.step(opt); olcek.update(); opt.zero_grad(set_to_none=True)
        adim += 1
        if time.time() - son_rapor > 60 or adim == 1:
            gecen = time.time() - bas
            print(f"adım {adim}/{toplam_adim} · kayıp {kayip.item():.3f} · {parca_adim * (adim - ilk_adim) / max(gecen, 1) / 1e3:.1f}k parça/sn · {gecen / 3600:.2f} saat", flush=True)
            son_rapor = time.time()
        if time.time() - son_kayit > 15 * 60:
            kaydet(); son_kayit = time.time()
            print(f"  kaydedildi · doğrulama kaybı {dogrula():.3f}", flush=True)
    kaydet()
    print(f"oturum bitti: adım {adim}/{toplam_adim} · doğrulama kaybı {dogrula():.3f}", flush=True)
    print("TAMAMLANDI" if adim >= toplam_adim else "DEVAM EDECEK: bir sonraki oturumda aynı komut kaldığı yerden sürer", flush=True)


if __name__ == "__main__":
    main()
