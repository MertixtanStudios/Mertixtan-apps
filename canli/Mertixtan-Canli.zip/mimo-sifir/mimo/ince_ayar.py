"""Sohbet ince ayarı (ChatGPT adımı): ön eğitimli modele MIMO olarak sohbet etmeyi öğretir.
Kayıp yalnızca MIMO'nun cevaplarından hesaplanır; kullanıcının yazdıklarını taklit etmeyi öğrenmez.

python ince_ayar.py --on-egitim ciktilar/on_egitim.pt --sozluk mimo_sozluk.model --dersler mimo_dersler.jsonl --cikti ciktilar
"""
import argparse, json, math, os, random, time
import torch
import sentencepiece as spm
from model import Ayar, Mimo

SISTEM, KULLANICI, MIMO_, SON = 4, 5, 6, 7  # veri.py OZEL sırası
ROL = {"sistem": SISTEM, "kullanici": KULLANICI, "mimo": MIMO_}


def konusma_kodla(sp, k, baglam):
    """Sohbet şablonuyla birebir aynı: <|rol|>\\n metin<|son|>\\n ..."""
    ids, maske = [1], [0]
    nl = sp.encode("\n")
    for m in k["mesajlar"]:
        bas = [ROL[m["rol"]]] + nl
        govde = sp.encode(m["metin"].strip()) + [SON] + nl
        ids += bas + govde
        ogren = 1 if m["rol"] == "mimo" else 0
        maske += [0] * len(bas) + [ogren] * len(govde)
    return ids[:baglam + 1], maske[:baglam + 1]


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--on-egitim", required=True)
    p.add_argument("--sozluk", required=True)
    p.add_argument("--dersler", required=True)
    p.add_argument("--cikti", required=True)
    p.add_argument("--tur", type=int, default=4)
    p.add_argument("--lr", type=float, default=1e-4)
    p.add_argument("--toplu", type=int, default=16)
    a = p.parse_args()
    cihaz = "cuda" if torch.cuda.is_available() else "cpu"
    sp = spm.SentencePieceProcessor(model_file=a.sozluk)
    k = torch.load(a.on_egitim, map_location=cihaz)
    ayar = Ayar(**k["ayar"])
    model = Mimo(ayar).to(cihaz)
    model.load_state_dict(k["model"])
    konusmalar = [json.loads(s) for s in open(a.dersler, encoding="utf-8") if s.strip()]
    ornekler = [konusma_kodla(sp, c, ayar.baglam) for c in konusmalar]
    print(f"{len(ornekler)} sohbet, en uzun {max(len(i) for i, _ in ornekler)} parça", flush=True)
    opt = torch.optim.AdamW(model.parameters(), lr=a.lr, weight_decay=0.0, betas=(0.9, 0.95))
    bf16 = cihaz == "cuda" and torch.cuda.is_bf16_supported()
    tur = torch.bfloat16 if bf16 else torch.float16
    olcek = torch.amp.GradScaler(enabled=cihaz == "cuda" and not bf16)
    toplam = a.tur * math.ceil(len(ornekler) / a.toplu); adim = 0
    model.train()
    for t in range(a.tur):
        random.shuffle(ornekler)
        for i in range(0, len(ornekler), a.toplu):
            grup = ornekler[i:i + a.toplu]
            L = max(len(x) for x, _ in grup)
            x = torch.zeros(len(grup), L - 1, dtype=torch.long); y = torch.zeros_like(x); m = torch.zeros(len(grup), L - 1)
            for j, (ids, mk) in enumerate(grup):
                n = len(ids) - 1
                x[j, :n] = torch.tensor(ids[:-1]); y[j, :n] = torch.tensor(ids[1:]); m[j, :n] = torch.tensor(mk[1:], dtype=torch.float)
            x, y, m = x.to(cihaz), y.to(cihaz), m.to(cihaz)
            for g in opt.param_groups: g["lr"] = a.lr * 0.5 * (1 + math.cos(math.pi * adim / toplam))
            with torch.autocast(cihaz, dtype=tur, enabled=cihaz == "cuda"):
                _, kayip = model(x, y, m)
            olcek.scale(kayip).backward(); olcek.unscale_(opt)
            torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            olcek.step(opt); olcek.update(); opt.zero_grad(set_to_none=True); adim += 1
        print(f"tur {t + 1}/{a.tur} · kayıp {kayip.item():.3f}", flush=True)
    yol = os.path.join(a.cikti, "mimo_sohbet.pt")
    torch.save({"model": model.state_dict(), "ayar": ayar.sozluk_()}, yol)
    print("kaydedildi:", yol)
    # birkaç deneme
    model.eval()
    for soru in ["Merhaba!", "Sen kimsin?", "Türkiye'nin başkenti neresi?"]:
        ids, _ = konusma_kodla(sp, {"mesajlar": [{"rol": "kullanici", "metin": soru}]}, ayar.baglam)
        ids = ids + [MIMO_] + sp.encode("\n")
        out = model.uret(torch.tensor([ids], device=cihaz), 80, sicaklik=0.7, dur=SON)[0].tolist()[len(ids):]
        print(f"  S: {soru}\n  MIMO: {sp.decode([i for i in out if i != SON])}", flush=True)


if __name__ == "__main__":
    main()
