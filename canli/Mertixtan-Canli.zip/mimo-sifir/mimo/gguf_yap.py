"""Eğitilen MIMO'yu llama.cpp'nin çalıştırdığı GGUF dosyasına yazar (sunucuda llama-server ile çalışır).

python gguf_yap.py --model ciktilar/mimo_sohbet.pt --sozluk mimo_sozluk.model --cikti mimo.gguf
"""
import argparse
import numpy as np
import torch
import sentencepiece as spm
import gguf
from model import Ayar

SABLON = ("{% for m in messages %}"
          "{% if m['role'] == 'system' %}<|sistem|>\n{{ m['content'] }}<|son|>\n"
          "{% elif m['role'] == 'user' %}<|kullanici|>\n{{ m['content'] }}<|son|>\n"
          "{% else %}<|mimo|>\n{{ m['content'] }}<|son|>\n{% endif %}"
          "{% endfor %}{% if add_generation_prompt %}<|mimo|>\n{% endif %}")


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--model", required=True)
    p.add_argument("--sozluk", required=True)
    p.add_argument("--cikti", required=True)
    p.add_argument("--ad", default="MIMO-Sifir")
    a = p.parse_args()
    k = torch.load(a.model, map_location="cpu")
    ay = Ayar(**k["ayar"]); sd = k["model"]
    sp = spm.SentencePieceProcessor(model_file=a.sozluk)
    w = gguf.GGUFWriter(a.cikti, "llama")
    w.add_name(a.ad)
    w.add_context_length(ay.baglam)
    w.add_embedding_length(ay.boyut)
    w.add_block_count(ay.katman)
    w.add_feed_forward_length(ay.ileri)
    w.add_head_count(ay.bas)
    w.add_head_count_kv(ay.kv_bas)
    w.add_rope_dimension_count(ay.boyut // ay.bas)
    w.add_layer_norm_rms_eps(ay.eps)
    w.add_rope_freq_base(ay.rope_teta)
    w.add_vocab_size(ay.sozluk)
    w.add_file_type(gguf.LlamaFileType.MOSTLY_F16)
    # kelime ayırıcı (SentencePiece)
    parcalar, puanlar, turler = [], [], []
    for i in range(sp.get_piece_size()):
        parcalar.append(sp.id_to_piece(i).encode("utf-8")); puanlar.append(sp.get_score(i))
        if sp.is_unknown(i): t = gguf.TokenType.UNKNOWN
        elif sp.is_control(i): t = gguf.TokenType.CONTROL
        elif sp.is_unused(i): t = gguf.TokenType.UNUSED
        elif sp.is_byte(i): t = gguf.TokenType.BYTE
        else: t = gguf.TokenType.NORMAL
        turler.append(t)
    w.add_tokenizer_model("llama")
    w.add_token_list(parcalar); w.add_token_scores(puanlar); w.add_token_types(turler)
    w.add_bos_token_id(1); w.add_eos_token_id(7); w.add_eot_token_id(7); w.add_unk_token_id(0); w.add_pad_token_id(3)
    w.add_add_bos_token(True); w.add_add_eos_token(False); w.add_add_space_prefix(False)
    w.add_chat_template(SABLON)
    # ağırlıklar: model düzeni llama.cpp ile aynı (permütasyon gerekmez)
    f16 = lambda t: t.detach().float().numpy().astype(np.float16)
    f32 = lambda t: t.detach().float().numpy().astype(np.float32)
    w.add_tensor("token_embd.weight", f16(sd["tok_embeddings.weight"]))
    for i in range(ay.katman):
        o = f"layers.{i}."
        w.add_tensor(f"blk.{i}.attn_norm.weight", f32(sd[o + "attention_norm.weight"]))
        w.add_tensor(f"blk.{i}.attn_q.weight", f16(sd[o + "attention.wq.weight"]))
        w.add_tensor(f"blk.{i}.attn_k.weight", f16(sd[o + "attention.wk.weight"]))
        w.add_tensor(f"blk.{i}.attn_v.weight", f16(sd[o + "attention.wv.weight"]))
        w.add_tensor(f"blk.{i}.attn_output.weight", f16(sd[o + "attention.wo.weight"]))
        w.add_tensor(f"blk.{i}.ffn_norm.weight", f32(sd[o + "ffn_norm.weight"]))
        w.add_tensor(f"blk.{i}.ffn_gate.weight", f16(sd[o + "feed_forward.w1.weight"]))
        w.add_tensor(f"blk.{i}.ffn_up.weight", f16(sd[o + "feed_forward.w3.weight"]))
        w.add_tensor(f"blk.{i}.ffn_down.weight", f16(sd[o + "feed_forward.w2.weight"]))
    w.add_tensor("output_norm.weight", f32(sd["norm.weight"]))
    w.add_tensor("output.weight", f16(sd["output.weight"]))
    w.write_header_to_file(); w.write_kv_data_to_file(); w.write_tensors_to_file(); w.close()
    print("yazıldı:", a.cikti)


if __name__ == "__main__":
    main()
