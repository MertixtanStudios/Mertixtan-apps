@echo off
cd /d "%~dp0"
MertixtanOS.exe --kiosk
